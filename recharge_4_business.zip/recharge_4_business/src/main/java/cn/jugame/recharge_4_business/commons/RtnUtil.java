package cn.jugame.recharge_4_business.commons;

import com.alibaba.fastjson.JSONObject;
import org.joda.money.CurrencyUnit;
import org.joda.money.Money;

public class RtnUtil {
    public static final String CODE="code";
    public static final String MSG="msg";
    public static final String DATA="data";
    public static final int OK = 1;
    public static final int FAIL = -1;

    public static JSONObject OK(JSONObject data) {
        JSONObject o = new JSONObject();
        o.put(CODE, OK);
        o.put(MSG, "ok");
        o.put(DATA, data);
        return o;
    }

    public static JSONObject FAIL(String errorMsg) {
        JSONObject o = new JSONObject();
        o.put(CODE, FAIL);
        o.put(MSG, errorMsg);
        o.put(DATA, new JSONObject());
        return o;
    }

    public static JSONObject setResult(int code, String msg) {
        JSONObject o = new JSONObject();
        o.put(CODE, code);
        o.put(MSG, msg);
        return o;
    }

    public static void main(String[] args) {
        Money m = Money.of(CurrencyUnit.of("CNY"),25.9);
        System.out.println(m.getAmountMinorLong());
    }

}
