package cn.jugame.recharge_4_business.service.task;


import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.commons.constant.RefundStatus;
import cn.jugame.recharge_4_business.commons.constant.ZhifuStatus;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.entity.ZhifuOrderRefund;
import cn.jugame.recharge_4_business.service.IBasePayService;
import cn.jugame.recharge_4_business.service.ZhifuOrderRefundService;
import cn.jugame.recharge_4_business.service.ZhifuOrderService;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

@Component
public class QueryRefundStatusTask {

    private static Logger log = LoggerFactory.getLogger(QueryRefundStatusTask.class);


    @Autowired
    private ZhifuOrderService zhifuOrderService;

    @Autowired
    private ZhifuOrderRefundService zhifuOrderRefundService;

    @Autowired
    IBasePayService aliPayService;
    @Autowired
    IBasePayService nowPayService;
    @Autowired
    IBasePayService jhPayService;

//    @Value("${pay.task.enable.host}")
//    private String enableHost;
    private static final int retry_time_limit = 20;

    @Async
    @Scheduled(cron = "0 */30 * * * *")
    public void run() {
        log.info("查询订单第三方退款状态 任务开始...");
//        String currentHostName = "";
//        try {
//            currentHostName = InetAddress.getLocalHost().getHostName();
//        } catch (UnknownHostException e) {
//            log.error("QueryRefundStatusTask ->获取主机名异常:",e);
//            return;
//        }
//
//        if (!enableHost.equals(currentHostName)) {
//            log.info("QueryRefundStatusTask -> 当前主机名非执行定时任务的主机,不执行任务，任务退出");
//            return;
//        }
        List<ZhifuOrderRefund> list = null;
        try {
            list = zhifuOrderRefundService.queryAllRefundByStatus(RefundStatus.REFUND_APPLY_SUCCESS.getStatus(),0,50);

        } catch(Exception e) {
            log.error("查询待查退款单异常:",e);
            return;
        }
        if (null == list || list.size() <=0) {
            log.info("QueryRefundStatusTask -> 没有退款单需查询，退出.");
            return;
        }
        for(ZhifuOrderRefund refund : list) {
            String zhifuId = refund.getZhifuId();
            String orderNo = refund.getOrderNo();
            String refundNo = refund.getRefundNo();
            String payClient = refund.getPayClient();
            int retryTimes = refund.getRetryTimes();
            if(retryTimes>=retry_time_limit){//超过查询次数修改状态不再查询
                    String remark = refund.getRemark();
                    refund.setRefundStatus(-2);
                    refund.setRemark("["+remark+"][查询次数超过限制]");
                    zhifuOrderRefundService.update(refund);
                    continue;
            }
            ZhifuOrder zhifuOrder = zhifuOrderService.findByZhifuId(zhifuId);
            if (null == zhifuOrder) {
                continue;
            }
            retryTimes++;
            refund.setRetryTimes(retryTimes);
            JSONObject result = null;
            try {
                if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_ORIGIN.getChannel()){//原生渠道
                    if(refund.getPayType() == PayType.PAY_TYPE_ALIPAY.getType()) {
                        result = aliPayService.orderRefundQuery(refundNo,payClient);
                    }

                } else if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_NOWPAY.getChannel()){//现在支付渠道
                    result =  nowPayService.orderRefundQuery(refundNo,payClient);
                } else if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_JHPAY.getChannel()){//聚合支付渠道
                    result =  jhPayService.orderRefundQuery(refundNo,payClient);
                } else {
                    refund.setRefundStatus(-2);
                    refund.setRemark("订单渠道或支付类型不支持");
                    zhifuOrderRefundService.update(refund);
                    continue;
                }

                log.info("订单{} - 退款单{} 退款结果为：{}",orderNo, refundNo, result);
                String msg = result.containsKey("msg") ? result.getString("msg") : "";
                refund.setRemark(msg);
                if(result != null && result.getIntValue("code") == 1){//成功
                    //再更新一次支付单状态为已退费
                    zhifuOrder.setZhifuStatus(ZhifuStatus.REFUND.getStatus());
                    zhifuOrderService.update(zhifuOrder);

                    refund.setRefundStatus(RefundStatus.REFUND_SUCCESS.getStatus());
                    log.info("订单{} - 退款单{} 退款成功更新状态为成功", orderNo, refundNo);
                } else if(result != null && result.getIntValue("code") == 2) {//失败
                    refund.setRefundStatus(RefundStatus.REFUND_FAIL.getStatus());
                    log.info("订单{} - 退款单{} 退款失败更新状态为失败",orderNo, refundNo);
                } else if(result != null && result.getIntValue("code") == -2) {//异常无法重试
                    refund.setRefundStatus(RefundStatus.REFUND_EXCEPTION.getStatus());
                    log.info("订单{} - 退款单{} 退款失败更新状态为失败",orderNo, refundNo);
                }
                zhifuOrderRefundService.update(refund);
                Thread.sleep(300);
            } catch (Exception e) {
                log.error("订单{} - 退款单{} 退款查询异常：{}",orderNo, refundNo, e);
            }
        }

        log.info("查询订单第三方退款状态 任务结束");
    }
}
