package cn.jugame.recharge_4_business.mapper;

import cn.jugame.recharge_4_business.entity.ZhifuOrderRefund;
import cn.jugame.recharge_4_business.handler.MoneyTypeHandler;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Description:
 * @Author: sueyoung
 * @Date: 2019-07-17 17:13
 * @Param: 
 * @Return: 
 */
@Repository
@Mapper
public interface ZhifuOrderRefundMapper {
  @Insert("insert into zhifu_order_refund (`zhifu_id`, `order_no`, `uid`" +
          ",`refund_no`,`refund_amount`,`pay_type`,`pay_client`,`refund_status`,`remark`,`retry_times`,`create_time`,`update_time`) " +
          "values(#{zhifuId}, #{orderNo}, #{uid}, #{refundNo},#{refundAmount,jdbcType=INTEGER,typeHandler=cn.jugame.recharge_4_business.handler.MoneyTypeHandler}, #{payType}," +
          "#{payClient},#{refundStatus},#{remark},#{retryTimes},now(),now())")
  int save(ZhifuOrderRefund refund);

  @Select("select * from `zhifu_order_refund` where zhifu_id = #{zhifuId} limit 1")
  @Results({@Result(column="refund_amount",property="refundAmount", jdbcType = JdbcType.INTEGER, typeHandler = MoneyTypeHandler.class)})
  ZhifuOrderRefund findFirstByZhifuId(@Param("zhifuId") String zhifuId);

  @Select("select * from `zhifu_order_refund`")
  @Results({@Result(column="refund_amount",property="refundAmount", jdbcType = JdbcType.INTEGER, typeHandler = MoneyTypeHandler.class)})
  List<ZhifuOrderRefund> findAll();


  @Update({
          "update zhifu_order_refund",
          "set order_no = #{orderNo},",
          "uid = #{uid},",
          "refund_no = #{refundNo},",
          "refund_amount = #{refundAmount,jdbcType=INTEGER,typeHandler=cn.jugame.recharge_4_business.handler.MoneyTypeHandler},",
          "pay_type = #{payType},",
          "pay_client = #{payClient},",
          "refund_status = #{refundStatus},",
          "remark = #{remark},",
          "retry_times = #{retryTimes},",
          "update_time = now() ",
          "where id = #{id}"
  })
  int updateById(ZhifuOrderRefund refund);

    @Update({
            "update zhifu_order_refund",
            "set order_no = #{orderNo},",
            "uid = #{uid},",
            "refund_no = #{refundNo},",
            "refund_amount = #{refundAmount,jdbcType=INTEGER,typeHandler=cn.jugame.recharge_4_business.handler.MoneyTypeHandler},",
            "pay_type = #{payType},",
            "pay_client = #{payClient},",
            "refund_status = #{refundStatus},",
            "remark = #{remark},",
            "retry_times = #{retryTimes},",
            "update_time = now() ",
            "where zhifu_id = #{zhifuId}"
    })
    int updateByZhifuId(ZhifuOrderRefund refund);

  @Select("select * from `zhifu_order_refund` where refund_status = #{refundStatus} limit #{start},#{size}")
  @Results({@Result(column="refund_amount",property="refundAmount", jdbcType = JdbcType.INTEGER, typeHandler = MoneyTypeHandler.class)})
  List<ZhifuOrderRefund> queryAllRefundByRefundStatus(@Param("refundStatus") int refundStatus, @Param("start") int start, @Param("size") int size);
}
