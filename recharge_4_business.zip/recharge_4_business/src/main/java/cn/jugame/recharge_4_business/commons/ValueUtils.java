package cn.jugame.recharge_4_business.commons;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ValueUtils {

  private static Logger log = LoggerFactory.getLogger(ValueUtils.class.getSimpleName());
  /**
   * 值是否有效
   */
  public static boolean has(Integer value) {
    return value != null && value > 0;
  }

  /**
   * 值是否有效
   */
  public static boolean has(Long value) {
    return value != null && value > 0;
  }

  public static Long def(Long value, long def) {
    return value != null ? value : def;
  }

  public static interface Express<R> {
    R execute();
  }

  /**
   * 安全获取值
   * <p>性能有待商榷,尽量不要使用</p>
   */
  public static <R> R safeGet(Express<R> express) {
    try {
      return express.execute();
    } catch (Exception e) {
      return null;
    }
  }
}
