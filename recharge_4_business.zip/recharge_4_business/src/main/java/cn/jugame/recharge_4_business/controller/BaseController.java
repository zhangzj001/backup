package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.core.HibernateProxyTypeAdapter;
import cn.jugame.recharge_4_business.core.NullStringToEmptyAdapterFactory;
import cn.jugame.recharge_4_business.entity.Query;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.ui.Model;

public abstract class BaseController {

  private static final Gson gson = new GsonBuilder()
      .registerTypeAdapterFactory(new NullStringToEmptyAdapterFactory()).registerTypeAdapterFactory(
          HibernateProxyTypeAdapter.FACTORY).setFieldNamingPolicy(
          FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).setDateFormat("yyyy-MM-dd HH:mm:ss")
      .create();

  protected void addAttribute(Model model, String key, List value) {
    JSONArray arr = new JSONArray();
    for (Object item : value) {
      String objstr = gson.toJson(item);
      JSONObject jsonObj = JSONObject.fromObject(objstr);
      arr.add(jsonObj);
    }
    model.addAttribute(key, arr);
  }

  protected void addAttribute(Model model, String key, Object value) {
    if (value instanceof Integer || value instanceof String || value instanceof Long) {
      model.addAttribute(key, value);
    } else {
      String objstr = gson.toJson(value);
      model.addAttribute(key, JSONObject.fromObject(objstr));
    }
  }

  protected String getParam(HttpServletRequest request, String name, String defaultValue) {
    String value = request.getParameter(name);
    return StringUtils.isBlank(value) ? defaultValue : request.getParameter(name);
  }

  protected String getParam(HttpServletRequest request, String name) {
    return getParam(request, name, "");
  }

  protected int getParamToInt(HttpServletRequest request, String name, int defaultValue) {
    String value = getParam(request, name);
    if (StringUtils.isNumeric(value)) {
      return Integer.parseInt(value);
    } else {
      return defaultValue;
    }
  }

  protected long getParamToLong(HttpServletRequest request, String name, long defaultValue) {
    String value = getParam(request, name);
    if (StringUtils.isNumeric(value)) {
      return Long.parseLong(value);
    } else {
      return defaultValue;
    }
  }

  protected int getParamToInt(HttpServletRequest request, String name) {
    return getParamToInt(request, name, 0);
  }

  protected double getParamToDouble(HttpServletRequest request, String name, double defaultValue) {
    String value = getParam(request, name);
    if (StringUtils.isNumeric(value)) {
      return Double.parseDouble(value);
    } else {
      return defaultValue;
    }
  }

  protected double getParamToDouble(HttpServletRequest request, String name) {
    return getParamToDouble(request, name, 0f);
  }

  private static final String[] IP_HEADER_CANDIDATES = {
      "x-real-ip",
      "X-Forwarded-For",
      "Proxy-Client-IP",
      "WL-Proxy-Client-IP",
      "HTTP_X_FORWARDED_FOR",
      "HTTP_X_FORWARDED",
      "HTTP_X_CLUSTER_CLIENT_IP",
      "HTTP_CLIENT_IP",
      "HTTP_FORWARDED_FOR",
      "HTTP_FORWARDED",
      "HTTP_VIA",
      "REMOTE_ADDR"};

  public String getIp(HttpServletRequest request) {
    for (String header : IP_HEADER_CANDIDATES) {
      String h = request.getHeader(header.toLowerCase());
      if (StringUtils.isNotEmpty(h) && !"unknown".equalsIgnoreCase(h)) {
        return h;
      }
    }
    return request.getRemoteAddr();
  }

  protected String htmlEncode(String str) {
    if (str == null) {
      return null;
    }
    str = str.replaceAll("<", "&lt;");
    str = str.replaceAll(">", "&gt;");

    //替换掉一些utf8的四字节内容！
    str = str.replaceAll("[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]", "");

    return str;
  }

  protected JSONObject buildSuccResp(JSONObject data, String msg) {
    JSONObject obj = new JSONObject();
    obj.put("code", 1);
    obj.put("msg", msg);
    obj.put("data", data);
    return obj;
  }

  /**
   * 将字符串金额（单位元）转成整型分
   */
  protected int toFen(String money) {
    if (StringUtils.isBlank(money)) {
      return 0;
    }
    try {
      double yuan = Double.parseDouble(money);
      return (int) (yuan * 100);
    } catch (Exception e) {
      return 0;
    }
  }

  private static Map<Integer, String> orderStatusMap = new HashMap();
  private static Map<Integer, String> productStatusMap = Maps.newHashMap();

  static {
    orderStatusMap.put(0, "未付款");
    orderStatusMap.put(2, "已支付");
    orderStatusMap.put(6, "交易完成");
    orderStatusMap.put(8, "交易取消");
    orderStatusMap.put(100, "未付款");
    //商品状态3 审核 7 上架 8 下架 201：出租中 202：保护期
    productStatusMap.put(3, "审核");
    productStatusMap.put(7, "上架");
    productStatusMap.put(8, "下架");
    productStatusMap.put(201, "出租中");
    productStatusMap.put(202, "保护期");
  }

  public static String getOrderStatusName(int status) {
    return orderStatusMap.get(status);
  }

  public static String getProductStatusName(int status) {
    return productStatusMap.get(status);
  }

  protected void initPages(Model model, long totalNum, int totalPage, int currentPage, int offset,
      int limit) {
    List<Integer> pages = Lists.newArrayList();
    for (int i = -3; i <= 3; ++i) {
      int p = currentPage + i;
      if (p < 1 || p > totalPage) {
        continue;
      }
      pages.add(p);
    }
    model.addAttribute("current_page", currentPage);
    model.addAttribute("total_num", totalNum);
    model.addAttribute("total_page", totalPage);
    model.addAttribute("show_pages", pages);
    model.addAttribute("limit", limit);
    model.addAttribute("offset", offset);
  }

  protected String generateOrderNo(String bussinessType) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd-HHmmssSSS");
    Random rand = new Random();
    return bussinessType + "-" + sdf.format(new Date()) + String.format("%02d", rand.nextInt(100));
  }

  public static Date dateValue(String v, String fm, Date def) {
    if (v == null || v.length() == 0) {
      return def;
    }
    try {
      return new SimpleDateFormat(fm).parse(v.trim());
    } catch (Exception e) {
      return def;
    }
  }

  public static Date dateValue(String v, Date def) {
    return dateValue(v, "yyyy-MM-dd HH:mm:ss", def);
  }

  public static boolean isNumeric(String str) {
    return str.matches("-?[0-9]+.*[0-9]*");
  }

  protected void initQuery(Query query, HttpServletRequest request) {
    Field[] fields = query.getClass().getFields();
    for (Field f : fields) {
      String name = f.getName();
      String v = request.getParameter(name);
      if (StringUtils.isNotEmpty(v) && !"undefined".equalsIgnoreCase(v)) {
        Class type = f.getType();
        if (type == int.class || type == Integer.class) {
          try {
            f.set(query, Integer.parseInt(v));
          } catch (IllegalAccessException e) {
          }
        } else if (type == String.class) {
          try {
            f.set(query, v);
          } catch (IllegalAccessException e) {
          }
        }
      }
    }
  }
}
