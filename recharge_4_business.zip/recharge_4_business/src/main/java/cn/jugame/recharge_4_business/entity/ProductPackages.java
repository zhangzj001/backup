package cn.jugame.recharge_4_business.entity;

import com.alibaba.fastjson.annotation.JSONField;
import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by solom on 2019-07-17. ClassName: ProductPackage Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-17 13:47
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductPackages implements Serializable {
  private int id;
  private int productId;
  private String name;
  private int productNum;
  private int type;//类型，1：Q币，2：视频会员
  private String thirdProductCode; //第三方产品编号
  private int thirdProductPrice; //第三方产品价格
  private int packagePrice = 0;
  private int status;
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date createTime;
}
