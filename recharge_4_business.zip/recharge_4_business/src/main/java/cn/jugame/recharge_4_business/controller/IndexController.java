package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.commons.CookieUtil;
import cn.jugame.recharge_4_business.commons.ProductType;
import cn.jugame.recharge_4_business.configs.JymConstants;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.entity.Product;
import cn.jugame.recharge_4_business.entity.ProductPackages;
import cn.jugame.recharge_4_business.filter.JymLoginFilter;
import cn.jugame.recharge_4_business.service.OrderService;
import cn.jugame.recharge_4_business.service.ProductService;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by solom on 2019-07-17. ClassName: IndexController Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-17 11:41
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Controller
public class IndexController extends BaseController {

    protected static Logger log = LoggerFactory.getLogger(IndexController.class);

    @Autowired
    private ProductService productService;
    @Autowired
    private OrderService orderService;
    @Value("${discount}")
    private double discount;

    @RequestMapping("/")
    public String index1(HttpServletRequest request, HttpServletResponse response, HttpSession session,
                         Model model) throws IOException {
        String fr = getParam(request, "fr", "");
        if (StringUtils.isNotEmpty(fr)) {
            session.setAttribute("recharge_4_business_ch", fr);
        }
        response.sendRedirect("/qb.html");
        return null;
    }

    @RequestMapping("index.html")
    public String index(HttpServletRequest request, HttpServletResponse response, HttpSession session,
                        Model model) throws IOException {
        String fr = getParam(request, "fr", "");
        if (StringUtils.isNotEmpty(fr)) {
            session.setAttribute("recharge_4_business_ch", fr);
        }
        response.sendRedirect("/qb.html");
        return null;
    }

    @RequestMapping("qb.html")
    public String qb(HttpServletRequest request, HttpServletResponse response, HttpSession session,
                     Model model) {
        String fr = getParam(request, "fr", "");
        if (StringUtils.isNotEmpty(fr)) {
            session.setAttribute("recharge_4_business_ch", fr);
        }
        Product p = productService.findAllQBProduct();
        BigDecimal b = new BigDecimal(p.getPrice());
        p.setPrice(b.multiply(new BigDecimal(discount)).intValue());
        model.addAttribute("product", p);
        return "qb";
    }

    @RequestMapping("vip.html")
    public String vip(HttpServletRequest request, HttpServletResponse response, HttpSession session,
                      Model model) {
        String fr = getParam(request, "fr", "");
        if (StringUtils.isNotEmpty(fr)) {
            session.setAttribute("recharge_4_business_ch", fr);
        }
        model.addAttribute("products", productService.findAllVIPProduct());
        return "vip";
    }

    @RequestMapping("create_order.html")
    public String createOrder(HttpServletRequest request, HttpServletResponse response,
                              HttpSession session, Model model) throws IOException {
        String account = getParam(request, "account", "");
        String ip = getIp(request);
        int packageId = getParamToInt(request, "packageId", -1);
        int productId = getParamToInt(request, "productId", -1);

        String fr = "web";
        String ua = request.getHeader("User-Agent");
        if (StringUtils.isNotEmpty(ua) && (ua.contains("cn.jhw.hwzh") || ua.contains("cn.jugame.assistant"))) {
            fr = "app";
        }
        String ch = (String) session.getAttribute("recharge_4_business_ch");

        Integer uid = (Integer) session.getAttribute("uid");
        if (uid == null || uid < 0) {
            model.addAttribute("errorMsg", "请先登录");
            return "error";
        }
        if (StringUtils.isEmpty(account)) {
            model.addAttribute("errorMsg", "请输入需要充值的账号");
            return "error";
        }
        Product p = null;
        ProductPackages packages = null;
        if (packageId <= 0 && productId <= 0) {
            model.addAttribute("errorMsg", "请选择商品");
            return "error";
        }
        int productNum = 0;
        int price = 0;
        int amount = 0;
        int productType = -1;
        String productName = "";
        String packageName = "";
        String productNo = "";
        String thirdProductCode = "";
        int thirdProductPrice = 0;
        String productDesc = "";
        if (packageId <= 0) { //没选套餐的情况下，必须有商品数量
            productNum = getParamToInt(request, "num", 1);
            p = productService.findById(productId);
            BigDecimal b = new BigDecimal(p.getPrice());
            amount = (b.multiply(new BigDecimal(discount)).intValue() * productNum) / 10;
            productType = p.getType();
            productName = p.getName();
            productNo = p.getProductNo();
            productDesc = p.getProductDesc();
            packageName = "【" + p.getName() + "】" + productNum + (p.getType() == ProductType.QCoin.value() ? "个Q币" : "会员天");
        } else {
            packages = productService.findPackagesById(packageId);
            p = productService.findById(packages.getProductId());
            productNum = packages.getProductNum();
            amount = price = packages.getPackagePrice();
            productType = packages.getType();
            productName = p.getName();
            packageName = "【" + p.getName() + "】" + packages.getName();
            productId = packages.getProductId();
            productNo = p.getProductNo();
            productDesc = p.getProductDesc();
            thirdProductCode = packages.getThirdProductCode();
            thirdProductPrice = packages.getThirdProductPrice();
        }
        String orderNo = generateOrderNo("RG");

        //如果有交易猫的UID
        String externUid = "";
        String externChannel = "";
        Object jymUid = request.getSession().getAttribute(JymConstants.SESSION_JYM_USER_ID);
        if (jymUid != null) {
            externUid = String.valueOf(jymUid);
            externChannel = "jym";
        }
        model.addAttribute("externUid", externUid);
        model.addAttribute("externChannel", externChannel);

        OrderInfo orderInfo = OrderInfo.builder().orderNo(orderNo).orderTime(new Date())
                .orderStatus(0).uid(uid).rechargeAccount(account).fr(fr).ch(ch).amount(amount)
                .productNum(productNum).productNo(productNo).productName(productName)
                .thirdProductCode(thirdProductCode).thirdProductPrice(thirdProductPrice).productDesc(productDesc)
                .productType(productType).packageId(packageId).productId(productId).packageName(productName)
                .ip(ip)
                .packageName(packageName)
                .externUid(externUid).externChannel(externChannel)
                .build();
        if (!orderService.addOrder(orderInfo)) {
            model.addAttribute("errorMsg", "系统错误");
            return "error";
        }
        model.addAttribute("order", orderInfo);
        return "pay";
    }

    @RequestMapping("order_list.html")
    public String orderList(HttpServletRequest request, HttpServletResponse response,
                            HttpSession session, Model model) throws IOException {
        Integer uid = (Integer) session.getAttribute("uid");
        if (uid == null || uid < 0) {
            model.addAttribute("errorMsg", "请先登录");
            return "error";
        }
        int status = getParamToInt(request, "status", -1);
        String statusList = "1,2,3,4";
        switch (status) {
            case 1:
                statusList = "1,2";
                break;
            case 2:
                statusList = "3";
                break;
            default:
                break;
        }
        model.addAttribute("status", status);
        model.addAttribute("orders", orderService.queryUserOrder(uid, statusList, 0, 10));
        return "order_list";
    }

    @RequestMapping("_order_list.html")
    public String orderSubList(HttpServletRequest request, HttpServletResponse response,
                               HttpSession session, Model model) throws IOException {
        Integer uid = (Integer) session.getAttribute("uid");
        if (uid == null || uid < 0) {
            model.addAttribute("errorMsg", "请先登录");
            return "error";
        }
        int status = getParamToInt(request, "status", -1);
        int pagetNo = getParamToInt(request, "pageNo", 1);
        int pagetSize = getParamToInt(request, "pagetSize", 10);
        String statusList = "1,2,3";
        switch (status) {
            case 1:
                statusList = "1,2";
                break;
            case 2:
                statusList = "3";
                break;
            default:
                break;
        }
        if (pagetNo > 0) {
            pagetNo = (pagetNo - 1) * pagetSize;
        }
        List<OrderInfo> orders = orderService.queryUserOrder(uid, statusList, pagetNo, pagetSize);
        model.addAttribute("orders", orders);
        if (orders == null || orders.size() <= 0) {
            return "_empty";
        }
        return "_order";
    }

    @RequestMapping("order_detail.html")
    public String orderDetail(HttpServletRequest request, HttpServletResponse response,
                              HttpSession session, Model model) throws IOException {
        Integer uid = (Integer) session.getAttribute("uid");
        if (uid == null || uid <= 0) {
            model.addAttribute("errorMsg", "请先登录");
            return "error";
        }

        //如果有交易猫的UID
        String externUid = "";
        String externChannel = "";
        Object jymUid = request.getSession().getAttribute(JymConstants.SESSION_JYM_USER_ID);
        if (jymUid != null) {
            externUid = String.valueOf(jymUid);
            externChannel = "jym";
        }
        model.addAttribute("externUid", externUid);
        model.addAttribute("externChannel", externChannel);

        String orderNo = getParam(request, "orderNo", "");
        OrderInfo orderInfo = orderService.queryUserOrder(uid, orderNo);
        if(orderInfo == null){
            model.addAttribute("errorMsg", "不存在的订单");
            return "error";
        }
        model.addAttribute("order", orderInfo);
        return "order_detail";
    }
}
