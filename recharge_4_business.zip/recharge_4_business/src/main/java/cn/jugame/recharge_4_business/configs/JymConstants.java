package cn.jugame.recharge_4_business.configs;

public class JymConstants {
    public final static String SESSION_JYM_USER_ID = "jym-user-id";
    public final static String SESSION_JYM_USER_NAME = "jym-user-name";
    public final static String SESSION_CHANNEL_NAME = "jym";
}
