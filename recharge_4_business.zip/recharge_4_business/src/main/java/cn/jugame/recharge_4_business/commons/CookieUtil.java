package cn.jugame.recharge_4_business.commons;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by solom on 2019/2/15. ClassName: CookieUtil Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-02-15 10:43
 *
 * @author: solom
 * @since: jdk 1.7
 */
public class CookieUtil {
  public static void setCookie(HttpServletRequest request, HttpServletResponse response,
      String name, String value, int maxAge) {
    Cookie cookie = new Cookie(name, value);
    if (maxAge > 0) {
      cookie.setMaxAge(maxAge);
    }

    cookie.setPath("/");
    String serverName = request.getServerName();
    if (serverName.contains("8868.cn")) {
      cookie.setDomain("8868.cn");
    } else if (serverName.contains("8868.com")) {
      cookie.setDomain("8868.com");
    } else if (serverName.contains("8868test.lo")) {
      cookie.setDomain("8868test.lo");
    }

    response.addCookie(cookie);
  }

  public static String getCookie(HttpServletRequest request, String name) {
    Map<String, Cookie> cookieMap = readCookieMap(request);
    if (cookieMap.containsKey(name)) {
      Cookie cookie = (Cookie) cookieMap.get(name);
      return cookie.getValue();
    } else {
      return null;
    }
  }

  public static void removeCookie(HttpServletRequest request, HttpServletResponse response,
      String name) {
    Map<String, Cookie> cookieMap = readCookieMap(request);
    if (cookieMap.containsKey(name)) {
      Cookie cookie = (Cookie) cookieMap.get(name);
      cookie.setPath("/");
      String serverName = request.getServerName();
      if (serverName.contains("8868.cn")) {
        cookie.setDomain(".8868.cn");
      } else if (serverName.contains("8868.com")) {
        cookie.setDomain(".8868.com");
      } else if (serverName.contains("8868test.lo")) {
        cookie.setDomain(".8868test.lo");
      }

      cookie.setValue((String) null);
      cookie.setMaxAge(0);
      response.addCookie(cookie);
    }

  }

  private static Map<String, Cookie> readCookieMap(HttpServletRequest request) {
    Map<String, Cookie> cookieMap = new HashMap();
    Cookie[] cookies = request.getCookies();
    if (null != cookies) {
      Cookie[] var3 = cookies;
      int var4 = cookies.length;

      for (int var5 = 0; var5 < var4; ++var5) {
        Cookie cookie = var3[var5];
        cookieMap.put(cookie.getName(), cookie);
      }
    }

    return cookieMap;
  }
}