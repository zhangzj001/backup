package cn.jugame.recharge_4_business.commons;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by solom on 2019-05-10. ClassName: DateUtils Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-05-10 11:14
 *
 * @author: solom
 * @since: jdk 1.8
 */
public final class DateUtils {

  public static DateFormat FORMAT_DATETIME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  public static DateFormat YMD_FORMAT_DATETIME = new SimpleDateFormat("yyyy-MM-dd");

  public static String getDateFormatString(String formatStr) {
    DateFormat df = new SimpleDateFormat(formatStr);
    return df.format(new Date());
  }


  public static Date parseDate(String gmtPayment, String formatStr) {
    DateFormat df = new SimpleDateFormat(formatStr);
    try {
      return df.parse(gmtPayment);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return new Date();
  }

  public static Date addDay(Date sDate, int days) {
    Calendar calendar = new GregorianCalendar();
    calendar.setTime(sDate);
    calendar.add(calendar.DATE, days);// 把日期往后增加days天.整数往后推,负数往前移动
    return calendar.getTime();
  }

  public static String addMinute(Date date, int minute, String format) {
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    cal.add(Calendar.MINUTE, minute);
    return new SimpleDateFormat(format).format(new Date(cal.getTime().getTime()));
  }

  public static String parseDate2Str(Date date, String format) {
    if (date == null || StringUtils.isEmpty(format)) {
      return null;
    }
    return new SimpleDateFormat(format).format(date);
  }

  public static String parseDate2Str(Date date) {
    return YMD_FORMAT_DATETIME.format(date);
  }
}
