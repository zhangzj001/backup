package cn.jugame.recharge_4_business.controller.admin;

import cn.jugame.recharge_4_business.commons.ProductType;
import cn.jugame.recharge_4_business.controller.BaseController;
import cn.jugame.recharge_4_business.entity.Product;
import cn.jugame.recharge_4_business.entity.ProductPackages;
import cn.jugame.recharge_4_business.entity.Query;
import cn.jugame.recharge_4_business.service.ProductService;
import cn.juhaowan.jiaoyi.manage.sso.client.SysUserInfo;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by solom on 2019-07-19. ClassName: AdminIndexController Function: TODO ADD FUNCTION.
 * <br/> Date: 2019-07-19 14:39
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Controller
@RequestMapping("/admin/product/")
public class AdminProductController extends BaseController {

  @Data
  public static class ListQuery extends Query {
    public String productNo;
    public int productType;
    public int status = -1;
  }

  @Autowired
  private ProductService productService;
  Logger logger = LoggerFactory.getLogger(AdminProductController.class);

  @RequestMapping("list.html")
  public String list(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    return "admin/product/list";
  }

  @RequestMapping("pagelist.html")
  @ResponseBody
  public String listPage(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    ListQuery query = new ListQuery();
    initQuery(query, request);
    List<Product> productList = productService.queryAllProduct(query);
    Map<String, Object> map = Maps.newHashMap();
    map.put("rows", productList);
    map.put("total", productService.count(query));
    String str = JSONObject.toJSONString(map);
    return str;
  }

  @RequestMapping("add.html")
  @ResponseBody
  public String add(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    int type = getParamToInt(request, "type", 1);
    String price = getParam(request, "price", "1");
    String remark = getParam(request, "remark", "");
    String productDesc = getParam(request, "product_desc", "");
    String discount = getParam(request, "discount", "1");
    int status = getParamToInt(request, "status", 0);
    String name = getParam(request, "name", "");
    JSONObject json = new JSONObject();
    if (!isNumeric(price)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    if (!isNumeric(discount)) {
      json.put("code", 0);
      json.put("msg", "折扣不能为0");
      return json.toJSONString();
    }
    BigDecimal priceBD = new BigDecimal(price);
    BigDecimal discountBD = new BigDecimal(discount);

    if (discountBD.compareTo(new BigDecimal(0)) <= 0) {
      json.put("code", 0);
      json.put("msg", "折扣不能小于0");
      return json.toJSONString();
    }

    if ((type == ProductType.QCoin.value() && priceBD.compareTo(new BigDecimal(0.0)) <= 0)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    if (type == ProductType.QCoin.value() && productService.countQCProduct() == 1) {
      json.put("code", 0);
      json.put("msg", "Q币商品已经存在，请勿再加");
      return json.toJSONString();
    }
    Product p = Product.builder().type(type).price(priceBD.multiply(new BigDecimal(100)).intValue())
        .name(name).remark(remark)
        .productDesc(productDesc).status(status).build();
    p.setProductNo(generateOrderNo("PRO"));
    productService.save(p);
    json.put("code", 1);
    json.put("msg", "新增成功");
    return json.toJSONString();
  }

  @RequestMapping("update.html")
  @ResponseBody
  public String update(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    int id = getParamToInt(request, "id", -1);
    String price = getParam(request, "price", "0");
    String remark = getParam(request, "remark", "");
    String productDesc = getParam(request, "product_desc", "");
    int status = getParamToInt(request, "status", 0);
    JSONObject json = new JSONObject();
    Product p = productService.findById(id);
    if (p == null) {
      json.put("code", 0);
      json.put("msg", "商品不存在");
      return json.toJSONString();
    }
    if (!isNumeric(price)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    BigDecimal priceBD = new BigDecimal(price);

    if ((p.getType() == ProductType.QCoin.value() && priceBD.compareTo(new BigDecimal(0.0)) <= 0)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    if (priceBD.multiply(new BigDecimal(100)).intValue() != p.getPrice()) {
      SysUserInfo adminUser = (SysUserInfo) session.getAttribute("admin_user");
      logger.error(
          "用户" + adminUser.getFullname() + "【" + adminUser.getUserId() + "】修改了商品：" + p.getName()
              + "的价格:" + (p.getPrice() / 100.0) + "->" + price);
    }
    p.setStatus(status);
    p.setRemark(remark);
    p.setProductDesc(productDesc);
    p.setPrice(priceBD.multiply(new BigDecimal(100)).intValue());
    productService.update(p);
    json.put("code", 1);
    json.put("msg", "修改成功");
    return json.toJSONString();
  }

  @RequestMapping("delete.html")
  @ResponseBody
  public String delete(HttpServletRequest req, HttpServletResponse resp, Model model) {
    JSONObject json = new JSONObject();
    String idstr = getParam(req, "ids");
    if (!StringUtils.isEmpty(idstr)) {
      if (productService.deleteByIds(idstr)) {
        json.put("code", 1);
        json.put("msg", "删除成功");
      }
    } else {
      json.put("code", 0);
      json.put("msg", "删除失败");
    }
    json.put("code", 1);
    json.put("msg", "删除成功");
    return json.toJSONString();
  }

  @RequestMapping("packages.html")
  @ResponseBody
  public String packages(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    int id = getParamToInt(request, "id", -1);
    int pageNo = getParamToInt(request, "page", 1);
    int pageSize = getParamToInt(request, "rows", 50);
    Map<String, Object> map = Maps.newHashMap();
    map.put("rows", productService.findAllPackages(id, pageNo, pageSize));
    map.put("total", productService.countAllByProductId(id));
    String str = JSONObject.toJSONString(map);
    return str;
  }

  @RequestMapping("add_pkg.html")
  @ResponseBody
  public String addPackage(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    int productId = getParamToInt(request, "productId", -1);
    Product p = productService.findById(productId);
    JSONObject json = new JSONObject();
    if (p == null) {
      json.put("code", 0);
      json.put("msg", "商品不存在");
      return json.toJSONString();
    }
    String name = getParam(request, "pkg_name", "");
    int productNum = getParamToInt(request, "product_num", 1);
    String price = getParam(request, "pkg_price", "0");

    if (!isNumeric(price)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    BigDecimal priceBD = new BigDecimal(price);

    if ((p.getType() == ProductType.QCoin.value() && priceBD.compareTo(new BigDecimal(0.0)) <= 0)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    String thirdProductCode = getParam(request, "third_product_code", "");
    int thirdProductPrice = getParamToInt(request, "third_product_price", 100);
    thirdProductPrice = thirdProductPrice * 100;
    ProductPackages pkg = ProductPackages.builder()
        .productNum(productNum).productId(productId).type(p.getType())
        .status(1).name(name).thirdProductCode(thirdProductCode)
        .thirdProductPrice(thirdProductPrice)
        .packagePrice(priceBD.multiply(new BigDecimal(100)).intValue()).build();
    productService.savePkg(pkg);
    json.put("code", 1);
    json.put("msg", "新增成功");
    return json.toJSONString();
  }

  @RequestMapping("delete_pkg.html")
  @ResponseBody
  public String deletePkg(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    JSONObject json = new JSONObject();
    String idstr = getParam(request, "ids");
    if (!StringUtils.isEmpty(idstr)) {
      if (productService.deletePkgByIds(idstr)) {
        json.put("code", 1);
        json.put("msg", "删除成功");
      }
    } else {
      json.put("code", 0);
      json.put("msg", "删除失败");
    }
    return json.toJSONString();
  }

  @RequestMapping("update_pkg.html")
  @ResponseBody
  public String updatePkg(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    int id = getParamToInt(request, "id", -1);
    String price = getParam(request, "pkg_price", "0");
    String pkgName = getParam(request, "pkg_name", "");
    String thirdProductCode = getParam(request, "third_product_code", "");
    int productNum = getParamToInt(request, "product_num", 1);
    int thirdProductPrice = getParamToInt(request, "third_product_price", 100);

    JSONObject json = new JSONObject();
    ProductPackages p = productService.findPackagesById(id);
    if (p == null) {
      json.put("code", 0);
      json.put("msg", "套餐不存在");
      return json.toJSONString();
    }
    if (!isNumeric(price)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    BigDecimal priceBD = new BigDecimal(price);

    if ((p.getType() == ProductType.QCoin.value() && priceBD.compareTo(new BigDecimal(0.0)) <= 0)) {
      json.put("code", 0);
      json.put("msg", "单价不能小于0");
      return json.toJSONString();
    }
    if (priceBD.multiply(new BigDecimal(100)).intValue() != p.getPackagePrice()) {
      SysUserInfo adminUser = (SysUserInfo) session.getAttribute("admin_user");
      logger.error(
          "用户" + adminUser.getFullname() + "【" + adminUser.getUserId() + "】修改了商品：" + p.getName()
              + "的价格:" + (p.getPackagePrice() / 100.0) + "->" + price);
    }
    p.setPackagePrice(priceBD.multiply(new BigDecimal(100)).intValue());
    p.setName(pkgName);
    p.setThirdProductCode(thirdProductCode);
    p.setThirdProductPrice(thirdProductPrice * 100);
    p.setProductNum(productNum);
    productService.updatePkg(p);
    json.put("code", 1);
    json.put("msg", "修改成功");
    return json.toJSONString();
  }
}
