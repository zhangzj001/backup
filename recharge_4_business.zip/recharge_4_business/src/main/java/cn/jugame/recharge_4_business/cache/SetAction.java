package cn.jugame.recharge_4_business.cache;

@FunctionalInterface
public interface SetAction {

  void set(String key, Object value) throws Exception;
}