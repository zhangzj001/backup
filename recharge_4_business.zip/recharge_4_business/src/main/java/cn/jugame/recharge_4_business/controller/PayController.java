package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.service.OrderService;
import cn.jugame.recharge_4_business.service.PayService;
import cn.jugame.recharge_4_business.service.payrequest.BasePayReq;
import com.alibaba.fastjson.JSONObject;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by solom on 2019-07-23. ClassName: PayController Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-23 14:22
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Controller
@RequestMapping("/pay/")
public class PayController extends BaseController{

  @Autowired
  private OrderService orderService;
  @Autowired
  private PayService payService;

  @RequestMapping("index.html")
  public String pay(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    String orderNo = getParam(request, "orderNo", "");
    Integer uid = (Integer) session.getAttribute("uid");
    if (uid == null || uid < 0) {
      model.addAttribute("errorMsg", "请先登录");
      return "error";
    }

    //是否微信中打开
    String ua = request.getHeader("User-Agent");
    String platform = "wap";
    if(!StringUtils.isEmpty(ua) && ua.contains("MicroMessenger")){//公众号，现在支付说公众号退不了款，呵呵，直接屏蔽
      platform = "gzh";
    }

    OrderInfo orderInfo = orderService.queryUserOrder(uid, orderNo);
    if(orderInfo == null){
      model.addAttribute("errorMsg", "订单信息错误");
      return "error";
    }

    int payType = getParamToInt(request, "payType", 1);
    //更新订单的支付方式
    orderService.updatePayType(orderInfo.getId(), payType);
    orderInfo.setPayType(payType);
    JSONObject resObj = payService.wapPay(BasePayReq.convert(orderInfo,platform));
    model.addAttribute("html", resObj.getJSONObject("data").getString("hmtlStr"));
    return "user/pay";
  }
}
