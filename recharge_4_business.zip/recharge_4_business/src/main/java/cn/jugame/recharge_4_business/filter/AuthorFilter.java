package cn.jugame.recharge_4_business.filter;

import cn.jugame.recharge_4_business.configs.SSOClientChecker;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@Component
@Order(2)
@WebFilter(filterName = "AuthorFilter", urlPatterns = "/admin/*")
public class AuthorFilter implements Filter {

  @Autowired
  private SSOClientChecker checker;

  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
    SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response,
      FilterChain chain) throws IOException, ServletException {
    //获取uri地址
    HttpServletRequest req = (HttpServletRequest) request;
    String uri = req.getRequestURI();
    String ctx = req.getContextPath();
    uri = uri.substring(ctx.length());
    if (uri.startsWith("/admin")) {
      if (!checker.check(req)) {
        request.setAttribute("errorMsg", "身份验证错误！");
        request.getRequestDispatcher("/error.html").forward(request, response);
        return;
      } else {
        chain.doFilter(request, response);
      }
    } else {
      chain.doFilter(request, response);
    }
  }

  @Override
  public void destroy() {

  }
}
