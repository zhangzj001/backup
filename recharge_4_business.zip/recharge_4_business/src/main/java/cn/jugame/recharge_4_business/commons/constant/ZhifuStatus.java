package cn.jugame.recharge_4_business.commons.constant;

public enum ZhifuStatus {
    INIT(0,"初始状态"),
    PAY_FAIL(1,"支付失败"),
    PAY_SUCCESS(2,"支付成功"),
    REFUND(3,"已退费");

    private int status;
    private String desc;

    private ZhifuStatus(int s,String d){
        this.status = s;
        this.desc = d;
    }

    public int getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    };
}
