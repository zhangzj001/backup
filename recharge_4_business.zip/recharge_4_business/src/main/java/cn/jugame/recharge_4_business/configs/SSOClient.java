package cn.jugame.recharge_4_business.configs;

import cn.jugame.recharge_4_business.commons.HttpRequestUtil;
import cn.jugame.recharge_4_business.commons.MD5;
import cn.juhaowan.jiaoyi.manage.sso.client.SysModule;
import cn.juhaowan.jiaoyi.manage.sso.client.SysUserInfo;
import cn.juhaowan.jiaoyi.manage.sso.client.SysUserPermission;
import cn.juhaowan.jiaoyi.manage.sso.client.SysUserRole;
import com.google.common.collect.Lists;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by solom on 2019-07-24. ClassName: SSOClient Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-24 12:04
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Component
public class SSOClient {

  @Value("${jiaoyi.manage.serverUrl}")
  private String serverUrl;
  @Value("${jiaoyi.manage.key}")
  private String key;
  @Value("${jiaoyi.manage.modId}")
  private int modId;

  private SysUserInfo sysUserInfo;
  /**
   * 角色列表
   */
  private List<SysUserRole> userRoleList = Lists.newArrayList();

  /**
   * 模块列表
   */
  private List<SysModule> moduleList = Lists.newArrayList();

  /**
   * 权限列表
   */
  private List<SysUserPermission> perList = Lists.newArrayList();

  Logger logger = LoggerFactory.getLogger(SSOClient.class);

  public int invoke(String ticket) throws Exception {
    String sign = MD5.encode(ticket + key + modId);

    StringBuffer url = new StringBuffer(serverUrl);
    if (url.indexOf("?") < 0) {
      url.append("?");
    }
    url.append("ticket=" + ticket);
    url.append("&modId=" + modId);
    url.append("&sign=" + sign);

    String json = HttpRequestUtil.doGet(url.toString());

    if (StringUtils.isBlank(json)) {
      logger.error("response is null，url=" + url.toString());
      return -99;
    }
    JSONObject jsonObject = JSONObject.fromObject(json);

    int code = jsonObject.getInt("code");

    if (code != 0) {
      return code;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    //解释用户
    if (jsonObject.containsKey("user")) {
      sysUserInfo = new SysUserInfo();
      JSONObject user = jsonObject.getJSONObject("user");
      sysUserInfo.setUserId(user.getInt("user_id"));
      sysUserInfo.setLoginId(user.getString("loginid"));
      sysUserInfo.setFullname(user.getString("fullname"));
      sysUserInfo.setUserType(user.getInt("usertype"));
      sysUserInfo.setStatus(user.getInt("status"));
      String str = user.getString("create_time");
      sysUserInfo.setCreateTime(sdf.parse(str));
      sysUserInfo.setCustomerServiceId(user.getString("customer_service_id"));
      sysUserInfo.setOnlineStatus(user.getInt("online_status"));
      sysUserInfo.setIsCustomer(user.getInt("is_customer"));
      sysUserInfo.setIsObjectCustomer(user.getInt("is_object_customer"));
      sysUserInfo.setIsOnDuty(user.getInt("is_object_customer"));
      sysUserInfo.setCustomerNickname(user.getString("customer_nickname"));
      sysUserInfo.setCustomerQq(user.getString("customer_qq"));
    }
    //角色列表
    if (jsonObject.containsKey("userrole")) {
      userRoleList = new ArrayList<>();
      JSONArray roleList = jsonObject.getJSONArray("userrole");
      for (int i = 0; i < roleList.size(); i++) {
        SysUserRole role = new SysUserRole();
        JSONObject obj = roleList.getJSONObject(i);
        role.setRoleId(obj.getInt("role_id"));
        role.setUserId(obj.getInt("user_id"));
        role.setRoleCode(obj.getString("role_code"));
        role.setRoleName(obj.getString("role_name"));
        role.setStatus(obj.getInt("status"));
        userRoleList.add(role);
      }
    }
    //模块列表
    if (jsonObject.containsKey("rolemodule")) {
      moduleList = new ArrayList<>();
      JSONArray modList = jsonObject.getJSONArray("rolemodule");
      for (int i = 0; i < modList.size(); i++) {
        SysModule mod = new SysModule();
        JSONObject obj = modList.getJSONObject(i);
        mod.setModId(obj.getInt("mod_id"));
        mod.setRoleId(obj.getInt("role_id"));
        mod.setRoleName(obj.getString("role_name"));
        mod.setParentId(obj.getInt("parent_id"));
        mod.setModuleCode(obj.getString("module_code"));
        mod.setModuleName(obj.getString("module_name"));
        mod.setLevelSeq(obj.getInt("level_seq"));
        mod.setFirstPage(obj.getString("first_page"));
        mod.setIsMenu(obj.getInt("is_menu"));
        mod.setStatus(obj.getInt("status"));
        mod.setOrderNo(obj.getInt("order_no"));

        moduleList.add(mod);
      }
    }
    //权限列表
    if (jsonObject.containsKey("rolepermission")) {
      perList = new ArrayList<>();
      JSONArray list = jsonObject.getJSONArray("rolepermission");
      for (int i = 0; i < list.size(); i++) {
        SysUserPermission per = new SysUserPermission();
        JSONObject obj = list.getJSONObject(i);
        per.setModId(obj.getInt("mod_id"));
        per.setRoleId(obj.getInt("role_id"));
        per.setRoleName(obj.getString("role_name"));
        per.setPid(obj.getInt("pid"));
        per.setPerName(obj.getString("per_name"));
        per.setPerCode(obj.getString("per_code"));
        per.setRemark(obj.getString("remark"));
        perList.add(per);
      }
    }
    return code;
  }

  public SysUserInfo getSysUserInfo() {
    return sysUserInfo;
  }

  public List<SysUserPermission> getPerList() {
    return perList;
  }

  public List<SysUserRole> getUserRoleList() {
    return userRoleList;
  }

  public List<SysModule> getModuleList() {
    return moduleList;
  }
}
