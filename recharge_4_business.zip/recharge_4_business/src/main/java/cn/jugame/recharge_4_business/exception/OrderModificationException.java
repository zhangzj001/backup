package cn.jugame.recharge_4_business.exception;


public class OrderModificationException extends ApiException {

    public OrderModificationException(String msg) {
        super(OrderExceptionCode.ORDER_MODIFICATION_EXCEPTION.getCode(), msg);
    }

}
