package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.commons.pay.BeanToMapUtil;
import cn.jugame.recharge_4_business.commons.pay.FormDateReportConvertor;
import cn.jugame.recharge_4_business.commons.pay.MD5Facade;
import cn.jugame.recharge_4_business.service.CallbackService;
import cn.jugame.recharge_4_business.service.payrequest.NowPayBackEndRequest;
import cn.jugame.recharge_4_business.service.payrequest.NowpayCallbackBean;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;


/**
 * Created by surong on 2019-04-28.
 * ClassName: CallbackRequestAlipay
 * Function: 现在支付后台回调. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Controller
public class NowPayCallbackController {
	protected static Logger log = LoggerFactory.getLogger(NowPayCallbackController.class);

	@Autowired
	CallbackService callbackService;

	@Value("${nowpay.app.appId}")
	public String appId;
	@Value("${nowpay.app.appKey}")
	public String appKey;
	@Value("${nowpay.wap.appId}")
	public String wapAppId;
	@Value("${nowpay.wap.appKey}")
	public String wapAppKey;


	private String nowPayCallbackBackend(HttpServletRequest request, String device, NowpayCallbackBean nowpayCallbackBean) throws IOException, ParseException {
		String rtnMsg = "success=Y";
		String reportContent = "";
		try{
			reportContent = getRequestBody(request);
		}catch(IOException e){
			log.error("现在支付后台回调获取请求体异常", e);
		}
		Map<String,String> dataMap=null;
		if(StringUtils.isBlank(reportContent)){//现在支付以http协议进行通知时，而我们给的后台通知地址是https的协议，这种情况会出现报文为空情况，根据现在支付那边给予的方法，就用了这种判断
			log.error("reportContent is empty");
			try {
				dataMap= BeanToMapUtil.convertBean(nowpayCallbackBean);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("现在支付后台回调获取请求体异常", e);
			}
		}else{
			dataMap = FormDateReportConvertor.parseFormDataPatternReportWithDecode(reportContent, "UTF-8","UTF-8");
		}

		String md5Key = wapAppKey;
		if ("app".equals(device)) {
			md5Key = appKey;
		}
		if(dataMap==null){
			log.error("reportContent或nowpayCallbackBean is empty");
			rtnMsg = "success=N";
		}

		//验证签名
		boolean isValidSignature = newVerifySignature(dataMap, md5Key,device);
		log.info("验签结果：" + isValidSignature);
		if(!isValidSignature){
			rtnMsg = "success=N";
		}
		//获取请求体
		NowPayBackEndRequest backEndRequest = buildBackEndRequestByMap(dataMap);
		if(backEndRequest == null){
			log.error("parse backEndRequest fail");
			rtnMsg = "success=N";
		}
		log.info("nowpay-backEndRequest=>" + JSONObject.fromObject(backEndRequest));
		//通用后台回调
		double payAmount = Double.valueOf(backEndRequest.getMhtOrderAmt()) / 100; //转成单位元
		String tradeStatus = backEndRequest.getTradeStatus();
		boolean isPay = false;
		if("A001".equals(tradeStatus)) {
			isPay = true;
		}
		boolean ret = callbackService.callbackBackend(backEndRequest.getMhtOrderNo(),backEndRequest.getChannelOrderNo(), new Date(), "", isPay, payAmount, PayChannel.CHANNEL_NOWPAY.getChannel(), PayType.PAY_TYPE_WXPAY.getType());
		//其它错误情况了，log出来
		if(!ret){
			log.error(device + "现在支付后台回调失败，支付单号:{}", backEndRequest.getMhtOrderNo());
		}

		return rtnMsg;

	}

	/**
	 * 支付回调(后台通知)
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/callback/nowPayCallbackBackendApp")
	@ResponseBody
	public void nowPayCallbackBackendApp(HttpServletRequest request, HttpServletResponse response, NowpayCallbackBean nowpayCallbackBean) throws IOException, ParseException {
		String device = "app";
		String ret = nowPayCallbackBackend(request, device, nowpayCallbackBean);
		try{
			response.getOutputStream().write(ret.getBytes());
		}catch(Exception e){
			log.error("error", e);
		}
	}

	/**
	 * 现在支付wap端回调(后台通知)
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/callback/nowPayCallbackBackendWap")
	@ResponseBody
	public void nowPayCallbackBackendWap(HttpServletRequest request, HttpServletResponse response, NowpayCallbackBean nowpayCallbackBean) throws IOException, ParseException {
		String device = "wap";
		String ret = nowPayCallbackBackend(request, device, nowpayCallbackBean);

		try{
			response.getOutputStream().write(ret.getBytes());
		}catch(Exception e){
			log.error("error", e);
		}
	}

	@RequestMapping(value = "/callback/nowpayCallbackFrontWap")
	public String nowpayCallbackFrontWap(HttpServletRequest request, Model model){
		String callbackUrl = nowpayCallbackFront(request, model, "wap");
		return callbackUrl;
	}

	private String nowpayCallbackFront(HttpServletRequest request, Model model, String device){
		Map<String, String> map = new TreeMap<String, String>();
		//打印出所有回调的参数
		StringBuffer sb = new StringBuffer();
		Enumeration<String> paramNameEnum = request.getParameterNames();
		while(paramNameEnum.hasMoreElements()){
			String paramName = paramNameEnum.nextElement();
			String paramValue = request.getParameter(paramName);
			sb.append(paramName).append("=").append(paramValue).append("&");
			//顺便把参数取出来，用来做签名用
			if("signType".equals(paramName) || "signature".equals(paramName))
				continue;
			map.put(paramName, paramValue);
		}
		log.info(device + "-nowpayCallbackFront.param => " + sb.toString());

		//注意：前台回调的时候，nowpay给的参数不只文档上说的那些。。。
		String mhtOrderNo = request.getParameter("mhtOrderNo");
		String tradeStatus = request.getParameter("tradeStatus");
		String signature = request.getParameter("signature");

		String key = wapAppKey;
		if("app".equals(device)) {
			key = appKey;
		}
		//验证参数
		if(!MD5Facade.validateFormDataParamMD5(map, key, signature)){
			log.info(device + "-nowpayCallbackFront verify fail");
			return null;
		}

		boolean payResult = false;
		if("A001".equals(tradeStatus)){
			payResult = true;
		}

		String returnUrl = callbackService.callbackFront(mhtOrderNo);
		return "redirect:" + returnUrl;
	}

	private static String getRequestBody(HttpServletRequest request) throws IOException{
		// 获取通知数据需要从body中流式读取
		BufferedReader reader = request.getReader();
		StringBuilder reportBuilder = new StringBuilder();
		String tempStr = "";
		while ((tempStr = reader.readLine()) != null) {
			reportBuilder.append(tempStr);
		}
		String reportContent = reportBuilder.toString();
		return reportContent;
	}

	private static NowPayBackEndRequest buildBackEndRequestByMap(Map<String, String> dataMap){
		NowPayBackEndRequest backEndRequest = new NowPayBackEndRequest();
		backEndRequest.setFuncode(dataMap.get("funcode"));
		backEndRequest.setAppId(dataMap.get("appId"));
		backEndRequest.setMhtOrderNo(dataMap.get("mhtOrderNo"));
		backEndRequest.setMhtOrderName(dataMap.get("mhtOrderName"));
		backEndRequest.setMhtOrderType(dataMap.get("mhtOrderType"));
		backEndRequest.setMhtCurrencyType(dataMap.get("mhtCurrencyType"));
		backEndRequest.setMhtOrderAmt(dataMap.get("mhtOrderAmt"));
		backEndRequest.setMhtOrderTimeOut(dataMap.get("mhtOrderTimeOut"));
		backEndRequest.setMhtOrderStartTime(dataMap.get("mhtOrderStartTime"));
		backEndRequest.setMhtCharset(dataMap.get("mhtCharset"));
		backEndRequest.setDeviceType(dataMap.get("deviceType"));
		backEndRequest.setPayChannelType(dataMap.get("payChannelType"));
		backEndRequest.setTradeStatus(dataMap.get("tradeStatus"));
		backEndRequest.setMhtReserved(dataMap.get("mhtReserved"));
		backEndRequest.setSignType(dataMap.get("signType"));
		backEndRequest.setSignature(dataMap.get("signature"));
		backEndRequest.setChannelOrderNo(dataMap.containsKey("channelOrderNo") ? dataMap.get("channelOrderNo") : "");
		backEndRequest.setPayConsumerId(dataMap.containsKey("payConsumerId") ? dataMap.get("payConsumerId") : "");
		backEndRequest.setTransStatus(dataMap.get("transStatus"));
		backEndRequest.setNowPayOrderNo(dataMap.get("nowPayOrderNo"));
		return backEndRequest;
	}

	private static boolean newVerifySignature(Map<String,String> dataMap, String appkey, String device){
		//去除签名类型和签名值
		if ("wap".equals(device)) {
			dataMap.remove("signType");
		}
		String signature = dataMap.remove("signature");

		//验证签名
		boolean isValidSignature = MD5Facade.validateFormDataParamMD5(dataMap,appkey,signature);
		return isValidSignature;
	}
}
