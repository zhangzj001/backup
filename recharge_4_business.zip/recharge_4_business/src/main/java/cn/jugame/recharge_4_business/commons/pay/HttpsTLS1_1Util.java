package cn.jugame.recharge_4_business.commons.pay;

import net.sf.json.JSONObject;
import okhttp3.FormBody.Builder;
import okhttp3.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.URLEncoder;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * 由于jugameCommons里面的httpClinet不稳定，所以只能自己用OKhttp封装
 * @author Administrator
 *
 */
public class HttpsTLS1_1Util {
	
	public static String DEFAULT_CHARSET = "UTF-8";
	
	private final static Logger log = LoggerFactory.getLogger(HttpsTLS1_1Util.class);
	private final static X509TrustManager trustManager = new X509TrustManager() {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {

        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {

        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    };
    private final static TslSocketFactory tslSocketFactory = new TslSocketFactory();

	public static OkHttpClient client = new OkHttpClient().newBuilder().sslSocketFactory(tslSocketFactory,trustManager)
			.connectTimeout(60, TimeUnit.SECONDS)
			.readTimeout(60, TimeUnit.SECONDS)
			.build();
	
	public static String doGet(String url,Map<String, String> params,String charset) throws IOException {
		StringBuilder sb = new StringBuilder();

		for (String key : params.keySet()) {
			Object v = params.get(key);
			String value;
			if (v == null) {
				value = "";
			} else {
				value = String.valueOf(v);
			}
			try {
				value = URLEncoder.encode(value, charset);
			} catch (Exception e) {
				log.error("URLEncode出现异常: " + ExceptionUtils.getStackTrace(e));
				value = "";
			}
			sb.append("&").append(key).append("=").append(value);
		}

		String paramString = sb.substring(1);
		String requestUrl = url + "?" + paramString;

		Request request = new Request.Builder().url(requestUrl).build();

		Response response = client.newCall(request).execute();
		if (response.isSuccessful()) {
			return response.body().string();
		} else {
			throw new IOException("Unexpected code " + response);
		}

	}
	
    public static String doPost(String url, Map<String, String> params) throws IOException {
        Builder builder = new Builder();
        Set<String> set = params.keySet();
        for (String key : set) {
            builder.add(key, String.valueOf(params.get(key)));
        }
        RequestBody formBody = builder.build();
        Request request = new Request.Builder().url(url).post(formBody).build();
        
        Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            return response.body().string();
        } else {
            throw new IOException("Unexpected code " + response);
        }

    }
    
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    
    public static String doPostJSON(String url, JSONObject obj){
    	RequestBody body = RequestBody.create(JSON, obj.toString());
		Request request = new Request.Builder().url(url).post(body).build();
		try {
			Response response = client.newCall(request).execute();
			if(response.isSuccessful()){
				return response.body().string();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}
    
    
    public static void main(String[] args) {
        String result = "responseCode=A001&tn=123456";
        System.out.println(result.substring(21, result.length()));;
    }
    
}
