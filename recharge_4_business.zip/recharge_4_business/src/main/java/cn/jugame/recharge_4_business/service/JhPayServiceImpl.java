package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.HttpRequestUtil;
import cn.jugame.recharge_4_business.commons.RtnUtil;
import cn.jugame.recharge_4_business.commons.constant.RefundStatus;
import cn.jugame.recharge_4_business.commons.pay.MD5;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service("jhPayService")
public class JhPayServiceImpl implements IBasePayService {
    @Value("${jh.pay.mcht.id}")
    private String mchtId;
    @Value("${jh.pay.term.id}")
    private String termId;
    @Value("${jh.pay.key}")
    private String key;
    @Value("${jh.pay.notify.url}")
    private String notifyUrl;
    @Value("${jh.pay.api.url}")
    private String apiUrl;
    @Value("${order_detail_url}")
    String orderDetailUrl;

    protected static Logger log = LoggerFactory.getLogger(JhPayServiceImpl.class);

    /**
     * 订单退款
     * @param zhifuOrder
     * @param rerundReason
     * @return 申请成功 则返回"success",其他为失败
     * @throws UnsupportedEncodingException
     */
    @Override
    public String orderRefund(ZhifuOrder zhifuOrder, String refundNo, String rerundReason) throws UnsupportedEncodingException {

        String mhtOrderNo = zhifuOrder.getZhifuId();
        //单位是分，需转换
        long amount = zhifuOrder.getZhifuOrderAmount().getAmountMinorLong();

        Map<String, String> params = new HashMap<String, String>();
        params.put("mchtid", mchtId);
        params.put("termid", termId);
        params.put("fee", zhifuOrder.getZhifuOrderAmount().getAmountMinorLong() + "");
        params.put("refundorderid", refundNo);
        params.put("oldorderid", zhifuOrder.getZhifuId());

        StringBuilder signData = new StringBuilder();
        signData.append(mchtId).append(termId).append(zhifuOrder.getZhifuOrderAmount().getAmountMinorLong()).append(refundNo).append(zhifuOrder.getZhifuId());
        String sign = getSign(signData, key);
        //签名
        params.put("sign", sign);
        String result = "";
        try {
            log.info(zhifuOrder.getOrderNo() + "调用聚合支付退款请求数据：{}", JSONObject.toJSON(params));
            result = HttpRequestUtil.sendPost(apiUrl+"/Refund", params);
            log.info(zhifuOrder.getOrderNo() + "调用聚合支付退款返回：{}", result);
        } catch (Exception e) {
            log.error(zhifuOrder.getOrderNo() + "调用聚合支付退款异常:", e);
        }

        JSONObject data = null;
        if (!StringUtils.isBlank(result)) {
            data =  JSONObject.parseObject(result);
        } else {
            return "退款异常,返回结果为空";
        }
        String responseMsg = "fail";
        //请求成功
        if (null !=data && data.containsKey("result") && data.get("result").equals("true")) {
            String tradeStatus = data.getString("state");
//        	00	成功
//        	09	处理中
//        	其他 失败
            responseMsg = data==null? "": data.getString("error");
            switch(tradeStatus) {
                case "00": case "09":
                    log.info(zhifuOrder.getOrderNo() + "退款申请成功");
                    responseMsg = "success";
                    break;
                default:
                    log.info(zhifuOrder.getOrderNo() + "退款申请失败:{}",responseMsg);
                    break;
            }
        } else {
            responseMsg = data==null? "null": data.getString("error");
            log.error(zhifuOrder.getOrderNo() +"退款申请退款失败：{}", responseMsg);

        }
        return responseMsg;
    }

    @Override
    public JSONObject appPay(ZhifuOrder zhifuOrder, String ip) {
        return null;
    }

    @Override
    public String wapPay(ZhifuOrder zhifuOrder, String ip) {
        if(null == zhifuOrder) {
            return "";
        }
        Map<String,String> params = buildWapRequestMap(zhifuOrder);
        try {
            String result = "";
            log.info("订单{}聚合微信wap请求数据：{}",zhifuOrder.getOrderNo(), JSONObject.toJSONString(params));
            result = HttpRequestUtil.sendPost(apiUrl+"/FixCode", params);
            log.info("订单{}聚合微信wap返回结果{}", zhifuOrder.getOrderNo(),URLDecoder.decode(result,"UTF-8"));
            if (StringUtils.isBlank(result)) {
                log.error("订单{}请求聚合微信wap支付失败",zhifuOrder.getOrderNo());
                return "";
            }
            JSONObject data = JSONObject.parseObject(result);
            if (null != data && "00".equals(data.getString("state"))) {
                String requestURL = data.getString("code_url");
                return buildwapPayForm(requestURL, orderDetailUrl + "?orderNo=" + zhifuOrder.getOrderNo());
            }

        } catch (Exception e) {
            log.error("订单{}请求聚合微信wap支付异常:{}", zhifuOrder.getOrderNo(),e);
        }
        return "";
    }

    /**
     * 现在支付退款查询
     * @param refundNo
     * @param clientType
     * @return -1 查询失败  0处理中  1退款成功  2退款失败
     */
    @Override
    public JSONObject orderRefundQuery(String refundNo, String clientType) {

        Map<String, String> params = new HashMap<String, String>();
        params.put("mchtid", mchtId);
        params.put("termid", termId);
        params.put("orderid", refundNo);
//        params.put("refundorderid", refundNo);

        StringBuilder signData = new StringBuilder();
        signData.append(mchtId).append(termId).append(refundNo);
        String sign = getSign(signData, key);
        //签名
        params.put("sign", sign);
        String result = "";
        try {
            log.info("退款单{}调用聚合支付退款查询请求数据：{}", refundNo,JSONObject.toJSON(params));
            result = HttpRequestUtil.sendPost(apiUrl+"/QueryOrder", params);
            log.info(refundNo + "调用聚合支付退款查询返回：{}", URLDecoder.decode(result, "utf-8"));
        } catch (Exception e) {
            log.error(refundNo + "调用聚合支付退款查询异常:", e);
        }

        JSONObject data = null;
        if (!StringUtils.isBlank(result)) {
            data =  JSONObject.parseObject(result);
        } else {
            return RtnUtil.setResult(-1, "退款查询异常");
        }

        String responseMsg = null == data ? "" : data.getString("error");
        if (null !=data && data.containsKey("result") && data.getString("result").equals("true")) {
            String tradeStatus = data.getString("state");
            int status = 0;
            if ("00".equals(tradeStatus)) {
                status = RefundStatus.REFUND_SUCCESS.getStatus();
            } else if ("09".equals(tradeStatus)) {
                status = RefundStatus.REFUND_APPLY_SUCCESS.getStatus();
            } else {
                status = RefundStatus.REFUND_FAIL.getStatus();
            }

            return RtnUtil.setResult(status, responseMsg);

        } else {
            return RtnUtil.setResult(RefundStatus.REFUND_FAIL.getStatus(), responseMsg);
        }
    }

    /**
     * 构建wap微信支付请求参数
     * @Author: sueyoung
     * @Date: 2019-07-18 17:54
     * @Param: [zhifuOrder]
     * @Return: java.util.Map<java.lang.String,java.lang.String>
     */
    private Map<String,String> buildWapRequestMap(ZhifuOrder zhifuOrder){
        //生成post给nowpay的数据
        String mhtOrderName = zhifuOrder.getOrderName();
        mhtOrderName = StringFilter(mhtOrderName);
        if(mhtOrderName.length() > 10){
            mhtOrderName = mhtOrderName.substring(0, 10) + "...";
        }

        Map<String,String> params = new HashMap<String,String>();
        params.put("orderid", zhifuOrder.getZhifuId());
        params.put("mchtid", mchtId);
        params.put("termid", termId);
        params.put("fee", zhifuOrder.getZhifuOrderAmount().getAmountMinorLong() + "");
        params.put("backurl", notifyUrl);

        StringBuilder signData = new StringBuilder();
        signData.append(mchtId).append(termId).append(zhifuOrder.getZhifuId()).append(zhifuOrder.getZhifuOrderAmount().getAmountMinorLong());
        String sign = getSign(signData, key);
        //签名
        params.put("sign", sign);
        return params;
    }

    /**
     * 签名
     * @Author: sueyoung
     * @Date: 2019-07-30 16:21
     * @Param: [dataStr, key]
     * @Return: java.lang.String
     */
    private static String getSign(StringBuilder signData,String key){
        if(null == signData) return null;

        StringBuilder toMD5StringBuilder = new StringBuilder();

        try{
            signData.append(key);
            String toMD5String = signData.toString();
            log.info("待MD5签名字符串：{}",toMD5String);
            String lastMD5Result = MD5.md5(toMD5String,"UTF-8");
            log.info("MD5签名后字符串:{}",lastMD5Result);
            return lastMD5Result;
        }catch (Exception ex){
            return "";
        }
    }

    // 过滤特殊字符
    private static String StringFilter(String str) {
        String regEx="[`@#$%^&*()+=|{}❤]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return m.replaceAll("").trim();
    }


    /**
     * 将&连接的参数转为map
     * @param content
     * @return
     */
    private static Map<String,String> parseParams(String content) {
        Map<String,String> dataMap = null;
        if(StringUtils.isBlank(content)){
            return null;
        }
        dataMap = new HashMap<String, String>();
        String[] paras = content.split("&");
        String paraName = null;
        String paraVal = null;
        int pos = -1;
        for(String kv : paras){
            pos = kv.indexOf("=");
            if(-1 == pos) {
                dataMap.put(kv, "");
            } else {
                paraName = kv.substring(0, pos);
                paraVal = kv.substring(pos+1);
                dataMap.put(paraName, paraVal);
            }
        }
        return dataMap;

    }

    public static String buildwapPayForm(String requestUrl, String orderDetatilUrl) {

        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no\"><title>支付</title><style type=\"text/css\">\n" +
                "html{height: 100%}\n" +
                "body{position:relative;min-height: 100%;background-color: rgba(0,0,0,.7);margin:0;line-height: 1.6;}\n" +
                ".payBox{position:absolute;top:50%;left:10%;right:10%;background-color: #fff;text-align: center;border-radius: 6px;-webkit-transform: translateY(-50%);transform: translateY(-50%);}\n" +
                ".payBox-title{font-size:18px;padding: 15px 10px;}\n" +
                ".payBox-link {display:block;padding:10px;font-size:15px;color:#39f;text-decoration:none;border-top: 1px solid #C5C5C5;}\n" +
                ".payBox-link img {width: 19px;height: 19px;vertical-align: middle;margin-left: 20px;}\n" +
                "</style></head><body>");
        sbHtml.append("<div class=\"payBox\">\n" +
                "<div class=\"payBox-title\">是否已完成支付</div>\n" +
                "<a href=\"").append(orderDetatilUrl).append("\" class=\"payBox-link\">支付成功，查看详情<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAMAAACf4xmcAAAAe1BMVEUAAAAzmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf/Tsa5mAAAAKHRSTlMA+Vgvs/N+7NSfkz3LomAlIgTJGRY3t46LQzUGdyoRB9qsTuTNwGtp1vGoWQAAAUJJREFUOMu1lGmPwiAQhncQpAc97KVV26p7vf//F25kC2ShptkY+TIzzdMhvHO8vfA0eawkkVRxXj+EUk6wh3i6CJUcQLRnbVG0bB8B4GVIMQHKNi7eZATBfGoLVAYyYAVs/346A8nO/3WXeBwzcXgHc1EpkCw/PoFw7+BQp2XsVIFbvUCbkGC9fgchtcmykOohtM1MuoYQJttFiH9lATXayRGFyb4h5qpGyLWNcQioUeI8u4c5rQJbEOIyWU2VthJHnxoIN+MfIbUlFD7WobN+AfKxuaw30BBg7tKU4js4XVzt3KUKzGLg071d5OgwBuULwgifYy3wpSMrSCBvL/BxReRaT8sbFquVAHoTmWKFpR/ecTW+K33YSPXWjKhrJJOuetyW3T+bfH1kXLw+gOvjvL4c1ldNV64vLvD0uTX4/PkBTdYffHilZhkAAAAASUVORK5CYII=\"> </a>\n" +
                "<a href=\"#\" onclick=\"payFailed();\" class=\"payBox-link\">遇到问题，重新支付<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAMAAACf4xmcAAAAe1BMVEUAAAAzmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf/Tsa5mAAAAKHRSTlMA8XhVrzL27ujVCc9+NiUSBG1cOhzdpJuHcWdiQj0X4tm8p0otH45QM/tiDQAAAR1JREFUOMvVk9tugzAMQHECgQBtgdILo/d22/n/L5xUhgJtkHjtecM6xlZsBx/Dd3m7CLG9tfW0dLziCCO/dAoBCfNWV3kowHblsRYJZDr9/0rbC2yi94KCKYeBQhlk8WItheQ1dxETL0eR9ELSRxyRkBXDwB4Onn7voEZ5u33gY0e8mvHctaEMZrAlm6P9gqt6WvuUVGv9BbnWx27gZ28Hd3rOT2sDfHm8fSd1w6g3MOW9WX7vB5Bn45aetdeTLlwplcNWKeV972qwEBm7YAYKOc3QVjLvd/nEItkmHc3FukV1PGKyYhzxLHmUIK+5B4NphqlFY5D1xAH2YlpZOD+mzjkOVaXbPDTv5+wKX3Fcj8Ekyya0CWJvZR18DH8kuh+QLcybIQAAAABJRU5ErkJggg==\"></a>\n" +
                "</div>\n" +
                "<a id=\"paynowURL\" href=\"").append(requestUrl).append("\"></a>\n" +
                "</form>");

        sbHtml.append("<script>\n" +
                "var link = document.getElementById('paynowURL').getAttribute('href');\n" +
                "if (window.frames.length != parent.frames.length) {\n" +
                "top.location.href=link;\n" +
                "}else{\n" +
                "window.location.href=link;\n" +
                "}\n" +
                "function payFailed(){\n" +
                "window.location.reload();\n" +
                "}\n" +
                "</script>\n" +
                "</body>\n" +
                "</html>");

        return sbHtml.toString();
    }

    //将url形式参数转换map
    public static Map<String,String> parseUrlParams(String content) {
        Map<String,String> dataMap = null;
        if(StringUtils.isBlank(content)){
            return null;
        }
        dataMap = new HashMap<String, String>();
        String[] paras = content.split("&");
        String paraName = null;
        String paraVal = null;
        int pos = -1;
        for(String kv : paras){
            pos = kv.indexOf("=");
            if(-1 == pos) {
                dataMap.put(kv, "");
            } else {
                paraName = kv.substring(0, pos);
                paraVal = kv.substring(pos+1);
                dataMap.put(paraName, paraVal);
            }
        }
        return dataMap;

    }
}
