package cn.jugame.recharge_4_business.filter;

import cn.jugame.recharge_4_business.commons.Common;
import cn.jugame.recharge_4_business.configs.JymConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@Order(1)
@WebFilter(filterName="jymLoginFilter", urlPatterns="/jym/*")
public class JymLoginFilter implements Filter {

    @Value("${jym.login_url}")
    private String jymLoginUrl;

    @Value("${jym.client_id}")
    private String jymClientId;

    @Value("${jym.login_callback_url}")
    private String jymLoginCallbackUrl;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse res = (HttpServletResponse) servletResponse;
        HttpSession session = req.getSession();

        String uri = req.getRequestURI();
        //首页就不用去登录了
        if(uri.contains("jym/index")){
            filterChain.doFilter(servletRequest, servletResponse);
            return;
        }

        //默认跳转地址
        String redirectUrl = jymLoginCallbackUrl;
        StringBuffer currentUrl = ((HttpServletRequest) servletRequest).getRequestURL();
        if(currentUrl != null && StringUtils.isNotBlank(currentUrl.toString()))
            redirectUrl = currentUrl.toString();
        //带上query-string
        if (StringUtils.isNotBlank(req.getQueryString())) {
            redirectUrl += "?" + req.getQueryString();
        }

        //如果cookie中没有指定的kv，那么说明没登录，则跳去登录
        String jymUserId = (String)session.getAttribute(JymConstants.SESSION_JYM_USER_ID);
        if(StringUtils.isBlank(jymUserId)){
            // 跳去交易猫登录
            String url = jymLoginUrl + "?client_id=" + jymClientId + "&redirectUrl=" + Common.urlEncode(redirectUrl);
            res.sendRedirect(url);
            return;
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {
    }
}
