package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.HttpRequestUtil;
import cn.jugame.recharge_4_business.commons.ProductType;
import cn.jugame.recharge_4_business.commons.pay.MD5;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.mapper.OrderInfoMapper;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service("rechargeService")
public class RechargeService{
    @Value("${recharge.plat.id}")
    private String recPlatID;
    @Value("${recharge.api.key}")
    private String recApiKey;

    @Value("${recharge.callback.url}")
    private String callbackUrl;

    @Value("${recharge.api.url}")
    private String apiUrl;

    protected static Logger log = LoggerFactory.getLogger(RechargeService.class);

    @Autowired
    OrderInfoMapper orderInfoMapper;

    /**
     * Q币|会员充值
     * 注意该接口返回结果仅代表充值下单结果， 具体充值成功需等待回调通知或主动查询接口确认
     * @Author: sueyoung
     * @Date: 2019-07-23 11:07
     * @Param: [order]
     * @Return: boolean （返回false则可以确认充值失败， 返回true还需等待回调通知或主动查询获取最终结果）
     */
    public boolean recharge(OrderInfo order){

        String qqType = ""; //Q币类型 1001 Q币, 视频会员按配置的产品编码
        int fee = 0;//充值金额， q币按1个Q币1元的比例传，不能随便传其他金额， 视频会员按当前产品套餐面额，不能拿订单价格
        if (ProductType.QCoin.value() == order.getProductType()) {
            qqType = "1001";//全国Q币
            fee = order.getProductNum() * 100;
        } else if (ProductType.Video.value() == order.getProductType()) {
            qqType = order.getThirdProductCode();
            fee = order.getThirdProductPrice();
        } else {
            log.error("产品类型不支持");
            return false;
        }

        Map<String,String> paramMap=new HashMap<String,String>();
        paramMap.put("PlatID", recPlatID);//商户节点ID
        paramMap.put("NodeOrderID",order.getOrderNo());//商户订单号
        paramMap.put("Phone", order.getRechargeAccount());//充值手机号
        paramMap.put("Fee", fee + "");//充值金额，以分为单位，10元
        paramMap.put("CallBackUrl", callbackUrl);//回调地址
        paramMap.put("TransType", "00");//Q币充值
        paramMap.put("QQType", qqType);//Q币充值
        paramMap.put("IP", order.getIp());//客户端远程IP地址

        String sign = getSign(paramMap, recApiKey);

        paramMap.put("Sign",sign);
        log.info("请求地址{}, 请求参数:{}",apiUrl + "/Recharge.json",paramMap);
        String result= HttpRequestUtil.sendPost(apiUrl + "/Recharge.json", paramMap);
        log.info("订单{}充值qqType-{} 结果:{}",order.getOrderNo(), qqType, result);
        if (StringUtils.isBlank(result)) {
            //网络异常，状态处理中，需要调用查询或等待回调地址获取结果,
            //这里直接返回true，因为不确认是否充值失败，如果确认失败返回false会立即退款
            log.error("订单{}充值qqType-{} 网络异常，需调用查询或等待回调地址获取结果",order.getOrderNo(),qqType);
            return true;
        }
        JSONObject jsonObj = JSONObject.fromObject(result);
        String success = jsonObj.optString("success");
        String errorMsg = jsonObj.optString("errorMsg");
        if (success.equals("true")){
            //充值受理成功,需要调用查询接口获取充值结果数据或等待回调地址获取结果数据
            JSONObject data = jsonObj.getJSONObject("data");
            String rechargeNo = data.get("InnerOrderID").toString();//内部订单号
            order.setRechargeNo(rechargeNo);
            return true;//值肯定为：0000
        } else {
            log.error("订单{}充值qqType-{} 失败:{}",order.getOrderNo(),qqType,errorMsg);
            return false;
        }
    }

    /**
     * 充值查询
     * @Author: sueyoung
     * @Date: 2019-07-23 11:42
     * @Param: [orderNo]
     * @Return: 00：处理中, 01-成功, 02-失败
     */
    public String queryDetail(String orderNo){

        Map<String,String> paramMap=new HashMap<String,String>();
        paramMap.put("PlatID", recPlatID);//商户节点ID
        paramMap.put("NodeOrderID",orderNo);//商户订单号

        String sign = getSign(paramMap, recApiKey);

        paramMap.put("Sign",sign);

        String result = "";

        try {
            result= HttpRequestUtil.sendPost(apiUrl + "/QueryDetail.json", paramMap);
            log.info("订单{}充值查询 结果:{}", orderNo, result);
            if (StringUtils.isBlank(result)) {
                //网络异常，状态处理中，需要调用查询或等待回调地址获取结果,
                log.error("订单{}充值查询网络异常，需调用查询或等待回调地址获取结果",orderNo);
                return "-1";//异常
            }
            JSONObject jsonObj = JSONObject.fromObject(result);
            String success = jsonObj.optString("success");
            String errorCode = jsonObj.optString("errorCode");
            String errorMsg = jsonObj.optString("errorMsg");
            if (success.equals("true")){
                if(errorCode.equals("0000")) {
                    return "01";
                } else if (errorCode.equals("0001")) {
                    return "00";
                } else {
                    return "02";//失败
                }
            } else {
                return "02";
            }
        } catch (Exception e) {
            log.error("订单{}查询充值异常{}",orderNo,e);
        }
        return "00";
    }


    private static String getSign(Map<String,String> dataMap, String apiKey){
        if(dataMap == null) return null;

        Set<String> keySet = dataMap.keySet();
        List<String> keyList = new ArrayList<String>(keySet);
        Collections.sort(keyList);
        StringBuilder toMD5StringBuilder = new StringBuilder();
        for(String key : keyList){
            String value = dataMap.get(key);
            if(value != null && value.length()>0){
                toMD5StringBuilder.append(value);
            }
        }
        try{
            toMD5StringBuilder.append(apiKey);
            String toMD5String = toMD5StringBuilder.toString();
            log.info("待MD5签名字符串：[{}]",toMD5String);
            String lastMD5Result = MD5.md5(toMD5String,"UTF-8").toUpperCase();
            log.info("MD5签名后字符串:[{}]",lastMD5Result);
            return lastMD5Result;
        }catch (Exception ex){
            return "";
        }
    }

}
