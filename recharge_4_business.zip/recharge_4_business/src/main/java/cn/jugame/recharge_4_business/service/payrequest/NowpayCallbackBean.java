package cn.jugame.recharge_4_business.service.payrequest;

public class NowpayCallbackBean {
	
	private String funcode;
	private String version;
	private String appId;
	private String mhtOrderNo;
	private String mhtOrderName;
	private String mhtOrderType;
	private String mhtCurrencyType;
	private String mhtOrderAmt;
	private String oriMhtOrderAmt;
	private String discountAmt;
	private String mhtOrderTimeOut;
	private String mhtOrderStartTime;
	private String payTime;
	private String mhtCharset;
	private String nowPayOrderNo;
	private String deviceType;
	private String payChannelType;
	private String mhtReserved;
	private String bankType;
	private String cardType;
	private String signType;
	private String signature;
	private String channelOrderNo;
	private String payConsumerId;
	private String tradeStatus;//现在支付公众号支付的交易支付状态
	public String getFuncode() {
		return funcode;
	}
	public void setFuncode(String funcode) {
		this.funcode = funcode;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getMhtOrderNo() {
		return mhtOrderNo;
	}
	public void setMhtOrderNo(String mhtOrderNo) {
		this.mhtOrderNo = mhtOrderNo;
	}
	public String getMhtOrderName() {
		return mhtOrderName;
	}
	public void setMhtOrderName(String mhtOrderName) {
		this.mhtOrderName = mhtOrderName;
	}
	public String getMhtOrderType() {
		return mhtOrderType;
	}
	public void setMhtOrderType(String mhtOrderType) {
		this.mhtOrderType = mhtOrderType;
	}
	public String getMhtCurrencyType() {
		return mhtCurrencyType;
	}
	public void setMhtCurrencyType(String mhtCurrencyType) {
		this.mhtCurrencyType = mhtCurrencyType;
	}
	public String getMhtOrderAmt() {
		return mhtOrderAmt;
	}
	public void setMhtOrderAmt(String mhtOrderAmt) {
		this.mhtOrderAmt = mhtOrderAmt;
	}
	public String getOriMhtOrderAmt() {
		return oriMhtOrderAmt;
	}
	public void setOriMhtOrderAmt(String oriMhtOrderAmt) {
		this.oriMhtOrderAmt = oriMhtOrderAmt;
	}
	public String getDiscountAmt() {
		return discountAmt;
	}
	public void setDiscountAmt(String discountAmt) {
		this.discountAmt = discountAmt;
	}
	public String getMhtOrderTimeOut() {
		return mhtOrderTimeOut;
	}
	public void setMhtOrderTimeOut(String mhtOrderTimeOut) {
		this.mhtOrderTimeOut = mhtOrderTimeOut;
	}
	public String getMhtOrderStartTime() {
		return mhtOrderStartTime;
	}
	public void setMhtOrderStartTime(String mhtOrderStartTime) {
		this.mhtOrderStartTime = mhtOrderStartTime;
	}
	public String getPayTime() {
		return payTime;
	}
	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}
	public String getMhtCharset() {
		return mhtCharset;
	}
	public void setMhtCharset(String mhtCharset) {
		this.mhtCharset = mhtCharset;
	}
	public String getNowPayOrderNo() {
		return nowPayOrderNo;
	}
	public void setNowPayOrderNo(String nowPayOrderNo) {
		this.nowPayOrderNo = nowPayOrderNo;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getPayChannelType() {
		return payChannelType;
	}
	public void setPayChannelType(String payChannelType) {
		this.payChannelType = payChannelType;
	}
	public String getMhtReserved() {
		return mhtReserved;
	}
	public void setMhtReserved(String mhtReserved) {
		this.mhtReserved = mhtReserved;
	}
	public String getBankType() {
		return bankType;
	}
	public void setBankType(String bankType) {
		this.bankType = bankType;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getChannelOrderNo() {
		return channelOrderNo;
	}
	public void setChannelOrderNo(String channelOrderNo) {
		this.channelOrderNo = channelOrderNo;
	}
	public String getPayConsumerId() {
		return payConsumerId;
	}
	public void setPayConsumerId(String payConsumerId) {
		this.payConsumerId = payConsumerId;
	}

	
	public String getTradeStatus() {
		return tradeStatus;
	}
	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}
	@Override
	public String toString() {
		return "NowpayCallbackWapBean [funcode=" + funcode + ", version=" + version + ", appId=" + appId
				+ ", mhtOrderNo=" + mhtOrderNo + ", mhtOrderName=" + mhtOrderName + ", mhtOrderType=" + mhtOrderType
				+ ", mhtCurrencyType=" + mhtCurrencyType + ", mhtOrderAmt=" + mhtOrderAmt + ", oriMhtOrderAmt="
				+ oriMhtOrderAmt + ", discountAmt=" + discountAmt + ", mhtOrderTimeOut=" + mhtOrderTimeOut
				+ ", mhtOrderStartTime=" + mhtOrderStartTime + ", payTime=" + payTime + ", mhtCharset=" + mhtCharset
				+ ", nowPayOrderNo=" + nowPayOrderNo + ", deviceType=" + deviceType + ", payChannelType="
				+ payChannelType + ", mhtReserved=" + mhtReserved + ", bankType=" + bankType + ", cardType=" + cardType
				+ ", signType=" + signType + ", signature=" + signature + ", channelOrderNo=" + channelOrderNo
				+ ", payConsumerId=" + payConsumerId + ", tradeStatus=" + tradeStatus + "]";
	}
	
	

}
