package cn.jugame.recharge_4_business.commons;

import java.util.Random;
import java.util.UUID;

/**
 * Created by solom on 2019-05-10.
 * ClassName: Util
 * Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-05-10 11:21
 *
 * @author: solom
 * @since: jdk 1.8
 */
public final class Util {

  /**
   * 产生随机数
   *
   * @param len 长度
   * @return
   */
  public static String genVcode(int len) {
    StringBuffer sb = new StringBuffer();
    Random r = new Random();
    for (int i = 0; i < len; i++) {
      sb.append(r.nextInt(10));
    }
    return sb.toString();
  }

  /**
   * 查询手机号的类型（移动，联通，电信）
   *
   * @param mobile
   * @return 1移动 ,2联通,3电信
   */
  public static int getMobileType(String mobile) {
    if (mobile.startsWith("134") || mobile.startsWith("135")
            || mobile.startsWith("136") || mobile.startsWith("137")
            || mobile.startsWith("138") || mobile.startsWith("139")
            || mobile.startsWith("159") || mobile.startsWith("150")
            || mobile.startsWith("151") || mobile.startsWith("158")
            || mobile.startsWith("157") || mobile.startsWith("188")
            || mobile.startsWith("187") || mobile.startsWith("152")
            || mobile.startsWith("182") || mobile.startsWith("147")) {
      return 1;
    } else if (mobile.startsWith("130") || mobile.startsWith("131")
            || mobile.startsWith("132") || mobile.startsWith("155")
            || mobile.startsWith("156") || mobile.startsWith("185")
            || mobile.startsWith("186")) {
      return 2;
    } else if (mobile.startsWith("180") || mobile.startsWith("189")
            || mobile.startsWith("133") || mobile.startsWith("153")) {
      return 3;
    }

    return 1;//找不出类型时，默认移动
  }


  public static String getUUID() {
    return UUID.randomUUID().toString();
  }
}
