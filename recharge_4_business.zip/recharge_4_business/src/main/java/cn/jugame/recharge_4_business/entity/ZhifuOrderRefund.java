package cn.jugame.recharge_4_business.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;
import org.joda.money.Money;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ZhifuOrderRefund implements Serializable {
    private long id;
    private String zhifuId;
    private String orderNo;
    private long uid;
    private String refundNo;
    private Money refundAmount;
    private int payType;
    private String payClient;
    private int refundStatus;
    private String remark;
    private int retryTimes;
    private Date createTime;
    private Date updateTime;
}
