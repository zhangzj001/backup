package cn.jugame.recharge_4_business.service;

import com.aligames.maga.open.ApiInvoke;
import com.aligames.maga.open.ApiParam;
import com.aligames.maga.open.MagaClient;
import com.aligames.maga.open.MagaOpenClient;
import com.aligames.maga.open.exception.InitializeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * 阿里游戏接口
 */
@Service
public class MagaClientService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${jym.appkey}")
    private String appKey;

    @Value("${jym.appsecret}")
    private String appSecret;

    @Value("${jym.domain}")
    private String domain;

    private MagaClient magaClient = null;

    @PostConstruct
    public void init(){
        try {
            magaClient = MagaOpenClient.defaultBuilder()
                    .secret(appKey, appSecret)
                    .host(domain)
                    .build();
        } catch (InitializeException e) {
            // maga open client 初始化异常，例如没有设置秘钥信息，没有设置HOST信息等
            logger.error("error", e);
        }
    }

    public String call(@NotNull String apiName, @NotNull String apiVer, @NotNull Map<String, Object> params){
        if(magaClient == null){
            logger.error("magaClient not initialized");
            return null;
        }

        ApiParam.Builder apiParamBuilder = ApiParam.builder()
                .requestId(String.valueOf(System.currentTimeMillis()));
        for(Map.Entry<String, Object> e : params.entrySet()){
            apiParamBuilder.add(e.getKey(), e.getValue());
        }
        ApiParam apiParam = apiParamBuilder.build();

        try {
            ApiInvoke apiInvoke = magaClient.invoke(apiName, apiVer, apiParam);
            if(apiInvoke == null){
                logger.error("apiName:{}, apiVer:{}, 无响应！", apiName, apiVer);
                return null;
            }
            logger.info("apiName:{}, apiVer:{}, 响应结果：", apiName, apiVer, apiInvoke.getResult());

            return apiInvoke.isSuccessful() ? apiInvoke.getResult() : null;
        }catch(Exception e){
            return null;
        }
    }

    public void close(){
        magaClient.destroy();
    }
}
