package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.ProductType;
import cn.jugame.recharge_4_business.controller.admin.AdminProductController.ListQuery;
import cn.jugame.recharge_4_business.entity.Product;
import cn.jugame.recharge_4_business.entity.ProductPackages;
import cn.jugame.recharge_4_business.mapper.ProductMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by solom on 2019-07-17. ClassName: ProductService Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-17 14:55
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Service
public class ProductService {

  @Autowired
  private ProductMapper productMapper;

  public Map<Integer, List<Product>> findAllProduct() {
    Map<Integer, List<Product>> m = Maps.newHashMap();
    List<Product> QCProducts = productMapper.findAllProduct(ProductType.QCoin.value());
    if (QCProducts == null || QCProducts.size() <= 0) {
      m.put(ProductType.QCoin.value(), Lists.newArrayList());
    } else {
      QCProducts.forEach(item -> {
        item.setPackagesList(productMapper.findAllPkgByProductId(item.getId(), 0, 1000));
      });
      m.put(ProductType.QCoin.value(), QCProducts);
    }
    List<Product> VProducts = productMapper.findAllProduct(ProductType.Video.value());
    if (VProducts == null || VProducts.size() <= 0) {
      m.put(ProductType.Video.value(), Lists.newArrayList());
    } else {
      VProducts.forEach(item -> {
        item.setPackagesList(productMapper.findAllPkgByProductId(item.getId(), 0, 1000));
      });
      m.put(ProductType.Video.value(), VProducts);
    }
    return m;
  }

  public Product findAllQBProduct() {
    Product p = null;
    List<Product> QCProducts = productMapper.findAllProduct(ProductType.QCoin.value());
    if (QCProducts == null || QCProducts.size() <= 0) {
      return null;
    }
    p = QCProducts.get(0);
    p.setPackagesList(productMapper.findAllPkgByProductId(p.getId(), 0, 1000));
    return p;
  }

  public List<Product> findAllVIPProduct() {
    List<Product> products = productMapper.findAllProduct(ProductType.Video.value());
    if (products == null || products.size() <= 0) {
      return Lists.newArrayList();
    }
    products.forEach(item -> {
      item.setPackagesList(productMapper.findAllPkgByProductId(item.getId(), 0, 1000));
    });
    return products;
  }

  public List<ProductPackages> findAllPackages(int productId, int no, int size) {
    no = (no > 0 ? no - 1 : no) * size;
    return productMapper.findAllPkgByProductId(productId, no, size);
  }

  public List<Product> queryAllProduct(ListQuery param) {
    if (param.getPage() < 0) {
      param.setPage(0);
    } else {
      param.setPage(
          (param.getPage() > 0 ? param.getPage() - 1 : param.getPage()) * param.getRows());
    }
    List<Product> products = productMapper.searchAllProduct(param);
    products.forEach(item -> {
      item.setPkgNames(queryPkgNames(item.getId()));
    });
    return products;
  }

  private String queryPkgNames(int productId) {
    return StringUtils.join(productMapper.queryPkgNames(productId), ",");
  }

  public Product findById(int productId) {
    return productMapper.findById(productId);
  }

  public ProductPackages findPackagesById(int packagesId) {
    return productMapper.findByPackageId(packagesId);
  }

  public int count(ListQuery param) {
    return productMapper.count(param);
  }

  public int countQCProduct() {
    return productMapper.countByType(ProductType.QCoin.value());
  }

  public boolean save(Product p) {
    return productMapper.insert(p) > 0;
  }

  public boolean update(Product p) {
    return productMapper.update(p) > 0;
  }

  public int countAllByProductId(int id) {
    return productMapper.countAllByProductId(id);
  }

  public boolean savePkg(ProductPackages packages) {
    return productMapper.savePkg(packages);
  }

  public boolean deleteByIds(String idstr) {
    if (productMapper.deleteByIds(idstr) > 0) {
      return productMapper.deletePkgByProductIds(idstr) > 0;
    }
    return false;
  }

  public boolean deletePkgByIds(String idstr) {
    return productMapper.deletePkgByIds(idstr) > 0;
  }

  public boolean updatePkg(ProductPackages p) {
    return productMapper.updatePkg(p) > 0;
  }
}
