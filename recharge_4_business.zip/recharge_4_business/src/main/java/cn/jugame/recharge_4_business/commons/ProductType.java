package cn.jugame.recharge_4_business.commons;

/**
 * Created by solom on 2019-07-18. ClassName: ProductType Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-18 10:36
 *
 * @author: solom
 * @since: jdk 1.8
 */
public enum ProductType {
  QCoin(1, "Q币"),
  Video(2, "视频会员");
  private int value;
  private String name;

  private ProductType(int v, String name) {
    this.value = v;
    this.name = name;
  }

  public int value() {
    return this.value;
  }

  public String n(){
    return this.name;
  }
}
