package cn.jugame.recharge_4_business.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.concurrent.TimeUnit;

@Slf4j
public class OrderLock implements AutoCloseable {

    private RedisTemplate<String, Object> redisTemplate;
    private String lockIdentifier;

    public OrderLock(RedisTemplate<String, Object> redisTemplate, String lockIdentifier) {
        this.redisTemplate = redisTemplate;
        this.lockIdentifier = lockIdentifier;
    }

    public boolean acquire(long acquireTimeout, long expireTime) throws InterruptedException {
        boolean locked;
        long startTime = System.currentTimeMillis();
        while (!(locked = redisTemplate.opsForValue().setIfAbsent(lockIdentifier, "1"))
                && System.currentTimeMillis() - startTime <= acquireTimeout) {
            Thread.sleep(5);
        }
        if (locked) {
            log.info("[LOCK ACQUIRED] " + lockIdentifier);
            redisTemplate.expire(lockIdentifier, expireTime, TimeUnit.MILLISECONDS);
        } else {
            log.error("[LOCK ACQUIRE FAILED] " + lockIdentifier);
        }
        return locked;
    }

    public void release() {
        String v = (String) redisTemplate.opsForValue().get(lockIdentifier);
        if ("1".equals(v)) {
            redisTemplate.delete(lockIdentifier);
            log.info("[LOCK RELEASED] " + lockIdentifier);
        }
    }


    @Override
    public void close() {
        release();
    }
}
