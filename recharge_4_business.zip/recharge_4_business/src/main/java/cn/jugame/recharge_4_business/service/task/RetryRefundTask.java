package cn.jugame.recharge_4_business.service.task;

import cn.jugame.recharge_4_business.commons.DateUtils;
import cn.jugame.recharge_4_business.commons.Util;
import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.commons.constant.RefundStatus;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.entity.ZhifuOrderRefund;
import cn.jugame.recharge_4_business.service.IBasePayService;
import cn.jugame.recharge_4_business.service.ZhifuOrderRefundService;
import cn.jugame.recharge_4_business.service.ZhifuOrderService;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RetryRefundTask {

    private static Logger log = LoggerFactory.getLogger(RetryRefundTask.class);

    @Autowired
    private ZhifuOrderService zhifuOrderService;

    @Autowired
    private ZhifuOrderRefundService zhifuOrderRefundService;

    @Autowired
    IBasePayService aliPayService;
    @Autowired
    IBasePayService nowPayService;
    @Autowired
    IBasePayService jhPayService;

//    @Value("${pay.task.enable.host}")
//    private String enableHost;
    private static final int retry_time_limit = 5;

    @Async
    @Scheduled(cron = "0 0/15 * * * *")
    public void run() {
        log.info("订单退款失败重试 任务开始...");
//        String currentHostName = "";
//        try {
//            currentHostName = InetAddress.getLocalHost().getHostName();
//        } catch (UnknownHostException e) {
//            log.error("RetryRefundTask ->获取主机名异常:",e);
//            return;
//        }
//        //host校验
//        if (!enableHost.equals(currentHostName)) {
//            log.info("RetryRefundTask -> 当前主机名非执行定时任务的主机,不执行任务，任务退出");
//            return;
//        }

        //读取退款失败记录
        List<ZhifuOrderRefund> list = null;
        try {
            list = zhifuOrderRefundService.queryAllRefundByStatus(RefundStatus.REFUND_FAIL.getStatus(),0,50);
        } catch(Exception e) {
            log.error("查询退款失败记录异常:",e);
            return;
        }
        if (null == list || list.size() <=0) {
            log.info("RetryRefundTask -> 没有退款失败记录需处理，退出.");
            return;
        }

        //开始处理
        for(ZhifuOrderRefund refund : list) {
            String zhifuId = refund.getZhifuId();
            String orderNo = refund.getOrderNo();
            String refundNo = refund.getRefundNo();
            String payClient = refund.getPayClient();
            int retryTimes = refund.getRetryTimes();
            if(retryTimes>=retry_time_limit){//超过查询次数修改状态不再查询
                    String remark = refund.getRemark();
                    refund.setRefundStatus(-2);
                    refund.setRemark("["+remark+"][退费重试次数超过限制]");
                    zhifuOrderRefundService.update(refund);
                    continue;
            }
            ZhifuOrder zhifuOrder = zhifuOrderService.findByZhifuId(zhifuId);
            if (null == zhifuOrder) {
                continue;
            }
            retryTimes++;
            refund.setRetryTimes(retryTimes);

            //先再查一次退款状态，失败则重试，成功则直接修改状态
            JSONObject queryResult = null;
            try {
                if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_ORIGIN.getChannel()){//原生渠道
                    if(refund.getPayType() == PayType.PAY_TYPE_ALIPAY.getType()) {
                        queryResult = aliPayService.orderRefundQuery(refundNo,payClient);
                    }
                } else if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_NOWPAY.getChannel()){//现在支付渠道
                    queryResult =  nowPayService.orderRefundQuery(refundNo,payClient);
                } else if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_JHPAY.getChannel()){//现在支付渠道
                    queryResult =  jhPayService.orderRefundQuery(refundNo,payClient);
                }  else {
                    refund.setRefundStatus(-2);
                    refund.setRemark("支付渠道或支付类型不支持");
                    zhifuOrderRefundService.update(refund);
                    continue;
                }

                log.info("订单{} - 退款单{} 查询结果为：{}",orderNo, refundNo,queryResult);
                String msg = queryResult.containsKey("msg") ? queryResult.getString("msg") : "";
                refund.setRemark(msg);
                if(queryResult != null && queryResult.getIntValue("code") == 1){//成功
                    refund.setRefundStatus(RefundStatus.REFUND_SUCCESS.getStatus());
                } else if(queryResult != null && queryResult.getIntValue("code") == 2) {//失败
                    String refundResult = "";
                    if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_ORIGIN.getChannel()){
                        //原生支付宝
                        if(refund.getPayType() == PayType.PAY_TYPE_ALIPAY.getType()) {
                            refundResult = aliPayService.orderRefund(zhifuOrder,zhifuOrder.getZhifuId(),"订单退款");
                        }

                    } else if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_NOWPAY.getChannel()){//现在支付渠道
                        refundNo =  "RFQB-" + DateUtils.getDateFormatString("yyMMddHHmmssSSS") + Util
                            .genVcode(5);
                        refundResult =  nowPayService.orderRefund(zhifuOrder, refundNo , "订单退款");
                    } else if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_JHPAY.getChannel()){//现在支付渠道
                        refundNo =  "RFQB-" + DateUtils.getDateFormatString("yyMMddHHmmssSSS") + Util
                                .genVcode(5);
                        refundResult =  jhPayService.orderRefund(zhifuOrder, refundNo , "订单退款");
                    }
                    log.info("订单{} - 退款单{} 退款重试结果:{}",orderNo, refundNo, refundResult);
                    //成功更新退费单状态
                    if ("success".equals(refundResult)) {
                        refund.setRefundStatus(RefundStatus.REFUND_APPLY_SUCCESS.getStatus());
                        refund.setRefundNo(refundNo);
                        refund.setRemark("退款申请成功");
                        refund.setRetryTimes(0);
                    } else {
                        refund.setRemark(refundResult);
                    }
                }
                zhifuOrderRefundService.update(refund);
                Thread.sleep(300);
            } catch (Exception e) {
                log.error("订单{} - 退款单{} 退款重试异常：{}",orderNo, refundNo, e);
            }
        }

        log.info("订单退款失败重试 任务结束");
    }
}
