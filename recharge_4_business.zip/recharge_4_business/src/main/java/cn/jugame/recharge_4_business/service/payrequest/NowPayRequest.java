package cn.jugame.recharge_4_business.service.payrequest;

import lombok.*;

import java.io.Serializable;


/**
 * Created by surong on 2019-04-28.
 * ClassName: NowPayRequest
 * Function: TODO BUILD NOWPAY REQUEST. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NowPayRequest implements Serializable {

	/**
	 * 功能码
	 * 定值：WP001  统一下单接口
	 */
	private String funcode = "WP001";

	/**
	 * 版本号
	 * 定值：1.0.3
	 */
	private String version = "1.0.3";
	
	/**
	 * 应用id，必填，参与签名
	 */
	private String appId;
	
	/**
	 * 商户订单号，必填，参与签名
	 */
	private String mhtOrderNo;

	/**
	 * 商户商品名称
	 */
	private String mhtOrderName;
	
	/**
	 * 币种，默认156 人民币
	 */
	private String mhtCurrencyType = "156";
	
	/**
	 * 交易金额，单位为 分
	 */
	private Long mhtOrderAmt;
	
	/**
	 * 商户订单详情 必须
	 */
	private String mhtOrderDetail;

	/**
	 * 设备类型
	 */
	private String deviceType;
	
	/**
	 * 商户交易类型 定值：05
	 */
	private String mhtOrderType = "05";
	
	/**
	 * 商户订单开始时间 必须 yyyyMMddHHmmss
	 */
	private String mhtOrderStartTime;
	
	/**
	 * 商户后台通知URL 必须
	 */
	private String notifyUrl;
	
	/**
	 * 前台回调地址  非必须
	 */
	private String frontNotifyUrl;
	
	/**
	 * 商户字符编码
	 */
	private String mhtCharset="UTF-8";
	
	/**
	 * 用户所选渠道类型 必须  12-支付宝  13-微信
	 */
	private String payChannelType;
	
	/**
	 * 商户签名方法 定值 MD5
	 */
	private String mhtSignType = "MD5";
	
	/**
	 * 商户数据签名 必须
	 */
	private String mhtSignature;

	/**
	 * 商户订单超时时间 非必须，默认3600秒  60~3600秒
	 */
	private String mhtOrderTimeOut;

	/**
	 * 商户保留域 非必须
	 */
	private String mhtReserved;

	/**
	 * 消费者ID 非必须
	 */
	private String consumerId;

	/**
	 * 消费者名称 非必须
	 */
	private String consumerName;


//	private String mhtSubOpenId;
//
//	private String mhtSubAppId;
//
//
//	private String outputType;
//
//
//	//小程序
//	private String oriMhtOrderAmt;
//
//	private String discountAmt;
//
//	private String mhtLimitPay;
}
