package cn.jugame.recharge_4_business.commons.constant;

public class OrderStatus {
    /**
     * 订单初始状态，待支付
     */
    public static final Integer ORDER_NEW = 0;
    /**
     * 订单已支付，待发货
     */
    public static final Integer ORDER_PAYED = 1;
    /**
     * 订单已发货，待收货
     */
    public static final Integer ORDER_DELIVERED = 2;
    /**
     * 订单已完成
     */
    public static final Integer ORDER_FINISHED = 3;
    /**
     * 订单已取消
     */
    public static final Integer ORDER_CANCELED = 4;

    /**
     * 虚拟状态：全部
     */
    public static final Integer ALL = 99;
}
