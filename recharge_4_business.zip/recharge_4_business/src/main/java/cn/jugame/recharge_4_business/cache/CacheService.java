package cn.jugame.recharge_4_business.cache;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class CacheService {

  @Autowired
  private RedisTemplate<String, Object> redisTemplate;

  //带纪录的统计器
  public void incrementWithRecord(String key, String countId, String operator) {
    String recordKey = key + "_record";
    String recordHashKey = countId + "_" + operator;
    //统计纪录
    Object recordVal = redisTemplate.opsForHash().get(recordKey, recordHashKey);
    Validate.isTrue(recordVal == null || StringUtils.isEmpty(String.valueOf(recordVal)), "重复操作");
    //添加纪录
    redisTemplate.opsForHash().put(recordKey, recordHashKey, "Y");
    //增加统计数
    redisTemplate.opsForHash().increment(key, countId, 1);
  }

  /**
   * @param exp 秒
   */
  public void set(String key, int exp, Object value) {
    redisTemplate.opsForValue().set(key, value, exp, TimeUnit.SECONDS);
  }

  /**
   *
   */
  public void setHash(String key, String hashKey, Object value) {
    redisTemplate.opsForHash().put(key, hashKey, value);
  }


  public static interface CastValue<T> {

    //转换
    T cast(Object object);

    //空值转换
    T castNull();
  }

  public static interface Action {

    void doAction(RedisTemplate<String, Object> redisTemplate);
  }

  public void multi(Action action) {
    redisTemplate.multi();
    action.doAction(redisTemplate);
    redisTemplate.exec();
  }

  /**
   *
   */
  public Object getHash(String key, String hashKey) {
    return redisTemplate.opsForHash().get(key, hashKey);
  }


  /**
   *
   */
  public List<Object> mgetHash(String key, List<String> hashKeys) {
    List<Object> hkeys = new ArrayList<>(hashKeys);
    return redisTemplate.opsForHash().multiGet(key, hkeys);
  }

  public Long addSet(String key, String zkey) {
    //插入参与纪录
    return redisTemplate.opsForSet().add(key, zkey);
  }

  public Long lengthSet(String key) {
    return redisTemplate.opsForSet().size(key);
  }

  public void del(String key) {
    redisTemplate.delete(key);
  }

  public Object get(String key) {
    return redisTemplate.opsForValue().get(key);
  }

  public long incr(String key, long delta) {
    return redisTemplate.opsForValue().increment(key, delta);
  }

  /**
   * 获取缓存
   */
  public <T> T get(String key, LoadAction<T> loadAction) throws Throwable {
    return get(key, 0, loadAction);
  }

  public <T> T get(String key, int exp, LoadAction<T> loadAction) throws Throwable {
    T value = (T) get(key);
    if (value == null) {
      value = loadAction.get(key);
      if (value != null) {
        set(key, exp > 0 ? exp : Integer.MAX_VALUE, value);
      }
    }
    return value;
  }

  public void set(String key, Object value, SetAction setAction) throws Exception {
    del(key);
    setAction.set(key, value);
  }


  /**
   * 将键值对设定一个指定的时间timeout.
   * @param key
   * @param timeout 键值对缓存的时间，单位是毫秒
   * @return 设置成功返回true，否则返回false
   */
  public boolean tryLock(String key, long timeout) {
    boolean isSuccess = redisTemplate.opsForValue().setIfAbsent(key, "");
    if (isSuccess) {
      redisTemplate.expire(key, timeout, TimeUnit.MILLISECONDS);
    }
    return isSuccess;
  }

  /**
   * 释放锁
   * @Author: sueyoung
   * @Date: 2019-06-24 11:21
   * @Param: [key]
   * @Return: boolean
   */
  public boolean unLock(String key) {
    del(key);
    return true;
  }


}
