//package cn.jugame.recharge_4_business.configs;
//
//import cn.jugame.recharge_4_business.filter.AuthorFilter;
//import java.util.ArrayList;
//import java.util.List;
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//
///**
// * Created by solom on 2018/7/10. ClassName: FilterConfig Function: TODO ADD FUNCTION. <br/> Date:
// * 2019-07-17 10:15
// *
// * @author: solom
// * @since: jdk 1.8
// */
//@Configuration
//public class FilterConfig {
//  @Bean
//  public FilterRegistrationBean filterRegistrationBean() {
//    FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
//    List<String> urlPatterns = new ArrayList<String>();
//    AuthorFilter filter = new AuthorFilter();   //new过滤器
//    urlPatterns.add("/admin/*");      //指定需要过滤的url
//    filterRegistrationBean.setFilter(filter);       //set
//    filterRegistrationBean.setUrlPatterns(urlPatterns);     //set
//    return filterRegistrationBean;
//  }
//}
