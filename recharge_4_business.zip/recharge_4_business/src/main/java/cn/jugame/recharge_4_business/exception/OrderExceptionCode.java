package cn.jugame.recharge_4_business.exception;

public enum OrderExceptionCode {

    ORDER_CREATE_EXCEPTION(550),
    ORDER_MODIFICATION_EXCEPTION(551),
    ORDER_NOT_FOUND_EXCEPTION(552),
    ORDER_STATUS_CHANGE_EXCEPTION(553),
    ORDER_PAY_EXCEPTION(554);

    int code;

    OrderExceptionCode(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

}
