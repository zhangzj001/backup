package cn.jugame.recharge_4_business.mapper;

import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.handler.MoneyTypeHandler;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.type.JdbcType;
import org.springframework.stereotype.Repository;

/**
 * @Description:
 * @Author: sueyoung
 * @Date: 2019-07-17 17:13
 * @Param: 
 * @Return: 
 */
@Repository
@Mapper
public interface ZhifuOrderMapper {

  @Insert("insert into zhifu_order (`zhifu_id`, `busi_code`, `order_no`, `zhifu_order_amount`, `order_name`, `order_customer_id`" +
          ",`order_time`,`expire_time`,`remark`,`zhifu_status`,`pay_type`,`pay_channel`,`pay_client_type`,`pay_callback_time`,`external_order_id`,`create_time`,`update_time`) " +
          "values(#{zhifuId}, #{busiCode}, #{orderNo}, #{zhifuOrderAmount,jdbcType=INTEGER,typeHandler=cn.jugame.recharge_4_business.handler.MoneyTypeHandler}, #{orderName},#{orderCustomerId}, #{orderTime}," +
          "#{expireTime},#{remark},#{zhifuStatus},#{payType},#{payChannel},#{payClientType},#{payCallbackTime},#{externalOrderId},now(),now())")
  int save(ZhifuOrder zo);

  @Select("select * from `zhifu_order` where order_no = #{orderNo} limit 1")
  @Results({@Result(column="zhifu_order_amount",property="zhifuOrderAmount", jdbcType = JdbcType.INTEGER, typeHandler = MoneyTypeHandler.class)})
  ZhifuOrder findFirstByOrderNo(@Param("orderNo") String orderNo);

  @Select("select * from `zhifu_order` where order_no = #{orderNo} and zhifu_status = #{zhifuStatus} limit 1")
  @Results({@Result(column="zhifu_order_amount",property="zhifuOrderAmount", jdbcType = JdbcType.INTEGER, typeHandler = MoneyTypeHandler.class)})
  ZhifuOrder findFristByOrderNoAndZhifuStatus(@Param("orderNo") String orderNo, @Param("zhifuStatus") int zhifuStatus);

  @Select("select * from `zhifu_order` where zhifu_id = #{zhifuId}")
  @Results({@Result(column="zhifu_order_amount",property="zhifuOrderAmount", jdbcType = JdbcType.INTEGER, typeHandler = MoneyTypeHandler.class)})
  ZhifuOrder findByZhifuId(@Param("zhifuId") String zhifuId);

  @Update({
          "update zhifu_order",
          "set order_no = #{orderNo},",
          "zhifu_order_amount = #{zhifuOrderAmount,jdbcType=INTEGER,typeHandler=cn.jugame.recharge_4_business.handler.MoneyTypeHandler},",
          "order_name = #{orderName},",
          "order_customer_id = #{orderCustomerId},",
          "order_time = #{orderTime},",
          "expire_time = #{expireTime},",
          "remark = #{remark},",
          "zhifu_status = #{zhifuStatus},",
          "pay_type = #{payType},",
          "pay_channel = #{payChannel},",
          "pay_client_type = #{payClientType},",
          "pay_callback_time = #{payCallbackTime},",
          "external_order_id = #{externalOrderId},",
          "update_time = #{updateTime,jdbcType=TIMESTAMP}",
          "where zhifu_id = #{zhifuId}"
  })
  int updateByZhifuId(ZhifuOrder zo);
}
