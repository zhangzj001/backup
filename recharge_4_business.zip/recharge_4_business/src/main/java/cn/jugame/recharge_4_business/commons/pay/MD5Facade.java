package cn.jugame.recharge_4_business.commons.pay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;


/**
 * MD5Facade  ---  汇集多类型MD5签名逻辑
 * User: 韩彦伟
 * Date: 14-8-6
 * Time: 下午7:52
 * To change this template use File | Settings | File Templates.
 */
public class MD5Facade {
    protected static Logger log = LoggerFactory.getLogger(MD5Facade.class);


    /**
     * 针对NowPay目前统一的MD5签名方式：key1=value1&key2=value2....keyn=valuen&securityKeySignature  进行MD5
     * @param dataMap  --需要参与MD5签名的数据
     * @param securityKey    --密钥
     * @return
     */
    public static boolean validateFormDataParamMD5(Map<String,String> dataMap,String securityKey,String currentSignature){
        if(dataMap == null) return false;

        Set<String> keySet = dataMap.keySet();
        List<String> keyList = new ArrayList<String>(keySet);
        Collections.sort(keyList);

        StringBuilder toMD5StringBuilder = new StringBuilder();
        for(String key : keyList){
            String value = dataMap.get(key);

            if(value != null && value.length()>0){
                toMD5StringBuilder.append(key+"="+ value+"&");
            }
        }

        try{
            String securityKeyMD5 = MD5.md5(securityKey,"");
            toMD5StringBuilder.append(securityKeyMD5);

            String toMD5String = toMD5StringBuilder.toString();

            String actualMD5Value = MD5.md5(toMD5String,"");

            return actualMD5Value.equals(currentSignature);
        }catch (Exception ex){
            return false;
        }
    }

    /**
     * 针对NowPay目前统一的MD5签名方式：key1=value1&key2=value2....keyn=valuen&securityKeySignature  进行MD5
     * <p>要先对Key进行按字典升序排序
     * @param dataMap  -- 数据
     * @param securityKey    --密钥
     * @param charset
     * @return
     */
    public static String getFormDataParamMD5(Map<String,String> dataMap,String securityKey,String charset){
        if(dataMap == null) return null;

        Set<String> keySet = dataMap.keySet();
        List<String> keyList = new ArrayList<String>(keySet);
        Collections.sort(keyList);

        StringBuilder toMD5StringBuilder = new StringBuilder();
        for(String key : keyList){
            String value = dataMap.get(key);

            if(value != null && value.length()>0){
                toMD5StringBuilder.append(key+"="+ value+"&");
            }
        }

        try{
            String securityKeyMD5 = MD5.md5(securityKey,charset);
            toMD5StringBuilder.append(securityKeyMD5);

            String toMD5String = toMD5StringBuilder.toString();
            log.info("待MD5签名字符串：" + toMD5String);

            String lastMD5Result = MD5.md5(toMD5String,charset);
            log.info("MD5签名后字符串:" + lastMD5Result);

            return lastMD5Result;
        }catch (Exception ex){
            //ignore
            return "";
        }
    }


    public static void main(String[] args) throws Exception{
//    	StringBuffer sb = new StringBuffer("appId=1478245720318760&frontNotifyUrl=http://posp.ipaynow.cn:10808/mobilewaptest/frontnotify&mhtCharset=UTF-8&mhtCurrencyType=156&mhtOrderAmt=10&mhtOrderDetail=mhtOrderDetail&mhtOrderName=merchantTest&mhtOrderNo=1478500464320&mhtOrderStartTime=20161107143424&mhtOrderType=01&notifyUrl=http://posp.ipaynow.cn:10808/mobilewaptest/notify&outputType=0&payChannelType=13");
//
//    	Map<String,String> params = new HashMap<String,String>();
//    	for(String tmp : sb.toString().split("&")){
//    		String[] values = tmp.split("=");
//    		params.put(values[0],values[1]);
//    	}
//
//    	String securityKeyMD5 = MD5.md5("WsDy5GKal18Vcw0nHsNUYx9qsxwWkm4M","UTF-8");
//    	sb.append("&"+securityKeyMD5);
//    	String lastMD5Result = MD5.md5(sb.toString(),"UTF-8");
//
//    	params.put("mhtSignType", "MD5");
//        params.put("mhtSignature",lastMD5Result);
//        params.put("funcode", "WP001");
//        params.put("deviceType", "0600");
//
//    	String result = HttpUtil.doPost("http://api.ipaynow.cn", params);
//    	System.out.println("result:" + result);
//
//    	System.out.println(lastMD5Result);


    }
}