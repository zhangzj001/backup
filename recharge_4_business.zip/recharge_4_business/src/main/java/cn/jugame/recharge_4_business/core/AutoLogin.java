package cn.jugame.recharge_4_business.core;

import cn.jugame.recharge_4_business.commons.CookieUtil;
import cn.jugame.recharge_4_business.commons.DES;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author caixb
 *
 */
public class AutoLogin {
	public static String USER_AUTO_LOGIN_KEY = "auto-login";    //用户名密码cookie key（用于网站用户记住密码登录）
	public static String USER_SYNC_LOGIN_KEY = "user_sid";	//用户名密码cookie key（用于网站与开心大厅登录同步）
	public static String DEFAULT_KEY = "a24d88ee-feae-46fc-a08a-1f829ea85a55";
	static Logger logger = LoggerFactory.getLogger(AutoLogin.class);
	
	/**
	 * 自动登录	
	 * 
	 * @param request
	 * @param response
	 * @param token
	 */
	public static void autoLogin(HttpServletRequest request, HttpServletResponse response, String token){
		try {
			//自动登录处理
			String tokenCip = autoLoginEncode(request, token);
			String autoLogin = request.getParameter("isAutoLogin");
			if(StringUtils.isNotBlank(autoLogin)){
				CookieUtil.setCookie(request, response, USER_AUTO_LOGIN_KEY, tokenCip, 3600 * 24 * 7); //7天有效
			}else{
				CookieUtil.setCookie(request, response, USER_AUTO_LOGIN_KEY, tokenCip, 0); //当前打开浏览器生命周期内有效
				//CookieUtil.removeCookie(request, response, USER_AUTO_LOGIN_KEY); // 删掉
			}
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 对token进行加密
	 * @param request
	 * @param token
	 * @return
	 */
	public static String autoLoginEncode(HttpServletRequest request, String token){
		try {
			String userAgent = request.getHeader("user-agent");
			return DES.encode(token, (userAgent == null ? DEFAULT_KEY : userAgent));
		} catch (Exception e) {
			logger.error("", e);
		}
		return null;
	}
	
	/**
	 * 获取记住密码登录的token并解密
	 * @param request
	 * @return
	 */
	public static String getTokenByCookie(HttpServletRequest request){
		try {
			String tokenCip = CookieUtil.getCookie(request, USER_AUTO_LOGIN_KEY);
			if(StringUtils.isNotBlank(tokenCip)){
				String userAgent = request.getHeader("user-agent");
				return DES.decode(tokenCip, (userAgent == null ? DEFAULT_KEY : userAgent));
			}
		} catch (Exception e) {
			logger.error("", e);
		}
		return null;
	}
	/**
	 * 获取与开心大厅同步登录的token并解密
	 * @param request
	 * @return
	 */
	public static String getSyncTokenByCookie(HttpServletRequest request){
		try {
			String tokenCip = CookieUtil.getCookie(request, USER_SYNC_LOGIN_KEY);
			if(StringUtils.isNotBlank(tokenCip)){
				String userAgent = request.getHeader("user-agent");
				return DES.decode(tokenCip, (userAgent == null ? DEFAULT_KEY : userAgent));
			}
		} catch (Exception e) {
			//logger.error("", e);
		}
		return null;
	}
}