package cn.jugame.recharge_4_business.entity;

import com.alibaba.fastjson.annotation.JSONField;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by solom on 2019-07-17. ClassName: Product Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-17 13:45
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Product implements Serializable {
  private int id;
  private String productNo;
  private String name;
  private int type; //类型，1：Q币，2：视频会员
  private int price;
  private int status;
  private String remark;
  private String productDesc;
  private List<ProductPackages> packagesList;
  private String pkgNames;
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date createTime;
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date updateTime;
  private int start;
  private int size;
}
