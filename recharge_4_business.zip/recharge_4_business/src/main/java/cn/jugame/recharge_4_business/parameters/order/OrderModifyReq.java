package cn.jugame.recharge_4_business.parameters.order;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class OrderModifyReq {
    public long uid;
    public String orderNo;
    public int payType;
    public String consigneeName;
    public String consigneeAddress;
    public String consigneeMobile;
    public String consigneeRemark;
    public int couponId;
}
