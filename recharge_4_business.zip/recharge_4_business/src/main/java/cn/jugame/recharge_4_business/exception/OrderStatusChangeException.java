package cn.jugame.recharge_4_business.exception;


public class OrderStatusChangeException extends ApiException {

    private int fromStatus;
    private int toStatus;

    public OrderStatusChangeException(int fromStatus, int toStatus) {
        super(OrderExceptionCode.ORDER_STATUS_CHANGE_EXCEPTION.getCode(), "订单状态不能从[ " + fromStatus + " ]变更到[ " + toStatus + " ]");
        this.fromStatus = fromStatus;
        this.toStatus = toStatus;
    }

    public int getFromStatus() {
        return fromStatus;
    }

    public int getToStatus() {
        return toStatus;
    }

}
