package cn.jugame.recharge_4_business.controller.admin;

import cn.jugame.recharge_4_business.commons.DateUtils;
import cn.jugame.recharge_4_business.commons.ExcelFileGenerator;
import cn.jugame.recharge_4_business.controller.BaseController;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.entity.Query;
import cn.jugame.recharge_4_business.service.OrderService;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by solom on 2019-07-19. ClassName: AdminOrderController Function: TODO ADD FUNCTION.
 * <br/> Date: 2019-07-19 18:19
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Controller
@RequestMapping("/admin/order/")
public class AdminOrderController extends BaseController {

  @Data
  public static class ListQuery extends Query {
    public String orderNo;
    public String productNo;
    public int productType;
    public String rechargeAccount;
    public int uid;
    public int orderStatus = -1;
    public String startTime;
    public String endTime;
    public String payPlatform;
  }

  @Autowired
  private OrderService orderService;

  @RequestMapping("list.html")
  public String list(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    return "admin/order/list";
  }

  @RequestMapping("pagelist.html")
  @ResponseBody
  public String pageList(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    ListQuery query = new ListQuery();
    initQuery(query, request);
    Map<String, Object> map = Maps.newHashMap();
    map.put("rows", orderService.queryOrders(query));
    map.put("total", orderService.count(query));
    String str = JSONObject.toJSONString(map);
    return str;
  }

  @RequestMapping("export.html")
  public void export(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws Exception {
    ListQuery query = new ListQuery();
    initQuery(query, request);
    query.setPage(1);
    query.setRows(10000);
    List<OrderInfo> rows = orderService.queryOrders(query);
    ArrayList<String> title = Lists.newArrayList();
    title.add("订单号");
    title.add("下单平台");
    title.add("下单渠道");
    title.add("商品名称");
    title.add("商品ID");
    title.add("充值账号");
    title.add("套餐");
    title.add("付款金额");
    title.add("买家UID");
    title.add("状态");
    title.add("支付方式");
    title.add("支付平台");
    title.add("创建时间");
    ArrayList<List<String>> f = Lists.newArrayList();
    for (OrderInfo o : rows) {
      ArrayList<String> item = Lists.newArrayList();
      item.add(o.getOrderNo());
      item.add(o.getFr());
      item.add(o.getCh());
      item.add(o.getProductName());
      item.add(o.getProductNo());
      item.add(o.getRechargeAccount());
      item.add(o.getPackageName());
      item.add(o.getAmount() / 100 + "元");
      item.add(o.getUid() + "");
      item.add(explainStatus(o.getOrderStatus()));
      item.add(explainPayType(o.getPayType()));
      item.add(explainPayPlatform(o.getPayPlatform()));
      item.add(DateUtils.parseDate2Str(o.getOrderTime(), "yyyy-MM-dd HH:mm:ss"));
      f.add(item);
    }
    ExcelFileGenerator gen = new ExcelFileGenerator(title, f);
    gen.exportExcel(response, "订单数据导出");
  }

  private String explainPayType(int payType) {
    if (payType == 1) {
      return "支付宝";
    } else if (payType == 2) {
      return "微信";
    } else {
      return "--";
    }
  }

  private String explainPayPlatform(String platform) {
    if ("wap".equalsIgnoreCase(platform)) {
      return "网页支付";
    } else if ("gzh".equalsIgnoreCase(platform)) {
      return "微信公众号";
    } else {
      return "--";
    }
  }

  private String explainStatus(int orderStatus) {
    switch (orderStatus) {
      case 0:
        return "初始";
      case 1:
        return "已支付";
      case 2:
        return "已发货";
      case 3:
        return "完成";
      case 4:
        return "取消";
      default:
        return "--";
    }
  }
}
