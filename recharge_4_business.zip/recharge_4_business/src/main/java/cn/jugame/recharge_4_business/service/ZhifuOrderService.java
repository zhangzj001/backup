package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.DateUtils;
import cn.jugame.recharge_4_business.commons.Util;
import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.commons.constant.RefundStatus;
import cn.jugame.recharge_4_business.commons.constant.ZhifuStatus;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.entity.ZhifuOrderRefund;
import cn.jugame.recharge_4_business.mapper.ZhifuOrderMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;

@Service
public class ZhifuOrderService {

    @Autowired
    ZhifuOrderMapper zhifuOrderMapper;
    @Autowired
    IBasePayService aliPayService;
    @Autowired
    IBasePayService nowPayService;
    @Autowired
    IBasePayService jhPayService;
    @Autowired
    ZhifuOrderRefundService zhifuOrderRefundService;


    protected static Logger log = LoggerFactory.getLogger(ZhifuOrderService.class);

    public ZhifuOrder findByOrderNoAndStatus(String orderNo, int status) {
        return zhifuOrderMapper.findFristByOrderNoAndZhifuStatus(orderNo,status);
    }

    public ZhifuOrder findByOrderNo(String orderNo) {
        return zhifuOrderMapper.findFirstByOrderNo(orderNo);
    }

    public int addZhifuOrder(ZhifuOrder zhifuOrder) {
        if(null == zhifuOrder) {
            return 0;
        }
        zhifuOrder.setZhifuId(genZhifuId("P", zhifuOrder.getBusiCode(),zhifuOrder.getOrderNo()));
        return zhifuOrderMapper.save(zhifuOrder);
    }

    public int update(ZhifuOrder zhifuOrder) {
        if(null == zhifuOrder || StringUtils.isBlank(zhifuOrder.getZhifuId())) {
            return 0;
        }
        return zhifuOrderMapper.updateByZhifuId(zhifuOrder);
    }

    /**
     * 产生一张支付单
     * @param busiCode
     * @param orderId
     * @return
     */
    public static String genZhifuId(String prefix, String busiCode, String orderId) {
        if(StringUtils.isEmpty(busiCode) || StringUtils.isEmpty(orderId)) {
            return null;
        }
        if (StringUtils.isEmpty(prefix)) {
            prefix ="P";
        }
        if (StringUtils.isEmpty(busiCode)) {
            busiCode = "qbcz";
        }
        //业务码前四位（多截断，少补x）
        if(busiCode.length() > 4) {
            busiCode = busiCode.substring(0, 4);
        } else if (busiCode.length() < 4) {
            for(int i=0; i<(4-busiCode.length()); i++) {
                busiCode = busiCode + "x";
            }
        }

        StringBuilder sb = new StringBuilder(24);
        //8位日期YYYYMMDD
        String time = DateUtils.getDateFormatString("yyMMddHH");

        //9位随机流水
        String randLog = String.valueOf((int)((Math.random()*9+1)*100000000));

        //1位前缀 + 8位时间 + 前4位busicode + 9位随机流水
        sb.append(prefix).append(time).append(busiCode).append(randLog);

        return sb.toString();
    }

    public ZhifuOrder findByZhifuId(String zhifuId) {
        return zhifuOrderMapper.findByZhifuId(zhifuId);
    }

    public String orderRefund(ZhifuOrder zhifuOrder, String refundReason) {

        ZhifuOrderRefund refund = zhifuOrderRefundService.findByZhifuId(zhifuOrder.getZhifuId());
        if (null == refund) {
            refund = ZhifuOrderRefund.builder()
                    .orderNo(zhifuOrder.getOrderNo())
                    .refundNo("")
                    .payClient(zhifuOrder.getPayClientType())
                    .payType(zhifuOrder.getPayType())
                    .refundAmount(zhifuOrder.getZhifuOrderAmount())
                    .refundStatus(RefundStatus.REFUND_APPLY_FAIL.getStatus())
                    .remark("")
                    .retryTimes(0)
                    .uid(zhifuOrder.getOrderCustomerId())
                    .zhifuId(zhifuOrder.getZhifuId()).build();
            int sr = zhifuOrderRefundService.save(refund);
            if(sr <= 0) {
                log.info("订单{}创建退款记录失败", zhifuOrder.getOrderNo());
                return "创建退款记录失败";
            }
        }
        if (refund.getRefundStatus() == RefundStatus.REFUND_APPLY_SUCCESS.getStatus()
                || refund.getRefundStatus() == RefundStatus.REFUND_SUCCESS.getStatus()) {
            log.info("订单{}已退过款", zhifuOrder.getOrderNo());
            return "订单已经有成功退款记录";
        }

        String refundNo = zhifuOrder.getZhifuId();
        String refundResult = "fail";
        try {
            //区分是原生支付渠道还是现在支付渠道
            if (zhifuOrder.getPayChannel() == PayChannel.CHANNEL_ORIGIN.getChannel()) {
                //原生支付渠道现在只有支付宝
                if (zhifuOrder.getPayType() == PayType.PAY_TYPE_ALIPAY.getType()) {
                    refundResult = aliPayService.orderRefund(zhifuOrder, refundNo, refundReason);
                }
            } else if(zhifuOrder.getPayChannel() == PayChannel.CHANNEL_NOWPAY.getChannel()) {
                refundNo =  "RFQB-" + DateUtils.getDateFormatString("yyMMddHHmmssSSS")+ Util.genVcode(5);
                refundResult = nowPayService.orderRefund(zhifuOrder, refundNo, refundReason);
            } else if(zhifuOrder.getPayChannel() == PayChannel.CHANNEL_JHPAY.getChannel()) {
                refundNo =  "RFQB-" + DateUtils.getDateFormatString("yyMMddHHmmssSSS")+ Util.genVcode(5);
                refundResult = jhPayService.orderRefund(zhifuOrder, refundNo, refundReason);
            }
        } catch (UnsupportedEncodingException e) {
            log.info("退款异常:", e);
        }
        refund.setRefundNo(refundNo);
        if ("success".equals(refundResult)) {
            //更新支付单状态为退费
            refund.setRefundStatus(RefundStatus.REFUND_APPLY_SUCCESS.getStatus());
        } else {
            refund.setRefundStatus(RefundStatus.REFUND_APPLY_FAIL.getStatus());
        }
        zhifuOrder.setZhifuStatus(ZhifuStatus.REFUND.getStatus());
        zhifuOrder.setRemark(refundReason);
        int uo = update(zhifuOrder);
        int ur = zhifuOrderRefundService.updateByZhifuId(refund);
        log.info("订单{}更新退款状态:{}, 更新退款记录状态:{}",zhifuOrder.getOrderNo(), uo, ur);
        return refundResult;
    }
}
