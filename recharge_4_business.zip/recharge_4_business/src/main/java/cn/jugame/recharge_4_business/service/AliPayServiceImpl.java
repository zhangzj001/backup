package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.RtnUtil;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.domain.AlipayTradeFastpayRefundQueryModel;
import com.alipay.api.domain.AlipayTradeRefundModel;
import com.alipay.api.domain.AlipayTradeWapPayModel;
import com.alipay.api.request.AlipayTradeAppPayRequest;
import com.alipay.api.request.AlipayTradeFastpayRefundQueryRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.request.AlipayTradeWapPayRequest;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import com.alipay.api.response.AlipayTradeFastpayRefundQueryResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.alipay.api.response.AlipayTradeWapPayResponse;
import jodd.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by surong on 2019-04-28.
 * ClassName: AliPayServiceImpl
 * Function: 定义原生支付宝支付接口. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Service
@Component("aliPayService")
public class AliPayServiceImpl implements IBasePayService {
	private static final Logger log = LoggerFactory.getLogger(AliPayServiceImpl.class);

	@Autowired
	private AlipayClient alipayClient;

	@Value("${alipay.notify.url}")
	private String notify_url;
	@Value("${alipay.return.url}")
	private String return_url;
	@Value("${alipay.order.timeout}")
	private String orderTimeout;

	@Override
	public JSONObject appPay(ZhifuOrder zhifuOrder, String ip) {

		JSONObject data = new JSONObject();
		String orderGoodName = StringFilter(zhifuOrder.getOrderName());
		// 实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
		AlipayTradeAppPayRequest request = new AlipayTradeAppPayRequest();
		// SDK已经封装掉了公共参数，这里只需要传入业务参数。以下方法为sdk的model入参方式(model和biz_content同时存在的情况下取biz_content)。
		AlipayTradeAppPayModel model = new AlipayTradeAppPayModel();
		model.setBody(orderGoodName);
		model.setSubject(orderGoodName);
		model.setOutTradeNo(zhifuOrder.getZhifuId());
		model.setTimeoutExpress(orderTimeout);
		model.setTotalAmount(zhifuOrder.getZhifuOrderAmount().getAmount().toString());
		model.setProductCode("QUICK_MSECURITY_PAY");
		request.setBizModel(model);
		request.setNotifyUrl(notify_url);
		String alipayString = "";
		try {
			// 这里和普通的接口调用不同，使用的是sdkExecute
			AlipayTradeAppPayResponse response = alipayClient.sdkExecute(request);
			if (response.isSuccess()) {
				alipayString  = response.getBody();//就是orderString 可以直接给客户端请求，无需再做处理。
			}

			log.info(zhifuOrder.getOrderNo() + " 获取支付宝APP端支付参数返回：orderString:" + alipayString, ", msg:" + response.getMsg());

		} catch (AlipayApiException e) {
			log.error(zhifuOrder.getOrderNo() + "获取支付宝支付数据异常:{}", e);
		}
		if(StringUtil.isBlank(alipayString)) {
			return null;
		}
		data.put("payInfo", alipayString);
		return data;
	}

	@Override
	public String wapPay(ZhifuOrder zhifuOrder, String ip) {
		JSONObject data = new JSONObject();
		String orderGoodName = StringFilter(zhifuOrder.getOrderName());
		// 实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
		AlipayTradeWapPayRequest request = new AlipayTradeWapPayRequest();
		// SDK已经封装掉了公共参数，这里只需要传入业务参数。以下方法为sdk的model入参方式(model和biz_content同时存在的情况下取biz_content)。
		AlipayTradeWapPayModel model = new AlipayTradeWapPayModel();

		model.setBody(orderGoodName);
		model.setSubject(orderGoodName);
		model.setOutTradeNo(zhifuOrder.getZhifuId());
		model.setTimeoutExpress(orderTimeout);
		model.setTotalAmount(zhifuOrder.getZhifuOrderAmount().getAmount().toString());
		model.setQuitUrl(return_url);
		model.setProductCode("QUICK_WAP_WAY");
		request.setBizModel(model);
		request.setNotifyUrl(notify_url);
		request.setReturnUrl(return_url);
		String htmlString = "";
		try {
			// 这里和普通的接口调用不同，使用的是sdkExecute
			AlipayTradeWapPayResponse response = alipayClient.pageExecute(request);
			if (response.isSuccess()) {
				htmlString  = response.getBody();//就是orderString 可以直接给客户端请求，无需再做处理。
			}

			log.info(zhifuOrder.getOrderNo() + " 获取支付宝wap端支付参数返回：htmlString:" + htmlString, ", msg:" + response.getMsg());

		} catch (AlipayApiException e) {
			log.error(zhifuOrder.getOrderNo() + "获取支付宝wap支付数据异常:{}", e);
		}
		if(StringUtil.isBlank(htmlString)) {
			return null;
		}
		return htmlString;
	}

	/**
	 * 支付宝退款查询
	 * @param refundNo
	 * @param clientType
	 * @return -1 查询失败  0处理中  1退款成功  2退款失败
	 */
	@Override
	public JSONObject orderRefundQuery(String refundNo, String clientType) {
		AlipayTradeFastpayRefundQueryRequest request = new AlipayTradeFastpayRefundQueryRequest();
		// 创建退款查询请求builder，设置请求参数
		AlipayTradeFastpayRefundQueryModel model = new AlipayTradeFastpayRefundQueryModel();
		model.setOutTradeNo(refundNo);
		model.setOutRequestNo(refundNo);
		request.setBizModel(model);

		AlipayTradeFastpayRefundQueryResponse response = null;
		try {
			response = alipayClient.execute(request);
		} catch (AlipayApiException e) {
			log.error("退款单{}支付宝退款结果查询异常:{}", refundNo, e);
			return RtnUtil.setResult(-1, "支付宝退款结果查询异常");
		}
		if(response.isSuccess() && !StringUtils.isBlank(response.getRefundAmount())){
			log.info("退款单{}支付宝退款成功",refundNo);
			return RtnUtil.setResult(1, "支付宝退款成功");
		} else {
			log.error("退款单{}支付宝退款失败:{}", refundNo,response.getSubMsg());
			return RtnUtil.setResult(2, StringUtils.isBlank(response.getSubMsg()) ? "失败" : response.getSubMsg());
		}
	}

	@Override
	public String orderRefund(ZhifuOrder zhifuOrder, String refundNo, String refundReason) {
		log.info("订单支付宝退款开始：{}", zhifuOrder.getOrderNo());
		String  refundResult = "fail";
		// (必填) 外部订单号，需要退款交易的商户外部订单号
		String outTradeNo = zhifuOrder.getZhifuId();
		// (必填) 退款金额，该金额必须小于等于订单的支付金额，单位为元
		String refundAmount = zhifuOrder.getZhifuOrderAmount().getAmount().toString();
		AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
		AlipayTradeRefundModel model = new AlipayTradeRefundModel();
		model.setOutTradeNo(outTradeNo);
		model.setRefundAmount(refundAmount);
		model.setRefundReason(refundReason);
		request.setBizModel(model);

		AlipayTradeRefundResponse response = null;
		try {
			response = alipayClient.execute(request);
		} catch (AlipayApiException e) {
			log.info("订单{}支付宝退款异常:{}",zhifuOrder.getOrderNo(), e);
			refundResult = "支付宝退款申请异常";
		}
		if(response.isSuccess()){
			log.info("订单{}支付宝退款申请成功",zhifuOrder.getOrderNo());
			refundResult = "success";
		} else {
			log.info("订单{}支付宝退款失败:{}",zhifuOrder.getOrderNo(), response.getSubMsg());
			refundResult = "支付宝退款申请失败";
		}
		return refundResult;

	}

	// 过滤特殊字符
	private static String StringFilter(String str) {
		String regEx="[`@#$%^&*()+=|{}❤]";
		Pattern p = Pattern.compile(regEx);
		Matcher m = p.matcher(str);
		return m.replaceAll("").trim();
	}

}
