package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import com.alibaba.fastjson.JSONObject;

import java.io.UnsupportedEncodingException;

/**
 * Created by surong on 2019-04-28.
 * ClassName: IBasePayService
 * Function: 定义第三方支付接口. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
public interface IBasePayService {

	/**
	 * 订单退款
	 * @param zhifuOrder
	 * @param refundReason
	 * @return  String
	 * @Date	2019年4月29日
	 * @Author  surong
	 */
	String orderRefund(ZhifuOrder zhifuOrder, String refundNo, String refundReason) throws UnsupportedEncodingException;

	/**
	 * app 下单
	 * @param zhifuOrder
	 * @return  JSONObject
	 * @Date	2019年4月29日
	 * @Author  surong
	 */
	JSONObject appPay(ZhifuOrder zhifuOrder, String ip);

	/**
	 * wap 下单
	 * @param zhifuOrder
	 * @return  JSONObject
	 * @Date	2019年4月29日
	 * @Author  surong
	 */
	String wapPay(ZhifuOrder zhifuOrder, String ip);

	/**
	 * 订单退款状态查询
	 * @param refundNo
	 * @param clientType
	 * @return  String
	 * @Date	2019年4月29日
	 * @Author  surong
	 */
	JSONObject orderRefundQuery(String refundNo, String clientType);

}
