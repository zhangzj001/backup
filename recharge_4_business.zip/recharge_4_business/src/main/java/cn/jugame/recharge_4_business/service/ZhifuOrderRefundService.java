package cn.jugame.recharge_4_business.service;


import cn.jugame.recharge_4_business.entity.Product;
import cn.jugame.recharge_4_business.entity.ZhifuOrderRefund;
import cn.jugame.recharge_4_business.mapper.ZhifuOrderRefundMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZhifuOrderRefundService {

    @Autowired
    ZhifuOrderRefundMapper zhifuOrderRefundMapper;

    public ZhifuOrderRefund findByZhifuId(String zhifuId) {
        return zhifuOrderRefundMapper.findFirstByZhifuId(zhifuId);
    }

    public int save(ZhifuOrderRefund refund) {
        return zhifuOrderRefundMapper.save(refund);
    }

    public int update(ZhifuOrderRefund refund) {
        return zhifuOrderRefundMapper.updateById(refund);
    }

    public int updateByZhifuId(ZhifuOrderRefund refund) {
        return zhifuOrderRefundMapper.updateByZhifuId(refund);
    }

    public List<ZhifuOrderRefund> queryAllRefundByStatus(int status, int pageNo, int pageSize) {
        pageNo = (pageNo > 1 ? pageNo - 1 : pageNo) * pageSize;
        return zhifuOrderRefundMapper.queryAllRefundByRefundStatus(status,pageNo, pageSize);
    }

}
