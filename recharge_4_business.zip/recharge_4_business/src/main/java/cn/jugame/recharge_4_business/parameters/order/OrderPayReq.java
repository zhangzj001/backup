package cn.jugame.recharge_4_business.parameters.order;

public class OrderPayReq {
    public long uid;
    public String orderNo;
}
