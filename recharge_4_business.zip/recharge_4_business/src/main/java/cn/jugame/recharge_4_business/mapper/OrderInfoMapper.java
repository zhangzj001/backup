package cn.jugame.recharge_4_business.mapper;

import cn.jugame.recharge_4_business.controller.admin.AdminOrderController.ListQuery;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.entity.Query;
import cn.jugame.recharge_4_business.mapper.provider.OrderInfoProvider;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

/**
 * Created by solom on 2019-07-18. ClassName: OrderInfoMapper Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-18 15:10
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Repository
@Mapper
public interface OrderInfoMapper {

    @Insert("insert into `order_info` ( `id`, `ch`, `ip`, `package_name`, "
            + "`pay_type`, `product_num`, `fr`, `product_id`, `amount`, `order_time`, "
            + "`uid`, `order_finish_time`, `order_no`, `product_type`, `pay_time`, `package_id`,"
            + " `recharge_account`, `product_no`, `product_name`, `third_product_code`, `third_product_price`, `product_desc`,"
            + " `extern_uid`, `extern_channel`)"
            + " values (#{id}, #{ch}, #{ip}, #{packageName}, #{payType},"
            + "#{productNum}, #{fr}, #{productId}, #{amount}, now(),"
            + "#{uid}, null, #{orderNo}, #{productType}, null, #{packageId},"
            + "#{rechargeAccount}, #{productNo}, #{productName}, #{thirdProductCode}, #{thirdProductPrice}, #{productDesc},"
            + "#{externUid}, #{externChannel})")
    int insert(OrderInfo o);

    @Update("update `order_info` set pay_time = #{payTime}, order_status = 1 where id = #{id}")
    int updatePay(OrderInfo o);

    @Update("update `order_info` set order_status = #{status}, update_time = now() where id = #{id}")
    int updateStatus(@Param("status") int status, @Param("id") int id);

    @Select("select * from order_info where order_no = #{orderNo}")
    OrderInfo findByOrderNo(@Param("orderNo") String orderNo);

    @Select("select * from order_info where uid = #{uid} and order_status in (${status}) order by id desc limit #{start}, #{size}")
    List<OrderInfo> findAllByUidAndStatusPage(@Param("uid") int uid, @Param("status") String status, @Param("start") int pageNo, @Param("size") int pageSize);

    @Select("select * from order_info where uid = #{uid} and order_status in (${status}) and `extern_uid` = #{externUid} and `extern_channel` = #{externChannel} order by id desc limit #{start}, #{size}")
    List<OrderInfo> findAllByUidAndStatusAndExternPage(@Param("uid") int uid, @Param("status") String status, @Param("externUid") String externUid, @Param("externChannel") String externChannel, @Param("start") int pageNo, @Param("size") int pageSize);

    @Select("select * from order_info where uid = #{uid} and order_no = #{orderNo}")
    OrderInfo findUserOrderDetail(@Param("uid") int uid, @Param("orderNo") String orderNo);

    @SelectProvider(type = OrderInfoProvider.class, method = "select")
    List<OrderInfo> queryOrders(Query param);

    @SelectProvider(type = OrderInfoProvider.class, method = "count")
    int countOrders(ListQuery param);

    @Select("select count(1) from order_info")
    int count();

    @Select("select order_status from order_info where order_no = #{orderNo}")
    int findOrderStatusByOrderNo(@Param("orderNo") String orderNo);

    @Update("update `order_info` set order_status = 1, pay_time = now(), pay_platform = #{payPlatform}, update_time = now() where order_no = #{orderNo} and uid = #{uid}")
    int updateOrderForPay(@Param("orderNo") String orderNo, @Param("uid") long uid, @Param("payPlatform") String payPlatform);

    @Update("update `order_info` set is_refunded = 1, refund_reason = #{refundReason}, refund_time = now(), update_time = now() where order_no = #{orderNo}")
    int updateOrderForRefund(@Param("orderNo") String orderNo, @Param("refundReason") String refundReason);

    @Update("update `order_info` set recharge_no = #{rechargeNo}, update_time = now() where order_no = #{orderNo}")
    int updateOrderRechargeNo(@Param("rechargeNo") String rechargeNo, @Param("orderNo") String orderNo);

    @Update("update `order_info` set order_status = 2, recharge_no = #{rechargeNo}, update_time = now() where order_no = #{orderNo} and uid = #{uid}")
    int updateOrderForRecharging(@Param("rechargeNo") String rechargeNo, @Param("orderNo") String orderNo, @Param("uid") long uid);

    @Update("update `order_info` set order_status = 3, order_finish_time = now(), update_time = now() where order_no = #{orderNo} and uid = #{uid}")
    int updateOrderForFinish(@Param("orderNo") String orderNo, @Param("uid") long uid);

    @Update("update `order_info` set order_status = 4, is_refunded = 1, refund_reason = #{cancelReason},update_time = now() where order_no = #{orderNo} limit 1")
    int updateOrderForCancelAndRefund(String orderNo, String cancelReason);

    @Update("update `order_info` set pay_type = #{payType} where id = #{id}")
    int updatePayType(@Param("id") int id, @Param("payType") int payType);
}
