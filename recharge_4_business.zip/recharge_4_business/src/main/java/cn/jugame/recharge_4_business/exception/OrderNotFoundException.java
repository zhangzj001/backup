package cn.jugame.recharge_4_business.exception;


public class OrderNotFoundException extends ApiException {

    public OrderNotFoundException(String msg) {
        super(OrderExceptionCode.ORDER_NOT_FOUND_EXCEPTION.getCode(), msg);
    }

}
