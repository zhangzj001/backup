package cn.jugame.recharge_4_business.parameters.order;

public class OrderFinishReq {
    public long uid;
    public String orderNo;
}
