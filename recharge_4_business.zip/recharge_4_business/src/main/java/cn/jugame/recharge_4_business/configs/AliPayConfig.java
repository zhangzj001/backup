package cn.jugame.recharge_4_business.configs;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * Created by surong on 2019-04-28.
 * ClassName: AliPayConfig
 * Function: 原生支付宝配置类. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */

@Configuration
@Component
@PropertySource("classpath:pay.properties")
public  class AliPayConfig {

    @Value("${ali.sign_type}")
 	private  String signType;
    @Value("${ali.open_api_domain}")
    private String openApiDomain;
    @Value("${ali.appid}")
    private String appId;
    @Value("${ali.private_key}")
    private String privateKey;
    @Value("${ali.alipay_public_key}")
    private String alipayPublicKey;

    @Bean
    public AlipayClient alipayClient(){
        return new DefaultAlipayClient(
                openApiDomain, appId,
                privateKey, "json", "utf-8",
                alipayPublicKey,signType);
    }

}
