package cn.jugame.recharge_4_business.controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by solom on 2019-07-17. ClassName: UserController Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-17 15:02
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Controller
@RequestMapping("/user/")
public class UserController extends BaseController {

  @RequestMapping("login.html")
  public String login(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    String url = getParam(request, "currentUrl", "");
    model.addAttribute("currentUrl", url);
    return "user/login";
  }

  @RequestMapping("ip.html")
  @ResponseBody
  public String ip(HttpServletRequest request, HttpServletResponse response,
      HttpSession session, Model model) throws IOException {
    System.err.println(getIp(request));
    return getIp(request);
  }
}
