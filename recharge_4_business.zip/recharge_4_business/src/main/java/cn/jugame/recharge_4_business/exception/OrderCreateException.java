package cn.jugame.recharge_4_business.exception;


public class OrderCreateException extends ApiException {

    public OrderCreateException() {
        super(OrderExceptionCode.ORDER_CREATE_EXCEPTION.getCode(), "创建订单失败");
    }

    public OrderCreateException(String msg) {
        super(OrderExceptionCode.ORDER_CREATE_EXCEPTION.getCode(), msg);
    }

}
