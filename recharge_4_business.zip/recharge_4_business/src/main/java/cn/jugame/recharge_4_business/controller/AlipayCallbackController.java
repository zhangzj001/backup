package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.commons.DateUtils;
import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.service.CallbackService;
import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * Created by surong on 2019-04-28.
 * ClassName: CallbackRequestAlipay
 * Function: 原生支付宝后台回调. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Controller
@PropertySource(value = "classpath:pay.properties")
public class AlipayCallbackController {
  protected static Logger log = LoggerFactory.getLogger(AlipayCallbackController.class);

  @Value("${ali.sign_type}")
  private String signType;
  @Value("${ali.appid}")
  private String appId;
  @Value("${ali.alipay_public_key}")
  private String alipayPublicKey;

  @Autowired
  CallbackService callbackService;

  /**
   * 原生支付宝支付回调(后台通知)
   *
   * @param request
   * @param response
   * @return
   */
  @PostMapping(value = "/callback/alipayCallbackBackend")
  @ResponseBody
  public void aliPayCallbackBackend(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
    String message = "success";
    int payChannel = PayChannel.CHANNEL_ORIGIN.getChannel();//原生支付宝渠道
    int payType = PayType.PAY_TYPE_ALIPAY.getType();
    Map<String, String> params = new HashMap<String, String>();
    // 取出所有参数是为了验证签名
    Enumeration<String> parameterNames = request.getParameterNames();
    while (parameterNames.hasMoreElements()) {
      String parameterName = parameterNames.nextElement();
      params.put(parameterName, request.getParameter(parameterName));
    }
    log.info("支付宝后台回调参数：{}", params);
    //验证签名 校验签名
    boolean signVerified = false;
    try {
      signVerified = AlipaySignature.rsaCheckV1(params, alipayPublicKey, "utf-8", signType);
      //这里可能需要注意一下,2018/01/26 以后新建应用只支持RSA2签名方式，目前已使用RSA签名方式的应用仍然可以正常调用接口，注意下自己生成密钥的签名算法
      //可能使用了这个API导致验签失败，特此说明一下
      //signVerified = AlipaySignature.rsaCheckV2(params, Configs.getAlipayPublicKey(), "UTF-8");//正式环境
    } catch (AlipayApiException e) {
      e.printStackTrace();
      message = "failed";
    }
    boolean isPay = false;
    if (signVerified) {
      log.info("支付宝验证签名成功！");
      // 若参数中的appid和填入的appid不相同，则为异常通知
      if (!appId.equals(params.get("app_id"))) {
        log.info("与付款时的appid不同，此为异常通知，应忽略！");
        message = "failed";
      } else {
        String outTradeno = params.get("out_trade_no");
        //支付宝交易号
        String tradeNo = params.get("trade_no");
        //交易状态
        String tradeStatus = params.get("trade_status");
        //支付时间
        String gmtPayment = params.get("gmt_payment");
        //交易金额
        String totalFee = params.get("total_amount");
        String status = params.get("trade_status");
        if(!status.equals("TRADE_CLOSED")) { //注意退款或超时关闭也会通知，有毛病，对这两种情况不处理
          isPay = (status.equals("TRADE_SUCCESS") || status.equals("TRADE_FINISHED"));
          boolean ret = callbackService.callbackBackend(outTradeno, tradeNo, DateUtils.parseDate(gmtPayment, "yyyy-MM-dd HH:mm:ss"), "", isPay, Double.valueOf(totalFee), payChannel, payType);
          log.info("支付单{}后台回调结果：{}",outTradeno,ret);
        }
      }
    } else { // 如果验证签名没有通过
      message = "failed";
      log.info("验证签名失败！");
    }
    log.info("支付宝后台回调回填:{}",message);
    BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
    out.write(message.getBytes());
    out.flush();
    out.close();
  }

  @RequestMapping(value = "/callback/alipayCallbackFront")
  public String alipayCallbackFront(HttpServletRequest request, Model model){
    try {
      Map<String,String> params = new HashMap<String,String>();
      Map requestParams = request.getParameterMap();
      for (Iterator iter = requestParams.keySet().iterator(); iter.hasNext();) {
        String name = (String) iter.next();
        String[] values = (String[]) requestParams.get(name);
        String valueStr = "";
        for (int i = 0; i < values.length; i++) {
          valueStr = (i == values.length - 1) ? valueStr + values[i]
                  : valueStr + values[i] + ",";
        }
        //乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
//        valueStr = new String(valueStr.getBytes("ISO-8859-1"), "utf-8");
        params.put(name, valueStr);
      }
      log.info("支付宝前台回调参数1：{}", params);

      //计算得出通知验证结果
      boolean verifyResult = AlipaySignature.rsaCheckV1(params, alipayPublicKey, "utf-8", signType);
      if(!verifyResult){
        log.info("verify fail");
        return "";
      }

      String outTradeo = params.get("out_trade_no");
      //支付宝交易号
      String tradeNo = params.get("trade_no");

      //跳转支付详情页
      String returnUrl = callbackService.callbackFront(outTradeo);
      return "redirect:" + returnUrl;
    } catch (Exception e) {
      log.error("callbackFront异常:",e);
      model.addAttribute("errorMsg","跳转异常");
      return "error";
    }
  }

}
