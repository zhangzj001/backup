package cn.jugame.recharge_4_business.mapper.provider;

import cn.jugame.recharge_4_business.controller.admin.AdminProductController.ListQuery;
import cn.jugame.recharge_4_business.entity.Product;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by solom on 2019-07-22. ClassName: ProductSqlProvider Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-22 15:04
 *
 * @author: solom
 * @since: jdk 1.8
 */
public class ProductSqlProvider {

  public String select(ListQuery param) {
    StringBuffer sql = new StringBuffer("select * from `product` where 1 = 1");
    if (StringUtils.isNotEmpty(param.getProductNo())) {
      sql.append(" and product_no = #{productNo}");
    }
    if (param.getProductType() > 0) {
      sql.append(" and type = #{productType}");
    }
    if (param.getStatus() != -1) {
      sql.append(" and status = #{status}");
    }
    sql.append(" limit #{page}, #{rows}");
    System.err.println(sql);
    return sql.toString();
  }

  public String count(ListQuery param) {
    StringBuffer sql = new StringBuffer("select count(1) from `product` where 1 = 1");
    if (StringUtils.isNotEmpty(param.getProductNo())) {
      sql.append(" and product_no = #{productNo}");
    }
    if (param.getProductType() > 0) {
      sql.append(" and type = #{productType}");
    }
    if (param.getStatus() != -1) {
      sql.append(" and status = #{status}");
    }
    return sql.toString();
  }
}
