package cn.jugame.recharge_4_business.commons;

import java.util.Date;

/**
 * 登录用户信息
 * @author Samsung
 *
 */
public class SysUserInfo {

  /**
   * 用户ID
   */
  private int userId;
  /**
   * 登录账号
   */
  private String loginId;
  /**
   * 用户类型 0超级管理员 1普通管理员
   */
  private int userType;
  private int status;
  private Date createTime ;
  private String customerServiceId;
  private String fullname;

  /**
   * 在线状态 1 休息 2 接单
   */
  private int onlineStatus;
  private int isCustomer ;
  private int isObjectCustomer;
  private int isOnDuty;
  private String customerNickname;
  private String customerQq;


  public int getUserId() {
    return userId;
  }
  public void setUserId(int userId) {
    this.userId = userId;
  }
  public String getLoginId() {
    return loginId;
  }
  public void setLoginId(String loginId) {
    this.loginId = loginId;
  }
  public int getUserType() {
    return userType;
  }
  public void setUserType(int userType) {
    this.userType = userType;
  }
  public int getStatus() {
    return status;
  }
  public void setStatus(int status) {
    this.status = status;
  }
  public Date getCreateTime() {
    return createTime;
  }
  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }
  public String getCustomerServiceId() {
    return customerServiceId;
  }
  public void setCustomerServiceId(String customerServiceId) {
    this.customerServiceId = customerServiceId;
  }
  public int getOnlineStatus() {
    return onlineStatus;
  }
  public void setOnlineStatus(int onlineStatus) {
    this.onlineStatus = onlineStatus;
  }
  public int getIsCustomer() {
    return isCustomer;
  }
  public void setIsCustomer(int isCustomer) {
    this.isCustomer = isCustomer;
  }
  public int getIsObjectCustomer() {
    return isObjectCustomer;
  }
  public void setIsObjectCustomer(int isObjectCustomer) {
    this.isObjectCustomer = isObjectCustomer;
  }
  public int getIsOnDuty() {
    return isOnDuty;
  }
  public void setIsOnDuty(int isOnDuty) {
    this.isOnDuty = isOnDuty;
  }
  public String getCustomerNickname() {
    return customerNickname;
  }
  public void setCustomerNickname(String customerNickname) {
    this.customerNickname = customerNickname;
  }
  public String getCustomerQq() {
    return customerQq;
  }
  public void setCustomerQq(String customerQq) {
    this.customerQq = customerQq;
  }
  public String getFullname() {
    return fullname;
  }
  public void setFullname(String fullname) {
    this.fullname = fullname;
  }
}
