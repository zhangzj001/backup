package cn.jugame.recharge_4_business.commons;

import java.net.URLEncoder;

/**
 * Created by solom on 2019-07-18. ClassName: Common Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-18 10:52
 *
 * @author: solom
 * @since: jdk 1.8
 */
public final class Common {

  public static String urlEncode(String s, String enc) {
    try {
      return URLEncoder.encode(s, enc);
    } catch (Exception e) {
      return null;
    }
  }

  public static String urlEncode(String s) {
    return urlEncode(s, "UTF-8");
  }
}
