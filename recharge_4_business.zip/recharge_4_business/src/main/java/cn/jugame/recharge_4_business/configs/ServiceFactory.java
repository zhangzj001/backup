package cn.jugame.recharge_4_business.configs;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.impl.APIAccountcenterServiceImpl;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ServiceFactory {

  private static Map<String, Object> HttpServiceCache = new HashMap<String, Object>();

  @Value("${account_center_service_url}")
  private String url;
  @Value("${account_center_service_caller}")
  private String caller;
  @Value("${account_center_service_sign_key}")
  private String key;

  public <T> T createService(Class<? extends T> clazz) {
    if (clazz.getName().equals("cn.jugame.account_center.api.IAccountCenterService")) {
      return (T) getAccountCenterService();
    }else{
      return null;
    }
  }

  private IAccountCenterService getAccountCenterService() {
    IAccountCenterService accountCenterService = (IAccountCenterService) HttpServiceCache.get("account_center_service");
    if (accountCenterService == null) {
      accountCenterService = new APIAccountcenterServiceImpl(url, 50, 1, caller, key);
      HttpServiceCache.put("account_center_service", accountCenterService);
    }
    return accountCenterService;
  }
}
