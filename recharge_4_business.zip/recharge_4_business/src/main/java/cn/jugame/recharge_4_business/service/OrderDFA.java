package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.constant.OrderStatus;

import java.util.Set;
import java.util.TreeSet;

public class OrderDFA {

    private static OrderDFA instance = new OrderDFA();

    public static OrderDFA getInstance() {
        return instance;
    }

    private OrderDFA() {

    }

    private Set<Integer> nextStatus(int currentStatus) {
        Set<Integer> statuses = new TreeSet<>();
        if (currentStatus == OrderStatus.ORDER_NEW) {
            statuses.add(OrderStatus.ORDER_PAYED);
            statuses.add(OrderStatus.ORDER_CANCELED);
        } else if (currentStatus == OrderStatus.ORDER_PAYED) {
            statuses.add(OrderStatus.ORDER_DELIVERED);
            statuses.add(OrderStatus.ORDER_CANCELED);
        } else if (currentStatus == OrderStatus.ORDER_DELIVERED) {
            statuses.add(OrderStatus.ORDER_CANCELED);
            statuses.add(OrderStatus.ORDER_FINISHED);
        }
        return statuses;
    }

    public boolean nextStatus(int currentStatus, int nextStatus) {
        return nextStatus(currentStatus).contains(nextStatus);
    }
}
