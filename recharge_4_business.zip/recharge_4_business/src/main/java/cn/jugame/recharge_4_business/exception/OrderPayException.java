package cn.jugame.recharge_4_business.exception;


public class OrderPayException extends ApiException {
    public OrderPayException(String msg) {
        super(OrderExceptionCode.ORDER_PAY_EXCEPTION.getCode(), msg);
    }
}
