package cn.jugame.recharge_4_business.configs;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SSOClientChecker {

  @Autowired
  private SSOClient client;

  private static final boolean DEBUG = false;

  public boolean check(HttpServletRequest request) {
    if (!DEBUG) {
      String ticket = request.getParameter("ticket");
      if (request.getSession().getAttribute("session_uid") != null) {
        return true;
      }
      int x = 0;
      try {
        x = client.invoke(ticket);
      } catch (Exception e) {
        e.printStackTrace();
      }
      if (x != 0) {
        return false;
      }
      request.getSession().setAttribute("admin_user", client.getSysUserInfo());
      request.getSession().setAttribute("session_uid", client.getSysUserInfo().getUserId());
    } else {
      request.getSession().setAttribute("session_uid", 1);
    }

    return true;
  }
}
