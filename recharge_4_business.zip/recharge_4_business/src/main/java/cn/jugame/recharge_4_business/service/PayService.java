package cn.jugame.recharge_4_business.service;


import cn.jugame.recharge_4_business.cache.CacheService;
import cn.jugame.recharge_4_business.commons.RtnUtil;
import cn.jugame.recharge_4_business.commons.constant.BusiCode;
import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.commons.constant.ZhifuStatus;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.service.payrequest.BasePayReq;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.joda.money.CurrencyUnit;
import org.joda.money.Money;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Created by surong on 2019-04-28.
 * ClassName: PayService
 * Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Service
public class PayService {

    @Autowired
    ZhifuOrderService zhifuOrderService;
    @Autowired
    ZhifuOrderRefundService zhifuOrderRefundService;
    @Autowired
    IBasePayService aliPayService;
    @Autowired
    IBasePayService nowPayService;
    @Autowired
    IBasePayService jhPayService;
    @Autowired
    CacheService cacheService;
//    @Autowired
//    OrderInfoRepository orderInfoRepository;

    @Value("${nowpay.order.timeout}")
    private long orderTimeOut;
    @Value("${ali.pay.channel}")
    private int aliPayChannel;
    @Value("${wx.pay.channel}")
    private int wxPayChannel;

    protected static Logger log = LoggerFactory.getLogger(PayService.class);

    /**
     * app端支付入口
     * @param req
     * @return
     * 1.原生支付宝：取payInfo字段在手机端调用支付宝sdk作为orderInfo直接传入
     * {"msg":"ok","code":1,"data":{"orderNo":"test-123","orderAmount":10,"payType":1,"orderTitle":"测试","payInfo":"alipay_sdk=alipay-sdk-java-3.7.26.ALL&app_id=2016100100635954&biz_content=%7B%22body%22%3A%22%E6%B5%8B%E8%AF%95%22%2C%22out_trade_no%22%3A%22P19043015dxdxCA6D00E33%22%2C%22product_code%22%3A%22QUICK_MSECURITY_PAY%22%2C%22subject%22%3A%22%E6%B5%8B%E8%AF%95%22%2C%22timeout_express%22%3A%22%22%2C%22total_amount%22%3A%220.10%22%7D&charset=utf-8&format=json&method=alipay.trade.app.pay&sign=M5t8fFpBYwcez4AsAIL3ZSeZUMaXkXpYfKkXVgNqjvZPfuIn4A7C%2F76MFebgFzvui9eVml5MHkZjh%2BNJAMCzOD7aZj%2FU8tQWcju2TVe2ozgB1E3Va%2Fxy60jxlQsBw%2BTc1My1RDKw0UjgVLFXMrKBVauC%2FZfIsvmOFYLHRKdJqP1M4rwpDAj54%2F9SG5gA9kt89UBfck6x44pdX7aM4EvQ4Yo4twlT7JsaZL3TyY5epPp5MIKwZV0ohZv1I0oWoLUxgERVIyozdM1yOK4AcxAr7vYBzH%2FgFytlE3f9M5ja6bL7%2B0OTUhgV2boKRFkb%2FnzXwTfer7jqruxd1gOeqU4W3g%3D%3D&sign_type=RSA2&timestamp=2019-04-30+15%3A52%3A56&version=1.0"}}
     * 2.现在支付：支付宝及微信返回一样，payInfo里的参数则为手机端调用现在支付sdk所需参数
     * {"msg":"ok","code":1,"data":{"orderNo":"test-123","orderAmount":10,"payType":2,"orderTitle":"测试","payInfo":{"appId":"123232131232","deviceType":"01","frontNotifyUrl":"","funcode":"WP001","mhtCharset":"utf-8","mhtCurrencyType":"156","mhtOrderAmt":10,"mhtOrderDetail":"测试","mhtOrderName":"测试","mhtOrderNo":"P19043016dxdx654134083","mhtOrderStartTime":"20190430164050","mhtOrderTimeOut":"1800","mhtOrderType":"05","mhtReserved":"test-123","mhtSignType":"MD5","mhtSignature":"9ADCB037140BDCE256C42329E7BF51D6","notifyUrl":"http://m.8868.cn","payChannelType":"13","version":"1.0.3"}}}
     *
     */
    public JSONObject appPay(BasePayReq req){
        log.info("appPay -> req:{}", req);
        boolean checkReq = checkParams(req);
        if(!checkReq) {
            return RtnUtil.FAIL("支付请求参数校验失败");
        }
        //防止重复支付
        Object payStatusDec = cacheService.get("pay_" + req.getOrderNo());
        if(null != payStatusDec && ("paying".equals((String) payStatusDec) || "paid".equals((String) payStatusDec))) {
            log.info("订单{}支付中，请勿重复提交...", req.getOrderNo());
            return RtnUtil.FAIL("订单支付中，请勿重复提交");
        } else {
            cacheService.set("pay_" + req.getOrderNo(),3, "paying");
        }
        //创建支付单，每次都新创建支付单，有些支付渠道一旦提交过一次支付单，即时没成功支付，后续不可再用相同的支付单提交
        int addZo = 0;
        ZhifuOrder zhifuOrder = ZhifuOrder.builder()
                    .zhifuOrderAmount(Money.ofMinor(CurrencyUnit.of("CNY"), req.getOrderAmount()))
                    .busiCode(StringUtils.isBlank(req.getBusiCode()) ? BusiCode.QBCZ.getCode() : req.getBusiCode())
                    .expireTime(orderTimeOut)
                    .orderTime(req.getOrderTime())
                    .orderCustomerId(req.getCustomerId())
                    .orderNo(req.getOrderNo())
                    .orderName(req.getOrderName())
                    .payClientType("app")
                    .payType(req.getPayType())
                    .zhifuStatus(ZhifuStatus.INIT.getStatus())
                    .remark("").build();
        try {
            addZo = zhifuOrderService.addZhifuOrder(zhifuOrder);
        } catch(Exception e) {
            log.error("创建支付单异常：{}", e);
            return RtnUtil.FAIL("支付单创建失败");
        }

        //判断订单是否成功
        if(addZo <= 0) {
            log.error("支付单创建失败, 订单号:{}", req.getOrderNo());
            return RtnUtil.FAIL("支付单创建失败");
        }

        if (zhifuOrder.getZhifuStatus() > ZhifuStatus.PAY_FAIL.getStatus()) {
             log.error("支付单状态非法：{}", req.getOrderNo());
            return RtnUtil.FAIL("订单支付状态非法");
        }
        int payChannel = PayChannel.CHANNEL_ORIGIN.getChannel();
        JSONObject data = new JSONObject();
        switch(req.getPayType()) {
            case 1: //支付宝（可以 走原生 或 现在支付）
                if(aliPayChannel == PayChannel.CHANNEL_ORIGIN.getChannel()) { //原生
                    data = aliPayService.appPay(zhifuOrder,req.getIp());
                } else {
                    data = nowPayService.appPay(zhifuOrder,req.getIp());
                    payChannel = PayChannel.CHANNEL_NOWPAY.getChannel();
                }
                break;
            case 2: //微信
                data = nowPayService.appPay(zhifuOrder, req.getIp());
                payChannel = PayChannel.CHANNEL_NOWPAY.getChannel();
        }
        if (null == data || !data.containsKey("payInfo")) {
            log.error("订单下单支付失败：{}:", zhifuOrder.getOrderNo());
            return RtnUtil.FAIL("订单下单支付失败:");
        }
        data.put("orderNo", zhifuOrder.getOrderNo());
        data.put("orderAmount", zhifuOrder.getZhifuOrderAmount().getAmount());
        data.put("orderTitle", zhifuOrder.getOrderName());
        data.put("payType", zhifuOrder.getPayType());
        data.put("payChannel", payChannel);
        log.info(zhifuOrder.getOrderNo() + "app下单支付返回：{}",data.toJSONString());
        return RtnUtil.OK(data);
    }

    /**
     * wap端支付入口
     * @Author: sueyoung
     * @Date: 2019-07-22 10:21
     * @Param: [req]
     * @Return:
     * 取htmlStr字段直接放入前段html页面，htmlStr字段为自动提交表单，自动跳转至支付界面
     * {"msg":"ok","code":1,"data":{"orderNo":"test-123","orderAmount":10,"payType":1,"orderTitle":"测试","htmlStr":"<form>....</form>"}}
     */
    public JSONObject wapPay(BasePayReq req){
        log.info("wapPay -> req:{}", req);
        boolean checkReq = checkParams(req);
        if(!checkReq) {
            return RtnUtil.FAIL("支付请求参数校验失败");
        }
        //防止重复支付
        Object payStatusDec = cacheService.get("pay_" + req.getOrderNo());
        if(null != payStatusDec && ("paying".equals((String) payStatusDec) || "paid".equals((String) payStatusDec))) {
            log.info("订单{}支付中，请勿重复提交...", req.getOrderNo());
            return RtnUtil.FAIL("订单支付中，请勿重复提交");
        } else {
            cacheService.set("pay_" + req.getOrderNo(),3, "paying");
        }
        //创建支付单，每次都新创建支付单，有些支付渠道一旦提交过一次支付单，即时没成功支付，后续不可再用相同的支付单提交
        int addZo = 0;
        ZhifuOrder zhifuOrder = ZhifuOrder.builder()
                .zhifuOrderAmount(Money.ofMinor(CurrencyUnit.of("CNY"), req.getOrderAmount()))
                .busiCode(StringUtils.isBlank(req.getBusiCode()) ? BusiCode.QBCZ.getCode() : req.getBusiCode())
                .expireTime(orderTimeOut)
                .orderTime(req.getOrderTime())
                .orderCustomerId(req.getCustomerId())
                .orderNo(req.getOrderNo())
                .orderName(req.getOrderName())
                .payClientType(req.getPlatform())
                .payType(req.getPayType())
                .zhifuStatus(ZhifuStatus.INIT.getStatus())
                .remark("").build();
        try {
            addZo = zhifuOrderService.addZhifuOrder(zhifuOrder);
        } catch(Exception e) {
            log.error("创建支付单异常：{}", e);
            return RtnUtil.FAIL("支付单创建失败");
        }

        //判断订单是否成功
        if(addZo <= 0) {
            log.error("支付单创建失败, 订单号:{}", req.getOrderNo());
            return RtnUtil.FAIL("支付单创建失败");
        }

        if (zhifuOrder.getZhifuStatus() > ZhifuStatus.PAY_FAIL.getStatus()) {
            log.error("支付单状态非法：{}", req.getOrderNo());
            return RtnUtil.FAIL("订单支付状态非法");
        }
        int payChannel = PayChannel.CHANNEL_ORIGIN.getChannel();
        String htmlString = "";
        switch(req.getPayType()) {
            case 1: //支付宝走原生
                htmlString = aliPayService.wapPay(zhifuOrder,req.getIp());
                break;
            case 2: //微信
                if (req.getPlatform().equals("gzh")) {//公众号支付用Q币充值那套聚合支付
                    htmlString = jhPayService.wapPay(zhifuOrder,req.getIp());
                    payChannel = PayChannel.CHANNEL_JHPAY.getChannel();
                } else { //现在支付
                    htmlString = nowPayService.wapPay(zhifuOrder, req.getIp());
                    payChannel = PayChannel.CHANNEL_NOWPAY.getChannel();
                }
        }

        if (StringUtils.isBlank(htmlString)) {
            log.error("订单下单支付失败：{}:", zhifuOrder.getOrderNo());
            return RtnUtil.FAIL("订单下单支付失败:");
        }
        JSONObject data = new JSONObject();
        data.put("orderNo", zhifuOrder.getOrderNo());
        data.put("orderAmount", zhifuOrder.getZhifuOrderAmount().getAmount());
        data.put("orderTitle", zhifuOrder.getOrderName());
        data.put("payType", zhifuOrder.getPayType());
        data.put("payChannel", payChannel);
        data.put("hmtlStr", htmlString);
        log.info(zhifuOrder.getOrderNo() + "wap下单支付返回：{}",data.toJSONString());
        return RtnUtil.OK(data);
    }


    /**
     * 订单退款
     * @param orderNo 订单号
     * @param refundReason 退款原因
     * @return "success" - 成功
     */
    public String orderRefund(String orderNo,String refundReason) {
        log.info("进入订单退单:{}",orderNo);
        String cacheKey = "orderRefund_" + orderNo;
        if(!cacheService.tryLock(cacheKey,10*1000)) {
            log.error("订单{}退款处理中,请勿重复提交",orderNo);
            return "订单退款处理中，请勿重复提交";
        }

        ZhifuOrder zhifuOrder = zhifuOrderService.findByOrderNoAndStatus(orderNo,ZhifuStatus.PAY_SUCCESS.getStatus());
        if (null == zhifuOrder) {
            log.info("订单{}不存在已支付的支付单", orderNo);
            return "订单不存在已支付的支付单";
        }

        String refundResult = zhifuOrderService.orderRefund(zhifuOrder, refundReason);
        return refundResult;
    }

    /**
     * 校验支付请求参数
     */
    private static boolean checkParams(BasePayReq req){

        if(StringUtils.isBlank(req.getOrderNo())) {
            log.error("支付参数校验失败：订单号不可为空");
            return false;
        }
        if(StringUtils.isBlank(req.getOrderName())) {
            log.error("支付参数校验失败：商品名称不可为空");
            return false;
        }
        if(req.getOrderAmount() <= 0) {
            log.error("支付参数校验失败：订单金额非法");
            return false;
        }
        if(req.getPayType() <= 0) {
            log.error("支付参数校验失败：支付方式非法");
            return false;
        }
        if(null == req.getOrderTime()) {
            log.error("支付参数校验失败：订单时间不可为空");
            return false;
        }
        if(req.getPayType() == PayType.PAY_TYPE_WXPAY.getType() && StringUtils.isBlank(req.getIp())) {
            log.error("支付参数校验失败：微信支付方式IP字段不可为空");
            return false;
        }
        return true;
    }

}
