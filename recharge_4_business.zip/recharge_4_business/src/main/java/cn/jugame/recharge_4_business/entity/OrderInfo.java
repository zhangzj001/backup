package cn.jugame.recharge_4_business.entity;

import com.alibaba.fastjson.annotation.JSONField;
import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by solom on 2019-07-18. ClassName: OrderInfo Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-18 10:56
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderInfo implements Serializable {
  private int id;
  private String orderNo;
  private int uid;
  private String fr;
  private String ch;
  private int productId;
  private String productNo;
  private int productType;
  private int packageId;
  private String thirdProductCode;
  private int thirdProductPrice;
  private String productName;
  private String packageName;
  private String productDesc;
  private int productNum;
  private String rechargeAccount;
  private String rechargeNo;
  private int amount;
  private int orderStatus;
  private int payType;
  private String payPlatform; //支付平台, wap,gzh
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date payTime;
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date orderFinishTime;
  private int isRefunded;
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date refundTime;
  private String refundReason;
  private String ip;
  @JSONField(format = "yyyy-MM-dd HH:mm:ss")
  private Date orderTime;

  private Date startTime;
  private Date endTime;
  private int start;
  private int size;

  private String externUid;
  private String externChannel;
}
