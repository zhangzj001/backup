package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.commons.constant.PayChannel;
import cn.jugame.recharge_4_business.commons.constant.PayType;
import cn.jugame.recharge_4_business.commons.pay.MD5;
import cn.jugame.recharge_4_business.service.CallbackService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by surong on 2019-04-28.
 * ClassName: CallbackRequestAlipay
 * Function: 现在支付后台回调. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Controller
public class JhPayCallbackController {
	protected static Logger log = LoggerFactory.getLogger(JhPayCallbackController.class);

	@Autowired
	CallbackService callbackService;

	@Value("${jh.pay.mcht.id}")
	private String mchtId;
	@Value("${jh.pay.term.id}")
	private String termId;
	@Value("${jh.pay.key}")
	private String key;


	private String jhPayCallbackBackend(HttpServletRequest request, String device) {
		String rtnMsg = "success";
		Map<String, String> params = new HashMap<String, String>();
		// 取出所有参数是为了验证签名
		Enumeration<String> parameterNames = request.getParameterNames();
		while (parameterNames.hasMoreElements()) {
			String parameterName = parameterNames.nextElement();
			params.put(parameterName, request.getParameter(parameterName));
		}
		log.info("聚合支付后台回调参数：{}", params);
		if (null == params || params.isEmpty()) {
			return "fail";
		}
		//验证签名 校验签名
		String rtnMchtId = params.get("mchtid");
		String rtnTermId = params.get("termid");
		String orderId = params.get("orderid");
		String state = params.get("state");
		String innerOrderId = params.get("innerorderid");
		String wechatId = params.get("wechatid");
		StringBuilder signData = new StringBuilder();
		signData.append(mchtId).append(termId).append(orderId).append(state);
		String sign = params.get("sign");
		boolean signVerified = verifySign(signData,sign, key);
		if (!signVerified) {
			log.error("支付单{}聚合支付后台回调验签失败",orderId);
			return "fail";
		}

			//通用后台回调
		boolean isPay = false;
		if("00".equals(state)) {
			isPay = true;
		}
		boolean ret = callbackService.callbackBackend(orderId,innerOrderId, new Date(), "", isPay, 0, PayChannel.CHANNEL_JHPAY.getChannel(), PayType.PAY_TYPE_WXPAY.getType());
		//其它错误情况了，log出来
		if(!ret){
			log.error(device + "聚合支付后台回调失败，支付单号:{}", orderId);
		}

			return rtnMsg;

	}

	/**
	 * 现在支付wap端回调(后台通知)
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/callback/jhPayCallbackBackendGzh")
	@ResponseBody
	public String jhPayCallbackBackendGzh (HttpServletRequest request){
		String device = "gzh";
		return jhPayCallbackBackend(request, device);

	}

	private static boolean verifySign (StringBuilder signData, String sign, String key){
		if (null == signData) return false;

		try {
			signData.append(key);
			String toMD5String = signData.toString();
			log.info("待MD5签名字符串：{}", toMD5String);
			String lastMD5Result = MD5.md5(toMD5String, "UTF-8");
			log.info("MD5签名后字符串:{}", lastMD5Result);
			return lastMD5Result.equals(sign);
		} catch (Exception ex) {
			return false;
		}
	}
}
