package cn.jugame.recharge_4_business.parameters.order;

import lombok.Data;
import lombok.ToString;

import java.util.List;


@Data
@ToString
public class OrderCreateReq {
    @Data
    @ToString
    public static class ProductInfo {
        public String productSpuNo;
        public String productSkuNo;
        public int count;
    }

    public long uid;
    public int payType;
    public String consigneeName;
    public String consigneeAddress;
    public String consigneeMobile;
    public String consigneeRemark;
    public List<ProductInfo> productList;
    public int couponId;
}
