package cn.jugame.recharge_4_business.parameters.order;

public class OrderOperateResp {
    public boolean success;
    public String reason;
    public String orderNo;
    public boolean isNeedPay;
}
