package cn.jugame.recharge_4_business.parameters.order;

import com.alibaba.fastjson.JSONObject;

public class OrderPayResp {
    public int payType;
    public int payChannel;
    public String payInfo;

    /**
     * 原生微信用
     */
    public JSONObject payObject;
}
