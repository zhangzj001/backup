package cn.jugame.recharge_4_business.filter;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.recharge_4_business.commons.Common;
import cn.jugame.recharge_4_business.configs.JymConstants;
import cn.jugame.recharge_4_business.configs.ServiceFactory;
import cn.jugame.recharge_4_business.core.AutoLogin;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

/**
 * Created by solom on 2019-07-23. ClassName: LoginFilter Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-23 10:34
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Order(3)
@WebFilter(filterName = "LoginFilter", urlPatterns = "/*")
public class LoginFilter implements Filter {

    @Value("${login_url}")
    private String loginUrl;

    @Value("${jym.login_url}")
    private String jymLoginUrl;

    @Value("${jym.client_id}")
    private String jymClientId;

    @Value("${jym.login_callback_url}")
    private String jymLoginCallbackUrl;

    @Autowired
    private ServiceFactory serviceFactory;

    public static String getLoginUrl(String baseUrl, String currentUrl) {
        return (new StringBuffer(baseUrl).append("?currentUrl=" + currentUrl).append("&onceLogin=1"))
                .toString();
    }

    private int checkLoginByToken(String token) {
        IAccountCenterService accountCenterService = serviceFactory
                .createService(IAccountCenterService.class);
        try {
            AccountBean accountBean = accountCenterService.checkLoginByToken(token);
            if (accountBean.getCode() == 0) {
                String str = accountBean.getData();
                JSONObject json = JSONObject.fromObject(str);
                if (json.containsKey("uid")) {
                    int uid = (int) json.get("uid");
                    return uid;
                }
            }
        } catch (Exception e) {
        }
        return -1;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        SpringBeanAutowiringSupport
                .processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        Integer uid = (Integer) session.getAttribute("uid");
        String requestUrl = req.getRequestURL().toString();

        String uri = req.getRequestURI();
        String ctx = req.getContextPath();
        uri = uri.substring(ctx.length());

        StringBuffer currentUrl = new StringBuffer(requestUrl);
        if (StringUtils.isNotBlank(req.getQueryString())) {
            currentUrl.append("?").append(req.getQueryString());
        }

//        //如果来自交易猫
//        String channel = (String)session.getAttribute("channel");
//        if(JymConstants.SESSION_CHANNEL_NAME.equalsIgnoreCase(channel)){
//            //这几个URL需要跳转到交易猫登录
//            if(uri.contains("/jym/history")
//                || uri.contains("/jym/_history")
//                || uri.contains("/create_order")
//                || uri.contains("/order_detail")) {
//                //已经有了交易猫的用户ID，就说明已经登录过了
//                String jymUserId = (String) session.getAttribute(JymConstants.SESSION_JYM_USER_ID);
//                if (StringUtils.isBlank(jymUserId)) {
//                    // 跳去交易猫登录
//                    String url = jymLoginUrl + "?client_id=" + jymClientId + "&redirectUrl=" + Common.urlEncode(currentUrl.toString());
//                    res.sendRedirect(url);
//                    return;
//                }
//            }
//            chain.doFilter(request, response);
//            return;
//        }

        //来自平台
        boolean needLogin = true;
        if (uri.startsWith("/create_order")
                || uri.startsWith("/order_list")
                || uri.startsWith("/_order_list")
                || uri.startsWith("/order_detail")
                ) {
            if (uid == null) {
                String token = AutoLogin.getSyncTokenByCookie(req);
                if (StringUtils.isBlank(token)) {
                    //获取记住密码的token
                    token = AutoLogin.getTokenByCookie(req);
                }
                if (StringUtils.isNotEmpty(token)) {
                    uid = checkLoginByToken(token);
                    if (uid > 0) {
                        AutoLogin.autoLogin(req, res, token);
                        session.setAttribute("uid", uid);
                        needLogin = false;
                    }
                }
            } else {
                needLogin = false;
            }
        } else {
            needLogin = false;
        }

        if (needLogin) {
            String redirectUrl = "";
            String ua = req.getHeader("User-Agent");
            if (StringUtils.isNotEmpty(ua) && (ua.contains("cn.jhw.hwzh"))) {
                redirectUrl = getLoginUrl(request.getScheme() + "://" + request.getServerName() + "/user/login.html", Common.urlEncode(currentUrl.toString()));
            } else {
                redirectUrl = getLoginUrl(loginUrl, Common.urlEncode(currentUrl.toString()));
            }
            res.sendRedirect(redirectUrl);
            return;
        }
        chain.doFilter(request, response);
        return;
    }

    @Override
    public void destroy() {

    }
}
