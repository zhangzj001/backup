package cn.jugame.recharge_4_business.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.money.Money;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ZhifuOrder implements Serializable {
    private String zhifuId;
    private String busiCode;
    private String orderNo;
    private Money zhifuOrderAmount;
    private String orderName;
    private long orderCustomerId;
    private Date orderTime;
    private long expireTime;
    private String remark;
    private int zhifuStatus;
    private int payType;
    private int payChannel;
    private String payClientType;
    private Date payCallbackTime;
    private String externalOrderId;
    private Date createTime;
    private Date updateTime;
}
