package cn.jugame.recharge_4_business.entity;

import lombok.Data;

/**
 * Created by solom on 2019-08-01. ClassName: Query Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-08-01 19:49
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Data
public class Query {
  public int page;
  public int rows;
}
