package cn.jugame.recharge_4_business.mapper;

import cn.jugame.recharge_4_business.controller.admin.AdminProductController.ListQuery;
import cn.jugame.recharge_4_business.entity.Product;
import cn.jugame.recharge_4_business.entity.ProductPackages;
import cn.jugame.recharge_4_business.mapper.provider.ProductSqlProvider;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

/**
 * Created by solom on 2019-07-17. ClassName: ProductMapper Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-17 13:50
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Repository
@Mapper
public interface ProductMapper {
  @Insert("insert into product (`product_no`, `name`, `type`, `price`, `status`, `remark`, `product_desc`, `create_time`) "
      + "values(#{productNo}, #{name}, #{type}, #{price}, #{status}, #{remark}, #{productDesc}, now())")
  int insert(Product p);

  @Select("select * from `product` where id = #{id}")
  Product findById(@Param("id") int id);

  @Select("select * from `product_packages` where id = #{id}")
  ProductPackages findByPackageId(@Param("id") int id);

  @Select("select * from product where type = #{type} and status = 1")
  List<Product> findAllProduct(@Param("type") int type);

  @Select("select * from `product_packages` where product_id = #{id} limit #{start}, #{size}")
  List<ProductPackages> findAllPkgByProductId(@Param("id") int id, @Param("start") int start, @Param("size") int size);

  @Select("select count(1) from `product_packages` where product_id = #{id}")
  int countAllByProductId(@Param("id") int id);

  @Select("select name from `product_packages` where product_id = #{id}")
  List<String> queryPkgNames(@Param("id") int id);

  @SelectProvider(type = ProductSqlProvider.class, method = "select")
  List<Product> searchAllProduct(ListQuery param);

  @SelectProvider(type = ProductSqlProvider.class, method = "count")
  int count(ListQuery param);

  @Select("select count(1) from product where type = #{type}")
  int countByType(@Param("type") int type);

  @Update("update product set status = #{status}, remark = #{remark}, price = #{price}, product_desc = #{productDesc}, update_time = now() where id = #{id}")
  int update(Product p);

  @Insert("insert into product_packages (`product_id`, `name`, `type`, `package_price`, `status`, `third_product_code`, `third_product_price`, `create_time`, `product_num`) values(#{productId}, #{name}, #{type}, #{packagePrice}, #{status}, #{thirdProductCode}, #{thirdProductPrice}, now(), #{productNum})")
  boolean savePkg(ProductPackages packages);

  @Delete("delete from `product` where id in (${ids})")
  int deleteByIds(@Param("ids") String ids);

  @Delete("delete from `product_packages` where id in (${ids})")
  int deletePkgByIds(@Param("ids")String idstr);

  @Delete("delete from `product_packages` where `product_id` in (${ids})")
  int deletePkgByProductIds(@Param("ids")String idstr);

  @Update("update product_packages set name = #{name}, package_price = #{packagePrice}, third_product_code = #{thirdProductCode}, third_product_price = #{thirdProductPrice}, product_num = #{productNum} where id = #{id}")
  int updatePkg(ProductPackages p);
}
