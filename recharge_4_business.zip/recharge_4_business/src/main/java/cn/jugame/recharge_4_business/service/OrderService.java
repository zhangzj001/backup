package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.constant.OrderStatus;
import cn.jugame.recharge_4_business.controller.admin.AdminOrderController.ListQuery;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.exception.OrderNotFoundException;
import cn.jugame.recharge_4_business.exception.OrderStatusChangeException;
import cn.jugame.recharge_4_business.mapper.OrderInfoMapper;
import cn.jugame.recharge_4_business.parameters.order.OrderOperateResp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by solom on 2019-07-18. ClassName: OrderService Function: TODO ADD FUNCTION. <br/> Date:
 * 2019-07-18 15:30
 *
 * @author: solom
 * @since: jdk 1.8
 */
@Service
public class OrderService {

  private static Logger logger = LoggerFactory.getLogger(OrderService.class);

  private static final String ORDER_LOCK_PREFIX = "LOCK-";

  @Autowired
  private RedisTemplate<String, Object> redisTemplate;

  @Autowired
  private OrderInfoMapper orderInfoMapper;

  @Autowired
  PayService payService;

  @Autowired
  RechargeService rechargeService;

  public OrderInfo findByOrderNo(String orderNo) {
    return orderInfoMapper.findByOrderNo(orderNo);
  }

  public boolean addOrder(OrderInfo orderInfo) {
    return orderInfoMapper.insert(orderInfo) > 0;
  }

  public List<OrderInfo> queryUserOrder(int uid, String status, int pageNo, int pageSize) {
    return orderInfoMapper.findAllByUidAndStatusPage(uid, status, pageNo, pageSize);
  }

  public List<OrderInfo> queryExternOrders(int uid, String status, String externUid, String externChannel, int pageNo, int pageSize){
      logger.info("uid=>{}", uid);
      logger.info("status=>{}", status);
      logger.info("externUid=>{}", externUid);
      logger.info("externChannel=>{}", externChannel);
      logger.info("pageNo=>{}", pageNo);
      logger.info("pageSize=>{}", pageSize);
      return orderInfoMapper.findAllByUidAndStatusAndExternPage(uid, status, externUid, externChannel, pageNo, pageSize);
  }

  public OrderInfo queryUserOrder(int uid, String orderNo) {
    return orderInfoMapper.findUserOrderDetail(uid, orderNo);
  }

  public List<OrderInfo> queryOrders(ListQuery param) {
    if(param.page < 0){
      param.page = 0;
    }else {
      param.page = (param.page > 0 ? param.page - 1 : param.page) * param.rows;
    }
    return orderInfoMapper.queryOrders(param);
  }

  public int count(ListQuery param){
    return orderInfoMapper.countOrders(param);
  }

  public OrderOperateResp payOrder(long uid, String orderNo, String payPlatform)
          throws OrderStatusChangeException, InterruptedException, OrderNotFoundException {
    logger.info("payOrder -> uid:{}, orderNo:{}", uid, orderNo);
    try (OrderLock lock = new OrderLock(redisTemplate, ORDER_LOCK_PREFIX + orderNo)) {
      boolean locked = lock.acquire(10000, 30000);
      if (!locked) {
        return lockFailure(orderNo);
      }
      OrderInfo orderInfo = orderInfoMapper.findByOrderNo(orderNo);
      if (null == orderInfo) {
        throw new OrderNotFoundException("订单不存在");
      }
      boolean canChangeStatus = OrderDFA.getInstance().nextStatus(orderInfo.getOrderStatus(), OrderStatus.ORDER_PAYED);
      if (!canChangeStatus) {
        throw new OrderStatusChangeException(orderInfo.getOrderStatus(), OrderStatus.ORDER_PAYED);
      }

      boolean result = orderInfoMapper.updateOrderForPay(orderNo, uid, payPlatform) > 0;
      logger.info("payOrder updateOrderForPay -> uid:{}, orderNo:{}, result:{}", uid, orderNo, result);

      //充值
      boolean rechargeResult = rechargeService.recharge(orderInfo);
      if (rechargeResult) {
          boolean updateOrderForRecharging =  orderInfoMapper.updateOrderForRecharging(orderInfo.getRechargeNo(), orderNo, uid) >0;
          logger.info("payOrder updateOrderForRecharging -> uid:{}, orderNo:{}, result:{}", uid, orderNo, updateOrderForRecharging);
      } else { // 退款
          String rtn = payService.orderRefund(orderNo, "充值失败退款");
          boolean refundResult = "success".equals(rtn);
          logger.info("refundOrder 第三方退还-> uid:{}, orderNo:{}, refundReason:充值失败退款, result:{}", uid, orderNo, refundResult);
          if(refundResult) {
              orderInfoMapper.updateOrderForCancelAndRefund(orderNo, "充值失败退款");
          }
      }

      OrderOperateResp resp = new OrderOperateResp();
      resp.success = result && rechargeResult;
      return resp;
    }
  }

  public OrderOperateResp markOrderRefunded(String orderNo, String reason) throws InterruptedException {
    logger.info("markOrderRefunded -> orderNo:{}, reason:{}", orderNo, reason);
    try (OrderLock lock = new OrderLock(redisTemplate, ORDER_LOCK_PREFIX + orderNo)) {
      boolean locked = lock.acquire(10000, 30000);
      if (!locked) {
        return lockFailure(orderNo);
      }

      boolean success = orderInfoMapper.updateOrderForRefund(orderNo, reason) > 0;
      logger.info("markOrderRefunded -> orderNo:{}, reason:{}, success:{}", orderNo, reason, success);

      OrderOperateResp resp = new OrderOperateResp();
      resp.success = success;
      return resp;
    }
  }

  public OrderOperateResp finishOrder(int uid, String orderNo)
          throws OrderStatusChangeException, InterruptedException {
    logger.info("finishOrder -> uid:{}, orderNo:{}", uid, orderNo);
    try (OrderLock lock = new OrderLock(redisTemplate, ORDER_LOCK_PREFIX + orderNo)) {
      boolean locked = lock.acquire(10000, 30000);
      if (!locked) {
        return lockFailure(orderNo);
      }
      int currStatus = orderInfoMapper.findOrderStatusByOrderNo(orderNo);
      boolean canChangeStatus = OrderDFA.getInstance().nextStatus(currStatus, OrderStatus.ORDER_FINISHED);
      if (!canChangeStatus) {
        throw new OrderStatusChangeException(currStatus, OrderStatus.ORDER_FINISHED);
      }

      boolean result = orderInfoMapper.updateOrderForFinish(orderNo, uid) > 0;
      logger.info("finishOrder -> uid:{}, orderNo:{}, result:{}", uid, orderNo, result);

      OrderOperateResp resp = new OrderOperateResp();
      resp.success = result;
      return resp;
    }
  }

  public OrderOperateResp refundOrder(long uid, String orderNo, String refundReason)
          throws OrderStatusChangeException, InterruptedException {
    logger.info("refundOrder -> uid:{}, orderNo:{}, cancelReason:{}", uid, orderNo, refundReason);
    try (OrderLock lock = new OrderLock(redisTemplate, ORDER_LOCK_PREFIX + orderNo)) {
      boolean locked = lock.acquire(10000, 30000);
      if (!locked) {
        return lockFailure(orderNo);
      }

      OrderInfo orderInfo = orderInfoMapper.findByOrderNo(orderNo);
      boolean canChangeStatus = OrderDFA.getInstance().nextStatus(orderInfo.getOrderStatus(), OrderStatus.ORDER_CANCELED);
      if (!canChangeStatus) {
        throw new OrderStatusChangeException(orderInfo.getOrderStatus(), OrderStatus.ORDER_CANCELED);
      }

      boolean refundResult = true;

      String rtn = payService.orderRefund(orderNo, refundReason);
      refundResult = "success".equals(rtn);
      logger.info("refundOrder 第三方退还-> uid:{}, orderNo:{}, refundReason:{}, result:{}", uid, orderNo, refundReason, refundResult);

      if(refundResult) {
        orderInfoMapper.updateOrderForCancelAndRefund(orderNo, refundReason);
      }

      OrderOperateResp resp = new OrderOperateResp();
      resp.success = refundResult;
      return resp;
    }
  }

  private OrderOperateResp lockFailure(String orderNo) {
    String reasonMsg = "获取订单锁失败，订单号:" + orderNo;
    logger.error(reasonMsg);

    OrderOperateResp resp = new OrderOperateResp();
    resp.success = false;
    resp.reason = reasonMsg;
    return resp;
  }

  public boolean updatePayType(int id, int payType) {
    return orderInfoMapper.updatePayType(id, payType) > 0;
  }
}