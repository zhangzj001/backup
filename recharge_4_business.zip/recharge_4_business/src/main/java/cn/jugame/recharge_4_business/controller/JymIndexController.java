package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.commons.MD5;
import cn.jugame.recharge_4_business.configs.JymConstants;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.entity.Product;
import cn.jugame.recharge_4_business.service.MagaClientService;
import cn.jugame.recharge_4_business.service.OrderService;
import cn.jugame.recharge_4_business.service.ProductService;
import net.sf.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Controller
public class JymIndexController extends BaseController {

    protected static Logger log = LoggerFactory.getLogger(JymIndexController.class);

    @Value("${jym.client_id}")
    private String jymClientId;

    @Value("${jym.client_secret}")
    private String jymClientSecret;

    @Value("${discount}")
    private double discount;

    @Value("${jym.user_ticket_command}")
    private String jymUserTicketCommand;

    @Value("${jym.trade_uid}")
    private int jymTradeUid;

    @Autowired
    private ProductService productService;
    @Autowired
    private OrderService orderService;

    @Autowired
    private MagaClientService magaClientService;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 暴露给交易猫登录成功后回调的接口，必须使用这个url！
     *
     * @param request
     * @param response
     * @param session
     * @return
     */
    @RequestMapping("/login")
    public String login(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
        String redirectUrl = getParam(request, "redirectUrl");
        String serviceTicket = getParam(request, "service_ticket");

        if (StringUtils.isBlank(serviceTicket)) {
            model.addAttribute("errorMsg", "缺少登录参数");
            return "error";
        }
        if (StringUtils.isBlank(redirectUrl)) {
            redirectUrl = "/jym/index";
        }

        Map<String, Object> params = new TreeMap<>();
        params.put("id", System.currentTimeMillis());
        params.put("clientId", jymClientId);
        params.put("serviceTicket", serviceTicket);
        String sign = MD5.encode(jymClientId + jymClientSecret + params.get("id") + serviceTicket);
        params.put("sign", sign.toLowerCase());
        logger.info("maga param => {}", params.toString());
        String content = magaClientService.call(jymUserTicketCommand, "1.0.0", params);
        if (StringUtils.isBlank(content)) {
            model.addAttribute("errorMsg", "无法获取登录用户信息，请稍后重试");
            return "error";
        }

        JSONObject json;
        try {
            json = JSONObject.fromObject(content);
        } catch (Exception e) {
            log.error("解析用户登录信息失败，content=>" + content, e);
            model.addAttribute("errorMsg", "获取用户登录信息失败，请稍后重试");
            return "error";
        }

        JSONObject bizData = json.optJSONObject("bizData");
        if (bizData == null) {
            log.error("登录失败，返回: " + json);
            model.addAttribute("errorMsg", "登录失败，请稍后重试");
            return "error";
        }

        String jymUid = bizData.getString("uid");
        String jymUname = bizData.getString("uname");
        session.setAttribute(JymConstants.SESSION_JYM_USER_ID, jymUid);
        session.setAttribute(JymConstants.SESSION_JYM_USER_NAME, jymUname);
        //保有登录状态，那么直接指定一个特定的我方UID作为充值用户来使用
        session.setAttribute("uid", jymTradeUid);

        try {
            logger.info("jym login succ, redirectUrl => {}", redirectUrl);
            response.sendRedirect(redirectUrl);
            return null;
        } catch (IOException e) {
            model.addAttribute("errorMsg", "很抱歉，服务器开了一些小差，请稍后重试");
            return "error";
        }
    }

    @RequestMapping("/jym/index")
    public String index(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
        String fr = getParam(request, "fr", "jym");
        if (StringUtils.isNotEmpty(fr)) {
            session.setAttribute("recharge_4_business_ch", fr);
        }
        Product p = productService.findAllQBProduct();
        BigDecimal b = new BigDecimal(p.getPrice());
        p.setPrice(b.multiply(new BigDecimal(discount)).intValue());
        model.addAttribute("product", p);

        //好像这里也没什么特别的逻辑，直接到界面去呗，可以充值Q币了
        return "jym/index";
    }

    @RequestMapping("/jym/create_order")
    public void createOrder(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model){
//        String queryStr = request.getQueryString();
//        String targetUrl = "/create_order.html";
//        if(StringUtils.isNotBlank(queryStr)){
//            targetUrl += "?" + queryStr;
//        }

        try {
            request.getRequestDispatcher("/create_order.html").forward(request, response);
        }catch(IOException | ServletException e){
        }
    }

    @RequestMapping("/jym/order_detail")
    public void orderDetail(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model){
        try {
            request.getRequestDispatcher("/order_detail.html").forward(request, response);
        }catch(IOException | ServletException e){
        }
    }

    @RequestMapping("/jym/history")
    public String history(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model){
        Integer uid = (Integer) session.getAttribute("uid");
        if (uid == null || uid < 0) {
            model.addAttribute("errorMsg", "请先登录");
            return "error";
        }
        int status = getParamToInt(request, "status", -1);
        String statusList = "1,2,3,4";
        switch (status) {
            case 1:
                statusList = "1,2";
                break;
            case 2:
                statusList = "3";
                break;
            default:
                break;
        }
        model.addAttribute("status", status);

        //交易猫UID
        Object jymUid = request.getSession().getAttribute(JymConstants.SESSION_JYM_USER_ID);
        if(jymUid != null) {
            model.addAttribute("orders", orderService.queryExternOrders(uid, statusList, String.valueOf(jymUid), "jym", 0, 10));
        }else{
            model.addAttribute("orders", new ArrayList<OrderInfo>());
        }
        return "jym/history";
    }

    @RequestMapping("/jym/_history")
    public String _history(HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) {
        Integer uid = (Integer) session.getAttribute("uid");
        if (uid == null || uid < 0) {
            model.addAttribute("errorMsg", "请先登录");
            return "error";
        }
        int status = getParamToInt(request, "status", -1);
        int pagetNo = getParamToInt(request, "pageNo", 1);
        int pagetSize = getParamToInt(request, "pagetSize", 10);
        String statusList = "1,2,3";
        switch (status) {
            case 1:
                statusList = "1,2";
                break;
            case 2:
                statusList = "3";
                break;
            default:
                break;
        }
        if (pagetNo > 0) {
            pagetNo = (pagetNo - 1) * pagetSize;
        }

        //交易猫UID
        Object jymUid = request.getSession().getAttribute("jym_uid");
        List<OrderInfo> orders;
        if(jymUid != null) {
            orders = orderService.queryExternOrders(uid, statusList, String.valueOf(jymUid), "jym", pagetNo, pagetSize);
        }else{
            orders = new ArrayList<>();
        }

        model.addAttribute("orders", orders);
        if (orders == null || orders.size() <= 0) {
            return "_empty";
        }
        return "jym/_history";
    }

}
