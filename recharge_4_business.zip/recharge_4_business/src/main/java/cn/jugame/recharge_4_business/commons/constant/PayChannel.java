package cn.jugame.recharge_4_business.commons.constant;

public enum PayChannel {
    CHANNEL_ORIGIN(1,"原生支付渠道"),
    CHANNEL_NOWPAY(2,"现在支付"),
    CHANNEL_JHPAY(3,"聚合支付");

    PayChannel(int channel, String desc) {
        this.channel = channel;
        this.desc = desc;
    }


    private int channel;
    private String desc;

    public int getChannel() {
        return channel;
    }
    public String getDesc() {
        return desc;
    }

}
