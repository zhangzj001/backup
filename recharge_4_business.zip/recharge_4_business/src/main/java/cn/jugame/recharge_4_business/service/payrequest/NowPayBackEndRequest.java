package cn.jugame.recharge_4_business.service.payrequest;

public class NowPayBackEndRequest {

	private String funcode;
	private String appId;
	private String mhtOrderNo;
	private String mhtOrderName;
	private String mhtOrderType;
	private String mhtCurrencyType;
	private String mhtOrderAmt;
	private String mhtOrderTimeOut;
	private String mhtOrderStartTime;
	private String mhtCharset;
	private String deviceType;
	private String payChannelType;
	private String tradeStatus;
	private String mhtReserved;
	private String signType;
	private String signature;
	private String channelOrderNo;
	private String payConsumerId;
	private String transStatus;//现在支付微信扫码的交易支付状态
	private String nowPayOrderNo;//现在支付流水号
	public String getFuncode() {
		return funcode;
	}
	public void setFuncode(String funcode) {
		this.funcode = funcode;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getMhtOrderNo() {
		return mhtOrderNo;
	}
	public void setMhtOrderNo(String mhtOrderNo) {
		this.mhtOrderNo = mhtOrderNo;
	}
	public String getMhtOrderName() {
		return mhtOrderName;
	}
	public void setMhtOrderName(String mhtOrderName) {
		this.mhtOrderName = mhtOrderName;
	}
	public String getMhtOrderType() {
		return mhtOrderType;
	}
	public void setMhtOrderType(String mhtOrderType) {
		this.mhtOrderType = mhtOrderType;
	}
	public String getMhtCurrencyType() {
		return mhtCurrencyType;
	}
	public void setMhtCurrencyType(String mhtCurrencyType) {
		this.mhtCurrencyType = mhtCurrencyType;
	}
	public String getMhtOrderAmt() {
		return mhtOrderAmt;
	}
	public void setMhtOrderAmt(String mhtOrderAmt) {
		this.mhtOrderAmt = mhtOrderAmt;
	}
	public String getMhtOrderTimeOut() {
		return mhtOrderTimeOut;
	}
	public void setMhtOrderTimeOut(String mhtOrderTimeOut) {
		this.mhtOrderTimeOut = mhtOrderTimeOut;
	}
	public String getMhtOrderStartTime() {
		return mhtOrderStartTime;
	}
	public void setMhtOrderStartTime(String mhtOrderStartTime) {
		this.mhtOrderStartTime = mhtOrderStartTime;
	}
	public String getMhtCharset() {
		return mhtCharset;
	}
	public void setMhtCharset(String mhtCharset) {
		this.mhtCharset = mhtCharset;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getPayChannelType() {
		return payChannelType;
	}
	public void setPayChannelType(String payChannelType) {
		this.payChannelType = payChannelType;
	}
	public String getTradeStatus() {
		return tradeStatus;
	}
	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}
	public String getMhtReserved() {
		return mhtReserved;
	}
	public void setMhtReserved(String mhtReserved) {
		this.mhtReserved = mhtReserved;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getChannelOrderNo() {
		return channelOrderNo;
	}
	public void setChannelOrderNo(String channelOrderNo) {
		this.channelOrderNo = channelOrderNo;
	}
	public String getPayConsumerId() {
		return payConsumerId;
	}
	public void setPayConsumerId(String payConsumerId) {
		this.payConsumerId = payConsumerId;
	}
	public String getTransStatus() {
		return transStatus;
	}
	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}
	public String getNowPayOrderNo() {
		return nowPayOrderNo;
	}
	public void setNowPayOrderNo(String nowPayOrderNo) {
		this.nowPayOrderNo = nowPayOrderNo;
	}
	
	

}
