package cn.jugame.recharge_4_business.mapper.provider;

import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.controller.admin.AdminOrderController.ListQuery;
import org.apache.commons.lang3.StringUtils;

/**
 * Created by solom on 2019-07-22. ClassName: OrderInfoProvider Function: TODO ADD FUNCTION. <br/>
 * Date: 2019-07-22 21:07
 *
 * @author: solom
 * @since: jdk 1.8
 */
public class OrderInfoProvider {
  public String select(ListQuery param) {
    StringBuffer sql = new StringBuffer("select * from `order_info` where 1 = 1");
    if(StringUtils.isNotEmpty(param.getOrderNo())){
      sql.append(" and order_no = #{orderNo}");
    }
    if (StringUtils.isNotEmpty(param.getProductNo())) {
      sql.append(" and product_no = #{productNo}");
    }
    if(param.getProductType() > 0){
      sql.append(" and product_type = #{productType}");
    }
    if(StringUtils.isNotEmpty(param.getRechargeAccount())){
      sql.append(" and recharge_account = #{rechargeAccount}");
    }
    if(param.getUid() > 0){
      sql.append(" and uid = #{uid}");
    }
    if(param.getOrderStatus() != -1){
      sql.append(" and order_status = #{orderStatus}");
    }
    if (param.getStartTime() != null) {
      sql.append(" and order_time >= #{startTime}");
    }
    if (param.getEndTime() != null) {
      sql.append(" and order_time <= #{endTime}");
    }
    if(StringUtils.isNotEmpty(param.getPayPlatform())){
      sql.append(" and pay_platform = #{payPlatform}");
    }
    sql.append(" order by id desc limit #{page}, #{rows}");
    System.err.println(sql);
    return sql.toString();
  }


  public String count(ListQuery param) {
    StringBuffer sql = new StringBuffer("select count(1) from `order_info` where 1 = 1");
    if(StringUtils.isNotEmpty(param.getOrderNo())){
      sql.append(" and order_no = #{orderNo}");
    }
    if (StringUtils.isNotEmpty(param.getProductNo())) {
      sql.append(" and product_no = #{productNo}");
    }
    if(param.getProductType() > 0){
      sql.append(" and product_type = #{productType}");
    }
    if(StringUtils.isNotEmpty(param.getRechargeAccount())){
      sql.append(" and recharge_account = #{rechargeAccount}");
    }
    if(param.getUid() > 0){
      sql.append(" and uid = #{uid}");
    }
    if(param.getOrderStatus() != -1){
      sql.append(" and order_status = #{orderStatus}");
    }
    if (param.getStartTime() != null) {
      sql.append(" and order_time >= #{startTime}");
    }
    if (param.getEndTime() != null) {
      sql.append(" and order_time <= #{endTime}");
    }
    if(StringUtils.isNotEmpty(param.getPayPlatform())){
      sql.append(" and pay_platform = #{payPlatform}");
    }
    return sql.toString();
  }
}
