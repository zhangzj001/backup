package cn.jugame.recharge_4_business.service.payrequest;

import cn.jugame.recharge_4_business.entity.OrderInfo;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class BasePayReq implements Serializable {

    //支付类型(1-支付宝，2-微信)(必须)
    private int payType;
    //订单号（必须）
    private String orderNo;
    //订单名称（必须）
    private String orderName;
    //订单金额（单位 分）（必须）
    private long orderAmount;
    //后台回调地址（可空）
    private String notifyUrl;
    //前台回调地址（可空）
    private String returnUrl;
    //订单时间 必须
    private Date orderTime;
    //用户id
    private long customerId;

    private String ip;

    private String busiCode;

    private String platform;

    public static BasePayReq convert(OrderInfo orderInfo, String platform){
        //TODO fix ip
        return BasePayReq.builder()
            .customerId(orderInfo.getUid()).ip(orderInfo.getIp()).orderAmount(orderInfo.getAmount())
            .orderName(orderInfo.getPackageName()).orderTime(orderInfo.getOrderTime())
            .orderNo(orderInfo.getOrderNo()).payType(orderInfo.getPayType()).platform(platform).build();
    }

}
