package cn.jugame.recharge_4_business.commons.constant;

public enum RefundStatus {
    REFUND_EXCEPTION(-2,"退款异常"),
    REFUND_APPLY_FAIL(-1,"退款申请失败"),
    REFUND_APPLY_SUCCESS(0,"退款申请受理中"),
    REFUND_SUCCESS(1,"退款成功"),
    REFUND_FAIL(2,"退款失败");

    private int status;
    private String desc;

    private RefundStatus(int s, String d){
        this.status = s;
        this.desc = d;
    }

    public int getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    };
}
