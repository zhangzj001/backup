package cn.jugame.recharge_4_business.commons.constant;

public enum BusiCode {
    QBCZ("qbcz","默认球鞋商城业务");


    BusiCode(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }


    private String code;
    private String desc;

    public String getCode() {
        return code;
    }
    public String getDesc() {
        return desc;
    }

}
