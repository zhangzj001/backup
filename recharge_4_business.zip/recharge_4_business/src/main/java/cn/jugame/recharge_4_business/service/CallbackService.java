package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.cache.CacheService;
import cn.jugame.recharge_4_business.commons.constant.OrderStatus;
import cn.jugame.recharge_4_business.commons.constant.ZhifuStatus;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.exception.OrderNotFoundException;
import cn.jugame.recharge_4_business.exception.OrderStatusChangeException;
import cn.jugame.recharge_4_business.parameters.order.OrderOperateResp;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class CallbackService {

  protected static Logger log = LoggerFactory.getLogger(CallbackService.class);
  @Autowired
  ZhifuOrderService zhifuOrderService;
  @Autowired
  OrderService orderService;
  @Autowired
  CacheService cacheService;

  @Value("${order_detail_url}")
  String callbackFrontUrl;

  public boolean callbackBackend(String zhifuId, String externalId, Date payTime,
      String msg, boolean isPay, double payAmount,
      int payChannel, int payType) {

    ZhifuOrder zhifuOrder = zhifuOrderService.findByZhifuId(zhifuId);

    //支付单校验
    if (zhifuOrder == null) {
      log.info(zhifuOrder.getOrderNo() + "当前支付单号不存在，支付单号:{} ", zhifuOrder.getZhifuId());
      return false;
    }
    //校验支付单状态
    //支付单已支付成功，返回不再回调
    if (zhifuOrder.getZhifuStatus() == ZhifuStatus.PAY_SUCCESS.getStatus()) {
      log.info(zhifuOrder.getOrderNo() + "支付单后台回调重复回调，支付单号{}：", zhifuOrder.getZhifuId());
      return true;
    }
    log.info("支付后台回调处理: orderNo=" + zhifuOrder.getOrderNo()
        + ", isPay:" + isPay + ", payAmount:" + zhifuOrder.getZhifuOrderAmount().getAmount().doubleValue() + ", payPlatform:"
        + payChannel + ", payType:" + payType);
    //更新支付单信息
    zhifuOrder.setPayCallbackTime(payTime);
    zhifuOrder.setExternalOrderId(externalId);
    zhifuOrder.setRemark(msg);
    zhifuOrder.setPayChannel(payChannel);
    //一收到第三方回调立刻缓存订单支付中状态，防止回调处理中又来支付
    cacheService.set("pay_" + zhifuOrder.getOrderNo(), 3, "paying");
    // 支付成功
    if (isPay) {
      cacheService.set("pay_" + zhifuOrder.getOrderNo(), 3, "paid");
      zhifuOrder.setZhifuStatus(ZhifuStatus.PAY_SUCCESS.getStatus());
      try {
        zhifuOrderService.update(zhifuOrder);
      } catch (Exception e) {
        log.error("订单{}更新支付单状态异常{}", zhifuOrder.getOrderNo(), e);
      }
      //更新订单状态为已支付
      try {
        orderService.payOrder(zhifuOrder.getOrderCustomerId(), zhifuOrder.getOrderNo(), zhifuOrder.getPayClientType());
      } catch (OrderStatusChangeException e) {
        //判断订单是否超时取消，超时取消直接退款 并通知订单退款时间原因
        if (e.getFromStatus() == OrderStatus.ORDER_CANCELED) {
          expiredAutoRefund(zhifuOrder);
          return true;
        } else {
          log.error("订单{}通知订单支付成功异常，支付单号:{}",zhifuOrder.getOrderNo(), e);
        }
      } catch (OrderNotFoundException e) {
        log.error("订单{}通知订单支付成功异常，支付单号:{}",zhifuOrder.getOrderNo(), e);
      } catch (InterruptedException e) {
        log.error("订单{}通知订单支付成功异常，支付单号:{}",zhifuOrder.getOrderNo(), e);
      }
    } else {
      cacheService.del("pay_" + zhifuOrder.getOrderNo());
      log.info("支付单回调结果为支付失败，支付单号：{}" + zhifuOrder.getZhifuId());
    }

    return true;
  }

  private String expiredAutoRefund(ZhifuOrder zhifuOrder) {
    String refundResult = "";
    try {
      refundResult = zhifuOrderService.orderRefund(zhifuOrder, "订单已超时自动退款");
      log.info("订单{}已超时，系统自动退款:{}", zhifuOrder.getOrderNo(), refundResult);
    } catch (Exception e) {
      log.info("订单{}超时系统自动退款异常:{}", zhifuOrder.getOrderNo(), e);
    }
    try {
      OrderOperateResp orderOperateResp = orderService.markOrderRefunded(zhifuOrder.getOrderNo(),"订单已超时自动退款");
      log.info("订单{}退款通知订单:{}", zhifuOrder.getOrderNo(),orderOperateResp.success);
    } catch (InterruptedException e) {
      log.info("退款通知订单异常:", e);
    }
    return refundResult;

  }


  public  String callbackFront(String zhifuId) {
    ZhifuOrder zhifuOrder = zhifuOrderService.findByZhifuId(zhifuId);

    //支付单校验
    if (zhifuOrder == null) {
      log.info(zhifuOrder.getOrderNo() + "当前支付单号不存在，支付单号:{} ", zhifuOrder.getZhifuId());
      return null;
    }

    String callbackUrl = callbackFrontUrl + "?orderNo=" + zhifuOrder.getOrderNo();

    log.info("订单{}前端回调地址{}",zhifuOrder.getOrderNo(), callbackUrl);
    return callbackUrl;
  }
}
