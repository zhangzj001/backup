package cn.jugame.recharge_4_business.cache;

@FunctionalInterface
public interface LoadAction<T> {

  T get(String key) throws Throwable;
}
