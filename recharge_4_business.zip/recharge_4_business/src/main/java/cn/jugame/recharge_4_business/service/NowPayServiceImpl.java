package cn.jugame.recharge_4_business.service;

import cn.jugame.recharge_4_business.commons.RtnUtil;
import cn.jugame.recharge_4_business.commons.RtnUtils;
import cn.jugame.recharge_4_business.commons.constant.RefundStatus;
import cn.jugame.recharge_4_business.commons.pay.FormDateReportConvertor;
import cn.jugame.recharge_4_business.commons.pay.HttpsTLS1_1Util;
import cn.jugame.recharge_4_business.commons.pay.MD5;
import cn.jugame.recharge_4_business.commons.pay.MD5Facade;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.service.payrequest.NowPayRequest;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service("nowPayService")
public class NowPayServiceImpl implements IBasePayService {
    @Value("${nowpay.app.appId}")
    private String app_appId;
    @Value("${nowpay.wap.appId}")
    private String wap_appId;
    @Value("${nowpay.app.appKey}")
    private String appKey;
    @Value("${nowpay.wap.appKey}")
    private String wapKey;
    @Value("${nowpay.app.notify.url}")
    private String notifyUrl;
    @Value("${nowpay.app.frontNotify.url}")
    private String frontNotifyUrl;

    @Value("${nowpay.wap.notify.url}")
    private String wapNotifyUrl;
    @Value("${nowpay.wap.frontNotify.url}")
    private String wapFrontNotifyUrl;

    @Value("${nowpay.order.timeout}")
    private String mhtOrderTimeOut;
    @Value("${nowpay.pay.api.url}")
    private String payUrl;
    @Value("${nowpay.refund.api.url}")
    private String refundUrl;
    @Value("${order_detail_url}")
    String orderDetailUrl;

    protected static Logger log = LoggerFactory.getLogger(NowPayServiceImpl.class);

    /**
     * 订单退款
     * @param zhifuOrder
     * @param rerundReason
     * @return 申请成功 则返回"success",其他为失败
     * @throws UnsupportedEncodingException
     */
    @Override
    public String orderRefund(ZhifuOrder zhifuOrder, String refundNo, String rerundReason) throws UnsupportedEncodingException {

        String device = zhifuOrder.getPayClientType();
        String appId = "";
        String key = "";
        switch(device) {
            case "wap":
                appId = wap_appId;
                key = wapKey;
                break;
            case "app":
                appId = app_appId;
                key = appKey;
                break;
            default:
                break;
        }
        String mhtOrderNo = zhifuOrder.getZhifuId();
        //单位是分，需转换
        long amount = zhifuOrder.getZhifuOrderAmount().getAmountMinorLong();

        Map<String, String> params = new HashMap<String, String>();
        params.put("appId", appId);
        params.put("mhtOrderNo", mhtOrderNo);
        params.put("mhtRefundNo", refundNo);
        params.put("amount", String.valueOf(amount));
        params.put("mhtCharset", "UTF-8");
        params.put("funcode", "R001");
        String mhtSignature = getFormatDataParamMD5(params, key,"UTF-8");
        params.put("signType", "MD5");
        params.put("mhtSignature", mhtSignature);
        String result = "";
        Map<String,String> rtnMap = null;
        try {
            log.info(zhifuOrder.getOrderNo() + "调用现在支付退款请求数据：{}", JSONObject.toJSON(params));
            result = HttpsTLS1_1Util.doPost(refundUrl, params);
            log.info(zhifuOrder.getOrderNo() + "调用现在支付退款返回：{}", URLDecoder.decode(result, "utf-8"));
        } catch (Exception e) {
            log.error(zhifuOrder.getOrderNo() + "调用现在支付退款异常:", e);
        }

        if (!StringUtils.isBlank(result)) {
            rtnMap =  parseParams(result);
        } else {
            return "退款异常,返回结果为空";
        }
        String responseMsg = "fail";
        //请求成功
        if (null !=rtnMap && rtnMap.containsKey("responseCode") && rtnMap.get("responseCode").equals("R000")) {
            String tradeStatus = rtnMap.get("tradeStatus");
//        	A001	成功
//        	A002	失败
//        	A003	处理中
//        	A004	受理成功
            try {
                responseMsg = rtnMap==null? "": URLDecoder.decode(rtnMap.get("responseMsg"), "utf-8");
            } catch (UnsupportedEncodingException e) {
            }
            switch(tradeStatus) {
                case "A001": case "A003": case "A004":
                    log.info(zhifuOrder.getOrderNo() + "退款申请成功");
                    responseMsg = "success";
                    break;
                case "A002":
                    log.info(zhifuOrder.getOrderNo() + "退款申请失败:{}",responseMsg);
                    break;
                default:
                    log.info(zhifuOrder.getOrderNo() + "退款申请失败:未知状态");
                    break;
            }
        } else {
            try {
                responseMsg = rtnMap==null? "null": URLDecoder.decode(rtnMap.get("responseMsg"), "utf-8");
            } catch (UnsupportedEncodingException e) {
            }
            log.error(zhifuOrder.getOrderNo() +"退款申请退款失败：{}", responseMsg);

        }
        return responseMsg;
    }

    @Override
    public JSONObject appPay(ZhifuOrder zhifuOrder, String ip) {
        if(null == zhifuOrder) {
            return null;
        }
        JSONObject data = new JSONObject();
        String reqString = buildRequestString(zhifuOrder, "app", zhifuOrder.getPayType());
        data.put("payInfo",reqString);
        return data;
    }

    @Override
    public String wapPay(ZhifuOrder zhifuOrder, String ip) {
        if(null == zhifuOrder) {
            return "";
        }
        Map<String,String> params = buildWapRequestMap(zhifuOrder);
        try {
            String result = "";
            log.info("订单{}微信wap请求数据：{}",zhifuOrder.getOrderNo(), JSONObject.toJSONString(params));
            result = HttpsTLS1_1Util.doPost(payUrl, params);
            log.info("订单{}微信wap返回结果{}", zhifuOrder.getOrderNo(),URLDecoder.decode(result,"UTF-8"));
            if (StringUtils.isBlank(result)) {
                log.error("订单{}请求微信wap支付失败",zhifuOrder.getOrderNo());
                return "";
            }
            if(result.indexOf("tn=") > 0) {
                result = result.substring(21, result.length());
                String requestURL = URLDecoder.decode(result, "utf-8");
                return buildwapPayForm(requestURL, orderDetailUrl + "?orderNo=" + zhifuOrder.getOrderNo());
            }

        } catch (Exception e) {
            log.error("订单{}请求微信wap支付异常:{}", zhifuOrder.getOrderNo(),e);
        }

        return "";
    }

    /**
     * 现在支付退款查询
     * @param refundNo
     * @param clientType
     * @return -1 查询失败  0处理中  1退款成功  2退款失败
     */
    @Override
    public JSONObject orderRefundQuery(String refundNo, String clientType){

        String device = clientType;
        String appId = "";
        String key = "";
        switch(device) {
            case "wap":
                appId = wap_appId;
                key = wapKey;
                break;
            case "app":
                appId = app_appId;
                key = appKey;
                break;
            default:
                break;
        }

        Map<String, String> params = new HashMap<String, String>();
        params.put("appId", appId);
        params.put("mhtRefundNo", refundNo);
        params.put("mhtCharset", "UTF-8");
        params.put("funcode", "Q001");

        String mhtSignature = getFormatDataParamMD5(params, key,"UTF-8");

        params.put("signType", "MD5");
        params.put("mhtSignature", mhtSignature);

        String result = "";
        Map<String,String> rtnMap = null;
        String refundUrl = StringUtils.defaultString(payUrl + "/refund/refundQuery", "https://pay.ipaynow.cn/refund/refundQuery");
        try {
            log.info(refundNo + "调用现在支付退款查询请求数据：" + JSONObject.toJSONString(params));
            result = HttpsTLS1_1Util.doPost(refundUrl, params);
            log.info("调用现在支付退款查询返回：" + URLDecoder.decode(result, "utf-8"));
        } catch (Exception e) {
            log.error("调用现在支付退款查询异常：", e);
        }

        if (!StringUtils.isBlank(result)) {
            rtnMap =  parseParams(result);
        } else {
            return RtnUtil.setResult(-1, "退款查询异常");
        }
        String responseMsg = "";
        try {
            responseMsg = null == rtnMap ? "" : URLDecoder.decode(rtnMap.get("responseMsg"),"utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        //请求成功
        if (null !=rtnMap && rtnMap.containsKey("responseCode") && rtnMap.get("responseCode").equals("R000")) {
            String tradeStatus = rtnMap.get("tradeStatus");
            int status = 0;
            if ("A001".equals(tradeStatus)) {
                status = RefundStatus.REFUND_SUCCESS.getStatus();
            } else if ("A002".equals(tradeStatus)) {
                status = RefundStatus.REFUND_FAIL.getStatus();
            } else if ("A003".equals(tradeStatus) || "A004".equals(tradeStatus)) {
                status = RefundStatus.REFUND_APPLY_SUCCESS.getStatus();
            } else {
                status = RefundStatus.REFUND_APPLY_FAIL.getStatus();
            }

            return RtnUtil.setResult(status, responseMsg);

        } else {
            return RtnUtil.setResult(RefundStatus.REFUND_FAIL.getStatus(), responseMsg);
        }
    }

    /**
     * 构建wap微信支付请求参数
     * @Author: sueyoung
     * @Date: 2019-07-18 17:54
     * @Param: [zhifuOrder]
     * @Return: java.util.Map<java.lang.String,java.lang.String>
     */
    private Map<String,String> buildWapRequestMap(ZhifuOrder zhifuOrder){
        //生成post给nowpay的数据
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String payChannelType = "1301";//微信wap
        String deviceType = "06"; //wap
        String mhtOrderType = "01";

        //过滤商品名称
        String mhtOrderName = zhifuOrder.getOrderName();
        mhtOrderName = StringFilter(mhtOrderName);
        if(mhtOrderName.length() > 10){
            mhtOrderName = mhtOrderName.substring(0, 10) + "...";
        }
        String mhtOrderStartTime = sdf.format(zhifuOrder.getOrderTime());

        Map<String,String> params = new HashMap<String,String>();
        params.put("appId", wap_appId);
        params.put("mhtOrderNo", zhifuOrder.getZhifuId());
        params.put("mhtOrderName", mhtOrderName);
        params.put("mhtCurrencyType", "156");
        params.put("mhtOrderAmt", zhifuOrder.getZhifuOrderAmount().getAmountMinorLong() + "");
        params.put("mhtOrderDetail", zhifuOrder.getOrderName());
        params.put("mhtOrderType", mhtOrderType);
        params.put("mhtOrderStartTime", mhtOrderStartTime);
        params.put("notifyUrl", wapNotifyUrl);
        params.put("frontNotifyUrl", wapFrontNotifyUrl);
        params.put("mhtCharset", "UTF-8");
        params.put("payChannelType", payChannelType);
        params.put("mhtReserved",zhifuOrder.getZhifuId());

        String mhtSignature = getFormatDataParamMD5(params, wapKey, "UTF-8");
        //签名
        params.put("funcode", "WP001");
        params.put("deviceType", deviceType);
        params.put("mhtSignType", "MD5");
        params.put("mhtSignature", mhtSignature);
        return params;
    }

    private  String buildRequestString(ZhifuOrder zhifuOrder, String device, int payType){
        //生成post给nowpay的数据
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        String appId = "";
        String payChannelType = payType == 1 ? "12" : "13"; // 12-支付宝，13-微信
        String deviceType = "";
        switch (device) {//预留扩展
            case "app":
                appId = app_appId;
                deviceType = "01";
                break;
            default:
                break;
        }
        //过滤商品名称
        String mhtOrderName = zhifuOrder.getOrderName();
        mhtOrderName = StringFilter(mhtOrderName);
        if(mhtOrderName.length() > 10){
            mhtOrderName = mhtOrderName.substring(0, 10) + "...";
        }
        String mhtOrderStartTime = sdf.format(zhifuOrder.getOrderTime());
        NowPayRequest payReq =  NowPayRequest.builder()
                .appId(appId)
                .payChannelType(payChannelType)
                .mhtOrderNo(zhifuOrder.getZhifuId())
                .mhtOrderName(mhtOrderName.trim())
                .mhtOrderAmt(zhifuOrder.getZhifuOrderAmount().getAmountMinorLong())
                .mhtOrderDetail(zhifuOrder.getOrderName())
                .mhtOrderStartTime(mhtOrderStartTime)
                .mhtOrderTimeOut(mhtOrderTimeOut)
                .notifyUrl(notifyUrl)
                .deviceType(deviceType)
                .mhtReserved(zhifuOrder.getOrderNo())
                .funcode("WP001")
                .version("1.0.3")
                .mhtCurrencyType("156")
                .mhtOrderType("05")//01
                .mhtCharset("UTF-8")
                .mhtSignType("MD5").build();

        String reqString = signAndBuildReqString(payReq,appKey,device);

        return reqString;
    }

    private  String signAndBuildReqString(NowPayRequest payRequest, String appKey,String device) {

        Map<String, String> dataMap = new HashMap<String, String>();
        dataMap.put("funcode", payRequest.getFuncode());
        dataMap.put("appId", payRequest.getAppId());
        dataMap.put("version", payRequest.getVersion());
        dataMap.put("mhtOrderNo", payRequest.getMhtOrderNo());
        dataMap.put("mhtOrderName", payRequest.getMhtOrderName());
        dataMap.put("mhtOrderType", payRequest.getMhtOrderType());
        dataMap.put("mhtCurrencyType", payRequest.getMhtCurrencyType());
        dataMap.put("mhtOrderAmt", payRequest.getMhtOrderAmt() + "");
        dataMap.put("mhtOrderDetail", payRequest.getMhtOrderDetail());
        dataMap.put("mhtOrderTimeOut", payRequest.getMhtOrderTimeOut());
        dataMap.put("mhtOrderStartTime", payRequest.getMhtOrderStartTime());
        dataMap.put("notifyUrl", payRequest.getNotifyUrl());
        dataMap.put("mhtCharset", payRequest.getMhtCharset());
        dataMap.put("deviceType",payRequest.getDeviceType());
        dataMap.put("payChannelType", payRequest.getPayChannelType());
        // 商户保留域， 可以不用填。 如果商户有需要对每笔交易记录一些自己的东西，可以放在这个里面
        dataMap.put("mhtReserved", payRequest.getMhtReserved());
        dataMap.put("mhtSignType", payRequest.getMhtSignType());
        log.info("订单{} 现在支付 签名参数：{}",payRequest.getMhtOrderNo(), dataMap);
        String mhtSignature = getFormatDataParamMD5(dataMap, appKey, "UTF-8");
//        dataMap.put("mhtSignature",mhtSignature);

        return FormDateReportConvertor.postBraceFormLinkReport(dataMap) + "&mhtSignature=" + mhtSignature;

    }


    /**
     * 针对NowPay目前统一的MD5签名方式：key1=value1&key2=value2....keyn=valuen&securityKeySignature  进行MD5
     * <p>要先对Key进行按字典升序排序
     * @param dataMap  -- 数据
     * @param securityKey    --密钥
     * @param charset
     * @return
     */
    private static String getFormatDataParamMD5(Map<String,String> dataMap,String securityKey,String charset){
        if(dataMap == null) return null;

        Set<String> keySet = dataMap.keySet();
        List<String> keyList = new ArrayList<String>(keySet);
        Collections.sort(keyList);

        StringBuilder toMD5StringBuilder = new StringBuilder();
        for(String key : keyList){
            String value = dataMap.get(key);

            if(value != null && value.length()>0){
                toMD5StringBuilder.append(key+"="+ value+"&");
            }
        }

        try{
            String securityKeyMD5 = MD5.md5(securityKey,"UTF-8");
            toMD5StringBuilder.append(securityKeyMD5);

            String toMD5String = toMD5StringBuilder.toString();
            log.info("待MD5签名字符串：[{}]",toMD5String);

            String lastMD5Result = MD5.md5(toMD5String,"UTF-8");
            log.info("MD5签名后字符串:[{}]",lastMD5Result);
            return lastMD5Result;
        }catch (Exception ex){
            return "";
        }
    }

    // 过滤特殊字符
    private static String StringFilter(String str) {
        String regEx="[`@#$%^&*()+=|{}❤]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        return m.replaceAll("").trim();
    }


    /**
     * 将&连接的参数转为map
     * @param content
     * @return
     */
    private static Map<String,String> parseParams(String content) {
        Map<String,String> dataMap = null;
        if(StringUtils.isBlank(content)){
            return null;
        }
        dataMap = new HashMap<String, String>();
        String[] paras = content.split("&");
        String paraName = null;
        String paraVal = null;
        int pos = -1;
        for(String kv : paras){
            pos = kv.indexOf("=");
            if(-1 == pos) {
                dataMap.put(kv, "");
            } else {
                paraName = kv.substring(0, pos);
                paraVal = kv.substring(pos+1);
                dataMap.put(paraName, paraVal);
            }
        }
        return dataMap;

    }

    public static String buildwapPayForm(String requestUrl, String orderDetatilUrl) {

        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no\"><title>支付</title><style type=\"text/css\">\n" +
                "html{height: 100%}\n" +
                "body{position:relative;min-height: 100%;background-color: rgba(0,0,0,.7);margin:0;line-height: 1.6;}\n" +
                ".payBox{position:absolute;top:50%;left:10%;right:10%;background-color: #fff;text-align: center;border-radius: 6px;-webkit-transform: translateY(-50%);transform: translateY(-50%);}\n" +
                ".payBox-title{font-size:18px;padding: 15px 10px;}\n" +
                ".payBox-link {display:block;padding:10px;font-size:15px;color:#39f;text-decoration:none;border-top: 1px solid #C5C5C5;}\n" +
                ".payBox-link img {width: 19px;height: 19px;vertical-align: middle;margin-left: 20px;}\n" +
                "</style></head><body>");
        sbHtml.append("<div class=\"payBox\">\n" +
                "<div class=\"payBox-title\">是否已完成支付</div>\n" +
                "<a href=\"").append(orderDetatilUrl).append("\" class=\"payBox-link\">支付成功，查看详情<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAMAAACf4xmcAAAAe1BMVEUAAAAzmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf/Tsa5mAAAAKHRSTlMA+Vgvs/N+7NSfkz3LomAlIgTJGRY3t46LQzUGdyoRB9qsTuTNwGtp1vGoWQAAAUJJREFUOMu1lGmPwiAQhncQpAc97KVV26p7vf//F25kC2ShptkY+TIzzdMhvHO8vfA0eawkkVRxXj+EUk6wh3i6CJUcQLRnbVG0bB8B4GVIMQHKNi7eZATBfGoLVAYyYAVs/346A8nO/3WXeBwzcXgHc1EpkCw/PoFw7+BQp2XsVIFbvUCbkGC9fgchtcmykOohtM1MuoYQJttFiH9lATXayRGFyb4h5qpGyLWNcQioUeI8u4c5rQJbEOIyWU2VthJHnxoIN+MfIbUlFD7WobN+AfKxuaw30BBg7tKU4js4XVzt3KUKzGLg071d5OgwBuULwgifYy3wpSMrSCBvL/BxReRaT8sbFquVAHoTmWKFpR/ecTW+K33YSPXWjKhrJJOuetyW3T+bfH1kXLw+gOvjvL4c1ldNV64vLvD0uTX4/PkBTdYffHilZhkAAAAASUVORK5CYII=\"> </a>\n" +
                "<a href=\"#\" onclick=\"payFailed();\" class=\"payBox-link\">遇到问题，重新支付<img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAmCAMAAACf4xmcAAAAe1BMVEUAAAAzmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf8zmf/Tsa5mAAAAKHRSTlMA8XhVrzL27ujVCc9+NiUSBG1cOhzdpJuHcWdiQj0X4tm8p0otH45QM/tiDQAAAR1JREFUOMvVk9tugzAMQHECgQBtgdILo/d22/n/L5xUhgJtkHjtecM6xlZsBx/Dd3m7CLG9tfW0dLziCCO/dAoBCfNWV3kowHblsRYJZDr9/0rbC2yi94KCKYeBQhlk8WItheQ1dxETL0eR9ELSRxyRkBXDwB4Onn7voEZ5u33gY0e8mvHctaEMZrAlm6P9gqt6WvuUVGv9BbnWx27gZ28Hd3rOT2sDfHm8fSd1w6g3MOW9WX7vB5Bn45aetdeTLlwplcNWKeV972qwEBm7YAYKOc3QVjLvd/nEItkmHc3FukV1PGKyYhzxLHmUIK+5B4NphqlFY5D1xAH2YlpZOD+mzjkOVaXbPDTv5+wKX3Fcj8Ekyya0CWJvZR18DH8kuh+QLcybIQAAAABJRU5ErkJggg==\"></a>\n" +
                "</div>\n" +
                "<a id=\"paynowURL\" href=\"").append(requestUrl).append("\"></a>\n" +
                "</form>");

        sbHtml.append("<script>\n" +
                "var link = document.getElementById('paynowURL').getAttribute('href');\n" +
                "if (window.frames.length != parent.frames.length) {\n" +
                "top.location.href=link;\n" +
                "}else{\n" +
                "window.location.href=link;\n" +
                "}\n" +
                "function payFailed(){\n" +
                "window.location.reload();\n" +
                "}\n" +
                "</script>\n" +
                "</body>\n" +
                "</html>");

        return sbHtml.toString();
    }

    //将url形式参数转换map
    public static Map<String,String> parseUrlParams(String content) {
        Map<String,String> dataMap = null;
        if(StringUtils.isBlank(content)){
            return null;
        }
        dataMap = new HashMap<String, String>();
        String[] paras = content.split("&");
        String paraName = null;
        String paraVal = null;
        int pos = -1;
        for(String kv : paras){
            pos = kv.indexOf("=");
            if(-1 == pos) {
                dataMap.put(kv, "");
            } else {
                paraName = kv.substring(0, pos);
                paraVal = kv.substring(pos+1);
                dataMap.put(paraName, paraVal);
            }
        }
        return dataMap;

    }
}
