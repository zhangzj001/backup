package cn.jugame.recharge_4_business.controller;

import cn.jugame.recharge_4_business.commons.pay.MD5;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.exception.OrderStatusChangeException;
import cn.jugame.recharge_4_business.mapper.OrderInfoMapper;
import cn.jugame.recharge_4_business.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;


/**
 * Created by surong on 2019-04-28.
 * ClassName: CallbackRequestAlipay
 * Function:  Q币|视频会员充值后台回调. <br/>
 * Date: 2019-04-28 18:06
 *
 * @author: surong
 * @since: jdk 1.8
 */
@Controller
public class RechargeCallbackController {
  protected static Logger log = LoggerFactory.getLogger(RechargeCallbackController.class);
  @Value("${recharge.api.key}")
  private String apiKey;

  @Autowired
  private OrderInfoMapper orderInfoMapper;

  @Autowired
  private OrderService orderService;

  /**
   * 充值回调(后台通知)
   *
   * @param request
   * @param response
   * @return
   */
  @RequestMapping(value = "/callback/rechargeCallbackBackend")
  @ResponseBody
  public String rechargeCallbackBackend(HttpServletRequest request, HttpServletResponse response) throws IOException, ParseException {
    Map<String, String> params = new HashMap<String, String>();
    // 取出所有参数是为了验证签名
    Enumeration<String> parameterNames = request.getParameterNames();
    while (parameterNames.hasMoreElements()) {
      String parameterName = parameterNames.nextElement();
      params.put(parameterName, request.getParameter(parameterName));
    }
    log.info("充值后台回调参数：{}", params);
    if(null == params || params.isEmpty()) {
      return "fail";
    }
    //验证签名 校验签名
    String sign = params.get("Sign");
    boolean signVerified = verifySign(params,sign, apiKey);
    if (signVerified) {

      String orderNo = params.get("NodeOrderID");
      OrderInfo order = orderInfoMapper.findByOrderNo(orderNo);
      if (null == order) {
        log.error("订单{}充值回调找不到订单记录", orderNo);
        return "fail";
      }

      String transState = params.get("TransState");
      if("0000".equals(transState)) { //成功
          //更新订单为交易完成
        try {
          orderService.finishOrder(order.getUid(), order.getOrderNo());
        } catch (OrderStatusChangeException e) {
          log.error("订单{}更新交易完成异常:{}", orderNo, e.getMessage());
        } catch (InterruptedException e) {
          log.error("订单{}更新交易完成异常:{}", orderNo, e.getMessage());
        }
      } else if ("0001".equals(transState)) {//待处理
          //这种待处理不处理，等后续人工或脚本来重试查询获取最终结果
          log.info("订单{}充值结果为待处理，需稍后再查询结果");
      } else { //失败
          //失败订单退款
        try {
          orderService.refundOrder(order.getUid(),order.getOrderNo(),"充值失败自动退款");
        } catch (OrderStatusChangeException e) {
          log.info("订单{}充值失败自动退款异常:{}",order.getOrderNo(),e.getMessage());
        } catch (InterruptedException e) {
          log.info("订单{}充值失败自动退款异常:{}",order.getOrderNo(),e.getMessage());
        }
      }

    } else { // 如果验证签名没有通过
      log.info("订单充值回调验证签名失败！");
      return "fail";
    }
    return "success";
  }

  private static boolean verifySign(Map<String,String> dataMap, String sign, String apiKey){
    if(dataMap == null) return false;

    Set<String> keySet = dataMap.keySet();
    List<String> keyList = new ArrayList<String>(keySet);
    Collections.sort(keyList);
    StringBuilder toMD5StringBuilder = new StringBuilder();
    for(String key : keyList){
      if("Sign".equals(key)) {
        continue;
      }
      String value = dataMap.get(key);
      if(value != null && value.length()>0){
        toMD5StringBuilder.append(value);
      }
    }
    try{
      toMD5StringBuilder.append(apiKey);
      String toMD5String = toMD5StringBuilder.toString();
      log.info("待MD5签名字符串：[{}]",toMD5String);
      String lastMD5Result = MD5.md5(toMD5String,"UTF-8").toUpperCase();
      log.info("MD5签名后字符串:[{}]",lastMD5Result);
      return lastMD5Result.equals(sign);
    }catch (Exception ex){
      return false;
    }
  }

}
