package cn.jugame.recharge_4_business.commons.constant;

public enum PayType {
    PAY_TYPE_ALIPAY(1,"支付宝"),
    PAY_TYPE_WXPAY(2,"微信");


    PayType(int type, String desc) {
        this.type = type;
        this.desc = desc;
    }


    private int type;
    private String desc;

    public int getType() {
        return type;
    }
    public String getDesc() {
        return desc;
    }

}
