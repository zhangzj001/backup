package cn.jugame.recharge_4_business.commons;

import net.sf.json.JSONObject;

/**
 * Created by solom on 2018/12/27.
 * ClassName: RtnUtils
 * Function: TODO ADD FUNCTION. <br/>
 * Date: 2018-12-27 16:22
 *
 * @author: solom
 * @since: jdk 1.7
 */
public final class RtnUtils {
    public final static int OK = 1;
    public final static int FAIL = 0;

    public static String fail(String msg) {
        JSONObject rtnData = new JSONObject();
        rtnData.put("code", FAIL);
        rtnData.put("msg", msg);
        return rtnData.toString();
    }

    public static String ok(JSONObject data) {
        JSONObject rtnData = new JSONObject();
        rtnData.put("code", OK);
        rtnData.put("msg", "ok");
        rtnData.put("data", data);
        return rtnData.toString();
    }
}
