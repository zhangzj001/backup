$(function() {
    init()
})

var PID = -1,
    NUM = 0;


function calcPrice() {

    var singlePrice = $("#otherNum").data("price");
    var num = $("#otherNum").val()

    PID = 0;
    NUM = num;

    var price = toDecimal(singlePrice * num)
    if (price > 0) {
        $("#needPay").html(price + " 元")
    } else {
        $("#needPay").html("-- 元")
    }
}

function toDecimal(x) {
    var f = parseFloat(x);
    if (isNaN(f)) {
        return;
    }
    f = Math.round(x * 100) / 100;
    return f;
}

function init() {

    $(".tabBar span").click(function(event) {

        $(".tabBar span").removeClass('active')
        $(this).addClass('active')

        var t = $(this).data("t")

        if (t == "1") {
            $("#qbLayout").show();
            $("#vipLayout").hide();
        } else if (t == "2") {
            $("#qbLayout").hide();
            $("#vipLayout").show();
        }


    });



    $("#qbGrid span").click(function(event) {
        $("#qbGrid span").removeClass('active')
        $("#otherNum").removeClass('active')
        $(this).addClass('active')


        PID = $(this).data("pid")
        NUM = 0;

        var price = $(this).data("yuan")
        $("#needPay").html(price + " 元")


    });

    $("#otherNum").click(function(event) {
        $("#qbGrid span").removeClass('active')
        $(this).addClass('active')
        calcPrice()

    });

    $("#otherNum").on("input", function(event) {
        var val = $("#otherNum").val()
        $(this).val(val.replace(/[^\d]/g,''))
        calcPrice()
    });


    $("#titleLink").click(function(event) {
        location.href = "/jym/history"
    });


    $("#btnRecharge").click(function(event) {

        var qq = $("#inputQQ").val();
        var productId = $("#productId").val();

        if ("" == qq.trim()) {
            showToast("请输入QQ账号")
            return
        }

        if (PID < 0) {
            showToast("请选择充值数量")
            return
        } else if (PID == 0) {
            if (NUM < 10) {
                showToast("请输入充值数量<br>不小于10")
                return
            }
        }
        var params = "?account=" + qq + "&packageId=" + PID + "&productId=" + productId + "&num=" + NUM
        location.href = "/jym/create_order"+params;
    });


}