$(function() {
    init()
})

var statusId = 0
var pageNo = 1
var pageSize = 10
var loading = false
var noMore = false

function init() {
    statusId = $("#tabBar").data("sid")
    initCopyAndLink()
    $(".tabBar a").removeClass('active')
    if (statusId == 1)
        $("#tab_1").addClass('active')
    else if (statusId == 2)
        $("#tab_2").addClass('active')
    else
        $("#tab_0").addClass('active')

    $("#more").click(function(event) {
        if (loading || noMore) {
            return
        }
        loading = true
        $(this).html("加载中...")
        $.ajax({
            url: '/jym/_history',
            type: 'POST',
            dataType: 'html',
            data: { "status": statusId, "pageNo": pageNo, "pageSize": pageSize },
            success: function(data) {
                $("#orderList").append(data)
                loading = false
                initCopyAndLink()
            },
            error: function() {
                showToast("加载失败")
                loading = false
                $("#more").html("更多")
            }
        })
    })
}

function initCopyAndLink() {
    $("#orderList li").click(function(event) {
        var no = $(this).data("no")
        location.href = "/jym/order_detail?orderNo=" + no
    })
    $(".copy,.orderNo").click(function(event) {
        var no = $(this).parent().data("no")
        copyText(no)
        event.stopPropagation()
    })
    var childrenCount = $("#orderList").children().length
    if (childrenCount == 0) {
        noMore = true
        $("#more").html("暂无记录")
    } else if (childrenCount < pageSize * pageNo) {
        noMore = true
        $("#more").html("到底了")
    } else {
        pageNo++
        $("#more").html("更多")
    }
}