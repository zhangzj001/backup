function showToast(msg, duration) {
    duration = isNaN(duration) ? 2000 : duration
    var m = document.createElement('div')
    m.innerHTML = msg
    m.style.cssText = "max-width:70%;min-width:100px;padding:10px;color:#FFF;line-height:24px;text-align:center;border-radius:4px;position:fixed;top:50%;left:50%;transform:translate(-50%, -50%);z-index:999999;background:rgba(0, 0, 0, 0.6);font-size:14px;"
    document.body.appendChild(m)
    setTimeout(function() {
        var d = 0.5
        m.style.webkitTransition = '-webkit-transform ' + d + 's ease-in, opacity ' + d + 's ease-in'
        m.style.opacity = '0'
        setTimeout(function() { document.body.removeChild(m) }, d * 1000)
    }, duration)
}


function copyText(text) {
    var element = $("<textarea>" + text + "</textarea>")
    $("body").append(element)
    element[0].select()
    document.execCommand("Copy")
    element.remove()
    showToast("已复制")
}