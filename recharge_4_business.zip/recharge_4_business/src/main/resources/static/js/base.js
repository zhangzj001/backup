;var base = (function () {
    var toastTimer;
    var toast = function (text) {
        clearTimeout(toastTimer);
        var $toast = $('#toast')
        if ($toast.length > 0) {
            $toast.find('.inner').text(text)
            $toast.show()
        } else {
            $toast = $('<div id="toast" class="toast" style="display:block"><span class="inner">' + text + '</span></div>')
            $(document.body).append($toast)
        }
        toastTimer = setTimeout(function () {
            $toast.hide()
        }, 2000)
    }
    //全局ajax设置
    $.ajaxSetup({
        error: function () {
            base.toast('连接失败,请稍候重试')
        }
    });

    return {
        toast: toast
    }
})();
