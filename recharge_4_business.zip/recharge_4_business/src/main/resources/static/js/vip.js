$(function() {
    init()
    if (navigator.userAgent.indexOf("cn.jugame.assistant") > 0 || navigator.userAgent.indexOf("cn.jhw.hwzh") > 0) {
        $(".titleBar span,.titleBar img").css("visibility", "hidden")
    }
})

var TID = 0,
    PID = 0;

function init() {

    $("#brandGrid span").click(function(event) {
        $("#brandGrid span").removeClass('active')
        $(".proGrid span").removeClass('active')
        $(this).addClass('active')

        TID = $(this).data('tid')

        $(".proGrid").hide()
        $("#proGrid_" + TID).show()
        $("#proDesc").html($(this).data('pdesc'))
        $("#proTips").html('注：<br/>'+$(this).data('remark'))
        PID = 0
        $("#needPay").html("-- 元")

        //$("#proGrid_" + TID + " span").first().click()

    });


    $(".proGrid span").click(function(event) {
        $(".proGrid span").removeClass('active')
        $(this).addClass('active')

        PID = $(this).data("pid")

        var price = $(this).data("yuan")
        $("#needPay").html(price + " 元")
    });


    $("#titleLink").click(function(event) {

        if (navigator.userAgent.indexOf("cn.jugame.assistant") > 0) {
            try {
                var res = JugameAppJsInterface.jsiGetUserInfo()
                if ("" == res) return
            } catch (ex) {
                console.debug(ex)
            }
        }

        location.href = "/order_list.html"
    });


    $("#btnRecharge").click(function(event) {

        if (navigator.userAgent.indexOf("cn.jugame.assistant") > 0) {
            try {
                var res = JugameAppJsInterface.jsiGetUserInfo()
                if ("" == res) return
            } catch (ex) {
                console.debug(ex)
            }
        }

        var acc = $("#inputAcc").val()

        if(""==acc.trim()){
            showToast("请输入账号")
            return
        }

         if(TID<=0){
            showToast("请选择视频类型")
            return
        }
        
        if(PID<=0){
            showToast("请选择套餐")
            return
        }

        var params = "?account=" + encodeURIComponent(acc) + "&packageId=" + PID
        location.href = "/create_order.html"+params;
        console.info(params)

    });


}