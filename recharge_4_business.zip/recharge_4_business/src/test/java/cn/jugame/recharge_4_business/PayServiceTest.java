package cn.jugame.recharge_4_business;

import cn.jugame.recharge_4_business.commons.constant.OrderStatus;
import cn.jugame.recharge_4_business.entity.OrderInfo;
import cn.jugame.recharge_4_business.entity.ZhifuOrder;
import cn.jugame.recharge_4_business.service.IBasePayService;
import cn.jugame.recharge_4_business.service.PayService;
import cn.jugame.recharge_4_business.service.RechargeService;
import cn.jugame.recharge_4_business.service.payrequest.BasePayReq;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.joda.money.CurrencyUnit;
import org.joda.money.Money;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class PayServiceTest {

    @Autowired
    private IBasePayService aliPayService;

    @Autowired
    private IBasePayService jhPayService;

    @Autowired
    private PayService payService;

    @Autowired
    RechargeService rechargeService;

    @Test
    public void wapAilPay() throws Throwable {
        ZhifuOrder order = ZhifuOrder.builder().orderNo("test-123456789011")
                .orderTime(new Date())
                .orderName("test")
                .zhifuId("ptest-123456789")
                .zhifuOrderAmount(Money.ofMinor(CurrencyUnit.of("CNY"), 1))
                .build();
       String result =  aliPayService.wapPay(order,"");
       log.info(result);

    }

    @Test
    public void wapPay() throws Throwable {
        BasePayReq req = BasePayReq.builder()
                .payType(2)
                .orderTime(new Date())
                .orderNo("test-jh-123456789001")
                .orderName("测试")
                .orderAmount(10)
                .customerId(123)
                .ip("219.136.74.193")
                .platform("gzh")
                .build();
        JSONObject data = payService.wapPay(req);
        assertEquals(1,data.get("code"));

    }

    @Test
    public void rechargeTest() throws Throwable {
        OrderInfo orderInfo = OrderInfo.builder()
                .orderNo("rec-test-123456789010")
                .orderStatus(OrderStatus.ORDER_PAYED.intValue())
                .thirdProductCode("1041")
                .amount(100)
                .orderTime(new Date())
                .ip("183.6.142.162")
                .productType(1)
                .rechargeAccount("568563191")
                .build();
        boolean result = rechargeService.recharge(orderInfo);

    }


    @Test
    public void rechargeQuery() throws Throwable {

        String result = rechargeService.queryDetail("RG-190725-18144304483");
        log.info(result);
    }

    @Test
    public void refund() throws Throwable {
        ZhifuOrder zhifuOrder = ZhifuOrder.builder().zhifuOrderAmount(Money.ofMinor(CurrencyUnit.of("CNY"),2))
                .orderCustomerId(401)
                .orderNo("RG-190731-09322866519")
                .zhifuId("P19073109qbcz182059477")
                .build();
        jhPayService.orderRefund(zhifuOrder,"RFQB-19073109324680589422","退款");
    }


    @Test
    public void refundQuery() throws Throwable {
        jhPayService.orderRefundQuery("RFQB-19073110000050386937","gzh");
    }


}