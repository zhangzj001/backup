package cn.jugame.recharge_4_business;

import cn.jugame.recharge_4_business.mapper.ProductMapper;
import cn.jugame.recharge_4_business.mapper.ZhifuOrderMapper;
import cn.jugame.recharge_4_business.service.CallbackService;
import java.math.BigDecimal;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Recharge4BusinessApplicationTests {

  @Autowired
  private ProductMapper productMapper;
  @Autowired
  CallbackService callbackService;
  @Autowired
  private ZhifuOrderMapper mapper;

  @Test
  public void contextLoads() throws Exception {
  }
}
