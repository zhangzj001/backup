package cn.jugame.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import org.apache.commons.codec.digest.DigestUtils;
import com.google.gson.Gson;


/**
 *  * H5游戏大厅  * 外部接口完整示例  * 替换临时token，可运行  
 **/
public class SimpleExample {
	private static Gson gson = new Gson();
    //8868分配的cpId
    private static final int cpId = 999;
    //8868分配的gameId
    private static final int gameId = 5;
    //8868分配的key
    private static final String key = "eb6ded12da650c5a941d2938e76c6785";
    //8868服务器地址
    private static final String domain="http://h5gameServer.8868.cn/";
    public static void main(String[] args){
        Map request = new HashMap();
        Map client = new HashMap();
         
        TreeMap data = new TreeMap(); //排序签名
         
        //构造请求协议头
        client.put("caller", cpId); //caller即为cpId
        client.put("gameId", gameId);
        request.put("id", System.currentTimeMillis());
        request.put("client", client);
         
        //换取token
        data.clear();
        //临时token
        data.put("token","9DB7FCA06FB8317A44A873F2F13A4E74");
         
        String mysign = sign(data,cpId,key);
         
        //构造签名 & 请求参数data
        request.put("sign", mysign);
        request.put("data", data);
        //请求path external/Token.get
        Map result =  post(domain+"external/Token.get",request);
        System.out.println("换取token接口响应:"+result);
         
         
        //获取永久token，为后续接口请求提供鉴权
        Map theData = (Map)result.get("data"); 
        String longToken = theData.get("token").toString();
         
         
        //查询用户信息接口
        data.clear();
        //构造签名 & 请求参数data
        data.put("token",longToken);
        mysign = sign(data,cpId,key);
        request.put("data", data);
        request.put("sign", mysign);
        result =  post(domain+"external/Member.getMemberInfo",request);
        System.out.println("查询用户信息接口响应:"+result);
         
        //开心豆消耗
        data.clear();
        //构造签名 & 请求参数data
        data.put("token",longToken);
        data.put("productName","test-prod-wenxy");
        data.put("happyBean",10);
        mysign = sign(data,cpId,key);
        request.put("sign", mysign);
        result =  post(domain+"external/HappyBean.consume",request);
        System.out.println("开心豆消耗接口响应:"+result);
         
        //开心豆兑换
        data.clear();
        //构造签名 & 请求参数data
        data.put("token",longToken);
        data.put("happyBean",100);
        data.put("gameCoin",10);
        //data.put("backurl","");
        mysign = sign(data,cpId,key);
        request.put("sign", mysign);
        result =  post(domain+"external/HappyBean.exchange",request);
        System.out.println("开心豆兑换响应:"+result);
           
    }
     
    private static String sign(TreeMap params,int caller,String secretKey){
        StringBuilder sb = new StringBuilder();
        sb.append(caller);
        for (Object key : params.keySet()) {
            Object v = params.get(key);
            if(v instanceof Map){
                continue;
            }
            String value = params.get(key).toString();
            if (value == null) {//为null时，替换为空字符
                value = "";
            }
            sb.append(key + "=" + value);
        }
        sb.append(secretKey);
        //org.apache.commons.codec.digest. DigestUtils
        return DigestUtils.md5Hex(sb.toString());
    }
     
    private static Map post(String url,Object request){
        PrintWriter out = null;
        BufferedReader in = null;
        Map map = new HashMap();
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();
            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            System.out.println("request--->"+gson.toJson(request));
            out.print(gson.toJson(request));
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            String result = "";
            while ((line = in.readLine()) != null) {
                result += "\n" + line;
            }
            map = gson.fromJson(result, Map.class);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
             } catch (IOException ex) {
                 ex.printStackTrace();
             }
        }
        return map;
    }
}