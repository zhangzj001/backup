/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.jugame.test;

import java.security.Key;
import java.security.Security;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import org.apache.commons.lang.StringUtils;

import sun.misc.BASE64Encoder;

/**
 *
 * @author Laputa
 */
public class DESUtil {

    private static String strDefaultKey = "default";
    private Cipher encryptCipher = null;
    private Cipher decryptCipher = null;

    /**
     * 默认构造方法，使用默认密钥
     *
     * @throws Exception
     */
    public DESUtil() throws Exception {
        this(strDefaultKey);
    }

    /**
     * 指定密钥构造方法
     *
     * @param strKey 指定的密钥
     * @throws Exception
     */
    public DESUtil(String strKey) throws Exception {
        Security.addProvider(new com.sun.crypto.provider.SunJCE());
        Key key = getKey(strKey.getBytes("UTF-8"));
        IvParameterSpec iv = getIV((strKey).getBytes("UTF-8"));

        encryptCipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        encryptCipher.init(Cipher.ENCRYPT_MODE, key, iv);

        decryptCipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        decryptCipher.init(Cipher.DECRYPT_MODE, key, iv);
       
    }

    /**
     * 加密字节数组
     *
     * @param arrB 需加密的字节数组
     * @return 加密后的字节数组
     * @throws Exception
     */
    public byte[] encrypt(byte[] arrB) throws Exception {
        return encryptCipher.doFinal(arrB);
    }

    /**
     * 加密字符串（utf8）
     *
     * @param str 需加密的字符串
     * @return 加密后的字符串
     * @throws Exception
     */
    public String encrypt(String str) throws Exception {
        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encode(encryptCipher.doFinal(str.getBytes("UTF-8")));
    }

    /**
     * 从指定字符串生成密钥，密钥所需的字节数组长度为8位 不足8位时后面补0，超出8位只取前8位
     *
     * @param arrBTmp 构成该字符串的字节数组
     * @return 生成的密钥
     * @throws java.lang.Exception
     */
    private Key getKey(byte[] arrBTmp) throws Exception {
        // 创建一个空的8位字节数组（默认值为0）
        byte[] arrB = new byte[8];

        // 将原始字节数组转换为8位
        for (int i = 0; i < arrBTmp.length && i < arrB.length; i++) {
            arrB[i] = arrBTmp[i];
        }

        // 生成密钥
        Key key = new javax.crypto.spec.SecretKeySpec(arrB, "DES");

        return key;
    }

    /**
     * 从指定字符串生成偏移向量，向量所需的字节数组长度为8位 不足8位时后面补0，超出8位只取前8位
     *
     * @param arrBTmp 构成该字符串的字节数组
     * @return 生成的密钥
     * @throws java.lang.Exception
     */
    private IvParameterSpec getIV(byte[] arrBTmp) throws Exception {
        // 创建一个空的8位字节数组（默认值为0）
        byte[] arrB = new byte[8];

        // 将原始字节数组转换为8位
        for (int i = 0; i < arrBTmp.length && i < arrB.length; i++) {
            arrB[i] = arrBTmp[i];
        }

        // 生成便宜向量
        IvParameterSpec iv = new IvParameterSpec(arrB);

        return iv;
    } 
    
    
    public  String ecryptSign(String[] params,String flag){
    	if(null==params||0==params.length||StringUtils.isEmpty(flag)){
    		return null;
    	}
    	StringBuffer sb=new StringBuffer();
    	for(String param:params){
    		sb.append(param).append(flag);
    	}
    	sb=sb.deleteCharAt(sb.length()-1);
    	String sign=null;
		try {
			sign = encrypt(sb.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return sign; 
    }
    

    public static void main(String[] args) throws Exception {
    	
/*    	DESUtil des = new DESUtil("scazas9afd9c3d7c40bf463faf244azz");
    	String test="{\"buyerAccount\": \"测试\", \"buyerPassword\": \"123456\", \"gameVersion\": \"gameVersion\" }";
    	String a=new String(des.encrypt(test));
    	System.out.println("默认密钥加密后的字符UTF-8：" +a);
       // System.out.println("默认密钥加密后通过Base64编码的字符：" + base64encoder.encode((des.encrypt(test.getBytes("UTF-8")))));
//		System.out.println("默认密钥加密后通过Base64解码的字符UTF-8：" + new String(base64decoder.decodeBuffer(base64encoder.encode((des.encrypt(test.getBytes("UTF-8"))))),"UTF-8"));
        System.out.println("默认密钥解密后的字符：" + new String(des.decrypt(a)));*/
    	
    	DESUtil des = new DESUtil("");	//key
    	String[] params=new String[3];
    	params[0]="";	//1771userid
    	params[1]="";	//渠道号
    	params[2]=Common.show_time(new Date(), "yyyyMMddHHmmss");
    	String a=des.ecryptSign(params, "&");
    	System.out.println(a);
    }
}
