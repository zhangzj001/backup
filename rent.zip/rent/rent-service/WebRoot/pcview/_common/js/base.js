//公共方法base
var base = (function () {
  var toastTimer;
  var toast = function (text) {
    clearTimeout(toastTimer);
    var $toast = $('#toast')
    if ($toast.length > 0) {
      $toast.find('.inner').text(text)
      $toast.show()
    } else {
      $toast = $('<div id="toast" class="toast" style="display:block"><span class="inner">' + text + '</span></div>')
      $(document.body).append($toast)
    }
    toastTimer = setTimeout(function () {
      $toast.hide()
    }, 2000)
  }
  var letters = function () {
    var letters = ['热门'];
    for (var i = 0; i < 26; i++) {
      letters.push(String.fromCharCode(65 + i));
    }
    return letters;
  }
  var utils = (function () {
    function detectVerticalSquash(img) {
      // 拍照在IOS7或以下的机型会出现照片被压扁的bug
      var data;
      var ih = img.naturalHeight;
      var canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = ih;
      var ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0);
      try {
        data = ctx.getImageData(0, 0, 1, ih).data;
      } catch (err) {
        console.log('Cannot check verticalSquash: CORS?');
        return 1;
      }
      var sy = 0;
      var ey = ih;
      var py = ih;
      while (py > sy) {
        var alpha = data[(py - 1) * 4 + 3];
        if (alpha === 0) {
          ey = py;
        } else {
          sy = py;
        }
        py = ey + sy >> 1; // py = parseInt((ey + sy) / 2)
      }
      var ratio = py / ih;
      return ratio === 0 ? 1 : ratio;
    }

    /**
     * dataURI to blob, ref to https://gist.github.com/fupslot/5015897
     * @param dataURI
     */
    function dataURItoBuffer(dataURI) {
      var byteString = atob(dataURI.split(',')[1]);
      var buffer = new ArrayBuffer(byteString.length);
      var view = new Uint8Array(buffer);
      for (var i = 0; i < byteString.length; i++) {
        view[i] = byteString.charCodeAt(i);
      }
      return buffer;
    }

    function dataURItoBlob(dataURI) {
      var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
      var buffer = dataURItoBuffer(dataURI);
      return new Blob([buffer], {
        type: mimeString
      });
    }

    /**
     * 获取图片的orientation
     * ref to http://stackoverflow.com/questions/7584794/accessing-jpeg-exif-rotation-data-in-javascript-on-the-client-side
     */
    function getOrientation(buffer) {
      var view = new DataView(buffer);
      if (view.getUint16(0, false) != 0xFFD8) return -2;
      var length = view.byteLength,
          offset = 2;
      while (offset < length) {
        var marker = view.getUint16(offset, false);
        offset += 2;
        if (marker == 0xFFE1) {
          if (view.getUint32(offset += 2, false) != 0x45786966) return -1;
          var little = view.getUint16(offset += 6, false) == 0x4949;
          offset += view.getUint32(offset + 4, little);
          var tags = view.getUint16(offset, little);
          offset += 2;
          for (var i = 0; i < tags; i++) {
            if (view.getUint16(offset + i * 12, little) == 0x0112) return view.getUint16(offset + i * 12 + 8, little);
          }
        } else if ((marker & 0xFF00) != 0xFF00) break;
        else offset += view.getUint16(offset, false);
      }
      return -1;
    }

    /**
     * 修正拍照时图片的方向
     * ref to http://stackoverflow.com/questions/19463126/how-to-draw-photo-with-correct-orientation-in-canvas-after-capture-photo-by-usin
     */
    function orientationHelper(canvas, ctx, orientation) {
      var w = canvas.width,
          h = canvas.height;
      if (orientation > 4) {
        canvas.width = h;
        canvas.height = w;
      }
      switch (orientation) {
        case 2:
          ctx.translate(w, 0);
          ctx.scale(-1, 1);
          break;
        case 3:
          ctx.translate(w, h);
          ctx.rotate(Math.PI);
          break;
        case 4:
          ctx.translate(0, h);
          ctx.scale(1, -1);
          break;
        case 5:
          ctx.rotate(0.5 * Math.PI);
          ctx.scale(1, -1);
          break;
        case 6:
          ctx.rotate(0.5 * Math.PI);
          ctx.translate(0, -h);
          break;
        case 7:
          ctx.rotate(0.5 * Math.PI);
          ctx.translate(w, -h);
          ctx.scale(-1, 1);
          break;
        case 8:
          ctx.rotate(-0.5 * Math.PI);
          ctx.translate(-w, 0);
          break;
      }
    }

    /**
     * 压缩图片
     */
    function compress(file, options, callback) {
      var reader = new FileReader();
      reader.onload = function (evt) {
        if (options.compress === false) {
          // 不启用压缩 & base64上传 的分支，不做任何处理，直接返回文件的base64编码
          file.base64 = evt.target.result;
          callback(file);
          return;
        }

        // 启用压缩的分支
        var img = new Image();
        img.onload = function () {
          var ratio = detectVerticalSquash(img);
          var orientation = getOrientation(dataURItoBuffer(img.src));
          var canvas = document.createElement('canvas');
          var ctx = canvas.getContext('2d');

          var maxW = options.compress.width;
          var maxH = options.compress.height;
          var w = img.width;
          var h = img.height;
          var dataURL = void 0;

          if (w < h && h > maxH) {
            w = parseInt(maxH * img.width / img.height);
            h = maxH;
          } else if (w >= h && w > maxW) {
            h = parseInt(maxW * img.height / img.width);
            w = maxW;
          }

          canvas.width = w;
          canvas.height = h;

          if (orientation > 0) {
            orientationHelper(canvas, ctx, orientation);
          }
          ctx.drawImage(img, 0, 0, w, h / ratio);

          if (/image\/jpeg/.test(file.type) || /image\/jpg/.test(file.type)) {
            dataURL = canvas.toDataURL('image/jpeg', options.compress.quality);
          } else {
            dataURL = canvas.toDataURL(file.type);
          }

          if (options.type == 'file') {
            if (/;base64,null/.test(dataURL) || /;base64,$/.test(dataURL)) {
              // 压缩出错，以文件方式上传的，采用原文件上传
              console.warn('Compress fail, dataURL is ' + dataURL + '. Next will use origin file to upload.');
              callback(file);
            } else {
              var blob = dataURItoBlob(dataURL);
              blob.id = file.id;
              blob.name = file.name;
              blob.lastModified = file.lastModified;
              blob.lastModifiedDate = file.lastModifiedDate;
              callback(blob);
            }
          } else {
            if (/;base64,null/.test(dataURL) || /;base64,$/.test(dataURL)) {
              // 压缩失败，以base64上传的，直接报错不上传
              options.onError(file, new Error('Compress fail, dataURL is ' + dataURL + '.'));
              callback();
            } else {
              file.base64 = dataURL;
              callback(file);
            }
          }
        };
        img.src = evt.target.result;
      };
      reader.readAsDataURL(file);
    }

    function upload(options) {
      var url = options.url,
          file = options.file,
          fileVal = options.fileVal,
          onBeforeSend = options.onBeforeSend,
          onProgress = options.onProgress,
          onError = options.onError,
          onSuccess = options.onSuccess,
          xhrFields = options.xhrFields;
      var name = file.name,
          type = file.type,
          lastModifiedDate = file.lastModifiedDate;

      var data = {
        name: name,
        type: type,
        size: options.type == 'file' ? file.size : file.base64.length,
        lastModifiedDate: lastModifiedDate
      };
      var headers = {};

      if (onBeforeSend(file, data, headers) === false) return;

      file.status = 'progress';

      onProgress(file, 0);

      var formData = new FormData();
      var xhr = new XMLHttpRequest();

      file.xhr = xhr;

      // 设置参数
      Object.keys(data).forEach(function (key) {
        formData.append(key, data[key]);
      });
      if (options.type == 'file') {
        formData.append(fileVal, file, name);
      } else {
        formData.append(fileVal, file.base64);
      }

      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (xhr.status == 200) {
            try {
              // 只支持json
              var ret = JSON.parse(xhr.responseText);
              onSuccess(file, ret);
            } catch (err) {
              onError(file, err);
            }
          } else {
            onError(file, new Error('XMLHttpRequest response status is ' + xhr.status));
          }
        }
      };
      xhr.upload.addEventListener('progress', function (evt) {
        if (evt.total == 0) return;

        var percent = Math.ceil(evt.loaded / evt.total) * 100;

        onProgress(file, percent);
      }, false);

      xhr.open('POST', url);

      Object.keys(xhrFields).forEach(function (key) {
        xhr[key] = xhrFields[key];
      });
      // 设置头部信息
      Object.keys(headers).forEach(function (key) {
        xhr.setRequestHeader(key, headers[key]);
      });

      xhr.send(formData);
    }

    var _id = 0;

    function uploader(selector, options) {
      var that = this;
      var $uploader = $(selector);
      var URL = window.URL || window.webkitURL || window.mozURL;

      // 找到DOM里file-content，若无，则插入一个。
      function findFileCtn($uploader, id) {
        var $file = $uploader.find('[data-id="' + id + '"]');
        var $fileCtn = $file.find('.uploader__file-content');

        if (!$fileCtn.length) {
          $fileCtn = $('<div class="uploader__file-content"></div>');
          $file.append($fileCtn);
        }
        $file.addClass('uploader__file_status');
        return $fileCtn;
      }

      // 清除DOM里的上传状态
      function clearFileStatus($uploader, id) {
        var $file = $uploader.find('[data-id="' + id + '"]').removeClass('uploader__file_status');
        $file.find('.uploader__file-content').remove();
      }

      // 设置上传
      function setUploadFile(file) {
        file.url = URL.createObjectURL(file);
        file.status = 'ready';
        file.upload = function () {
          that.upload($.extend({
            $uploader: $uploader,
            file: file
          }, options));
        };
        file.stop = function () {
          this.xhr.abort();
        };

        options.onQueued(file);
        if (options.auto) file.upload();
      }

      options = $.extend({
        url: '',
        auto: true,
        type: 'file',
        fileVal: 'file',
        xhrFields: {},
        onBeforeQueued: $.noop,
        onQueued: $.noop,
        onBeforeSend: $.noop,
        onSuccess: $.noop,
        onProgress: $.noop,
        onError: $.noop
      }, options);

      if (options.compress !== false) {
        options.compress = $.extend({
          width: 1600,
          height: 1600,
          quality: .8
        }, options.compress);
      }

      if (options.onBeforeQueued) {
        var onBeforeQueued = options.onBeforeQueued;
        options.onBeforeQueued = function (file, files) {
          var ret = onBeforeQueued.call(file, files);
          if (ret === false) {
            return false;
          }
          if (ret === true) {
            return;
          }
        };
      }
      if (options.onQueued) {
        var onQueued = options.onQueued;
        options.onQueued = function (file) {
          if (!onQueued.call(file)) {
            var $file = $uploader.find('[data-id="' + file.id + '"]');
            $file.css({
              backgroundImage: 'url("' + (file.base64 || file.url) + '")'
            });
            if (!options.auto) {
              clearFileStatus($uploader, file.id);
            }
          }
        };
      }
      if (options.onBeforeSend) {
        var onBeforeSend = options.onBeforeSend;
        options.onBeforeSend = function (file, data, headers) {
          var ret = onBeforeSend.call(file, data, headers);
          if (ret === false) {
            return false;
          }
        };
      }
      if (options.onSuccess) {
        var onSuccess = options.onSuccess;
        options.onSuccess = function (file, ret) {
          file.status = 'success';
          if (!onSuccess.call(file, ret)) {
            clearFileStatus($uploader, file.id);
          }
        };
      }
      if (options.onProgress) {
        var onProgress = options.onProgress;
        options.onProgress = function (file, percent) {
          if (!onProgress.call(file, percent)) {
            findFileCtn($uploader, file.id).html(percent + '%');
          }
        };
      }
      if (options.onError) {
        var onError = options.onError;
        options.onError = function (file, err) {
          file.status = 'fail';
          if (!onError.call(file, err)) {
            findFileCtn($uploader, file.id).html('<i class="icon-warn"></i>');
          }
        };
      }

      $uploader.find('input[type="file"]').on('change', function (evt) {
        var files = evt.target.files;

        if (files.length === 0) {
          return;
        }

        if (options.compress === false && options.type == 'file') {
          // 以原文件方式上传
          Array.prototype.forEach.call(files, function (file) {
            file.id = ++_id;

            if (options.onBeforeQueued(file, files) === false) return;

            setUploadFile(file);
          });
        } else {
          // base64上传 和 压缩上传
          Array.prototype.forEach.call(files, function (file) {
            file.id = ++_id;

            if (options.onBeforeQueued(file, files) === false) return;

            that.compress(file, options, function (blob) {
              if (blob) setUploadFile(blob);
            });
          });
        }

        this.value = '';
      });
    }

    return {
      compress: compress,
      upload: upload,
      uploader: uploader
    }
  })();
  //图片上传器
  var initUploader = function (type, maxCount) {
    var uploadCount = 0;
    //初始化上传器
    utils.uploader("#" + type + "-uploader", {
      url: '/rent/uploadImg',
      auto: true,
      type: 'file',
      fileVal: 'file',
      compress: {
        width: 1000,
        height: 1000,
        quality: .8
      },
      onBeforeQueued: function (files) {
        if (["image/jpg", "image/jpeg", "image/png", "image/gif"].indexOf(this.type) < 0) {
          alert('请上传图片');
          return false; // 阻止文件添加
        }
        if (this.size > 10 * 1024 * 1024) {
          alert('请上传不超过10M的图片');
          return false;
        }
        if (files.length > maxCount || $("#" + type + "-uploader img").length > 5) { // 防止一下子选择过多文件
          alert('最多只能上传' + maxCount + '张图片，请重新选择');
          return false;
        }
        if (uploadCount + 1 > maxCount) {
          alert('最多只能上传' + maxCount + '张图片');
          return false;
        }

        ++uploadCount;
        return true; // 阻止默认行为，不插入预览图的框架
      },
      onQueued: function () {
      },
      onBeforeSend: function () {
      },
      onProgress: function (procent) {
      },
      onSuccess: function (ret) {
        if (ret.code == 0) {
          var $html = $('<li class="item"><button type="button" class="rent-imgBtn">删除</button><div class="rent-imgWrapper"><div class="rent-imgBox"><img src="'
              + ret.url + '" alt=""></div></div><input type="hidden" name="pic" value="'
              + ret.url + '"></li>')
          $("#" + type + "-uploader-btn").before($html)
        }
        return true; // 阻止默认行为，不使用默认的成功态
      },
      onError: function (err) {
      }
    });

    //绑定事件
    $("#" + type + "-uploader").on('click', function (e) {
      var $this = $(e.target),
          $parent = $this.closest('.item')

      if (uploadCount > 0) {
        uploadCount = uploadCount - 1;
      }

      $parent.remove()
    });
  }
  var dialogForm = function (type, triggerSelector, events) {
    $(triggerSelector).on("click", function () {
      $("#" + type + "-dialog").show();
      $('body').css('overflow-y', 'hidden')
    })
    $("#" + type + "-cancel").on("click", function () {
      $("#" + type + "-dialog").hide();
      $('body').css('overflow-y', 'auto')
    })
    if (events) {
      //如果是函数，直接就是onSubmit事件
      if (events instanceof Function) {
        $("#" + type + "-dialog").on("submit", function (e) {
          return events(e, "#" + type + "-dialog")
        })
      }
      //如果是一个对象，则对应key->value的事件处理列表
      if (events instanceof Object) {
        for (k in events) {
          $("#" + type + "-dialog").on(k, function (e) {
            return events[k](e, "#" + type + "-dialog")
          })
        }
      }
    }
  }
  var simpleForm = function (type, triggerSelector, events, cancelFn, submitFn) {
    $(triggerSelector).on("click", function () {
      $("#" + type + "-simple-dialog").show();
      $('body').css('overflow-y', 'hidden')
      //触发显示逻辑回调
      if (events) {
        events(this)
      }
    })
    $("#" + type + "-simple-dialog-close").on('click', function () {
      $("#" + type + "-simple-dialog").hide();
      if (cancelFn) {
        cancelFn(this)
      }
      $('body').css('overflow-y', 'auto')
    })
    if (submitFn) {
      $("#" + type + "-simple-dialog-submit").on('click', function () {
        $("#" + type + "-simple-dialog").hide();
        submitFn(this)
        $('body').css('overflow-y', 'auto');
      })
    }
  };
  var seePass = function (eyeSelector, inputSelector) {
    //展示和隐藏密码
    $(eyeSelector).on("click", function () {
      var $input = $(inputSelector),
          $this = $(this);
      var inputType = $input.attr("type");
      //当前是不可见密码，点击后变为可见密码
      if (inputType == "password") {
        $(inputSelector).attr("type", "text");
        $this.attr("src", "/icons/eyesopen.png");
      } else {
        $(inputSelector).attr("type", "password");
        $this.attr("src", "/icons/eyesclose.png");
      }
    })
  }
  //获取游戏
  var get_game = function (obj) {
    $.ajax({
      url: '/rent/games',
      data: {
        type: obj.type || 1,
        letter: obj.letter,
        keywords: obj.keywords
      },
      success: function (data) {
        if (data.code === 0) {
          obj.done(data)
        } else if (obj.fail) {
          obj.fail(data)
        }
      }
    })
  };
  var get_channel = function (obj) {
    $.ajax({
      url: '/rent/channels',
      data: {
        game_id: obj.game_id
      },
      success: function (data) {
        if (data.code === 0) {
          obj.done(data)
        } else if (obj.fail) {
          obj.fail(data)
        }
      }
    })
  };
  var get_partition_categories = function (obj) {
    $.ajax({
      url: '/rent/partitionCategories',
      data: {
        game_id: obj.game_id,
        channel_id: obj.channel_id
      },
      success: function (data) {
        if (data.code === 0) {
          obj.done(data)
        } else if (obj.fail) {
          obj.fail(data)
        }
      }
    })
  };
  var get_partition = function (obj) {
    $.ajax({
      url: '/rent/partitions',
      data: {
        game_id: obj.game_id,
        category_id: obj.category_id
      },
      success: function (data) {
        if (data.code === 0) {
          obj.done(data)
        } else if (obj.fail) {
          obj.fail(data)
        }
      }
    })
  };
  var get_url_param = function (name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r) return decodeURI(r[2]);
    return null;
  };
  /*var search_vue_config = {
    el: '#search_game',
    data: {
      game_name: get_url_param('game_id') || '游戏',
      channel_name: get_url_param('channel_id') || '渠道',
      partition_name: get_url_param('partition_id') || '区服',
      m_games: [],
      pc_games: [],
      v_games: [],
      channels: [],
      categories: [],
      partitions: [],
      game_type: 1,
      game_letters: letters(),
      game_keyword: '',
      game_id: '',
      channel_id: '',
      category_id: '',
      partition_id: ''
    },
    methods:{
      get_game: function(type,data_name,letter,keywords){
        var data_name = arguments[1];
        if(keywords){
          if(this.game_type === 1){
            data_name = 'm'
          }else if(this.game_type === 2){
            data_name = 'v'
          }else if(this.game_type === 5){
            data_name = 'pc'
          }
        }

        base.get_game({
          letter: letter,
          type: type || this.game_type,
          keywords: keywords,
          done: function (data) {
            this[data_name+'_games'] = data.games;
          }.bind(this)
        })
      },
      close_box: function(attr,e){
        var keys = Object.keys(attr);
        var attr_name = keys[0].substring(0,keys[0].indexOf('_'));
        this[attr_name+'_id']=attr[attr_name+'_id'];
        this[attr_name+'_name']=attr[attr_name+'_name'];
      },
      on_submit: function (e) {
        var $this = $('.list_form')[0];
        $this.game_id.value = this.game_id;
        $this.channel_id.value = this.channel_id;
        $this.game_partition_id.value = this.partition_id;
      }
    },
    watch:{
      game_id: function (val) {
        base.get_channel({
          game_id: val,
          done: function (data) {
            this.channels = [{channel_name:'全部渠道',channel_id:''}].concat(data.channels);
            if(get_url_param('channel_id')){
              var has_page_channel_id = true;
              var channel_id = get_url_param('channel_id');
              var channel_name = get_url_param('channel_name');
            }
            if(!has_page_channel_id){
              this.channel_name = this.channels[0].channel_name;
              this.channel_id = this.channels[0].channel_id;
            }else{
              this.channel_name = channel_name;
              this.channel_id = channel_id;
              has_page_channel_id = false;
            }
          }.bind(this),
          fail: function(data){
            this.channels = [];
            this.channel_name = data.msg;
            this.channel_id = '';
          }.bind(this)
        })
      },
      channel_id: function (val) {
        base.get_partition_categories({
          game_id: this.game_id,
          channel_id: val,
          done: function (data) {
            this.categories = data.categories;
            this.category_id = this.categories[0].category_id;
          }.bind(this),
          fail: function (data) {
            this.categories = [];
            this.category_id = '';
          }.bind(this)
        })
      },
      category_id: function (val) {
        base.get_partition({
          game_id: this.game_id,
          category_id: val,
          done: function (data) {
            this.partitions = [{partition_name:'全部区服',partition_id:''}].concat(data.partitions);
            this.partition_id = this.partitions[0].partition_id;
            this.partition_name = this.partitions[0].partition_name;
          }.bind(this),
          fail: function (data) {
            this.partitions = [];
            this.partition_id = '';
            this.partition_name = data.msg;
          }.bind(this)
        })
      }
    }
  };*/
  return {
    toast: toast,
    letters: letters,
    utils: utils,
    initUploader: initUploader,
    dialogForm: dialogForm,
    simpleForm: simpleForm,
    seePass: seePass,
    get_game: get_game,
    get_channel: get_channel,
    get_partition: get_partition,
    get_partition_categories: get_partition_categories,
    get_url_param: get_url_param,
    get_mobile_code: function (obj) {
      var timer;
      var code_btn = obj.code_btn;
      function count(){
        var second = obj.second || 60;
        function counter(){
          if(second<=0){
            code_btn.html(obj.resend_txt || '重新发送')
            clearInterval(timer);
            timer = null;
          }else{
            code_btn.html(second--+'s');
          }
        }
        counter()
        timer = setInterval(counter,1000)
      }
      code_btn.on('click',function () {
        if(!timer) {
          if(!obj.mobile.val().match(/^1(3|4|5|6|7|8|9)\d{9}$/)){
            base.toast('请输入手机号码')
            obj.mobile.focus();
          } else {
            $.get((obj.url || '/auth/sendSmsCode?moblie=') + obj.mobile.val(), function (data) {
              base.toast(data.msg);
              if (data.code === 200) {
                count()
              }
            })
          }
        }
      })
    }
    //search_vue_config: search_vue_config
  }
})();

//ajax默认配置
$.ajaxSetup({
  dataType: 'json'
});

//图片懒加载
(function (factory) {
  if (typeof define === 'function' && define.amd) { // AMD
    // you may need to change `define([------>'jquery'<------], factory)`
    // if you use zepto, change it rely name, such as `define(['zepto'], factory)`
    define(['jquery'], factory)
    // define(['zepto'], factory)
  } else { // Global
    factory(window.jQuery || window.Zepto)
  }
})(function ($, undefined) {
  var w = window,
      $window = $(w),
      defaultOptions = {
        threshold: 100,
        failure_limit: 0,
        event: 'scroll',
        effect: 'show',
        effect_params: null,
        container: w,
        data_attribute: 'src',
        data_srcset_attribute: 'original-srcset',
        skip_invisible: true,
        appear: emptyFn,
        load: emptyFn,
        vertical_only: false,
        check_appear_throttle_time: 300,
        url_rewriter_fn: emptyFn,
        no_fake_img_loader: false,
        placeholder_data_img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAA8AAD/4QMvaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzEzOCA3OS4xNTk4MjQsIDIwMTYvMDkvMTQtMDE6MDk6MDEgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE3IChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpCRjg3OTFBMTlBRjExMUU4QjFFNjlBMEY0RkVBMTVDQyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpCRjg3OTFBMjlBRjExMUU4QjFFNjlBMEY0RkVBMTVDQyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkJGODc5MTlGOUFGMTExRThCMUU2OUEwRjRGRUExNUNDIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkJGODc5MUEwOUFGMTExRThCMUU2OUEwRjRGRUExNUNDIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/+4ADkFkb2JlAGTAAAAAAf/bAIQACAYGBwYFCAcHBwkJCAoMFA0MCwsMGRITDxQdGh8eHRocHCAkLicgIiwjHBwoNyksMDE0NDQfJzk9ODI8LjM0MgEJCQkMCwwYDQ0YMiEcITIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIy/8IAEQgAeAB4AwEiAAIRAQMRAf/EABoAAQADAQEBAAAAAAAAAAAAAAABBAUDAgf/2gAIAQEAAAAA+0gAAAAAAAAAAmYgAq282j493tKpaBRpRpVlebl4DOrafG3l9tABGVe6VvGgAOWUanYATyoXu0AA9eQAAAAAAAB//8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIDBAEF/9oACAECEAAAAIgAByOaejpzzrq79Iz4pemDNfIAAD//xAAZAQEAAwEBAAAAAAAAAAAAAAAAAgMEAQX/2gAIAQMQAAAA6AAHZ6YZ4kvRpnTlF+hgBdXEAAD/xAA2EAACAQMBBAYGCwEAAAAAAAABAgMABBEhBRITQRQiMDFRYSAzQoGRoRUkJVBSU2BjcXOSwf/aAAgBAQABPwD9BBSe4Gtxvw0VI7weye8EFyYp+qG1R+R/mhhiMHINXe05Y5pIoUVd043jrmnvLpzlriT3HFcab82T/ZpL25Q9W4f3nNWu05ZJo4pkV94hQw0xTYUnJpbxZrkQwYcDV35D09pxNJb5ChgupGNR5itnNOssYjk6u9qh8PKroZ2hLhd4mTu8aiiLxyF9mxqyjKjTrUkCyXbtPbiFI494xjnUNzDeSiCW2jVG0VkGq1BGYtoxoTkrLj51tFp2mkEkmE3uqg8POtmRMluSVChtQManz9MjIIpbaS2ukZWBRnFXQ+vS40PEpI1hFzG91KSFBLH2R41FE8M12rsZTwgQT7QoiRFt1CxxgsC4B+QoD7Wz+9/2ntpbm7kJYCNXoDAA78ePYFVYjeAOCDryq7QreyZ5sDU+OJff1LRid5piozmAKNedQWV0LqOSUZCnJJfNCF/pbBGpkLe6t1VJIAGSTpz7K7t+kRgr6xR8RRByQcisHkTWDnAJJPIGrS36OhZ/WsPgOzBIORU9slx1hhJPHxros3E4fDO9UFslv1jh5PkKJJOT2u82MZP3r//EACARAAICAgEFAQAAAAAAAAAAAAECABEDBCASITFAURT/2gAIAQIBAT8A9EkCPkVBbQ7i/Im0jGjCQODL1CplsIAfsYeJkWum/MxKS5Y8dnEXTtP1C+4mGspAUc8uqmQ3ERUFL6n/xAAhEQACAgEEAgMAAAAAAAAAAAABAgADERIgITEEQBNRwf/aAAgBAwEBPwD0VUt1K6msOFg8JvuP4jqMwKTsRtLZiMC+oRW7x+yt86sdS2zCBBtos0tzPi47ljFOSd6XMoxGYscn1P/Z',
        // todo : 将某些属性用global来配置，而不是每次在$(selector).lazyload({})内配置
      },
      type // function

  function emptyFn() {
  }

  type = (function () {
    var object_prototype_toString = Object.prototype.toString
    return function (obj) {
      // todo: compare the speeds of replace string twice or replace a regExp
      return object_prototype_toString.call(obj).replace('[object ', '').replace(']', '')
    }
  })()

  function belowthefold($element, options) {
    var fold
    if (options._$container == $window) {
      fold = ('innerHeight' in w ? w.innerHeight : $window.height()) + $window.scrollTop()
    } else {
      fold = options._$container.offset().top + options._$container.height()
    }
    return fold <= $element.offset().top - options.threshold
  }

  function rightoffold($element, options) {
    var fold
    if (options._$container == $window) {
      // Zepto do not support `$window.scrollLeft()` yet.
      fold = $window.width() + ($.fn.scrollLeft ? $window.scrollLeft() : w.pageXOffset)
    } else {
      fold = options._$container.offset().left + options._$container.width()
    }
    return fold <= $element.offset().left - options.threshold
  }

  function abovethetop($element, options) {
    var fold
    if (options._$container == $window) {
      fold = $window.scrollTop()
    } else {
      fold = options._$container.offset().top
    }
    // console.log('abovethetop fold '+ fold)
    // console.log('abovethetop $element.height() '+ $element.height())
    return fold >= $element.offset().top + options.threshold + $element.height()
  }

  function leftofbegin($element, options) {
    var fold
    if (options._$container == $window) {
      // Zepto do not support `$window.scrollLeft()` yet.
      fold = $.fn.scrollLeft ? $window.scrollLeft() : w.pageXOffset
    } else {
      fold = options._$container.offset().left
    }
    return fold >= $element.offset().left + options.threshold + $element.width()
  }

  function checkAppear($elements, options) {
    var counter = 0
    $elements.each(function (i, e) {
      var $element = $elements.eq(i)
      if (($element.width() <= 0 && $element.height() <= 0) || $element.css('display') === 'none') {
        return
      }

      function appear() {
        $element.trigger('_lazyload_appear')
        // if we found an image we'll load, reset the counter
        counter = 0
      }

      // If vertical_only is set to true, only check the vertical to decide appear or not
      // In most situations, page can only scroll vertically, set vertical_only to true will improve performance
      if (options.vertical_only) {
        if (abovethetop($element, options)) {
          // Nothing.
        } else if (!belowthefold($element, options)) {
          appear()
        } else {
          if (++counter > options.failure_limit) {
            return false
          }
        }
      } else {
        if (abovethetop($element, options) || leftofbegin($element, options)) {
          // Nothing.
        } else if (!belowthefold($element, options) && !rightoffold($element, options)) {
          appear()
        } else {
          if (++counter > options.failure_limit) {
            return false
          }
        }
      }
    })
  }

  // Remove image from array so it is not looped next time.
  function getUnloadElements($elements) {
    return $elements.filter(function (i, e) {
      return !$elements.eq(i)._lazyload_loadStarted
    })
  }

  // throttle : https://github.com/component/throttle , MIT License
  function throttle(func, wait) {
    var ctx, args, rtn, timeoutID // caching
    var last = 0

    return function throttled() {
      ctx = this
      args = arguments
      var delta = new Date() - last
      if (!timeoutID)
        if (delta >= wait) call()
        else timeoutID = setTimeout(call, wait - delta)
      return rtn
    }

    function call() {
      timeoutID = 0
      last = +new Date()
      rtn = func.apply(ctx, args)
      ctx = null
      args = null
    }
  }

  if (!$.fn.hasOwnProperty('lazyload')) {

    $.fn.lazyload = function (options) {
      var $elements = this,
          isScrollEvent,
          isScrollTypeEvent,
          throttleCheckAppear

      if (!$.isPlainObject(options)) {
        options = {}
      }

      $.each(defaultOptions, function (k, v) {
        var typeK = type(options[k])
        if ($.inArray(k, ['threshold', 'failure_limit', 'check_appear_throttle_time']) != -1) { // these params can be a string
          if (typeK == 'String') {
            options[k] = parseInt(options[k], 10)
          } else if (typeK != 'Number') {
            options[k] = v
          }
        } else if (k == 'container') { // options.container can be a seletor string \ dom \ jQuery object
          if (options.hasOwnProperty(k)) {
            if (options[k] == w || options[k] == document) {
              options._$container = $window
            } else {
              options._$container = $(options[k])
            }
          } else {
            options._$container = $window
          }
          delete options.container
        } else if (defaultOptions.hasOwnProperty(k) && (!options.hasOwnProperty(k) || (typeK != type(defaultOptions[k])))) {
          options[k] = v
        }
      })

      isScrollEvent = options.event == 'scroll'
      throttleCheckAppear = options.check_appear_throttle_time == 0 ?
          checkAppear
          : throttle(checkAppear, options.check_appear_throttle_time)

      // isScrollTypeEvent cantains custom scrollEvent . Such as 'scrollstart' & 'scrollstop'
      // https://github.com/search?utf8=%E2%9C%93&q=scrollstart
      isScrollTypeEvent = isScrollEvent || options.event == 'scrollstart' || options.event == 'scrollstop'

      $elements.each(function (i, e) {
        var element = this,
            $element = $elements.eq(i),
            placeholderSrc = $element.attr('src'),
            originalSrcInAttr = $element.attr('data-' + options.data_attribute), // `data-original` attribute value
            originalSrc = options.url_rewriter_fn == emptyFn ?
                originalSrcInAttr :
                options.url_rewriter_fn.call(element, $element, originalSrcInAttr),
            originalSrcset = $element.attr('data-' + options.data_srcset_attribute),
            isImg = $element.is('img')

        if ($element._lazyload_loadStarted == true || placeholderSrc == originalSrc) {
          $element._lazyload_loadStarted = true
          $elements = getUnloadElements($elements)
          return
        }

        $element._lazyload_loadStarted = false

        // If element is an img and no src attribute given, use placeholder.
        if (isImg && !placeholderSrc) {
          // For browsers that do not support data image.
          $element.one('error', function () { // `on` -> `one` : IE6 triggered twice error event sometimes
            $element.attr('src', options.placeholder_real_img)
          }).attr('src', options.placeholder_data_img)
        }

        // When appear is triggered load original image.
        $element.one('_lazyload_appear', function () {
          var effectParamsIsArray = $.isArray(options.effect_params),
              effectIsNotImmediacyShow

          function loadFunc() {
            // In most situations, the effect is immediacy show, at this time there is no need to hide element first
            // Hide this element may cause css reflow, call it as less as possible
            if (effectIsNotImmediacyShow) {
              // todo: opacity:0 for fadeIn effect
              $element.hide()
            }
            if (isImg) {
              // attr srcset first
              if (originalSrcset) {
                $element.attr('srcset', originalSrcset)
              }
              if (originalSrc) {
                $element.attr('src', originalSrc)
              }
            } else {
              $element.css('background-image', 'url("' + originalSrc + '")')
            }
            if (effectIsNotImmediacyShow) {
              $element[options.effect].apply($element, effectParamsIsArray ? options.effect_params : [])
            }
            $elements = getUnloadElements($elements)
          }

          if (!$element._lazyload_loadStarted) {
            effectIsNotImmediacyShow = (options.effect != 'show' && $.fn[options.effect] && (!options.effect_params || (effectParamsIsArray && options.effect_params.length == 0)))
            if (options.appear != emptyFn) {
              options.appear.call(element, $element, $elements.length, options)
            }
            $element._lazyload_loadStarted = true
            if (options.no_fake_img_loader || originalSrcset) {
              if (options.load != emptyFn) {
                $element.one('load', function () {
                  options.load.call(element, $element, $elements.length, options)
                })
              }
              loadFunc()
            } else {
              $('<img />').one('load', function () { // `on` -> `one` : IE6 triggered twice load event sometimes
                loadFunc()
                if (options.load != emptyFn) {
                  options.load.call(element, $element, $elements.length, options)
                }
              }).attr('src', originalSrc)
            }
          }
        })

        // When wanted event is triggered load original image
        // by triggering appear.
        if (!isScrollTypeEvent) {
          $element.on(options.event, function () {
            if (!$element._lazyload_loadStarted) {
              $element.trigger('_lazyload_appear')
            }
          })
        }
      })

      // Fire one scroll event per scroll. Not one scroll event per image.
      if (isScrollTypeEvent) {
        options._$container.on(options.event, function () {
          throttleCheckAppear($elements, options)
        })
      }

      // Check if something appears when window is resized.
      // Force initial check if images should appear when window is onload.
      $window.on('resize load', function () {
        throttleCheckAppear($elements, options)
      })

      // Force initial check if images should appear.
      $(function () {
        throttleCheckAppear($elements, options)
      })

      return this
    }
  }
  $(function () {
    $("img[data-src]").lazyload();
  })
});






