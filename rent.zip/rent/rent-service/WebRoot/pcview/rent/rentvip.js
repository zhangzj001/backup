$('#rent-form').validator({
  klass: 'is-error',
  before: function () {
    // 需要先同意租号协议
    if (!$('#check_rules')[0].checked) {
      base.toast('您需要先同意《租号服务协议》')
      return false
    }
  },
  errorCallback: function (fields) {
    var item = fields[0],
        $input = item.$el.prevObject,
        name = $input.attr('data-tip');
    $input.focus();
    if (item.error == 'empty') {
      base.toast(name + '不能为空')
      return
    }

    if (item.error == 'unvalid' && item.type == 'number') {
      var min = +($input.attr('min')),
          max = +($input.attr('max')),
          val = +($input.val())

      if (val) {
        if (val < min) {
          base.toast(name + '不能低于' + min)
          return
        }
        if (val > max) {
          base.toast(name + '不能超过' + max)
          return
        }
      }
    }

    base.toast(name + '不正确')
  },
  after: function () {
    // 交给服务器处理了

    //是否实名
    if(window.need_real && !window.bind_real_name){
      $('#real_name-simple-dialog').show();
      return false;
    }
    return true;
  }
});


$(function () {
  //查看和隐藏密码
  base.seePass(".form-see-password", "#game_login_password")
})