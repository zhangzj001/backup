$(function () {
  //判断是否勾选用户协议
  $('#check_rules').on('change', function () {
    $('#submit-btn')[0].style.backgroundColor = $(this)[0].checked ? '#f90' : '#999'
  })
  $('#form-order').validator({
    klass: 'is-error',
    before: function () {
      if (!$('#check_rules')[0].checked) {
        base.toast('您需要先同意《租号服务协议》')
        return false
      }
    },
    after: function () {
      // 交给服务器处理了
      return true;
    }
  });
  //如果是续租的话改title
  if ($('#order_id').val() != '') {
    $('.hd').find('h1').html('续租订单');
    $('title').html('续租订单');
    $('#buy_count').val('1');
  }
  //截取链接参数
  var getUrlParam = function (name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //正则匹配
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return r[2];
    return null;
  };
  //金额格式转换
  var parsePrice = function (s) {
    var n = 2 //设置保留的小数位数
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var l = s.split(".")[0].split("").reverse();
    var r = s.split(".")[1];
    var t = "";
    for (i = 0; i < l.length; i++) {
      t += l[i];
    }
    return t.split("").reverse().join("") + "." + r;
  };

  var $rentUnit = $('#rent-unit'),
      $rentInput = $('#buy_count'),
      priceHour = +($('#price-hour').text()),
      priceDay = +($('#price-day').text()),
      guaranteeAmount = +($('#guarantee-amount').text())
  var couponInfo = {};
  var flag = 0;
  var checkAmount = function () {
    var type = $('.content-inner').filter(function () {
          return $(this).hasClass('active')
        }).attr('data-value'),
        count = +($rentInput.val()),
        min, max = 100
    if (type === '1' || type === '3') {
      $rentUnit.text('小时')
      min = +($rentInput.attr('data-min'));
      if ($('#order_id').val() != '') {
        min = 1;
      }
    } else if (type === '4') {
      $('.rent-count1').hide();
      $('.rent-count2').show();
    } else {
      $('.rent-count1').show();
      $('.rent-count2').hide();
      $rentUnit.text('天')
      min = 1;
    }
    // count 不合法
    if (!count || count < min) {
      count = min
    }
    // count 过大
    if (count > max) {
      count = max
    }
    $rentInput.attr('min', min)
    $rentInput.val(count)
    $rentInput.val(count)

    var amount = 0;
    if (type === '1') {
      amount = count * priceHour;
    } else if (type == '2') {
      amount = count * priceDay;
    } else if (type == '3') {
      //标签用的还是时租价
      amount = count * priceHour;
    } else if (type == '4') {
      //包夜价用的标签还是依然是时租价的，但不需要计算件数了
      amount = priceHour;
    } else if (type == '5') {
      //一口价
      amount = priceHour;
    }
    var amountInt = parseInt(amount * 100),
        total = amountInt
    amount = amountInt / 100
    $('#rent-amount').text(amount)
    var price = amount;
    $('._conpons').each(function () {
      this.disabled = +$(this).attr('data-min-rental') > price;
    });
    getCoupon();
    var couponInt = 0;

    if (parseInt(couponInfo.minRental) > price) {
      couponInfo = '';

    }
    if (type == 1 || type == 2 || type == 4) {
      $('#_conpons').val(couponInfo.value);
    } else {
      $('#_conpons').remove();
    }
    if (couponInfo.type) {
      if (couponInfo.type == 1) {
        couponInt = Math.min(Math.min(Math.round(amountInt * (1 - couponInfo.discount)), couponInfo.maxDiscount), amountInt)
      }
      if (couponInfo.type == 2) {
        couponInt = Math.min(couponInfo.amountOff, amountInt)
      }
    }
    if (couponInt) {
      $('#coupon-amount').text('-' + parseInt(couponInt) / 100)
    } else {
      $('#coupon-amount').text('0')
    }

    $('#rent-total').text(parsePrice(parseInt(amountInt + guaranteeAmount * 100 - couponInt) / 100))
  }

  //设置加减按钮的不可点击
  var showBtn = function () {
    if (parseInt($('#buy_count').val()) >= 100) {
      $('.add').addClass('input-disabled');
    } else {
      $('.add').removeClass('input-disabled');
    }
    if (parseInt($('#buy_count').val()) <= $rentInput.attr('min')) {
      $('.min').addClass('input-disabled');
    } else {
      $('.min').removeClass('input-disabled');
    }

  }

  //优惠信息提示
  var getSpecial = function () {
    var rent_type = $('.content-inner').filter(function () {
      return $(this).hasClass('active')
    }).attr('data-value');
    if ($('#buy_count').val() == '') {
      if (rent_type == '1' && $('#order_id').val() == '') {
        buy_count = 2;
      } else {
        buy_count = 1;
      }
    } else {
      buy_count = $('#buy_count').val();
    }

    $('#buy_input').val(rent_type);
    var product_id = getUrlParam("product_id") ? decodeURIComponent(getUrlParam("product_id")) : "";
    if (product_id == '') {
      product_id = $('#product_id').val();
    }
    var param = {
      "rent_type": rent_type,
      "buy_count": buy_count,
      "product_id": product_id
    };
    $.ajax({
      type: "get",
      url: "/order/findBestMatchPromotion",
      data: param,
      dataType: 'json',
      contentType: "application/json",
      success: function (data) {
        $('.tost-msg').show();
        if (data.code == 200) {
          if (rent_type == 1) {
            $('.tost-msg').html("符合时租满送活动<span class='activity tabs' id='activity'></span>,送<span class='tabs' id='give'></span>小时");
          } else {
            $('.tost-msg').html("符合日租<span class='activity tabs' id='activity'></span>,立减<span class='tabs' id='give'></span>元");
          }
          $('#activity').html(data.data);
          $('#give').html(data.promote_gift);

          if (rent_type == 2) {
            $('#rent-total').html(parsePrice(parseInt(($('#rent-total').html() * 100) - parseInt(data.promote_gift) * 100) / 100))
          } else {

          }
        } else {
          $('.tost-msg').hide();
        }
      },
      error: function (data) {
        $('.tost-msg').hide();
      }
    });
  }

  function getCoupon() {
    var allBox = $(":checkbox[name='use_id']");

    if (!flag) {
      allBox.prop('checked', false);
      $('.coupon-item:not(.disable)').eq(0).find('._conpons').prop("checked", "checked").siblings().prop("checked", false);
    }
    $(":checkbox[name='use_id']").on('click', function () {
      if ($(this).prop('checked')) {
        allBox.prop('checked', false);
        $(this).prop("checked", true);
      } else {
        $(this).prop("checked", false);
      }
    });

    var $coupon = $('.order-couponList input').filter(function () {
      return this.checked
    })
    couponInfo = {
      type: +($coupon.attr('data-type')) || 0,
      discount: +($coupon.attr('data-discount')) || 0,
      maxDiscount: +($coupon.attr('data-max-discount')) || 0,
      amountOff: +($coupon.attr('data-amount-off')) || 0,
      minRental: +($coupon.attr('data-min-rental')) || 0,
      checked: ($coupon.attr('checked')) || 0,
      value: ($coupon.attr('value')) || ''
    }
  }

  $('.order-couponList input').on('change', function () {
    flag = 1;
    checkAmount();
    getSpecial();
  });

  $('.js-rent-radio').on('change', function () {
    checkAmount()
  });
  $('#buy_count').on('change', function () {
    checkAmount()
  });
  $('.input-wrap')
      .on('click', '.add', function () {
        var t = $('#buy_count');
        var max = 100;
        t.val(parseInt(t.val()) + 1);
        if (parseInt(t.val()) > max) {
          t.val(max);
        }
        checkAmount();
        showBtn();
        getSpecial();
      })
      .on('click', '.min', function () {
        var t = $('#buy_count');
        var min = $rentInput.attr('min');
        t.val(parseInt(t.val()) - 1);
        if (parseInt(t.val()) < min) {
          t.val(min);
        }
        checkAmount();
        showBtn();
        getSpecial();
      })
      .on('click','.input-disabled',function () {
        base.toast('最短租赁时长为'+$('#buy_count')[0].min+'小时')
      });
  getSpecial();
  showBtn();
  checkAmount();
  $('#buy_count').val($('#buy_count').attr('min'));
  $('.content-wrap').on('click', '.content-inner', function () {
    $(this).addClass("active").siblings().removeClass("active");
    $('#buy_count').val($(this).attr('min'));
    flag = 0;
    getSpecial();
    checkAmount();
    showBtn();

  });
//展开更多优惠券
  var more_coupon = $('#more_coupon');
  if(more_coupon.parent().is(':visible')){
    var coupon_list = $('.order-couponList');
    var coupon_list_height;
    more_coupon.on('change', function () {
      if(!coupon_list_height){
        coupon_list_height = coupon_list[0].scrollHeight
      }
      coupon_list.css('height', this.checked ? coupon_list_height : 100)
    })
  }

})