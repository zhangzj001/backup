//import("../_common/validator.js")

;
~function ($) {
  $.fn.noop = function () {
  }
}(window.jQuery || window.Zepto)

;var uploadCount = 0;
utils.uploader('#uploader', {
  url: 'uploadImg',
  auto: true,
  type: 'file',
  fileVal: 'file',
  compress: {
    width: 1000,
    height: 1000,
    quality: .8
  },
  onBeforeQueued: function (files) {
    // `this` 是轮询到的文件, `files` 是所有文件

    if (["image/jpg", "image/jpeg", "image/png", "image/gif"].indexOf(this.type) < 0) {
      alert('请上传图片');
      return false; // 阻止文件添加
    }
    if (this.size > 10 * 1024 * 1024) {
      alert('请上传不超过10M的图片');
      return false;
    }
    if (files.length > 10) { // 防止一下子选择过多文件
      alert('最多只能上传10张图片，请重新选择');
      return false;
    }
    if (uploadCount + 1 > 10) {
      alert('最多只能上传10张图片');
      return false;
    }

    ++uploadCount;

    return true; // 阻止默认行为，不插入预览图的框架
  },
  onQueued: function () {
    // console.log(this);

    // console.log(this.status); // 文件的状态：'ready', 'progress', 'success', 'fail'
    // console.log(this.base64); // 如果是base64上传，file.base64可以获得文件的base64

    // this.upload(); // 如果是手动上传，这里可以通过调用upload来实现；也可以用它来实现重传。
    // this.stop(); // 中断上传

    // return true; // 阻止默认行为，不显示预览图的图像
  },
  onBeforeSend: function () {
  },
  onProgress: function (procent) {
    // console.log(this, procent);
    // return true; // 阻止默认行为，不使用默认的进度显示
  },
  onSuccess: function (ret) {
    if (ret.code == 0) {
      var $html = $('<li class="item"><button type="button" class="rent-imgBtn">删除</button><div class="rent-imgWrapper"><div class="rent-imgBox"><img src="'
          + ret.url + '" alt=""></div></div><input type="hidden" name="pic" value="'
          + ret.url + '"></li>')
      $('#uploader-btn').before($html)
    }
    return true; // 阻止默认行为，不使用默认的成功态
  },
  onError: function (err) {
    // console.log(this, err);
    // return true; // 阻止默认行为，不使用默认的失败态
  }
})


$(function () {
  //查看和隐藏密码
  base.seePass(".form-see-password", "#game_login_password")

  uploadCount = $('#uploader .item').length
  $('#uploader').on('click', '.rent-imgBtn', function (e) {
    var $this = $(e.target),
        $parent = $this.closest('.item')

    if (uploadCount > 0) {
      uploadCount = uploadCount - 1;
    }

    $parent.remove()
  })
  //表单验证
  var rentForm = $('#rent-form')
  var discountStep = $('.discount-step');
  var discountStatus = $('.discount-check');
  var promotionData = $('#promotion');
  //如果有自定义字段且为checkbox类型的,则一定要选中一个
  $('.custom_prop').on('click',function (e) {
    if(e.target.type === 'checkbox' && !$(this).find('input[type="checkbox"]:checked').length){
      e.target.checked = true;
    }
  })
  rentForm.validator({
    klass: 'is-error',
    before: function () {
      // 需要先同意租号协议
      if (!$('#check_rules')[0].checked) {
        base.toast('您需要先同意《租号服务协议》')
        return false
      }
    },
    errorCallback: function (fields) {
      var item = fields[0],
          name = item.$el.find('label').text() || item.$el.find('input').attr('placeholder')
      if (!name) {
        name = item.$el.find('input').attr('name')
      }
      if(['text','number','password'].indexOf(item.type) >= 0){
        item.$el.prevObject[0].focus();
      }
      if (item.error == 'empty') {
        base.toast(name + '不能为空')
        return
      }
      if (item.error == 'unvalid' && item.type == 'number') {
        var $input = item.$el.find('input'),
            min = +($input.attr('min')),
            max = +($input.attr('max')),
            val = +($input.val())

        if (val) {
          if (val < min) {
            base.toast(name + '不能低于' + min)
            return
          }
          if (val > max) {
            base.toast(name + '不能超过' + max)
            return
          }
        }
      }
      var error_tip = item.$el[0].dataset.error_tip || (name + '不正确');
      base.toast(error_tip);
    },
    after: function () {
      // 交给服务器处理了
      //是否实名
      if(window.need_real && !window.bind_real_name){
        $('#real_name-simple-dialog').show();
        return false;
      }
      return true;
    }
  })

  //优惠设置
  //动态修改最高价格限制
  var priceDay = $('#price_day');
  var maxPricePerDay = priceDay.val();
  priceDay.on('blur', function () {
    var $this = $(this);
    var value = +$this.val();
    if (!value) {
      base.toast('日租金不能为空');
      $this.focus();
      return
    }
    maxPricePerDay = parseInt(value);
    $this.val(value.toFixed(2))
  })
  //添加和删除优惠设置操作
  discountStep.on('click', '.plus', function () {
    var currentLine = $(this).parent();
    var clone = currentLine.clone();
    clone.find('input').val('')
    currentLine.after(clone)
  }).on('click', '.minus', function () {
    var $this = $(this);
    var parent = $this.parent();
    /*var parentIndex = parent.index();
    var parentOfParent = parent.data('parent');
    //如果为编辑页,则要清空该条优惠
    if (parent.data("promotion_id")) {
      var promotionJSON = JSON.parse(promotionData.val());
      promotionJSON[parentOfParent].data[parentIndex].promote_unit = promotionJSON[parentOfParent].data[parentIndex].promote_gift = 0;
      promotionData.val(
          JSON.stringify(promotionJSON)
      )
    }*/
    parent.remove();
  })
  //优惠条件和优惠金额之间的联动
      .on('input', '.hour-input,.day-input,.hour-yuan-input,.day-yuan-input', function () {
        var $this = $(this);
        var inputVal = $this.val().replace(/^0/, '').replace(/\D/g, '');
        var className = $this.attr('class');
        if (className === 'day-input') {
          if (inputVal > 7) {
            inputVal = 7;
            base.toast('出租天数不能设置超过7天')
          }
        } else if(className === 'hour-yuan-input' && inputVal > 12){
          inputVal = 12;
          base.toast('最多只能送12小时')
        }
        $this.val(inputVal);
      })
  //优惠说明弹窗
  simpleForm('discount', '.discount-btn')
  //提交
  rentForm.on('submit', function () {
    var discountInputFlag = true;

    if (!maxPricePerDay) {
      base.toast('请设置日租金');
      priceDay.focus();
      return false;
    }
    discountStatus.filter(':checked').siblings(discountStep).find('input').each(function (index, element) {
      var $this = $(element);
      if (!$this.val()) {
        base.toast('请完善优惠信息');
        $this.focus();
        discountInputFlag = false;
        return false;
      }
    })
    if (discountInputFlag && discountStatus.eq(1)[0].checked) {
      $('.day-yuan-input').each(function (index, element) {
        var totalLimit = +$('.day-input').eq(index).val() * maxPricePerDay - 1;
        var $this = $(element);
        if (+$this.val() > totalLimit) {
          base.toast('当前的每日租金为' + (maxPricePerDay) + '元，优惠最多可设为' + totalLimit + '元');
          $this.focus();
          discountInputFlag = false;
          return false;
        }
      })
    }

    //判断是否有重复设置
    if (discountInputFlag) {
      var hourArray = [], dayArray = [];
      var checkExit = function (inputElement, inputArray) {
        $(inputElement).each(function (index, element) {
          var $this = $(element);
          var val = +$this.val();
          if (inputArray.length && inputArray.every(function (item) {
                return val == item;
              })) {
            base.toast('优惠套餐有重复哟，请重新设置');
            $this.focus();
            discountInputFlag = false;
            return false;
          } else {
            inputArray.push(val);
            $this.parent().parent().attr('data-value', val)
          }
        })
      }
      checkExit('.hour-input', hourArray);
      checkExit('.day-input', dayArray);
    }

    //排序提交
    if (discountInputFlag) {
      var sortFn = function (a, b) {
        return a - b;
      }
      hourArray.sort(sortFn)
      dayArray.sort(sortFn)
      var promotionHourData = [];
      var promotionDayData = [];
      var pushData = function (data, element, val) {
        var parents = $(element).parents(discountStep);
        //var promotionId = parents.data('promotion_id');
        var pashData = {
          promote_unit: val,
          promote_gift: +parents.find('[data-value=' + val + ']').find(element).val()
        }
        /*if (promotionId) {
          pashData.promotion_id = promotionId
        }*/
        data.push(pashData)
      }
      hourArray.forEach(function (val) {
        pushData(promotionHourData, '.hour-yuan-input', val)
      })
      dayArray.forEach(function (val) {
        pushData(promotionDayData, '.day-yuan-input', val)
      })
      var promotionDataJSON = JSON.parse(promotionData.val());
      promotionDataJSON.promotion_hour.data = promotionHourData;
      promotionDataJSON.promotion_hour.status = +discountStatus.eq(0)[0].checked;
      promotionDataJSON.promotion_day.data = promotionDayData;
      promotionDataJSON.promotion_day.status = +discountStatus.eq(1)[0].checked;
      promotionData.val(JSON.stringify(promotionDataJSON))
      //console.log(promotionData.val())
    } else {
      return false;
    }
  })
})