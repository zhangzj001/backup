$(function () {
  //当天第一次出租弹窗
  var oneDay = 1000*60*60*24,
      nowTime = +new Date('2018-02-16'),
      rentRuleTimestamp = +localStorage.getItem('rent-rule-timestamp'),
      rentRuleRead = +localStorage.getItem('rent-rule-read');
  //console.log('当前时间:'+nowTime,'已存时间:'+rentRuleTimestamp,'时间差:'+(nowTime - rentRuleTimestamp),'一天:'+oneDay)
  if(rentRuleTimestamp){
    //已超过一天,设置为未读
    if(nowTime - rentRuleTimestamp >= oneDay){
      rentRuleRead = 0;
      localStorage.setItem('rent-rule-read', 0);
      localStorage.setItem('rent-rule-timestamp', nowTime);
    }
  }else{
    localStorage.setItem('rent-rule-timestamp', nowTime);
  }
  if (!rentRuleRead) {
    $('#rent-rule-simple-dialog').show()
    simpleForm("rent-rule");
    $('#rent-rule-simple-dialog-close').on('click', function () {
      localStorage.setItem('rent-rule-read', 1)
    })
  }
})