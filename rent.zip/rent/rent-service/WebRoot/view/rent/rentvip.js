//import("../_common/base.js")
//import("../_common/validator.js")

;
~function ($) {
  $.fn.noop = function () {
  }
}(window.jQuery || window.Zepto)

$('#rent-form').validator({
  klass: 'is-error',
  before: function () {
    // 需要先同意租号协议
    if (!$('#check_rules')[0].checked) {
      base.toast('您需要先同意《租号服务协议》')
      return false
    }
  },
  errorCallback: function (fields) {
    var item = fields[0],
        name = item.$el.find('label').text() || item.$el.find('input').attr('placeholder')
    if (!name) {
      name = item.$el.find('input').attr('name')
    }
    if (item.error == 'empty') {
      base.toast(name + '不能为空')
      return
    }

    if (item.error == 'unvalid' && item.type == 'number') {
      var $input = item.$el.find('input'),
          min = +($input.attr('min')),
          max = +($input.attr('max')),
          val = +($input.val())

      if (val) {
        if (val < min) {
          base.toast(name + '不能低于' + min)
          return
        }
        if (val > max) {
          base.toast(name + '不能超过' + max)
          return
        }
      }
    }

    base.toast(name + '不正确')
  },
  after: function () {
    // 交给服务器处理了
    //是否实名
    if (window.need_real && !window.bind_real_name) {
      $('#real_name-simple-dialog').show();
      return false;
    }
    return true;
  }
});
//部分号主选中爱奇艺后可以编辑标题
if ($('select#game_id')[0]) {
  var title_input = $('#title_input');
  var orign_title_name;
  var vip_select = function () {
    var select_game = $('#game_id');
    var title = $('#title');
    var vip_list = select_game[0].dataset.value.split(',')
    if (vip_list.indexOf(select_game.val()) > -1) {
      title_input.show();
      title.prop('name', 'name').val(orign_title_name)
    } else {
      orign_title_name = title.val() === '会员vip' ? '' : title.val();
      title_input.hide();
      title.prop('name', '').val('会员vip')
    }
  };
  vip_select();
  $('#game_id').on('change', vip_select)
}
$(function () {
  //查看和隐藏密码
  base.seePass(".form-see-password", "#game_login_password")
})