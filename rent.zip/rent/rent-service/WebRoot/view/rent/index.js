$(function () {
  var gId = '', cId = '', links = $('#links');
  //选择分类后才显示剩下的内容
  /*$('.type_btn').on('click',function(){
    $(this).parent().addClass('remove');
    $('.item.is-active').removeClass('is-active').next().next().addClass('is-active')
    $('body').css('overflow','auto')
  })*/

  //获取游戏类型
  if(location.search && location.search.indexOf('type=') > -1){
    var gameType = location.search.substr(location.search.indexOf('=')+1);
  }
  // 获取游戏
  var getGame = function (params, getDataCallBack) {
    $.getJSON('games?type='+gameType, params, function (data) {
      if (!data.code) {
        var html = ''
        data.games.forEach(function (item) {
          html += '<li><a href="javascript:void(0)" data-id="'
              + item.game_id + '" class="js-game icon--after"><div class="img-box"><img data-src="'
              + item.icon + '"></div>' + item.game_name + '</a></li>'
        })
        links.html(html);
        $('img[data-src]:not([src])').lazyload()
        if (html && (typeof getDataCallBack).toLowerCase() === 'function') {
          getDataCallBack()
        }
      }
    })
  }
  getGame();
  //撑起固定栏的高度
  var autoHeight = function () {
    $('#rent-fixed-hd').height($('#rent-hd-box').height())
  }
  autoHeight()
  //点击不同按钮时进行
  $(".cTab-item").on("click", function () {
    //先返回页面顶部,防止内容显示不全
    window.scrollTo(0, 0);
    $(".cTab-item").removeClass("is-active");
    $(this).addClass("is-active");

    var id = $(this).attr("data-id");
    getGame({letter: id})
  });


  // 获取游戏渠道
  var getChannel = function (gameId) {
    $.getJSON('channels', {game_id: gameId}, function (data) {
      //将字母隐藏掉
      $(".cTab").css("display", "none");
      //继续计算固定头部的高度,强制撑起
      autoHeight()
      if (data.code == 0) {
        var html = ''
        data.channels.forEach(function (item) {
          html += '<li><a href="javascript:void(0)" data-id="'
              + item.channel_id + '" class="js-channel icon--after"><div class="img-box"><img src="'
              + item.icon + '"></div>' + item.channel_name + '</a></li>'
        })
        links.html(html)
      }
    })
  }

  // 获取区服
  var getPartition = function (gameId, cateId) {
    $.getJSON('partitions', {
      game_id: gameId,
      category_id: cateId
    }, function (data) {
      if (data.code == 0) {
        var html = ''
        data.partitions.forEach(function (item) {
          html += '<li><button type="button" data-id="' + item.partition_id + '">' + item.partition_name + '</li>'
        })
        $('#parts-list').html(html)
      }
    })
  }

  // 获取区服分类
  var getPartitionCates = function (gameId, channelId) {
    $.getJSON('partitionCategories', {
      game_id: gameId,
      channel_id: channelId
    }, function (data) {
      if (data.code == 0) {
        if (data.categories && data.categories.length > 0) {
          getPartition(gameId, data.categories[0].category_id)
        }
        var html = ''
        data.categories.forEach(function (item) {
          html += '<li data-id="' + item.category_id + '">' + item.category_name + '</li>'
        })
        $('#cats-list').html(html)
      }
    })
  }

  var rentProcess = function (id) {
    $('#rent-process .item').removeClass('is-active')
    $('#item-' + id).addClass('is-active')
  }

  links.on('click', function (e) {
    var $link = $(e.target).closest('a', links)
    window.scrollTo(0, 0)
    if ($link.hasClass('js-game')) {
      gId = $link.attr('data-id')
      rentProcess('channel')
      getChannel(gId)
      return
    }
    if ($link.hasClass('js-channel')) {
      cId = $link.attr('data-id')
      rentProcess('partition')
      $('#rent-mask').show()
      $('body').css('position', 'fixed');
      getPartitionCates(gId, cId)
    }
  })

  $('#cats-list').on('click', function (e) {
    var target = e.target
    if (target.nodeName == 'LI') {
      var id = $(target).attr('data-id')
      getPartition(gId, id)
    }
  })
  $('#parts-list').on('click', function (e) {
    var target = e.target
    if (target.nodeName == 'BUTTON') {
      var id = $(target).attr('data-id')
      location.href = 'rentdetail?game_id=' + gId + '&channel_id=' + cId + '&game_partition_id=' + id
    }
  })

  //点击空白区域关闭弹层
  $('#rent-mask').on('click', function (e) {
    var target = e.target;
    if (target.id == $(this).attr('id')) {
      $(this).hide();
      $('body').css('position', 'static')
    }
  })
  //搜索查找游戏
  //取消操作
  var cancelSearch = function () {
        $('.cTab').show();
        autoHeight();
        getGame({letter: $('.cTab-item.is-active').attr('data-id')})
      }
  ;(function () {
    var searchTimer;
    $('.search-bar').on('input', function () {
      var keyword = this.value;
      if (keyword) {
        clearTimeout(searchTimer)
        searchTimer = setTimeout(function () {
          getGame({keywords: keyword}, function () {
            $('.cTab').hide();
            autoHeight();
          })
        }, 500)
      } else {
        cancelSearch()
      }
    });
    //取消按钮
    $('.clear-search').on('click', function () {
      cancelSearch();
      this.previousElementSibling.value = '';
    })
  }());
})
