;
~ function($) {
    $.fn.noop = function() {}
}(window.jQuery || window.Zepto)

$(function(){
    //图片滑动展示
    var slider = new Slider('#slider'), maskSlider;
    if(slider.node.length != 0){
        slider.init()
        slider.onclick = function() {
            $('#mask-image-slider').css({
                'top': window.scrollY,
                'height': window.innerHeight
            })
            if (!maskSlider) {
                $('#mask-image-slider').html(slider.node.html())
                maskSlider = new Slider('#mask-image-slider')
                maskSlider.onclick = function() {
                    maskSlider.node.hide()
                }
            }
            if (!maskSlider.isInit) {
                maskSlider.init(slider.status.currentIndex)
                maskSlider.node.show()
            } else {
                maskSlider.node.show()
                setTimeout(function () {
                    maskSlider.setIndex(slider.status.currentIndex, true)
                }, 0)
            }
        }
    }

    //更新密码or验证码
    dialogForm("order-help", "#i-can-help");

    //同意撤单
    dialogForm("cancel-order", "#cancel-order");
})
