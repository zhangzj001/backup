function getSign(triggerBtn) {
  var sendApply = $(triggerBtn);
  sendApply.on('click',function () {
    var $this = $(this);
    $this.attr('disabled',true);
    $.ajax({
      url: '/user/sellerSign',
      dataType: 'json',
      success: function (data) {
        if(data.code === 200){
          $('[data-sign]').addClass('sign-success').off('click')
        }
        $this.attr('disabled',false)
        base.toast(data.msg)
      }
    })
  })
}