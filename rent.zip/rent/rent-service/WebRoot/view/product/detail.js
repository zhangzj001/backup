//import("../_common/slider.js");

$(function () {
  if(location.hash === '#mask-image-slider'){
    history.back()
  }
  //对过期时间的格式化处理
  Date.prototype.Format = function (fmt) {
    var o = {
      "M+": this.getMonth() + 1,
      "d+": this.getDate(),
      "h+": this.getHours(),
      "m+": this.getMinutes(),
      "s+": this.getSeconds(),
      "q+": Math.floor((this.getMonth() + 3) / 3),
      "S": this.getMilliseconds()
    };
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
      if (new RegExp("(" + k + ")").test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
      }
    }
    return fmt;
  };
  var Time = $('._rent_time').html();
  if (Time) {
    //ios无法解析yy-mm-dd这种格式
    var DiffTime = Time.replace(/\-/g, "/");
    var rentTime = Date.parse(DiffTime);
    $('._rent_time').html(new Date(rentTime).Format("MM月dd日hh:mm"));
  }
  var slider = new Slider('#slider'),
      maskSlider;
  if (slider.node.length == 0) {
    return;
  }
  var viewport = document.querySelector('meta[name="viewport"]');//以便打开缩放功能
  window.onhashchange = function(){
    if(location.hash === '#mask-image-slider'){
      viewport.content = viewport.content.replace('user-scalable=no','user-scalable=yes');
    }else{
      viewport.content = viewport.content.replace('user-scalable=yes','user-scalable=no');
    }
  }
  slider.init();
  slider.onclick = function () {
    $('#mask-image-slider').css({
      'top': window.scrollY,
      'height': window.innerHeight
    })
    if (!maskSlider) {
      $('#mask-image-slider').html(slider.node.html())
      maskSlider = new Slider('#mask-image-slider')
      /*maskSlider.onclick = function (e) {
          viewport.content = viewport.content.replace('user-scalable=yes','user-scalable=no');
          maskSlider.node.hide()
      }*/

    }
    if (!maskSlider.isInit) {
      maskSlider.init(slider.status.currentIndex);
      location.hash = '#mask-image-slider';
      //maskSlider.node.show();
    } else {
      location.hash = '#mask-image-slider';
      //maskSlider.node.show()
      setTimeout(function () {
        maskSlider.setIndex(slider.status.currentIndex, true)
      }, 0)
    }
  }
})