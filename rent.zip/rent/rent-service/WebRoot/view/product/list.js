$(function () {
  var $more = $('#more'),
      $text = $more.find('.text'),
      pageSize = 30;

  $('#keyword').on('focus', function () {
    $('body').css('overflow', 'hidden')
  }).on('blur', function () {
    $('body').css('overflow', 'auto')
  })

  function getMore() {
    var page = $('#product-list li').attr('page') || 1;
    if ($more.hasClass('more__loading') || $more.hasClass('more__no')) {
      return;
    }
    $text.text('加载中')
    $more.addClass('more__loading')

    var $form = $("#search-form");
    $.ajax({
      type: "get",
      dataType: "html",
      url: '/product/list',
      data: {
        'game_id': $('#game_id').val(),
        'channel_id': $('#channel_id').val(),
        'keyword': $('#keyword').val(),
        'game_partition_id': $('#game_partition_id').val(),
        'product_type': $('#product_type').val(),
        'status': $form[0].status.value,
        'orderby_price': $('#orderby_price').val(),
        'orderby_trade_hour': $('#orderby_trade_hour').val(),
        'sell_level': $('#sell_level').val(),
        'seller_uid': $("#seller_uid").val(),
        'has_seller_guarantee': $("#has_seller_guarantee").val(),
        'game_login_type': $('#game_login_type').val(),
        'is_promote_product': $('[name=is_promote_product]').val(),
        'is_recommend_product': $('[name=is_recommend_product]').val(),
        'is_support_area': $('#is_support_area').val(),
        'offset': page * pageSize,
        'limit': pageSize,
        'game_type': $('#game_type').val(),
      },
      success: function (html) {
        if (html.length > 0) {
          page++
          $('#product-list li').attr('page', page);
          var $html = $(html)
          $('#product-list').append($html);
          if ($html.find('li').length >= pageSize) {
            $text.text('查看更多  ')
            $more.removeClass('more__loading')
            return
          }
        }
        $more.hide();
      },
      error: function () {
        $text.text('请求异常')
        $more.removeClass('more__loading')
        $more.addClass('more__no')
      }
    });
  }

  $more.on('click', function () {
    getMore();
  });
  $('.product-list').on('click', '.link_url', function () {
    var page = $('#product-list li').attr('page') || 1;
    history.replaceState({
      page: page
    }, "", window.location.search + "#page=" + page);
    var listHtml = $('#product-list').html();
    if (window.localStorage) {
      sessionStorage.removeItem('list');
      sessionStorage.setItem('list', listHtml);
    }
  });
  $('#_main').on('click', '._link_url', function () {
    var _page = $('#_main li').attr('page') || 1;
    history.replaceState({
      _page: _page
    }, "", window.location.search + "#_page=" + _page);
    var mainList = $('.recommend_list').html();
    if (window.localStorage) {
      sessionStorage.removeItem('mainList');
      sessionStorage.setItem('mainList', mainList);
    }
  });

  //判断是从详情页面返回并且缓存里面有数据时直接显示缓存数据防止页面返回时刷新
  function cheakSession() {
    if (location.hash) {
      if (window.sessionStorage.getItem("list") === null && window.sessionStorage.getItem("mainList") === null) {
        return;
      }
      if (window.sessionStorage.getItem("list") != null && window.sessionStorage.getItem("mainList") === null) {
        $('#product-list').html(window.sessionStorage.getItem("list"));
      } else if (window.sessionStorage.getItem("list") === null && window.sessionStorage.getItem("mainList") != null) {
        $('.recommend_list').html(window.sessionStorage.getItem("mainList"));
      } else {
        $('#product-list').html(window.sessionStorage.getItem("list"));
        $('.recommend_list').html(window.sessionStorage.getItem("mainList"));
      }

//
    }
  }

  cheakSession();
  var productList = $('#product-list').find('li').length;
  var page = $('#product-list li').attr('page') || 1;
  if (productList < page * pageSize) {
    $more.hide();
  }
  $('.filter-mask-close').on('click', function () {
    $(this).closest('.filter-mask').hide()
  })


  // 获取游戏渠道
  var getChannel = function (gameId) {
    $.getJSON('/rent/channels', {
      game_id: gameId
    }, function (data) {
      if (data.code == 0) {
        var html = ''
        data.channels.forEach(function (item) {
          html += '<li><a href="javascript:void(0)" data-id="' +
              item.channel_id + '"><div class="img-box"><img src="' +
              item.icon + '"></div>' + item.channel_name + '</a></li>'
        })
        $('#channel-list').html(html)
      }else{
        base.toast(data.msg)
      }
    })
  }
  $('#channel-filter').on('click', function (e) {
    getChannel($('#game_id').val())
    $('#channel-mask').show()
  })
  $('#channel-list').on('click', function (e) {
    var target = e.target,
        $elem
    if (target.nodeName == 'A') {
      $elem = $(target)
    } else {
      $elem = $(target).closest('a')
    }
    var id = $elem.attr('data-id')
    $('#channel_id').val(id)
    $('#search-form').submit()
  })


  $("#price-filter").on("click", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#orderby_price").val(nextValue);
    $("#search-form").submit();
  })

  $('#trade-hour-filter').on("click", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#orderby_trade_hour").val(nextValue);
    $("#search-form").submit();
  })

  $('[name=filter_status]').on("change", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#status").val(nextValue);

  })

  $('[name=filter_sell_level]').on("change", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#sell_level").val(nextValue);

  })

  $('[name=filter_has_seller_guarantee]').on("change", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#has_seller_guarantee").val(nextValue);

  })

  $('[name=filter_game_login_type]').on("change", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#game_login_type").val(nextValue);
  })

  $('[name=filter2_has_seller_guarantee]').on("click", function () {
    var nextValue = $(this).attr("data-next-value");
    $("#has_seller_guarantee").val(this.checked ? nextValue : -1);
    $("#search-form").submit();
  })

  $('[name=filter2_seller_level]').on("click", function () {
    var nextValue = $(this).attr("data-next-value");
    if(this.id === 'signer_check'){
      if($('#lottery_product').val() == 0 && $("#sell_level").val() == 100){
        $("#sell_level").val(-1);
      } else if(nextValue == 1){
        $('#lottery_product').val(nextValue);
        this.checked = true;
      } else if(nextValue == 100){
        $('#lottery_product').val(0);
        $("#sell_level").val(100);
        this.checked = true;
      }
    } else {
      $("#sell_level").val(this.checked ? nextValue : -1);
    }
    $("#search-form").submit();
  })

  $('[name=is_promote_product_filter]').on('click', function () {
    $('#is_promote_product_filter').val(+this.checked);
    $("#search-form").submit();
  })
  // 获取区服
  var getPartition = function (gameId, cateId) {
    $.getJSON('/rent/partitions', {
      game_id: gameId,
      category_id: cateId
    }, function (data) {
      if (data.code == 0) {
        var html = ''
        data.partitions.forEach(function (item) {
          html += '<li><button type="button" data-id="' + item.partition_id + '">' + item.partition_name + '</li>'
        })
        $('#parts-list').html(html)
      }
    })
  }

  // 获取区服分类
  var getPartitionCates = function (gameId, channelId) {
    $.getJSON('/rent/partitionCategories', {
      game_id: gameId,
      channel_id: channelId
    }, function (data) {
      if (data.code == 0) {
        if (data.categories && data.categories.length > 0) {
          getPartition(gameId, data.categories[0].category_id)
        }
        var html = ''
        data.categories.forEach(function (item) {
          html += '<li data-id="' + item.category_id + '">' + item.category_name + '</li>'
        })
        $('#cats-list').html(html)
      }
    })
  }

  $('#partition-filter').on('click', function () {
    if (!$(this).hasClass('is-disabled')) {
      getPartitionCates($('#game_id').val(), $('#channel_id').val())
      $('#partition-mask').show()
    }
  })

  $('#cats-list').on('click', function (e) {
    var target = e.target
    if (target.nodeName == 'LI') {
      var id = $(target).attr('data-id')
      getPartition($('#game_id').val(), id)
    }
  })
  $('#parts-list').on('click', function (e) {
    var target = e.target
    if (target.nodeName == 'BUTTON') {
      var id = $(target).attr('data-id')
      $('#game_partition_id').val(id)
      $('#search-form').submit()
    }
  });

  ;
  (function () {
    var filterBtn = document.getElementById('filter-btn'),
        filterFloat = document.getElementById('filter-float'),
        win_height = document.body.clientHeight,
        switchFilter = function () {
          //计算好筛选框的高度
          filterFloat.style.height = (window.outerHeight - filterFloat.getBoundingClientRect().top)+'px';
          var style = filterFloat.style;
          //如果已显示
          if (style.opacity != 0) {
            style.opacity = 0;
            setTimeout(function () {
              style.visibility = 'hidden';
            }, 300);
            $('body').css('overflow', 'auto')
          } else {
            style.visibility = 'visible';
            $('body').css('overflow', 'hidden');
            style.opacity = 1
          }
        }
    if (filterBtn && filterFloat) {
      filterBtn.addEventListener('click', switchFilter);
      filterFloat.addEventListener('click', function (e) {
        if (e.target.id === this.id) {
          switchFilter()
        }
      });
    }
  }())
  //价格筛选
  var price_filter = $('.price-filter');
  var price_hour = $('.price_hour');
  price_hour.on('change',function () {
    var price_arr = this.value.split('-');
    price_filter.each(function (index,element) {
      element.value = price_arr[index];
    })
  });
  price_filter.on('input', function () {
    var val = $(this).val().replace(/[^0-9\.]/g, '');
    //如果有多个小数点
    if (val.indexOf('.') !== val.lastIndexOf('.')) {
      var tempArray = val.split('.');
      tempArray[0] += '.';
      val = tempArray.reduce(function (total, val) {
        return total + val
      })
    }
    $(this).val(val);
    price_hour.prop('checked',false)
  }).on('blur', function () {
    var val = Math.floor((+$(this).val()) * 10) / 10 || '';
    //最高价格不能小于最低价格
    if (this.name === 'price_up' && val > 0 && val < +$('[name=price_down]').val()) {
      base.toast('最高价格不能小于最低价格');
      $('.dropdown button[type=submit]')[0].disabled = true
      this.focus();
    } else {
      $('.dropdown button[type=submit]')[0].disabled = false
    }
    $(this).val(val);
  })

})