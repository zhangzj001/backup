//(function($){
//	$.fn.selectTab = function(o){
//			var d = {
//				select:'select', //定义下拉对象
//				con:'.jietu_box'          //定义切换对象
//			};
//			var o = $.extend(d,o);
//			var $option = $(d.select).find('option');//遍历下拉对象下的option
//			for(var i = 0; i < $option.length; i++){
//				$option.eq(i).attr('i',i);	//设置option 属性i从下标为0开始赋值
//			}
//			selectFn();
//			$(d.select).change(function(){
//				selectFn();
//			})
//			function selectFn(){
//				var selectedIndex = $(d.select).find('option:selected').attr('i') ; //保存被选中的option的属性i的值
//				indexG = selectedIndex;
//				//alert(selectedIndex)
//				$(d.con).eq(selectedIndex).show().siblings(d.con).hide();       //显示对应显示的对象
//			}
//	}
//})(jQuery);
//$(function(){
//	$().selectTab();
//})
(function($){
	$.fn.selectTab = function(o){
			var d = {
				select:'select', //定义下拉对象
				con:'.jietu_box'          //定义切换对象
			}; 
			var o = $.extend(d,o);
			var $option = $(d.select).find('option');//遍历下拉对象下的option
			for(var i = 0; i < $option.length; i++){
				$option.eq(i).attr('i',i);	//设置option 属性i从下标为0开始赋值
			}
			selectFn();
			$(d.select).change(function(){
				selectFn();
			})

			var bPicList, nowIndex, len;
			function selectFn(){
				bPicList = []
				var selectedIndex = $(d.select).find('option:selected').attr('i') ; //保存被选中的option的属性i的值
				indexG = selectedIndex;
				//alert(selectedIndex)
				$(d.con).eq(selectedIndex).show().siblings(d.con).hide();       //显示对应显示的对象
				var spicList = $(d.con).eq(selectedIndex).find('.spic')
				len = spicList.length
				spicList.each(function() {
					bPicList.push($(this).children('img').attr('src'))
				})
			}
			$('.spic').click(function() {
				nowIndex = $(this).index()
				$('.modal').show()
				$('#bigPic').attr('src', bPicList[nowIndex])
			})
			$('.button__left').click(function() {
				if (nowIndex > 0) {
					nowIndex -= 1
					$('#bigPic').attr('src', bPicList[nowIndex])
				}
			})
			$('.button__right').click(function() {
				if (nowIndex < len - 1) {
					nowIndex += 1
					$('#bigPic').attr('src', bPicList[nowIndex])
				}
			})
			$('#bigPic').click(function() {
				$('.modal').hide()
			})
			$('.modal .close').click(function() {
				$('.modal').hide()
			})
	}
})(jQuery);
$(function(){
	$().selectTab();
})