//import("../_common/validator.js");

$(function () {
  //是否新版本app
  if (window.JugameAppJsInterface && window.JugameAppJsInterface.jsiCallWeixinPay) {
    $('#is_new_version').val(1)
  }

  //判断是否勾选用户协议
  $('#check_rules').on('change', function () {
    $('#submit-btn')[0].style.backgroundColor = $(this)[0].checked ? '#fb2a35' : '#999'
  })
  $('#form-order').validator({
    klass: 'is-error',
    before: function () {
      if (!$('#check_rules')[0].checked) {
        base.toast('您需要先同意《租号服务协议》')
        return false
      }
    },
    after: function () {
      // 交给服务器处理了
      $('#submit-btn').attr('disabled', 'disabled');
      return true;
    }
  });
  //截取链接参数
  var getUrlParam = function (name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //正则匹配
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return r[2];
    return null;
  };
  //金额格式转换
  var parsePrice = function (s) {
    var n = 2 //设置保留的小数位数
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var l = s.split(".")[0].split("").reverse();
    var r = s.split(".")[1];
    var t = "";
    for (i = 0; i < l.length; i++) {
      t += l[i];
    }
    return t.split("").reverse().join("") + "." + r;
  };
  $('.order-more .form-text').on('click', function (e) {
    var $this = $(e.target),
        $parent = $this.closest('.order-more');

    $parent.toggleClass('is-open')
  })

  var $rentUnit = $('#rent-unit'),
      $rentInput = $('#buy_count'),
      priceHour = +($('#price-hour').text()),
      priceDay = +($('#price-day').text()),
      guaranteeAmount = +($('#guarantee-amount').text())
  var couponInfo = {};
  var checkAmount = function () {
    var type = $('.content-inner').filter(function () {
          return $(this).hasClass('active')
        }).attr('data-value'),
        count = +($rentInput.val()),
        min, max = 100
    if (type === '1' || type === '3') {
      $rentUnit.text('小时')
      min = +($rentInput.attr('data-min'))
    } else if (type === '4') {
      $('.rent-count1').hide();
      $('.rent-count2').show();
    } else {
      $('.rent-count1').show();
      $('.rent-count2').hide();
      $rentUnit.text('天')
      min = 1
    }
    // count 不合法
    if (!count || count < min) {
      count = min
    }
    // count 过大
    if (count > max) {
      count = max
    }
    $rentInput.attr('min', min)
    $rentInput.val(count)
    $rentInput.val(count)

    var amount = 0;
    if (type === '1') {
      amount = count * priceHour;
    } else if (type == '2') {
      amount = count * priceDay;
    } else if (type == '3') {
      //标签用的还是时租价
      amount = count * priceHour;
    } else if (type == '4') {
      //包夜价用的标签还是依然是时租价的，但不需要计算件数了
      amount = priceHour;
    } else if (type == '5') {
      //一口价
      amount = priceHour;
    }
    var amountInt = parseInt(amount * 100),
        total = amountInt

    amount = amountInt / 100
    $('#rent-amount').text(amount)
    var couponInt = 0
    if (couponInfo.type) {
      if (couponInfo.type == 1) {
        couponInt = Math.min(Math.min(Math.round(amountInt * (1 - couponInfo.discount)), couponInfo.maxDiscount), amountInt)
      }
      if (couponInfo.type == 2) {
        couponInt = Math.min(couponInfo.amountOff, amountInt)
      }
    }
    if (couponInt) {
      $('#coupon-amount').text('-' + parseInt(couponInt) / 100)
    } else {
      $('#coupon-amount').text('0')
    }
    $('#rent-total').text(parsePrice(parseInt(amountInt + guaranteeAmount * 100 - couponInt) / 100))

  }

  //设置加减按钮的不可点击
  var showBtn = function () {
    if (parseInt($('#buy_count').val()) >= 100) {
      $('.add').addClass('input-disabled');
    } else {
      $('.add').removeClass('input-disabled');
    }
    if (parseInt($('#buy_count').val()) <= $rentInput.attr('min')) {
      $('.min').addClass('input-disabled');
    } else {
      $('.min').removeClass('input-disabled');
    }

  }

  //优惠信息提示
  var getSpecial = function () {
    var rent_type = $('.content-inner').filter(function () {
      return $(this).hasClass('active')
    }).attr('data-value');
    console.log(rent_type)
    if ($('#buy_count').val() == '') {
      buy_count = 1;
    } else {
      buy_count = $('#buy_count').val();
    }
    var use_id = $('._conpons').filter(function () {
      return this.checked
    }).val();
    if (rent_type == 1 || rent_type == 2 || rent_type == 4) {
      $('#_conpons').val(use_id);
    } else {
      $('#_conpons').remove();
    }

    $('#buy_input').val(rent_type);
    var product_id = $('.order-prepare').attr('data-id');
    var param = {
      "rent_type": rent_type,
      "buy_count": buy_count,
      "product_id": product_id
    };
    $.ajax({
      type: "get",
      url: "/order/findBestMatchPromotion",
      data: param,
      dataType: 'json',
      contentType: "application/json",
      success: function (data) {
        $('.tost-msg').show();
        if (data.code == 200) {
          if (rent_type == 1) {
            $('.tost-msg').html("符合时租满送活动<span class='activity tabs' id='activity'></span>,送<span class='tabs' id='give'></span>小时");
          } else {
            $('.tost-msg').html("符合日租<span class='activity tabs' id='activity'></span>,立减<span class='tabs' id='give'></span>元");
          }
          $('#activity').html(data.data);
          $('#give').html(data.promote_gift);

          if (rent_type == 2) {
            $('#rent-total').html(parsePrice(parseInt(($('#rent-total').html() * 100) - parseInt(data.promote_gift) * 100) / 100))
          } else {

          }
        } else {
          $('.tost-msg').hide();
        }
      },
      error: function (data) {
        $('.tost-msg').hide();
      }
    });
  }

  function getCoupon() {
    $('.order-couponList').find('li').first().find('._conpons').attr("checked", "checked");
    var $coupon = $('.order-couponList input').filter(function () {
      return this.checked
    })
    couponInfo = {
      type: +($coupon.attr('data-type')) || 0,
      discount: +($coupon.attr('data-discount')) || 0,
      maxDiscount: +($coupon.attr('data-max-discount')) || 0,
      amountOff: +($coupon.attr('data-amount-off')) || 0
    }
  }

  getCoupon();
  $('.order-couponList input').on('change', function () {
    var $coupon = $('.order-couponList input').filter(function () {
      return this.checked
    })

    couponInfo = {
      type: +($coupon.attr('data-type')) || 0,
      discount: +($coupon.attr('data-discount')) || 0,
      maxDiscount: +($coupon.attr('data-max-discount')) || 0,
      amountOff: +($coupon.attr('data-amount-off')) || 0
    }

    checkAmount();
    getSpecial();
  })

  $('.js-rent-radio').on('change', function () {
    checkAmount()
  });
  $('#buy_count').on('change', function () {
    checkAmount()
  });
  $('.input-wrap')
      .on('click', '.add', function () {
        var t = $(this).parent().find('#buy_count');
        var max = 100;
        t.val(parseInt(t.val()) + 1);
        if (parseInt(t.val()) > max) {
          t.val(max);
        }
        checkAmount();
        showBtn();
        getSpecial();
      })
      .on('click', '.min', function () {
        var t = $(this).parent().find('#buy_count');
        var min = $rentInput.attr('min');
        t.val(parseInt(t.val()) - 1);
        if (parseInt(t.val()) < min) {
          t.val(min);
        }
        checkAmount();
        showBtn();
        getSpecial();
      })
      .on('click','.input-disabled',function () {
        base.toast('最短租赁时长为'+this.nextElementSibling.min+'小时')
      });

  getSpecial();
  showBtn();
  checkAmount();

  //优惠信息格式化
  function showDiscontH() {
    var disMsgH = $('.discont-msg-h').html();
    if (eval(disMsgH) == undefined) {
      return;
    }
    $('.discont-msg-h').html(eval(disMsgH).join('&nbsp;,&nbsp;'));
  }

  function showDiscontD() {
    var disMsgD = $('.discont-msg-d').html();
    if (eval(disMsgD) == undefined) {
      return;
    }
    $('.discont-msg-d').html(eval(disMsgD).join('&nbsp;,&nbsp;'));
  }

//	showDiscontH();
//	showDiscontD();
  $('#buy_count').val($('#buy_count').attr('min'));
  $('.content-wrap').on('click', '.content-inner', function () {
    $(this).addClass("active").siblings().removeClass("active");
    $('#buy_count').val($(this).attr('min'));
    getSpecial();
    checkAmount();
    showBtn();
  });
})