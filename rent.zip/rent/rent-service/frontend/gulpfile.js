const gulp = require('gulp');
const gulpif = require('gulp-if');
var changed = require('gulp-changed');//只对修改过的文件进行处理,加快编译速度
let buildCondition = false;
var base_view = '../WebRoot/view/';
var set_path = function(){
  return {
    'scss': base_view + '**/*.scss',
    'js': base_view + '**/*.js',
    'images': [base_view + '**/*.png', base_view + '**/*.jpg', base_view + '**/*.jpeg', base_view + '**/*.gif']
  }
}
var PATHS = set_path()//默认是手机开发
//修改开发路径
gulp.task('set_view',function(cb){
  base_view = '../WebRoot/pcview/';
  PATHS = set_path();
  cb()
})

const browserSync = require('browser-sync');
let bsclient = browserSync.create()
const proxy = require('http-proxy-middleware');
gulp.task('bs', function () {
  return bsclient.init({
    server: {
      baseDir: './build',
      directory: true
    },
    notify: false,
    middleware: function (req, res, next) {
      var url = req.url;
      var strMd5 = url.slice(url.lastIndexOf('-'),url.lastIndexOf('.'))
      if (/((css|js|images)\/\S+)\.(css|js|png|jpg|gif)/.test(url)) {
        /*url = url.replace(/(.*(css|js|images)\/\S+)\.(css|js|png|jpg|gif)/, function (match, p1, p2, p3, offset, string) {
           if (p1.lastIndexOf('.') == p1.length - 9) {
             return p1.substr(0, p1.length - 9) + '.' + p3;
           }
           return p1 + '.' + p3;
         })
         req.url = url*/
        req.url = url.replace(strMd5,'')
      }
      return next()
    }
  })
})
// 处理 sass 到 css
let sass = require('gulp-sass')
let postcss = require('gulp-postcss')
let autoprefixer = require('autoprefixer')
let sprites = require('postcss-sprites')
let csssimple = require('postcss-csssimple')
let cssnano = require('cssnano')

// 处理 CSS
gulp.task('css', function () {
  return gulp.src(base_view + 'style.scss')
      .pipe(changed('build/css'))
      .pipe(sass().on('error', sass.logError))
      .pipe(gulpif(buildCondition, postcss([autoprefixer(['iOS >= 7', 'Android >= 4.2']), cssnano({
        autoprefixer: false
      })])))
      .pipe(gulp.dest('build/css'))
})
//处理雪碧图
gulp.task('sprites', function () {
  return gulp.src('build/css/*.css')
      .pipe(postcss([sprites({
        spritePath: 'build/images',
        retina: base_view === '../WebRoot/view/',
        filterBy: function (image) {
          // 只对二级目录中的图片拼成雪碧图
          if (/images\/(.+)\/.+\@2x.png$/.test(image.url)) {
            return Promise.resolve()
          } else {
            return Promise.reject()
          }
        },
        groupBy: function (image) {
          let result = /images\/([^\/]+)\/.+\.png$/.exec(image.url)
          if (result) {
            var name = result[1];
            if (['_common', '_components', '_footer', '_header'].indexOf(name) >= 0) {
              name = 'common'
            }
            return Promise.resolve(name);
          }
          return Promise.reject(new Error('Not a sprite image.'));
        },
        spritesmith: {
          padding: 10
        }
      })]))
      .pipe(gulp.dest('build/css'))
})

// 处理 JS
const uglify = require('gulp-uglify')
const gulpImports = require('gulp-imports')
const concat = require('gulp-concat')

gulp.task('js', function () {
  return gulp.src(PATHS.js, {base: base_view})
      .pipe(changed('build/js'))
      .pipe(gulpImports())
      .pipe(gulpif(buildCondition, uglify().on('error', function (e) {
        console.log(e.cause)
      })))
      .pipe(gulp.dest('build/js'))
})

// 处理图片
gulp.task('images', function () {
  return gulp.src(PATHS.images, {base: base_view})
      .pipe(gulp.dest('build/images'))
})

// 开发用 watch
gulp.task('watch', function () {
  gulp.watch(PATHS.scss, gulp.task('css'))
  gulp.watch(PATHS.js, gulp.task('js'));
  gulp.watch(PATHS.images, gulp.task('images'));
})

gulp.task('setBuild', function (cb) {
  buildCondition = true
  cb()
})

const del = require('del')
gulp.task('clean', function () {
  var assets = base_view === '../WebRoot/view/' ? '../WebRoot/assets' : '../WebRoot/pcassets';
  return del([
    'build',
    'dist',
    assets
  ], {
    force: true
  })
})

const revAll = require('gulp-rev');

gulp.task('rev', function () {
  return gulp.src(['build/**/*.css', 'build/**/*.js', 'build/images/**/*.*'], {base: 'build'})
      .pipe(revAll())
      .pipe(gulp.dest('dist'))
      .pipe(revAll.manifest({
        merge: true
      }))
      .pipe(gulp.dest('dist'))
});

const replace = require('gulp-replace')

gulp.task('updateRefrence', function () {
  const map = require('./dist/rev-manifest.json');
  var assetsPrefix = base_view === '../WebRoot/view/' ? 'assetsPrefix' : 'pcAssetsPrefix';
  var assetsPrefix_name = '#(' + assetsPrefix + ')';
  var reg = new RegExp('#' + '\\(' + assetsPrefix + '\\)' + '((css|js|images)\\/\\S+)\\.(css|js|png|jpg|gif)','g');
  return gulp.src(base_view + '**/*.html', {base: base_view})
      .pipe(replace(reg, function (match, p1, p2, p3, offset, string) {
        var k = p1 + '.' + p3
        // 尝试直接替换 map
        if (map[k]) {
          return assetsPrefix_name + map[k]
        }

        // 尝试是否已有后缀
        if (p1.length > 11) {
          k = p1.substr(0, p1.length - 11) + '.' + p3
          if (map[k]) {
            return assetsPrefix_name + map[k]
          }
        }

        // 无法替换，原路返回
        return assetsPrefix_name + p1 + '.' + p3
      }))
      .pipe(gulp.dest(base_view))
})

//替换css内的图片路径
const revReplace = require("gulp-rev-replace");
gulp.task('css-update', function () {
  var manifest = gulp.src('./dist/rev-manifest.json');
  return gulp.src('./dist/css/*.*')
      .pipe(revReplace({manifest: manifest}))
      .pipe(gulp.dest('./dist/css'))
})

gulp.task('releaseAssets', function () {
  return gulp.src(['dist/**/*', '!dist/**/*.html', '!dist/**/*.json'], {base: 'dist/'})
      .pipe(gulp.dest(base_view === '../WebRoot/view/' ? '../WebRoot/assets' : '../WebRoot/pcassets'))
})

// 开发
gulp.task('dev', gulp.series(gulp.parallel(gulp.series('css', 'images'), 'js'), gulp.parallel('bs','watch')))
//pc开发
gulp.task('pc_dev',gulp.series('set_view',gulp.parallel(gulp.series('css', 'images'), 'js'), gulp.parallel('bs','watch')))
// 构建
gulp.task('build', gulp.series('setBuild', gulp.parallel(gulp.series('css', 'images', 'sprites'), 'js')))
// 打包
gulp.task('release', gulp.series('clean', 'build', 'rev', 'css-update', 'releaseAssets', 'updateRefrence'));
// pc打包
gulp.task('pc_release',gulp.series('set_view','clean', 'build', 'rev', 'css-update', 'releaseAssets', 'updateRefrence'))