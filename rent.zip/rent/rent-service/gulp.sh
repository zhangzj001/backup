cd frontend; gulp release
