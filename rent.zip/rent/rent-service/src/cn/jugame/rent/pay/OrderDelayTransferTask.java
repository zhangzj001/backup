package cn.jugame.rent.pay;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 定时任务：订单延迟转账任务
 * @author zimT_T
 */
@DisallowConcurrentExecution
public class OrderDelayTransferTask implements Job{
	
	private Logger logger = Loggers.rentLog();
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		List<Record> rows = SmartDb.find("select * from `order_delay_transfer` where `status`=? and `transfer_time`<=?", Order.DELAY_TRANSFER_NOT_FINISH, Common.now());
		for(Record row : rows){
			String orderId = row.getStr("order_id");
			
			DistLocker locker = new DistLocker(orderId);
			boolean succ = false;
			try{
				succ = locker.lock(PropKit.getInt("displock.timeout"));
				if(!succ){
					continue;
				}
				
				int selluserUid = row.getInt("uid");
				double amount = Common.round(row.getInt("amount")/100.0, 2);
				
				//先检查状态，避免同步问题
				Record dt = SmartDb.findFirst("select * from `order_delay_transfer` where `id`=? limit 1", row.getInt("id"));
				if(dt.getInt("status") == Order.DELAY_TRANSFER_FINISH){
					logger.info("延迟转账【" + orderId + "】订单已经完成，忽略本次转账处理！");
					continue;
				}
				
				//先更新状态
				logger.info("延迟转账任务：订单【" + orderId + "】-【" + row.getInt("id") + "】准备修改延迟转账状态！");
				row.keep("id");
				row.set("status", Order.DELAY_TRANSFER_FINISH);
				if(!SmartDb.update("order_delay_transfer", "id", row)){
					logger.error("延迟转账任务：更新订单【" + orderId + "】延迟转账状态为“已完成”失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
					continue;
				}
				logger.info("延迟转账任务：订单【" + orderId + "】修改延迟转账状态为“已完成”！");
				
				Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
				if(!PaymentFactory.raw().orderTransfer(order, selluserUid, IPayment.TRANSFER_SELLUSER, "订单【" + orderId + "】延时转账到账")){
					logger.error("延迟转账任务：订单【" + orderId + "】转账给用户【" + selluserUid + "】时发生了错误，金额【" + amount + "元】！");
				}
			}finally{
				if(succ) locker.unlock();
			}
		}
	}

}
