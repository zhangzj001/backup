package cn.jugame.rent.pay;

import java.util.List;

import com.jfinal.plugin.activerecord.Record;

import net.sf.json.JSONObject;

/**
 * 租号支付模块。该模块架构在支付服务和租号上层业务之间，提供一个与租号业务密切相关的安全支付环境，同时也避免支付服务的bug导致租号服务bug的事情发生。<br>
 * 支付模块将会管理 order 表的5个字段，上层业务可以不需要再管理这些字段: <br>
 * <code>order_isrend_rental, order_isrefund_guarantee, refund_buyuser_amount, 
 * refund_time, refund_selluser_amount </code>
 * @author zimT_T
 *
 */
public interface IPayment {

	//1-退买家， 2-转卖家, 3-转佣金, 4-转押金卖家, 5-转押金平台, 6-押金退买家
	public static final int TRANSFER_BUYUSER = 1;
	public static final int TRANSFER_SELLUSER = 2;
	public static final int TRANSFER_TG = 3;
	public static final int TRANSFER_DEPOSIT_SELLUSER = 4;
	public static final int TRANSFER_DEPOSIT_PLATFORM = 5;
	public static final int TRANSFER_DEPOSIT_BUYUSER = 6;
	
	/**
	 * 支付租号订单。
	 * @param payId 支付单ID，对应order_relet表的pay_id字段
	 * @param ip 用户IP
	 * @return 若成功返回需要302跳转的html，由业务引导用户跳转至该页面执行支付。若不成功返回null。
	 */
	public String payOrder(String payId, String ip);
	
	/**
	 * 支付租号订单（PC租号端）
	 * @param payId 订单ID
	 * @param way 支付方式
	 * @param ip 用户IP
	 * @return {code:0, msg:xxx, pay_way: xxx, 其余字段根据不同的pay_way值有不一样的key，请参考实现}
	 */
	public JSONObject payOrder(String payId, ZhifuWay way, String payPasswd, String ip,String clientType);
	
	/**
	 * 用户支付成功后的回调接口
	 * @param payId 支付单ID，对应order_relet表的pay_id字段
	 */
	public void onOrderPaySucc(String payId);
	
	/**
	 * 订单成功后的租金处理接口
	 * @param orderId
	 * @return
	 */
	public boolean orderSuccForRental(String orderId);
	
	/**
	 * 订单成功后的押金处理接口
	 * @param orderId
	 * @return
	 */
	public boolean orderSuccForGuarantee(String orderId);
	
	/**
	 * 租号订单失败时的转账接口。<br>
	 * 1. 如果是免责撤单，调用该接口时将直接将租金和押金退还给玩家。<br>
	 * 2. 如果是有责撤单，若还没有超过仲裁期该接口将返回失败，超过仲裁期了将执行买卖双方的转账操作。<br><br>
	 * <b>也就是说，调用该接口的时机一定是订单已经不能仲裁了！</b>
	 * @param orderId 订单ID，对应order表的order_id
	 * @return 成功 or 失败
	 */
	public boolean orderFailForBoth(String orderId);
	
	/**
	 * 支付保证金
	 * @param product 商品
	 * @param payId 支付单ID
	 * @param amount 保证金金额，单位为分
	 * @param ip 用户IP
	 * @return 若成功返回需要302跳转的html，由业务引导用户跳转至该页面执行支付。若不成功返回null。
	 */
	public String payGuarantee(Record product, String payId, Integer amount, String ip);
	
	/**
	 * 支付保证金（PC租号端）
	 * @param product 商品
	 * @param payId 支付ID
	 * @param amount 保证金金额，单位为分
	 * @param way 支付方式
	 * @param payPasswd 支付密码
	 * @param ip 用户IP
	 * @return {code:0, msg:xxx, pay_way: xxx, 其余字段根据不同的pay_way值有不一样的key，请参考实现}
	 */
	public JSONObject payGuarantee(Record product, String payId, Integer amount, ZhifuWay way, String payPasswd, String ip,String clientType);
	
	/**
	 * 支付新春商品装饰
	 * @param productDecorate 支付记录
	 * @param payId 支付ID
	 * @param amount 保证金金额，单位为分
	 * @param way 支付方式
	 * @param payPasswd 支付密码
	 * @param ip 用户IP
	 * @return {code:0, msg:xxx, pay_way: xxx, 其余字段根据不同的pay_way值有不一样的key，请参考实现}
	 */
	public JSONObject payProductDecorate(Record productDecorate, String payId, Integer amount, ZhifuWay way, String payPasswd, String ip,String clientType);
	
	/**
	 * 保证金支付成功后的回调接口
	 * @param product 商品
	 * @param payId 支付单ID
	 * @param amount 保证金金额，单位为分
	 */
	public void onGuaranteePaySucc(Record product, String payId, Integer amount);
	
	/**
	 * 退还保证金
	 * @param product 商品
	 * @param payId 支付单ID
	 * @param amount 保证金金额，单位为分
	 * @return 成功 or 失败
	 */
	public boolean refundGuarantee(Record product, String payId, Integer amount);
	
	/**
	 * 扣除保证金
	 * @param product 商品
	 * @param payId 支付单ID
	 * @return
	 */
	public boolean deductGuarantee(Record product, String payId, Integer amount);
	
	
	
	/**
	 * 简易支付，给个订单号+商品名称+金额就直接支付了！<br>
	 * 该接口作为一个业务简化支付的接口提供出来，该接口不会做任何并发保护、资金监控等操作。
	 * @param uid 支付者UID
	 * @param payId 支付单号
	 * @param productName 支付的商品名称
	 * @param amount 金额，元
	 * @param remark 备注信息
	 * @param ip 用户IP
	 * @return
	 */
	public String easyPay(int uid, String payId, String productName, Double amount, String remark, String cbFrontend, String cbBackend, String ip);
	
	/**
	 * 原始的退款接口，对支付单payId执行原路退款。
	 * @param uid 收款人UID
	 * @param orderId 标记的订单ID，也可以是商品ID或者任意你觉得合适的ID。这个字段仅用于日志
	 * @param payId 支付单ID
	 * @param amount 需要退款的金额，如果为null则是全额退款
	 * @param remark 退款备注
	 * @return
	 */
	public boolean refund(int uid, String orderId, String payId, Double amount, String remark);
	
	
	/**
	 * 获取支付策略
	 * @param platform PC版使用web，手机版本使用wap
	 * @return
	 */
	public List<ZhifuWay> getStrateges(String platform);
	
	/**
	 * 获取可用余额
	 * @param uid
	 * @return
	 */
	public Double getAvailableBalance(int uid) ;
	
	/***
	 * 将商品装饰的钱转到平台
	 * @param uid
	 * @param payId
	 * @param amount
	 * @return
	 */
	public boolean deductProductDecorate(int uid,String payId,Integer amount);

	/***
	 * 旧支付页
	 * @param uid
	 * @param payId
	 * @param amount
	 * @param ip
	 * @return
	 */
	public String payProductDecorate(int uid, String payId, Integer amount, String ip);
}
