package cn.jugame.rent.pay;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import net.sf.json.JSONObject;

public class ZhifuWay {
	public static final String ALIPAY_KEY = "zhiFuBaoPay";
	public static final String WXPAY_KEY = "weiXinPay";
	public static final String UNIONPAY_KEY = "unionPay";
	public static final String BALANCE_KEY = "balancePay";
	
	private String zhifuPlatform = "web";
	private String payWay;
	private String payKey;
	private String zhifuName;
	private boolean isMix = false;
	
	ZhifuWay(){}
	
	public String getZhifuPlatform() {
		return zhifuPlatform;
	}
	public void setZhifuPlatform(String zhifuPlatform) {
		this.zhifuPlatform = zhifuPlatform;
	}
	public String getPayWay() {
		return payWay;
	}
	public void setPayWay(String payWay) {
		this.payWay = payWay;
	}
	public String getZhifuName() {
		return zhifuName;
	}
	public void setZhifuName(String zhifuName) {
		this.zhifuName = zhifuName;
	}
	public boolean isMix() {
		return isMix;
	}
	public void setMix(boolean isMix) {
		this.isMix = isMix;
	}
	public void setPayKey(String payKey) {
		this.payKey = payKey;
	}
	public String getPayKey() {
		return payKey;
	}

	public static ZhifuWay alipay(List<ZhifuWay> ways, String payKey, String platform){
		for(ZhifuWay way : ways){
			if(ALIPAY_KEY.equalsIgnoreCase(way.getPayKey()))
				return way;
		}
		return null;
	}
	public static ZhifuWay wechat(List<ZhifuWay> ways, String payKey, String platform){
		for(ZhifuWay way : ways){
			if(WXPAY_KEY.equalsIgnoreCase(way.getPayKey()))
				return way;
		}
		return null;
	}
	public static ZhifuWay balance(List<ZhifuWay> ways, String payKey, String platform){
		for(ZhifuWay way : ways){
			if(BALANCE_KEY.equalsIgnoreCase(way.getPayKey()))
				return way;
		}
		return null;
	}
	public static ZhifuWay balanceMixAlipay(List<ZhifuWay> ways, String payKey, String platform){
		ZhifuWay way = new ZhifuWay();
		way.setZhifuName("支付宝混合支付");
		way.setZhifuPlatform(platform);
		way.setMix(true);
		way.setPayKey(payKey);
		
		String payWay = "";
		for(ZhifuWay w : ways){
			if(ALIPAY_KEY.equalsIgnoreCase(w.getPayKey()))
				payWay += w.getPayWay() + ",";
			if(BALANCE_KEY.equalsIgnoreCase(w.getPayKey()))
				payWay += w.getPayWay() + ",";
		}
		if(payWay.length() > 0){
			payWay = payWay.substring(0, payWay.length() - 1);
		}
		way.setPayWay(payWay);
		return way;
	}
	public static ZhifuWay balanceMixWechat(List<ZhifuWay> ways, String payKey, String platform){
		ZhifuWay way = new ZhifuWay();
		way.setZhifuName("微信混合支付");
		way.setZhifuPlatform(platform);
		way.setMix(true);
		way.setPayKey(payKey);

		String payWay = "";
		for(ZhifuWay w : ways){
			if(WXPAY_KEY.equalsIgnoreCase(w.getPayKey()))
				payWay += w.getPayWay() + ",";
			if(BALANCE_KEY.equalsIgnoreCase(w.getPayKey()))
				payWay += w.getPayWay() + ",";
		}
		if(payWay.length() > 0){
			payWay = payWay.substring(0, payWay.length() - 1);
		}
		way.setPayWay(payWay);
		
		return way;
	}
	
	public static ZhifuWay parse(String payKey, List<ZhifuWay> ways, String platform){
		if(StringUtils.isBlank(payKey)){
			ZhifuWay way = new ZhifuWay();
			way.setZhifuName("免支付");
			way.setZhifuPlatform(platform);
			way.setPayWay("");
			way.setPayKey(BALANCE_KEY); //免支付就认为是余额支付吧
			way.setMix(false);
			return way;
		}
		
		if(payKey.contains(BALANCE_KEY) && payKey.contains(ALIPAY_KEY))
			return balanceMixAlipay(ways, payKey, platform);
		if(payKey.contains(BALANCE_KEY) && payKey.contains(WXPAY_KEY))
			return balanceMixWechat(ways, payKey, platform);
		if(payKey.contains(BALANCE_KEY))
			return balance(ways, payKey, platform);
		if(payKey.contains(ALIPAY_KEY))
			return alipay(ways, payKey, platform);
		if(payKey.contains(WXPAY_KEY))
			return wechat(ways, payKey, platform);
		return null;
	}
	
	public JSONObject toJson(){
		JSONObject json = new JSONObject();
		json.put("zhifu_name", zhifuName);
		json.put("zhifu_platform", zhifuPlatform);
		json.put("pay_way", payWay);
		json.put("pay_key", payKey);
		json.put("is_mix", isMix);
		return json;
	}
}
