### 租号相关的支付服务代码
### 用法
IPayment payment = PaymentFactory.get();
