package cn.jugame.rent.pay;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.slf4j.Logger;

public class TransferRecord {
	
	private static final int TARGET_TYPE_ORDER = 1;
	private static final int TARGET_TYPE_PRODUCT = 2;
	
	public static final int PAY_TYPE_BUYER_RETAL = 1;
	public static final int PAY_TYPE_SELLER_RENTAL = 2;
	public static final int PAY_TYPE_BUYER_GUARANTEE = 3;
	public static final int PAY_TYPE_SELLER_GUARANTEE = 4;
	public static final int PAY_TYPE_PRODUCT_GUARANTEE = 5;
	//支付联合推广号主佣金
	public static final int PAY_TYPE_SPONSOR_FEE = 6;
	
	private static Logger logger = Loggers.rentLog();
	
	public static boolean addOrderTransfer(String orderId, int payType, Integer amount){
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			logger.error("addOrderTransfer -- 不存在的订单, orderId=>" + orderId);
			return false;
		}
		int uid = order.getInt("selluser_uid");
		
		Record row = new Record();
		row.set("target_id", orderId);
		row.set("type", TARGET_TYPE_ORDER);
		row.set("pay_type", payType);
		row.set("c_time", Common.now());
		row.set("amount", amount);
		row.set("uid", uid);
		if(!SmartDb.save("zhifu_transfer", row)){
			logger.error("记录订单支出金额失败, orderId=>" + orderId + ", amount=>" + amount + ", sql=>" + SmartDb.lastQuery(), SmartDb.getException());
			return false;
		}

		//计算单笔订单的超额值
		int orderAmount = order.getInt("order_amount");
		row = SmartDb.findFirst("select sum(`amount`) as _sum from `zhifu_transfer` where `target_id`=? and `type`=?", orderId, TARGET_TYPE_ORDER);
		int outgo = row.getBigDecimal("_sum").intValue();
		//如果转出的额度超过订单金额，立刻封禁。一般情况下 outgo = 0.85*orderAmount
		if(outgo > orderAmount){
			String remark = "租号订单【" + orderId + "】资金转出存在风险，暂时冻结用户【" + uid + "】";
			logger.info(remark);
			freezeUser(uid, remark);
		}
		
		return true;
	}
	
	public static boolean addProductTransfer(String productId, int payType, Integer amount, String payId){
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			logger.error("addProductTransfer -- 不存在的商品, productId=>" + productId);
			return false;
		}
		int uid = product.getInt("seller_uid");
		
		Record row = new Record();
		row.set("target_id", productId);
		row.set("type", TARGET_TYPE_PRODUCT);
		row.set("pay_type", payType);
		row.set("c_time", Common.now());
		row.set("amount", amount);
		row.set("uid", product.getInt("seller_uid"));
		if(!SmartDb.save("zhifu_transfer", row)){
			logger.error("记录订单支出金额失败, productId=>" + productId + ", amount=>" + amount + ", sql=>" + SmartDb.lastQuery(), SmartDb.getException());
			return false;
		}
		
		//计算单笔商品的超额值
		row = SmartDb.findFirst("select sum(amount) as _sum from `guarantee_amount_order` where `pay_id`=?", payId);
		int guaranteeAmount = row.getBigDecimal("_sum").intValue();
		row = SmartDb.findFirst("select sum(`amount`) as _sum from `zhifu_transfer` where `target_id`=? and `type`=?", productId, TARGET_TYPE_PRODUCT);
		int outgo = row.getBigDecimal("_sum").intValue();
		if(outgo > guaranteeAmount){
			String remark = "租号商品【" + productId + "】保证金转出存在风险，暂时冻结用户【" + uid + "】";
			logger.info(remark);
			freezeUser(uid, remark);
		}
		
		return true;
	}

	/**
	 * 冻结用户的资金功能
	 * @param uid
	 */
	private static void freezeUser(int uid, String remark){
		if(!PropKit.getBoolean("pay.freeze_user_on_exception", false)){
			logger.info("开关pay.freeze_user_on_exception=false，暂不执行用户资金冻结操作！");
			return;
		}
		
		int n = PropKit.getInt("pay.freeze_user_days", 15);
		String expDate = Common.show_time(System.currentTimeMillis() + n*3600*24L);
		
		boolean insert = true;
		Record row = SmartDb.findFirst("select * from `member_blacklist_new` where `uid`=? and `exp_time`>?", uid, expDate);
		if(row == null){
			row = new Record();
			row.set("uid", uid);
			row.set("comment", remark);
			row.set("create_time", Common.now());
			row.set("sell_authority", -1);
			row.set("login_authority", -1);
		}else{
			row.keep("uid");
			String comment = row.getStr("comment") + "；" + remark;
			row.set("comment", comment);
		}
		row.set("buy_authority", 0);
		row.set("cash_authority", 0);
		row.set("modify_time", Common.now());
		row.set("limit_time", n);
		row.set("exp_time", expDate);
		
		if(insert){
			if(!SmartDb.get("jiaoyi").save("member_blacklist_new", row)){
				logger.error("冻结用户失败了，uid=>" + uid + "，remark=>" + remark + "! sql => " + SmartDb.lastQuery(), SmartDb.getException());
			}
		}else{
			if(!SmartDb.get("jiaoyi").update("member_blacklist_new", "uid", row)){
				logger.error("冻结用户失败了，uid=>" + uid + "，remark=>" + remark + "! sql => " + SmartDb.lastQuery(), SmartDb.getException());
			}
		}
	}
}
