package cn.jugame.rent.pay;

public class PaymentFactory {
	private static SafePayment payment = new SafePayment();
	
	public static IPayment get(){
		return payment;
	}
	
	static SafePayment raw(){
		return payment;
	}
}
