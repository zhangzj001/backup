package cn.jugame.rent.pay;

public class RentPaymentException extends RuntimeException{
	private static final long serialVersionUID = 5308686140628483011L;
	
	public RentPaymentException(String msg){
		super(msg);
	}
}
