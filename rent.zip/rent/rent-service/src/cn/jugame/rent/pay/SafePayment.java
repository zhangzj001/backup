package cn.jugame.rent.pay;

import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.slf4j.Logger;

/**
 * 加了分布式锁的支付模块
 * @author ASUS
 *
 */
class SafePayment extends Payment{
	private Logger logger = Loggers.rentLog();
	
	@Override
	public String payOrder(String payId, String ip) {
		Record relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
		if(relet == null)
			return null;
		
		DistLocker locker = new DistLocker("Payment_" + relet.getStr("order_id"));
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.payOrder加锁失败，payId=>" + payId);
				return null;
			}
			return super.payOrder(payId, ip);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public void onOrderPaySucc(String payId) {
		Record relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
		if(relet == null)
			return;
		
		DistLocker locker = new DistLocker("Payment_" + relet.getStr("order_id"));
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.onOrderPaySucc加锁失败，payId=>" + payId);
				return;
			}
			super.onOrderPaySucc(payId);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public boolean orderSuccForRental(String orderId) {
		DistLocker locker = new DistLocker("Payment_" + orderId);
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.orderSuccForRental加锁失败，orderId=>" + orderId);
				return false;
			}
			return super.orderSuccForRental(orderId);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public boolean orderSuccForGuarantee(String orderId) {
		DistLocker locker = new DistLocker("Payment_" + orderId);
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.orderSuccForGuarantee加锁失败，orderId=>" + orderId);
				return false;
			}
			return super.orderSuccForGuarantee(orderId);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public boolean orderFailForBoth(String orderId) {
		DistLocker locker = new DistLocker("Payment_" + orderId);
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.onOrderFail加锁失败，orderId=>" + orderId);
				return false;
			}
			return super.orderFailForBoth(orderId);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public String payGuarantee(Record product, String payId, Integer amount, String ip) {
		DistLocker locker = new DistLocker("GuaranteePayment_" + product.getStr("product_id"));
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.payGuarantee加锁失败，payId=>" + payId + ", productId=>" + product.getStr("product_id"));
				return null;
			}
			return super.payGuarantee(product, payId, amount, ip);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public void onGuaranteePaySucc(Record product, String payId, Integer amount) {
		DistLocker locker = new DistLocker("GuaranteePayment_" + product.getStr("product_id"));
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.onGuaranteePaySucc加锁失败，payId=>" + payId + ", productId=>" + product.getStr("product_id"));
				return;
			}
			super.onGuaranteePaySucc(product, payId, amount);
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public boolean refundGuarantee(Record product, String payId, Integer amount) {
		DistLocker locker = new DistLocker("GuaranteePayment_" + product.getStr("product_id"));
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("SafePayment.refundGuarantee加锁失败，payId=>" + payId + ", productId=>" + product.getStr("product_id"));
				return false;
			}
			return super.refundGuarantee(product, payId, amount);
		}finally{
			if(succ) locker.unlock();
		}
	}
}
