package cn.jugame.rent.pay;

import cn.jugame.pay.http.api.PayApiWrapper;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import cn.jugame.rent.utils.Loggers;
import com.google.common.collect.Lists;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

class Payment implements IPayment{
	
	private Logger logger = Loggers.rentLog();
	
	//支付服务接口
	private PayApiWrapper payApi = new PayApiWrapper("setting.properties");
	
	private int officialUid = PropKit.getInt("order.official_uid");
	
	private Record getOrderRelet(String payId){
		Record record = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
		return record;
	}
	
	private Record getOrder(String orderId){
		Record record = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		return record;
	}
	
	private Record getFirstRelet(String orderId){
		Record record = SmartDb.findFirst("select * from `order_relet` where `order_id`=? and `type`=? limit 1", orderId, Order.ORDER_RELET_FIRST);
		return record;
	}
	
	private void ensureConfigs(String... keys){
		for(String key : keys){
			if(!PropKit.containsKey(key)){
				throw new RentPaymentException("缺失支付配置项: " + key);
			}
		}
	}
	
	private int toFen(Double yuan){
		return (int)(yuan*100);
	}

	@Override
	public String payOrder(String payId, String ip) {
		//先检查配置
		ensureConfigs("order.pay_timeout", "order.pay_strategy", "order.cb_frontend_url", "order.cb_backend_url");
		
		//支付过期时间
		String expiredTime = Common.show_time(System.currentTimeMillis() + PropKit.getLong("order.pay_timeout")*1000);
		
		Record relet = getOrderRelet(payId);
		if(relet == null){
			logger.error("Payemnt: 支付单【" + payId + "】找不到！");
			return null;
		}
		
		Record order = getOrder(relet.getStr("order_id"));
		if(order == null){
			logger.error("Payemnt: 支付单【" + payId + "】对应的订单找不到！");
			return null;
		}
		
		int payAmount = relet.getInt("order_pay_amount");
		//如果有减免金额（使用了优惠券）
		payAmount -= relet.getInt("amount_off");
		//如果小于0了，就设置为0元
		if(payAmount < 0)
			payAmount = 0;
		
		double amount = Common.round(payAmount/100.0, 2);
		//再次格式化一次
		if(amount < 0){
			amount = 0;
		}
		
		String parentOrderId = null;
		//如果是首租
		if(relet.getInt("type") == Order.ORDER_RELET_FIRST){
			parentOrderId = relet.getStr("pay_id");
			
			//首租的时候需要带上押金
			amount += Common.round(order.getInt("order_guarantee_deposit")/100.0, 2);
		}
		//如果是续租，拿首租的那笔租赁单ID作为父ID
		else{
			Record firstRelet = getFirstRelet(order.getStr("order_id"));
			parentOrderId = firstRelet.getStr("pay_id");
		}
		
		//务必确保保留2位小数
		amount = Common.round(amount, 2);
		if(amount < 0.01){
			amount = 0;
		}
		
		String remark = "[" + order.getStr("order_id") + "]-租号玩";
		logger.info("[" + order.getStr("order_id") + "]-支付金额：" + amount);
		
		String gamePartitionName = order.getStr("game_partition_name");
		
		//推广UID
		int tgUid = 0;
		//如果是加价卖非自有商品，那么分成者是shop_uid
		if(order.getInt("shop_markup_amount") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
			tgUid = order.getInt("shop_uid");
		}
		//
		else if(order.getInt("cooperation_uid") > 0){
			tgUid = order.getInt("cooperation_uid");
		}
		logger.info("订单【" + order.getStr("order_id") + "】的推广者UID=>" + tgUid);
		
		//发起支付，专款给中转帐户
		String productName = order.getStr("product_name");
		String prodShowName = productName;
		if(productName.length() > 15){
			prodShowName = productName.substring(0, 15) + "...";
		}
		String html = payApi.rentPay(
				relet.getStr("pay_id"), 
				Common.now(),
				expiredTime,
				String.valueOf(amount), 
				prodShowName, 
				String.valueOf(Common.round(order.getInt("product_price")/100.0, 2)),
				String.valueOf(relet.getInt("buy_count")),
				gamePartitionName, 
				String.valueOf(order.getInt("buyuser_uid")),
				String.valueOf(order.getInt("selluser_uid")),
				String.valueOf(tgUid),  //推广UID
				remark,
				parentOrderId, 
				PropKit.get("order.pay_strategy"), 
				PropKit.get("order.cb_frontend_url"), 
				PropKit.get("order.cb_backend_url")
		);
		return html;
	}

	@Override
	public JSONObject payOrder(String payId, ZhifuWay way, String payPasswd, String ip, String clientType) {
		//先检查配置
		ensureConfigs("order.pay_timeout", "order.pay_strategy", "order.cb_frontend_url", "order.cb_backend_url");
		
		//支付过期时间
		String expiredTime = Common.show_time(System.currentTimeMillis() + PropKit.getLong("order.pay_timeout")*1000);
		
		Record relet = getOrderRelet(payId);
		if(relet == null)
			return null;
		
		Record order = getOrder(relet.getStr("order_id"));
		if(order == null)
			return null;
		
		int payAmount = relet.getInt("order_pay_amount");
		//如果有减免金额（使用了优惠券）
		payAmount -= relet.getInt("amount_off");
		//如果小于0了，就设置为0元
		if(payAmount < 0)
			payAmount = 0;
		
		double amount = Common.round(payAmount/100.0, 2);
		//再次格式化一次
		if(amount < 0){
			amount = 0;
		}
		
		String parentOrderId = null;
		//如果是首租
		if(relet.getInt("type") == Order.ORDER_RELET_FIRST){
			parentOrderId = relet.getStr("pay_id");
			
			//首租的时候需要带上押金
			amount += Common.round(order.getInt("order_guarantee_deposit")/100.0, 2);
		}
		//如果是续租，拿首租的那笔租赁单ID作为父ID
		else{
			Record firstRelet = getFirstRelet(order.getStr("order_id"));
			parentOrderId = firstRelet.getStr("pay_id");
		}
		
		//务必确保保留2位小数
		amount = Common.round(amount, 2);
		if(amount < 0.01){
			amount = 0;
		}
		
		String remark = "[" + order.getStr("order_id") + "]-租号玩";
		logger.info("[" + order.getStr("order_id") + "]-支付金额：" + amount);
		
		String gamePartitionName = order.getStr("game_partition_name");
		
		int tgUid = 0;
		//如果是加价卖非自有商品，那么分成者是shop_uid
		if(order.getInt("shop_markup_amount") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
			tgUid = order.getInt("shop_uid");
		}
		//
		else if(order.getInt("cooperation_uid") > 0){
			tgUid = order.getInt("cooperation_uid");
		}
		logger.info("订单【" + order.getStr("order_id") + "】的推广者UID=>" + tgUid);
		
		//JSON格式字符串。
		//成功返回：{"code": 0, "msg": "支付请求已提交","data":{"payStatus":10,"payPlatformId":1,"payWayId":3,"payInfo":"html"}}；
		//失败返回：{"code": 除0外的数值, "msg": "响应描述","payStatus":相对应的数值,} 
		//说明：余额支付成功及租号0元单业务支付成功时，payStatus为20，其他成功的，payStatus为10。
		//payInfo字段的值是用来调起支付的，支付宝支付时，值为自动提交的form表单，可在页面调起支付；微信扫码支付时，值为图片形式的二维码地址的字符串
//		String productName = order.getStr("product_name");
//		String prodShowName = productName;
//		if(productName.length() > 15){
//			prodShowName = productName.substring(0, 15) + "...";
//		}
		String prodShowName = "8868租号-【" + order.getStr("game_name") + "】商品";
		String str = payApi.mixedPayForRent(
				relet.getStr("pay_id"), 
				String.valueOf(amount), 
				prodShowName, 
				gamePartitionName, 
				String.valueOf(relet.getInt("buy_count")),
				String.valueOf(Common.round(order.getInt("product_price")/100.0, 2)),
				String.valueOf(order.getInt("buyuser_uid")), 
				String.valueOf(order.getInt("selluser_uid")), 
				String.valueOf(tgUid),
				PropKit.get("order.pay_strategy"), 
				PropKit.get("order.cb_frontend_url"), 
				PropKit.get("order.cb_backend_url"),
				Common.now(),
				expiredTime, 
				remark,
				way.getZhifuPlatform(),
				payPasswd, 
				way.getPayWay(), 
				parentOrderId, 
				ip,
				clientType);
		
		try{
			JSONObject json = JSONObject.fromObject(str);
			logger.info("支付单【" + payId + "】从支付服务获取返回：" + str);
			
			int code = json.getInt("code");
			if(code != 0){
				logger.error("支付单【" + payId + "】支付时发生了异常，json => " + json);
				return Common.buildResp(1, json.optString("msg"));
			}
			
			//支付成功了，不同的支付方式返回的内容会有不同
			//纯余额支付，直接告知成功即可
			if(ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey()) || StringUtils.isBlank(way.getPayKey())){
				return Common.buildResp(0, "ok", new KeyValue<>("pay_way", "balance"));
			}
			//支付宝 or 支付宝混合支付，返回用户跳转的html
			if(way.getPayKey().contains(ZhifuWay.ALIPAY_KEY)){
				return Common.buildResp(0, "ok", 
						new KeyValue<>("alipay_url", json.getJSONObject("data").getString("alipayUrl")),
						new KeyValue<>("pay_way", "alipay"));
			}
			//微信 or 微信混合支付
			if(way.getPayKey().contains(ZhifuWay.WXPAY_KEY)){
				return Common.buildResp(0, "ok", 
						new KeyValue<>("payInfo",json.getJSONObject("data").getString("payInfo")),
						new KeyValue<>("qr_code", json.getJSONObject("data").getString("payInfo")),
						new KeyValue<>("pay_way", "wechat"),
						new KeyValue<>("pay_amount", json.getJSONObject("data").get("mhtOrderAmt")));
			}
			
			return Common.buildResp(99, "不支持的支付方式");
		}catch(Exception e){
			logger.error("支付单【" + payId + "】请求支付服务发生了错误，str=>" + str);
			return null;
		}
	}
	
	@Override
	public void onOrderPaySucc(String payId) {
	}

	
	private boolean doSettlement(String payId, Double buyuserAmount, Double selluserAmount, Double guaranteeDeposit, Double tgAmount){
		String content = payApi.orderFinishHandle(payId, 
				String.valueOf(buyuserAmount), 
				String.valueOf(selluserAmount), 
				String.valueOf(guaranteeDeposit), 
				String.valueOf(tgAmount), 
				"0");

		if(StringUtils.isBlank(content)){
			logger.error("支付单:" + payId + "执行结账失败，支付服务没有返回!");
			return false;
		}
		try{
			JSONObject json = JSONObject.fromObject(content);
			//-99 表示已经结过账了，这不是系统错误！
			if(json.getInt("code") != 0 && json.getInt("code") != -99){
				logger.error("支付单" + payId + "执行结账时支付服务返回错误，content=>" + content);
				return false;
			}else{
				logger.info("支付单" + payId + "执行结账时支付服务成功,content=>" + content);
			}
			return true;
		}catch(Exception e){
			logger.error("doSettlement -- 支付服务返回数据json解析错误，payId=>" + payId + ", content=>" + content, e);
			return false;
		}
	}
	
	private boolean doTransfer(String payId, int uid, int type, String remark){
		String content = payApi.rentOrderHandle(payId, String.valueOf(type), remark);
		if(StringUtils.isBlank(content)){
			logger.error("支付单:" + payId + "执行转账时失败，支付服务没有返回!uid=>" + uid + ", type=>" + type);
			return false;
		}
		try{
			JSONObject json = JSONObject.fromObject(content);
			if(json.getInt("code") != 0){
				logger.error("支付单" + payId + "执行转账时支付服务返回错误，uid=>" + uid + ", type=>" + type + ", content=>" + content);
				return false;
			}else{
				logger.info("支付单" + payId + "执行转账时支付服务成功, uid=>" + uid + ", type=>" + type + ", content=>" + content);
			}
			return true;
		}catch(Exception e){
			logger.error("doTransfer -- 支付服务返回数据json解析错误，uid=>" + uid + ", type=>" + type + ", payId=>" + payId + ", content=>" + content, e);
			return false;
		}
	}
	
	/**
	 * 订单结束清算！
	 * @param orderId
	 * @return
	 */
	private boolean orderSettlement(String orderId){
		Record order = getOrder(orderId);
		if(order == null){
			logger.error("orderSuccForRental -- 不存在的订单，orderId=>" + orderId);
			return false;
		}
		
		Record firstRelet = getFirstRelet(orderId);
		if(firstRelet == null){
			logger.error("transfer -- 给不存在首租单的支付单转账: " + orderId);
			return false;
		}
		
		String payId = firstRelet.getStr("pay_id");
		
		//如果有申请撤单的流程
		Record successApply = SmartDb.findFirst("select * from order_cancel_apply where order_id = ? and  `status` = ? order by c_time desc",
						order.getStr("order_id"), Order.ORDER_CANCEL_APPLY_SUCCESS);
		
		//计算实际应退还给玩家的租金
        double buyuserAmount = Order.getOrderRefundAmountToBuyuser(order, successApply);
        //计算实际应付给号主的租金
        double selluserAmount = Order.getOrderPayAmountToSelluser(order, successApply);
        //计算合租者分成金额
        double tgAmount = Order.getOrderPayAmountToCooperation(order, successApply);
        //如果是非自有商品加价，则忽略合租者分成，使用加价金额进行分成
        if(order.getInt("from_shop_id") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
        	tgAmount = Order.getOrderPayAmountToShopMarkup(order, successApply);
        }
        
        
        //订单押金
    	double guaranteeDeposit = Common.round(order.getInt("order_guarantee_deposit")/100.0, 2);
		
		return doSettlement(payId, buyuserAmount, selluserAmount, guaranteeDeposit, tgAmount);
	}
	
	@Override
	public boolean orderSuccForRental(String orderId){
		Record order = getOrder(orderId);
		if(order == null){
			logger.error("orderSuccForRental -- 不存在的订单，orderId=>" + orderId);
			return false;
		}
		
		//确保还没转过账给号主
		if(order.getInt("refund_selluser_amount") > 0){
			logger.error("orderSuccForRental -- 订单【" + orderId + "】已经成功转账给号主了，无需重复转账。");
			return false;
		}
		
		//确保进行清算一次
		if(!orderSettlement(orderId)){
			logger.error("orderSuccForRental -- 订单【" + orderId + "】进行结账清算时失败了！");
			return false;
		}
		
		//如果有申请撤单的流程
		Record successApply = SmartDb.findFirst("select * from order_cancel_apply where order_id = ? and  `status` = ? order by c_time desc",
				order.getStr("order_id"), Order.ORDER_CANCEL_APPLY_SUCCESS);
		
		//计算转账给号主的钱
        double amount = Order.getOrderPayAmountToSelluser(order, successApply);
        //计算合租者分成金额
        int tgUid = order.getInt("cooperation_uid");
        double tgAmount = Order.getOrderPayAmountToCooperation(order, successApply);
        String tgDesc = "订单【" + orderId + "】合租分成";
        //如果是非自有商品加价，则忽略合租者分成，使用加价金额进行分成
        if(order.getInt("from_shop_id") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
        	tgAmount = Order.getOrderPayAmountToShopMarkup(order, successApply);
        	tgUid = order.getInt("shop_uid");
        	tgDesc = "订单【" + tgDesc + "】商铺非自有商品加价分成";
        }
		
		//先更新本地数据库字段，不管怎么样，订单成功发起的转账只触发一次！
        {
			Record row = new Record();
			row.set("order_id", order.getStr("order_id"));
			row.set("refund_selluser_amount", (int)(amount*100));
			if(order.getInt("cooperation_uid") > 0){
				row.set("refund_cooperation_amount", (int)(tgAmount * 100));
			}
			if(!SmartDb.update("order", "order_id", row)){
				logger.error("orderSuccForRental -- 订单【" + orderId + "】更新数据时发生错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				return false;
			}
        }

		//租金转账给号主
		logger.info("订单【" + orderId + "】准备将租金【" + amount + "】转款给号主..");
		if(amount > 0.01){
			if(!smartOrderTransferSeller(order, amount)){
				logger.error("orderSuccForRental -- 订单" + orderId + "转款租金失败了！！！");
				return false;
			}
			
			//记录转账结果
			TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_SELLER_RENTAL, toFen(amount));
		}else{
			logger.info("orderSuccForRental -- 订单【" + orderId + "】因为租金<=0而无需转款给号主!");
		}
		
		//计算联合推广佣金给推广号主
		logger.info("订单【" + orderId + "】准备将推广资金【" + tgAmount + "】转款给推广者【" + tgUid + "】");
		if(tgAmount > 0.01){
			if(tgUid > 0 && !orderTransfer(order, tgUid, TRANSFER_TG, tgDesc)){
				logger.error("订单【" + orderId + "】转款推广费给【" + tgUid + "】失败了，金额【" + tgAmount + "元】！！！");
				return false;
			}
		}else{
			logger.info("orderSuccForRental -- 订单【" + orderId + "】因为佣金<=0而无需转款给推广者【" + tgUid + "】!");
		}
		
		return true;
	}
	
	@Override
	public boolean orderSuccForGuarantee(String orderId) {
		Record order = getOrder(orderId);
		if(order == null){
			logger.error("orderSuccForGuarantee -- 不存在的订单，orderId=>" + orderId);
			return false;
		}
		
		//确保这笔押金还没有转过
		if(order.getDate("refund_time") != null){
			logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】已经成功转账给玩家了，无需重复转账。");
			return false;
		}
		
		//订单流程还未结束，不允许转押金！
		if(!Order.scheduleEnd(order)){
			logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】流程还未结束，无法转账押金！");
			return false;
		}

		//确保进行清算一次
		if(!orderSettlement(orderId)){
			logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】进行结账清算时失败了！");
			return false;
		}
		
		//看看是否仲裁过，如果有仲裁结果则允许立刻转账，如果没有仲裁结果则需要等超过仲裁期
		int orderIsTerminate = order.getInt("order_isterminate");
		
		//如果号主仲裁成功了，押金要转给号主，否则押金转给玩家（前提是用户押金）
        double amount = Common.round(order.getInt("order_guarantee_deposit")/100.0, 2);
        int guaranteeDepositType = order.getInt("guarantee_deposit_type");
		//转给号主
		if(orderIsTerminate == Order.ORDER_TERMINATED){
			Record row = new Record();
			row.set("order_id", order.getStr("order_id"));
			row.set("refund_time", Common.now());
			if(!SmartDb.update("order", "order_id", row)){
				logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】更新数据时发生错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				return false;
			}
			
			//必须是用户押金类型才转账
			if(guaranteeDepositType == Product.GUARANTEE_DEPOSIT_TYPE_USER && amount >= 0.01){
				if(!orderTransfer(order, order.getInt("selluser_uid"), TRANSFER_DEPOSIT_SELLUSER, "订单【" + orderId + "】扣除玩家押金给号主")){
					logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】扣除玩家押金【" + amount + "】给号主时发生了转账错误。");
					return false;
				}
				
				//记录转账
				TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_SELLER_GUARANTEE, toFen(amount));
			}
			//如果是平台押金，则转给平台
			if(guaranteeDepositType == Product.GUARANTEE_DEPOSIT_TYPE_PLATFORM && amount >= 0.01){
				if(!orderTransfer(order, officialUid, TRANSFER_DEPOSIT_PLATFORM, "订单【" + orderId + "】扣除玩家押金给平台")){
					logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】扣除玩家押金【" + amount + "】给平台时发生了转账错误。");
					return false;
				}
				
				//XXX 给平台不需要记录流水
				
			}
		}
		//转给玩家
		else{
			Record row = new Record();
			row.set("order_id", order.getStr("order_id"));
			row.set("refund_time", Common.now());
			row.set("order_isrefund_guarantee", Order.ORDER_REFUNDED);
			row.set("refund_buyuser_amount", toFen(amount));
			if(!SmartDb.update("order", "order_id", row)){
				logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】更新数据时发生错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				return false;
			}
			
			if(amount >= 0.01){
				if(!orderTransfer(order, order.getInt("buyuser_uid"), TRANSFER_DEPOSIT_BUYUSER, "订单【" + orderId + "】退款押金给玩家。")){
					logger.error("orderSuccForGuarantee -- 订单【" + orderId + "】退款押金【" + amount + "】给玩家时失败了！");
					return false;
				}
				
				//记录转账
				TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_BUYER_GUARANTEE, toFen(amount));
			}
		}
		
		return true;
	}
	
	@Override
	public boolean orderFailForBoth(String orderId) {
		ensureConfigs("order.keep_guarantee_deposit_time");
		
		Record order = getOrder(orderId);
		if(order == null){
			logger.error("onOrderFail -- 不存在的订单， orderId=>" + orderId);
			return false;
		}
		
		//确保还没转过账
		if(order.getDate("refund_time") != null){
			logger.error("onOrderFail -- 订单【" + orderId + "】已经成功转账给双方了，无需重复转账。");
			return false;
		}
		
		//订单流程还未结束，不允许转账！
		if(!Order.scheduleEnd(order)){
			logger.error("onOrderFail -- 订单【" + orderId + "】流程还未结束，无法转账押金！");
			return false;
		}

		//确保进行清算一次
		if(!orderSettlement(orderId)){
			logger.error("onOrderFail -- 订单【" + orderId + "】进行结账清算时失败了！");
			return false;
		}

		//如果有申请撤单的流程
		Record successApply = SmartDb.findFirst("select * from order_cancel_apply where order_id = ? and  `status` = ? order by c_time desc",
				order.getStr("order_id"), Order.ORDER_CANCEL_APPLY_SUCCESS);
		
		//计算实际应退还给玩家的租金
        double buyuserAmount = Order.getOrderRefundAmountToBuyuser(order, successApply);
        //计算实际应付给号主的租金
        double selluserAmount = Order.getOrderPayAmountToSelluser(order, successApply);
        //计算合租者分成金额
        int tgUid = order.getInt("cooperation_uid");
        double tgAmount = Order.getOrderPayAmountToCooperation(order, successApply);
        String tgDesc = "订单【" + orderId + "】合租分成";
        //如果是非自有商品加价，则忽略合租者分成，使用加价金额进行分成
        if(order.getInt("from_shop_id") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
        	tgAmount = Order.getOrderPayAmountToShopMarkup(order, successApply);
        	tgUid = order.getInt("shop_uid");
        	tgDesc = "订单【" + tgDesc + "】商铺非自有商品加价分成";
        }
        //订单押金
    	double guaranteeDeposit = Common.round(order.getInt("order_guarantee_deposit")/100.0, 2);
    	//订单押金类型
    	int guaranteeDepositType = order.getInt("guarantee_deposit_type");
    	//仲裁情况
    	int orderIsTerminate = order.getInt("order_isterminate");
    	
    	//来到这里说明允许转账操作了！
        //先更新本地数据库，不管转账情况怎么样，这里确保转账行为只发生一次！
        {
        	//给买卖双方押金的退款
        	//如果要给买家退押金
        	int refundBuyuserAmount = (int)(buyuserAmount*100);
        	if (orderIsTerminate != Order.ORDER_TERMINATED && guaranteeDeposit >= 0.01){
        		refundBuyuserAmount += (int)(guaranteeDeposit*100);
        	}
        	
        	//如果要给卖家押金
        	int refundSelluserAmount = (int)(selluserAmount*100);
        	if(orderIsTerminate == Order.ORDER_TERMINATED 
		        			&& guaranteeDepositType == Product.GUARANTEE_DEPOSIT_TYPE_USER
		        			&& guaranteeDeposit >= 0.01){
        		refundSelluserAmount += (int)(guaranteeDeposit*100);
        	}

        	Record row = new Record();
        	row.set("order_id", order.getStr("order_id"));
			row.set("refund_time", Common.now());
			row.set("refund_selluser_amount",refundSelluserAmount );
			row.set("refund_buyuser_amount",refundBuyuserAmount );
			row.set("order_isrefund_rental", Order.ORDER_REFUNDED);
			row.set("order_isrefund_guarantee", Order.ORDER_REFUNDED);
			row.set("refund_sponsored_amount", (int)(tgAmount*100));  //FIXME 很神奇，为什么不是 refund_cooperation_amount 字段！？
			if(!SmartDb.update("order", "order_id", row)){
				logger.error("onOrderFail -- 订单【" + orderId + "】更新数据时发生错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				return false;
			}
        }
        
        //给玩家退款
        {
	    	logger.info("订单【" + orderId + "】取消交易后准备为玩家执行退款。");
	    	//如果没有仲裁成功，带上押金一块退款
	    	double amount = buyuserAmount;
	    	//需要退还押金，同时押金也足够转账的情况下
			if (orderIsTerminate != Order.ORDER_TERMINATED && guaranteeDeposit >= 0.01) {
				logger.info("订单【" + orderId + "】退款需要连带押金一块退还，押金=" + guaranteeDeposit);
				amount += guaranteeDeposit;
			}
			amount = Common.round(amount, 2);
			
			if(amount >= 0.01){
				if(!smartOrderRefund(order, buyuserAmount, "订单【" + orderId + "】进行资金退款，租金退款：" + buyuserAmount + "元")){
					logger.error("撤销订单【" + orderId + "】对玩家【" + order.getInt("buyuser_uid") + "】进行租金退款【" + buyuserAmount + "】时支付服务退款失败了！");
					return false;
				}else{
					logger.info("订单【" + orderId + "】退款租金给玩家【" + order.getInt("buyuser_uid") + "】，金额为" + buyuserAmount + "，退款成功！");
				}
				
				//记录转账
				TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_BUYER_RETAL, toFen(buyuserAmount));
				if(orderIsTerminate != Order.ORDER_TERMINATED && guaranteeDeposit >= 0.01){
					TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_BUYER_GUARANTEE, toFen(guaranteeDeposit));
				}

				//退款押金
				if(orderIsTerminate != Order.ORDER_TERMINATED && guaranteeDeposit >= 0.01){
					guaranteeDeposit = Common.round(guaranteeDeposit, 2);
					if(!orderTransfer(order, order.getInt("buyuser_uid"), TRANSFER_DEPOSIT_BUYUSER, "订单【" + orderId + "】进行资金退款，租金退款：" + guaranteeDeposit + "元")){
						logger.error("撤销订单【" + orderId + "】对玩家【" + order.getInt("buyuser_uid") + "】进行押金退款【" + guaranteeDeposit + "】时支付服务退款失败了！");
					}else{
						logger.info("订单【" + orderId + "】退款押金给玩家【" + order.getInt("buyuser_uid") + "】，金额为" + guaranteeDeposit + "，退款成功！");
					}
				}
			}else{
			    logger.info("订单【" + orderId + "】退款给玩家【" + order.getInt("buyuser_uid") + "】，金额为" + amount + "，值太小了不予转账。");
	        }
        }
        
        //给号主转账
        {
        	logger.info("订单【" + orderId + "】取消交易后准备为号主执行转账。");
        	double amount = selluserAmount;
        	//如果仲裁成功了，同时又是用户押金，连带押金一块转给号主
        	boolean flag = (orderIsTerminate == Order.ORDER_TERMINATED 
		        			&& guaranteeDepositType == Product.GUARANTEE_DEPOSIT_TYPE_USER
		        			&& guaranteeDeposit >= 0.01);
        	amount += guaranteeDeposit;
			amount = Common.round(amount, 2);
			
        	if(amount >= 0.01){
        		if(!smartOrderTransferSeller(order, selluserAmount)){
        			logger.error("撤销订单【" + orderId + "】对号主【" + order.getInt("selluser_uid") + "】进行租金转账【" + selluserAmount + "】时支付服务失败了！");
					return false;
        		}else{
        			logger.info("订单【" + orderId + "】转账租金给号主【" + order.getInt("selluser_uid") + "】，金额为" + selluserAmount + "，转账成功！");
        		}

    			//记录转账
    			TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_SELLER_RENTAL, toFen(selluserAmount));
    			if(flag && guaranteeDeposit >= 0.01){
    				TransferRecord.addOrderTransfer(orderId, TransferRecord.PAY_TYPE_SELLER_GUARANTEE, toFen(guaranteeDeposit));
    			}
    			
    			//扣除押金
				if(orderIsTerminate == Order.ORDER_TERMINATED && guaranteeDeposit >= 0.01){
					guaranteeDeposit = Common.round(guaranteeDeposit, 2);
					int type = TRANSFER_DEPOSIT_SELLUSER;
					int targetUid = order.getInt("selluser_uid");
					if(guaranteeDepositType == Product.GUARANTEE_DEPOSIT_TYPE_PLATFORM){
						type = TRANSFER_DEPOSIT_PLATFORM;
						targetUid = officialUid;
					}
					
					if(!orderTransfer(order, targetUid, type, "订单【" + orderId + "】进行资金退款，押金转账：" + guaranteeDeposit + "元")){
						logger.error("撤销订单【" + orderId + "】对号主/平台【" + targetUid + "】进行押金转账【" + guaranteeDeposit + "】时支付服务退款失败了！");
					}else{
						logger.info("订单【" + orderId + "】转账押金给号主/平台【" + targetUid + "】，金额为" + guaranteeDeposit + "，退款成功！");
					}
				}
        	}else{
        		logger.info("订单【" + orderId + "】转账给号主【" + order.getInt("selluser_uid") + "】，金额为" + amount + "，值太小了不予转账。");
        	}
        }
        
        //给联合推广号主转佣金
        {
        	logger.info("订单【" + orderId + "】取消交易后准备为推广用户【" + tgUid + "】转账推广资金。");
        	if(tgAmount >= 0.01){
        		if(tgUid > 0 && !orderTransfer(order, tgUid, TRANSFER_TG, tgDesc)){
    				logger.error("订单【" + orderId + "】转款推广资金给【" + tgUid + "】失败了，金额【" + tgAmount + "元】！！！");
    				return false;
    			}

    			//FIXME 佣金怎么记录转账结果呢？！
        		
        		
        	}else{
        		logger.info("订单【" + orderId + "】转账推广资金给推广者【" + tgUid + "】，金额为" + tgAmount + "，值太小了不予转账。");
        	}
        }
        
        return true;
	}

	@Override
	public String payGuarantee(Record product, String payId, Integer amount, String ip) {
		ensureConfigs("product.guarantee_amount.cb_frontend_url", "product.guarantee_amount.cb_backend_url");
		if(product == null)
			return null;
		
		String remark = "【" + product.getStr("product_id") + "】支付商品保证金";
		return easyPay(
				product.getInt("seller_uid"), 
				payId, 
				remark, 
				Common.round(amount/100.0, 2), 
				remark, 
				PropKit.get("product.guarantee_amount.cb_frontend_url"),
				PropKit.get("product.guarantee_amount.cb_backend_url"),
				ip);
	}

	@Override
	public JSONObject payGuarantee(Record product, String payId, Integer amount, ZhifuWay way, String payPasswd, String ip,String clientType) {
		ensureConfigs("order.pay_strategy", "product.guarantee_amount.cb_frontend_url", "product.guarantee_amount.cb_backend_url");
		if(product == null)
			return null;
		
		//clientType = "pc".equalsIgnoreCase(clientType) ? "pc" : "app";
		
		String expiredTime = Common.show_time(System.currentTimeMillis() + PropKit.getLong("order.pay_timeout")*1000);
		String remark = "【" + product.getStr("product_id") + "】支付商品保证金";
		//JSON格式字符串。
		//成功返回：{"code": 0, "msg": "支付请求已提交","data":{"payStatus":10,"payPlatformId":1,"payWayId":3,"payInfo":"html"}}；
		//失败返回：{"code": 除0外的数值, "msg": "响应描述","payStatus":相对应的数值,} 
		//说明：余额支付成功及租号0元单业务支付成功时，payStatus为20，其他成功的，payStatus为10。
		//payInfo字段的值是用来调起支付的，支付宝支付时，值为自动提交的form表单，可在页面调起支付；微信扫码支付时，值为图片形式的二维码地址的字符串
		String prodShowName = "8868租号-【" + product.getStr("game_name") + "】商品保证金";
		String str = payApi.mixedPayForRent(
				payId, 
				String.valueOf(Common.round(amount/100.0, 2)), 
//				product.getStr("name"), 
				prodShowName,
				product.getStr("game_partition_name"), 
				String.valueOf(1),
				String.valueOf(Common.round(amount/100.0, 2)),
				String.valueOf(product.getInt("seller_uid")), 
				String.valueOf(officialUid), 
				"0", //没有推广UID
				PropKit.get("order.pay_strategy"), 
				PropKit.get("product.guarantee_amount.cb_frontend_url"), 
				PropKit.get("product.guarantee_amount.cb_backend_url"),
				Common.now(),
				expiredTime, 
				remark,
				way.getZhifuPlatform(),
				payPasswd, 
				way.getPayWay(), 
				payId, 
				ip,
				clientType);
		
		try{
			JSONObject json = JSONObject.fromObject(str);
			
			int code = json.getInt("code");
			if(code != 0){
				logger.error("支付单【" + payId + "】支付时发生了异常，json => " + json);
				return Common.buildResp(1, json.optString("msg"));
			}
			
			//支付成功了，不同的支付方式返回的内容会有不同
			//纯余额支付，直接告知成功即可
			if(ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey())){
				return Common.buildResp(0, "ok", new KeyValue<>("pay_way", "balance"));
			}
			//支付宝 or 支付宝混合支付，返回用户跳转的html
			if(way.getPayKey().contains(ZhifuWay.ALIPAY_KEY)){
				return Common.buildResp(0, "ok", 
						new KeyValue<>("alipay_url", json.getJSONObject("data").getString("alipayUrl")),
						new KeyValue<>("pay_way", "alipay"));
			}
			//微信 or 微信混合支付
			if(way.getPayKey().contains(ZhifuWay.WXPAY_KEY)){
				return Common.buildResp(0, "ok", 
						new KeyValue<>("payInfo",json.getJSONObject("data").getString("payInfo")),
						new KeyValue<>("qr_code", json.getJSONObject("data").getString("payInfo")),
						new KeyValue<>("pay_way", "wechat"),
						new KeyValue<>("pay_amount", json.getJSONObject("data").get("mhtOrderAmt")));
			}
			
			return Common.buildResp(99, "不支持的支付方式");
		}catch(Exception e){
			logger.error("支付单【" + payId + "】请求支付服务发生了错误，str=>" + str);
			return null;
		}
	}
	
	@Override
	public void onGuaranteePaySucc(Record product, String payId, Integer amount) {
	}
	
	@Override
	public boolean refundGuarantee(Record product, String payId, Integer amount) {
		if(product == null)
			return false;
		
		String productId = product.getStr("product_id");
		int uid = product.getInt("seller_uid");
		if(amount < 1){
			logger.info("tranfer -- 保证金订单【" + payId + "】转账给uid【" + uid + "】的金额【" + amount + "】太小(小于1分钱)，忽略这次转账");
			return true;
		}
		//转为元，保留2位小数
		double rAmount = Common.round(amount/100.0, 2);

		//退还保证金时本地数据无法保证只转账一次，但是支付服务的orderRefund接口可以保证只做一次
		logger.info("商品【" + productId + "】-支付单【" + payId + "】进行资金原路退款，将" + rAmount + "元给[" + uid + "]");
		String remark = "商品【" + productId + "】-支付单【" + payId + "】当次支付原路退款";
		if(!refund(uid, payId, payId, null, remark)){
			logger.error("商品【" + productId + "】-支付单【" + payId + "】进行资源原路退回时发生了错误，amount=>" + rAmount + ", uid=>" + uid);
			return false;
		}
		
		TransferRecord.addProductTransfer(productId, TransferRecord.PAY_TYPE_PRODUCT_GUARANTEE, amount, payId);
		
		return true;
	}
	
	@Override
	public boolean deductGuarantee(Record product, String payId, Integer amount){
		if(product == null)
			return false;
		
		String productId = product.getStr("product_id");
		int uid = product.getInt("seller_uid");
		if(amount < 1){
			logger.info("tranfer -- 保证金订单【" + payId + "】转账给uid【" + uid + "】的金额【" + amount + "】太小(小于1分钱)，忽略这次转账");
			return true;
		}
		//转为元，保留2位小数
		double rAmount = Common.round(amount/100.0, 2);
		
		//先结账
		if(!doSettlement(payId, 0d, rAmount, 0d, 0d)){
			logger.error("deductGuarantee -- 扣除保证金时进行清算发生了错误，productId=>" + productId + ", payId=>" + payId);
			return false;
		}
		
		//转账
		return doTransfer(payId, officialUid, TRANSFER_SELLUSER, "商品【" + productId + "】扣除因租赁违规保证金");
	}

	/**
	 * 转账给号主，如果卖家是金牌号主将需要执行延迟转账，否则立即转入余额。
	 * @param order 订单
	 * @param amount 转账给号主的金额
	 * @return 转账成功或者失败
	 */
	private boolean smartOrderTransferSeller(Record order, Double amount){
		ensureConfigs("order.delay_transfer_time");
		if(order == null){
			return false;
		}
		
		//不用转账！
		if(amount < 0.01)
			return true;
		
		int sellLevel = order.getInt("sell_level");
		int selluserUid = order.getInt("selluser_uid");
		String orderId = order.getStr("order_id");
		
		//金牌签约号主要延迟
		if(sellLevel == User.SELL_LEVEL_GOLD){
			Date transferTime = new Date(System.currentTimeMillis() + PropKit.getInt("order.delay_transfer_time")*60L*1000);
			if(!delayTransfer(orderId, selluserUid, amount, transferTime)){
				logger.error("订单【" + orderId + "】设置延迟转账给【" + selluserUid + "】失败了，金额：【" + amount + "元】！！！");
				return false;
			}
		}
		//非金牌号主，直接转账
		else{
			if(!orderTransfer(order, order.getInt("selluser_uid"), TRANSFER_SELLUSER, "订单【" + orderId + "】收入金额" + amount)){
				logger.error("订单【" + orderId + "】转款给【" + selluserUid + "】失败了，金额【" + amount + "元】！！！");
				return false;
			}
		}
		return true;
	}
	
	/** 
	 * 指定时间延迟转账，由定时脚本 cn.jugame.rent.task.OrderDelayTransferTask 执行。
	 * @param orderId
	 * @param uid
	 * @param amount
	 * @param transferTime
	 * @return
	 */
	private boolean delayTransfer(String orderId, int uid, double amount, Date transferTime){
		if(amount < 0.01)
			return true;
		
		Record row = new Record();
		row.set("order_id", orderId);
		row.set("uid", uid);
		row.set("amount", (int)(amount * 100));
		row.set("c_time", Common.now());
		row.set("transfer_time", Common.show_time(transferTime));
		row.set("status", Order.DELAY_TRANSFER_NOT_FINISH);
		
		if(!SmartDb.save("order_delay_transfer", row)){
			logger.error("订单【" + orderId + "】延迟转账发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
			return false;
		}
		return true;
	}

    /**
     * 转账。将金额amount（元）转账给用户uid
     * @param order
     * @param uid
     * @param type
     * @param remark
     * @return
     */
	boolean orderTransfer(Record order, int uid, int type, String remark){
		if(order == null){
			logger.error("transfer -- order is null!!!");
			return false;
		}
		
		//要求只能转账给买卖双方
		if(order.getInt("buyuser_uid") != uid 
				&& order.getInt("selluser_uid") != uid 
				&& order.getInt("cooperation_uid") != uid
				&& order.getInt("shop_uid") != uid
				&& officialUid != uid){
			logger.error("transfer -- 转账目标UID不是买卖双方和推广方的任意一方，不允许这样的转账发生！orderId=>" + order.getStr("order_id") + ", uid=>" + uid);
			return false;
		}
		
		String orderId = order.getStr("order_id");
		
		Record firstRelet = getFirstRelet(orderId);
		if(firstRelet == null){
			logger.error("transfer -- 给不存在首租单的支付单转账: " + orderId);
			return false;
		}
		
		String payId = firstRelet.getStr("pay_id");
		if(StringUtils.isBlank(payId)){
			logger.error("transfer -- 订单[" + orderId + "]不存在首租单！！发生了诡异的一幕！");
			return false;
		}

		return doTransfer(payId, uid, type, remark);
	}

    /**
     * 根据金额判断退款路径
     * @param order
     * @param amount
     * @param remark
     * @return
     */
	private boolean smartOrderRefund(Record order, Double amount, String remark){
		if(amount < 0.01)
	         return true;
		return orderTransfer(order, order.getInt("buyuser_uid"), TRANSFER_BUYUSER, remark);
	}
	
	@Override
	public String easyPay(int uid, String payId, String productName, Double amount, String remark, String cbFrontend, String cbBackend, String ip){
		ensureConfigs("order.pay_timeout", "order.pay_strategy");
		
		String expiredTime = Common.show_time(System.currentTimeMillis() + PropKit.getLong("order.pay_timeout")*1000);
		String prodShowName = productName;
		if(productName.length() > 15){
			prodShowName = productName.substring(0, 15) + "...";
		}
		//发起支付，专款给中转帐户
		String html = payApi.rentPay(
				payId, 
				Common.now(),
				expiredTime,
				String.valueOf(amount), 
				prodShowName, 
				String.valueOf(amount),
				"1",
				"", 
				String.valueOf(uid),
				String.valueOf(officialUid), 
				"0",
				remark,
				payId, 
				PropKit.get("order.pay_strategy"),
				cbFrontend,
				cbBackend
		);
		return html;
	}
	
	@Override
	public boolean refund(int uid, String orderId, String payId, Double amount, String remark){
		ensureConfigs("busi.code");

		//传入0表示全额退款
		if(amount == null)
			amount = 0d;
		
		// content => {"code":0,"msg":"退费成功","data":{"orderId":"xxxxxxx","buyerRefundAmount":10.0,"sellerRefundAmount":10.0}} code=0时为成功，其他为失败。
		String content = payApi.orderRefund(payId, PropKit.get("busi.code"), String.valueOf(amount), remark, "0");
		if(StringUtils.isBlank(content)){
			logger.error("IPayApi.orderRefund: 订单【" + orderId + "】-租赁单【" + payId + "】执行退款时调用支付服务失败了！");
			return false;
		}

		JSONObject json = null;
		try{
			json = JSONObject.fromObject(content);
			if(json.getInt("code") == 0){
				logger.info("IPayApi.orderRefund: 订单【" + orderId + "】-租赁单【" + payId + "】退款成功！");
				return true;
			}
			logger.info("IPayApi.orderRefund: 订单【" + orderId + "】-租赁单【" + payId + "】退款失败（若用户未进行支付，此为正常），支付服务返回：" + json.toString());
			return false;
		}catch(Exception e){
			logger.error("IPayApi.orderRefund: 订单【" + orderId + "】-租赁单【" + payId + "】执行退款时，支付服务返回的不是json数据=>" + content);
			return false;
		}
	}

	@Override
	public List<ZhifuWay> getStrateges(String platform) {
		if(!"web".equalsIgnoreCase(platform) && !"wap".equalsIgnoreCase(platform)){
			return new ArrayList<ZhifuWay>();
		}
		
		// {"zhiFuBaoPay":"ALIPAY","weiXinPay":"NOWPAY","unionPay":null,"balancePay":"BALANCE"}
		// 说明：相应的字段等于null即没有该支付方式，相应的字段不等于null即字段对应的值就是存在的支付方式
		String str = payApi.findZhifuStrategyPay(PropKit.get("order.pay_strategy"), PropKit.get("busi.code"));
		JSONObject json = null;
		try{
			json = JSONObject.fromObject(str);
		}catch(Exception e){
			logger.error("payApi.findZhifuStrategyPay 接口傻逼了，返回了一个非json的字符串：" + str);
			return new ArrayList<ZhifuWay>();
		}

		List<ZhifuWay> ways = Lists.newArrayList();
		Iterator<?> it = json.keys();
		while(it.hasNext()){
			String key = (String)it.next();
			String value = json.getString(key);
			
			if(StringUtils.isBlank(value))
				continue;
			
			ZhifuWay way = new ZhifuWay();
			way.setPayWay(value);
			way.setZhifuPlatform(platform);
			way.setMix(false);
			way.setPayKey(key);
			if("zhiFuBaoPay".equalsIgnoreCase(key)){
				way.setZhifuName("支付宝");
			}
			if("weiXinPay".equalsIgnoreCase(key)){
				way.setZhifuName("微信");
			}
			if("unionPay".equalsIgnoreCase(key)){
				way.setZhifuName("银联");
			}
			if("balancePay".equalsIgnoreCase(key)){
				way.setZhifuName("余额");
			}
			ways.add(way);
		}
		
		return ways;
	}

	@Override
	public Double getAvailableBalance(int uid) {
		JSONObject json = JSONObject.fromObject(payApi.queryBalance(String.valueOf(uid)));
		return json.getDouble("cash_balance") ;
	}

	@Override
	public JSONObject payProductDecorate(Record productDecorate, String payId, Integer amount, ZhifuWay way, String payPasswd,
			String ip, String clientType) {
		ensureConfigs("order.pay_strategy", "product.guarantee_amount.cb_frontend_url", "product.guarantee_amount.cb_backend_url");
		if(productDecorate == null)
			return null;
		
		//clientType = "pc".equalsIgnoreCase(clientType) ? "pc" : "app";
		
		String expiredTime = Common.show_time(System.currentTimeMillis() + PropKit.getLong("order.pay_timeout")*1000);
		String remark = "【" + productDecorate.getInt("uid") + "】支付新春商品装饰";
		//JSON格式字符串。
		//成功返回：{"code": 0, "msg": "支付请求已提交","data":{"payStatus":10,"payPlatformId":1,"payWayId":3,"payInfo":"html"}}；
		//失败返回：{"code": 除0外的数值, "msg": "响应描述","payStatus":相对应的数值,} 
		//说明：余额支付成功及租号0元单业务支付成功时，payStatus为20，其他成功的，payStatus为10。
		//payInfo字段的值是用来调起支付的，支付宝支付时，值为自动提交的form表单，可在页面调起支付；微信扫码支付时，值为图片形式的二维码地址的字符串
		String str = payApi.mixedPayForRent(
				payId, 
				String.valueOf(Common.round(amount/100.0, 2)), 
				productDecorate.getStr("name"), 
				productDecorate.getStr("name"), 
				String.valueOf(1),
				String.valueOf(Common.round(amount/100.0, 2)),
				String.valueOf(productDecorate.getInt("uid")), 
				String.valueOf(officialUid), 
				"0",  //没有推广UID
				PropKit.get("order.pay_strategy"), 
				PropKit.get("product.decorate.cb_frontend_url"), 
				PropKit.get("product.decorate.cb_backend_url"),
				Common.now(),
				expiredTime, 
				remark,
				way.getZhifuPlatform(),
				payPasswd, 
				way.getPayWay(), 
				payId, 
				ip,
				clientType);
		
		try{
			JSONObject json = JSONObject.fromObject(str);
			
			int code = json.getInt("code");
			if(code != 0){
				logger.error("支付单【" + payId + "】支付时发生了异常，json => " + json);
				return Common.buildResp(1, json.optString("msg"));
			}
			
			//支付成功了，不同的支付方式返回的内容会有不同
			//纯余额支付，直接告知成功即可
			if(ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey())){
				return Common.buildResp(0, "ok", new KeyValue<>("pay_way", "balance"));
			}
			//支付宝 or 支付宝混合支付，返回用户跳转的html
			if(way.getPayKey().contains(ZhifuWay.ALIPAY_KEY)){
				return Common.buildResp(0, "ok", 
						new KeyValue<>("alipay_url", json.getJSONObject("data").getString("alipayUrl")),
						new KeyValue<>("pay_way", "alipay"));
			}
			//微信 or 微信混合支付
			if(way.getPayKey().contains(ZhifuWay.WXPAY_KEY)){
				return Common.buildResp(0, "ok", 
						new KeyValue<>("payInfo",json.getJSONObject("data").getString("payInfo")),
						new KeyValue<>("qr_code", json.getJSONObject("data").getString("payInfo")),
						new KeyValue<>("pay_way", "wechat"),
						new KeyValue<>("pay_amount", json.getJSONObject("data").get("mhtOrderAmt")));
			}
			
			return Common.buildResp(99, "不支持的支付方式");
		}catch(Exception e){
			logger.error("支付单【" + payId + "】请求支付服务发生了错误，str=>" + str);
			return null;
		}
	}

	@Override
	public boolean deductProductDecorate( int uid,String payId, Integer amount) {
		if(amount < 1){
			logger.info("tranfer -- 商品装饰支付【" + payId + "】转给平台的金额【" + amount + "】太小(小于1分钱)，忽略这次转账");
			return true;
		}
		//转为元，保留2位小数
		double rAmount = Common.round(amount/100.0, 2);
		
		//先结账
		if(!doSettlement(payId, 0d, rAmount, 0d, 0d)){
			logger.error("deductGuarantee -- 商品装饰支付金额进行清算发生了错误，uid=>" + uid + ", payId=>" + payId);
			return false;
		}
		
		//转账
		return doTransfer(payId, officialUid, TRANSFER_SELLUSER, "用户【" + uid + "】购买商品装饰的金额");
	}
	
	@Override
	public String payProductDecorate(int uid, String payId, Integer amount, String ip) {
		ensureConfigs("product.decorate.cb_frontend_url", "product.decorate.cb_backend_url");
		
		String remark = "【新春活动商品装饰】支付金额";
		return easyPay(
				uid, 
				payId, 
				remark, 
				Common.round(amount/100.0, 2), 
				remark, 
				PropKit.get("product.decorate.cb_frontend_url"),
				PropKit.get("product.decorate.cb_backend_url"),
				ip);
	}
}
