package cn.jugame.rent.interceptor;

import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

import cn.jugame.rent.utils.CookieUtil;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.RequestUtils;


public class VisitLogInterceptor implements Interceptor{

    private Logger visitLogger = Loggers.visitLog();

    private Logger logger = Loggers.rentLog();

    public static final String CHANNEL_COOKIE_UID = "jugame_cookie_uid";

    public static final String CHANNEL_COOKIE_NAME = "jugame_fr";

    @Override
    public void intercept(Invocation inv) {
        Controller controller = inv.getController(); controller.getRequest();
        HttpServletRequest request = controller.getRequest();
        HttpServletResponse response = controller.getResponse();

        try {
            response.setHeader("P3P", "CP=\"NON DSP COR CURa ADMa DEVa TAIa PSAa PSDa IVAa IVDa CONa HISa TELa OTPa OUR UNRa IND UNI COM NAV INT DEM CNT PRE LOC\"");

            String url = request.getRequestURL().toString();
            String queryString = request.getQueryString();

            if (StringUtils.isNotBlank(queryString)) {
                url += "?" + queryString;
            }

            String userip = RequestUtils.getUserIp(request);
            String referer = request.getHeader("referer");//来路

            Integer uid = controller.getSessionAttr("uid");

            // 给每一个用户记一个cookie号，用于标识UV
            String cookieUid = controller.getCookie(CHANNEL_COOKIE_UID);
            if (StringUtils.isBlank(cookieUid)) {
                UUID uuid = UUID.randomUUID();
                cookieUid = uuid.toString();
                controller.setCookie(CHANNEL_COOKIE_UID, cookieUid, 3600 * 24 * 365);
            }

            //处理fr参数
            String fr = RequestUtils.getParameter(request, "fr", "");
            if(StringUtils.isBlank(fr)){
                fr = controller.getCookie(CHANNEL_COOKIE_NAME);
            }
            //如果没有fr，则取默认值
            if(StringUtils.isBlank(fr)){
                fr = "rent";
            }
            //总是写回cookie
            controller.setCookie(CHANNEL_COOKIE_NAME, fr, 60*30);

            String userAgent = request.getHeader("user-agent");
            String orderEn = RequestUtils.getParameter(request, "order_en", "");
            if (StringUtils.isBlank(orderEn)) {
                orderEn = CookieUtil.getCookie(request, "order_en");
            }
            String method = inv.getMethodName();

            //写入访问日志
            visitLogger.info(cookieUid + "`" + uid + "`" + url + "`" + userAgent + "`" + userip + "`null`null`" + referer + "`" + fr + "`" + orderEn + "`" + method);

        } catch (Exception e) {
            logger.error("VisitLogInterceptor.error", e);
        }

        inv.invoke();
    }

}
