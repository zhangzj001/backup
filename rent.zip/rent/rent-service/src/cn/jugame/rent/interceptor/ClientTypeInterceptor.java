package cn.jugame.rent.interceptor;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.maven.model.Contributor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

public class ClientTypeInterceptor implements Interceptor{
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public void intercept(Invocation inv) {
		Controller controller = inv.getController();
		String clientType = parse(controller.getRequest());

		//正式环境下通过cookie保存当前客户端类型，开发环境则每次获取
		controller.setAttr("client_type", clientType);

		//判断是来自android还是来自ios，是来自wap还是来自pc
		String ua = controller.getRequest().getHeader("User-Agent");
		controller.setSessionAttr("pf", "wap");  //默认就是wap
		if("pc".equalsIgnoreCase(clientType)){
			inv.getController().setSessionAttr("pf", "pc");
		}else if(StringUtils.isNotBlank(ua) && (ua.contains("cn.jhw.hwzh.iOS") || ua.contains("cn.jhw.cwzh.iOS"))){
			controller.setSessionAttr("pf", "ios");
		}else if(StringUtils.isNotBlank(ua) && (ua.contains("cn.jhw.hwzh") || ua.contains("cn.jhw.cwzh") || ua.contains("cn.jugame.assistant") )){
			controller.setSessionAttr("pf", "android");
		}
		
		inv.invoke();
	}

	private String parse(HttpServletRequest req) {
		// queryStrign 带有__v参数，优先判断
		String v = req.getParameter("__v");
		if (v != null && ("pc".equalsIgnoreCase(v) || "wap".equalsIgnoreCase(v))) {
			return v;
		}
		
		// 判断UA
		boolean isMobile = false;
		String userAgent = req.getHeader("User-Agent");
		if (userAgent != null) {
			userAgent = userAgent.toLowerCase();

			// 现有 Android UA 都包含有 Mobile Safari 字符串
			boolean isAndroid = userAgent.indexOf("mobile safari") > 0;
			boolean isAndroid2 = userAgent.contains("Android") || userAgent.contains("android");
			// 现有 IOS 都包含 iPhone/iPad/iPod
			boolean isIOS = false;
			if (!isAndroid && !isAndroid2) {
				isIOS = userAgent.indexOf("iphone") > 0 || userAgent.indexOf("ipod") > 0 || userAgent.indexOf("ipad") > 0;
			}
			// Windows Phone UA 中包含 IEMobile
			boolean isIEMobile = userAgent.indexOf("iemobile") > 0;

			if (isAndroid || isIOS || isIEMobile || isAndroid2) {
				isMobile = true;
			}
			return isMobile ? "wap" : "pc";
		}
		
		// 默认走wap
		return "wap";
	}
}
