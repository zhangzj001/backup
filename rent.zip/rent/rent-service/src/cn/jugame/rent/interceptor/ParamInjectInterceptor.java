package cn.jugame.rent.interceptor;

import cn.jugame.rent.bean.Product;
import cn.jugame.rent.utils.Common;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;

/**
 * 参数拦截器！
 * XXX 请务必将此拦截器设置为第一个拦截器！！因为当遇到混合请求方式的时候（同时有GET参数和POST参数），则这个拦截器会首先将POST数据流读出来
 * @author 
 *
 */
public class ParamInjectInterceptor implements Interceptor {
    
	@Override
	public void intercept(Invocation inv) {
		Controller controller = inv.getController();
		controller.setAttr("request", controller.getRequest());
		
		//XXX 往客户端写入一个用于商品排序的cookie，实现每个人看到商品的不同排序方式
		Integer sortId = Product.getSortId(controller);
		//保存一份到session中，因为jfinal的setCookie和getCookie貌似是从不同的容器中获取值
		if(sortId == null){
			sortId = Common.rand(10000000, 99999999);
			controller.setSessionAttr("sortid", String.valueOf(sortId));
		}
		//总是写回cookie以保证不过期
		controller.setCookie("sortid", String.valueOf(sortId), PropKit.getInt("product.sortid_timeout"));
		
		inv.invoke();
	}
}
