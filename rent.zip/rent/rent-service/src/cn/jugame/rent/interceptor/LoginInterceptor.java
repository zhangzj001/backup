package cn.jugame.rent.interceptor;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

public class LoginInterceptor implements Interceptor{
	
	private Logger logger = Loggers.rentLog();

    @Override
    public void intercept(Invocation inv) {
        Controller c = inv.getController();

        String loginUid = System.getProperty("loginUid");
        if(StringUtils.isNotBlank(loginUid) && c.getSessionAttr("uid") == null){
        	c.setSessionAttr("uid", Integer.parseInt(loginUid));
        }
        
        String requestUrl = c.getRequest().getRequestURL().toString();
        Object uidObj = c.getSessionAttr("uid");
        
        //若用户已经登录，在客服聊天URL中追加uid参数
    	c.setAttr("kefuUrl", PropKit.get("kefu_url") + "&uid=" + loginUid);
    	c.setAttr("kefuRentAppUrl", PropKit.get("kefu_rentapp_url") + "&uid=" + loginUid);
    	
        String ua = c.getRequest().getHeader("User-Agent");
        
        //是否有fr参数，若有则设置sn
        String jugameFr = c.getCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME);
        if(StringUtils.isBlank(jugameFr))
            jugameFr = "rent";
        String sn = jugameFr;
        
        //APP登录方式
        if(StringUtils.isNotEmpty(ua) && (ua.contains("cn.jhw.hwzh") || ua.contains("cn.jhw.cwzh")) && uidObj == null){
            StringBuffer currentUrl = new StringBuffer(requestUrl);
            if(StringUtils.isNotBlank(c.getRequest().getQueryString())){
                currentUrl.append("?").append(c.getRequest().getQueryString());
            }

            String redirectUrl = getLoginUrl(PropKit.get("login_url"),
                    Common.url_encode(currentUrl.toString()),
                    sn);
            c.redirect("/user/login?currentUrl="+Common.url_encode(redirectUrl));
            return;
        }
        
        //网页登录方式
        if(uidObj == null) {
        	String clientType = c.getAttr("client_type");
        	String loginUrl = PropKit.get("login_url");
        	if("pc".equalsIgnoreCase(clientType)){
        		loginUrl = "/pc/user/login";
        	}
        	
            StringBuffer currentUrl = new StringBuffer(requestUrl);
            if(StringUtils.isNotBlank(c.getRequest().getQueryString())){
            	currentUrl.append("?").append(c.getRequest().getQueryString());
            }
            String redirectUrl = getLoginUrl(loginUrl,
                    Common.url_encode(currentUrl.toString()),
                    sn);
            c.redirect(redirectUrl);
            return;
        }

       inv.invoke();
    }
    
    public static String getLoginUrl(String baseUrl, String currentUrl, String sn) {
        return (new StringBuffer(baseUrl)
                .append("?currentUrl=" + currentUrl)
                .append("&onceLogin=1")
                .append("&sn=" + sn)
                .append("&fr=" + sn)).toString();
    }
}
