package cn.jugame.rent.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;

public class PCForwardInterceptor implements Interceptor{
	@Override
	public void intercept(Invocation inv) {
		String clientType = inv.getController().getAttr("client_type");
		//如果是PC，则强制forward到pc对应的controller中
		if("pc".equalsIgnoreCase(clientType) && !inv.getControllerKey().startsWith("/pc")){
			inv.getController().forwardAction("/pc" + inv.getActionKey());
			return;
		}
		inv.invoke();
	}
}
