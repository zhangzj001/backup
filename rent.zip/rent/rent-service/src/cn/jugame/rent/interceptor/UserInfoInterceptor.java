package cn.jugame.rent.interceptor;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.rent.bean.HotSetting;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import cn.jugame.rent.utils.UsernameUtil;
import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.xiaoleilu.hutool.lang.Dict;
import org.slf4j.Logger;

public class UserInfoInterceptor implements Interceptor {
	private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
	
	private Logger logger = Loggers.rentLog();

	@Override
	public void intercept(Invocation inv) {
		Controller controller = inv.getController();
		
		Integer uid = controller.getSessionAttr("uid");
		if(uid != null){
			Dict user = Dict.create().set("uid", uid);

	        //获取平台用户信息
	        cn.jugame.account_center.service.vo.MemberBean bean = null;
	        try {
	            bean = accountCenterService.findMemberByUid(uid);
	        }catch(Exception e){
	            logger.error("error", e);
	        }
	        
	        //用户昵称和头像
	        user.set("nickname", UsernameUtil.getUserName(bean, uid));

	        String headimg = "";
	        if(bean != null && bean.getData() != null){
	            Member member = (Member)bean.getData();
	            headimg = member.getHeadimgurl();
	        }
	        user.set("headimg", headimg);
	        
	        //玩家资产: 余额 + 优惠券数量 + 开心豆
            cn.jugame.account_center.service.vo.MemberBean mb = accountCenterService.queryBalance(uid);
            user.set("balance", mb.getData());
            
            //如果用户是商户，将商户的域名给出来
            Record row = SmartDb.findFirst("select * from `shop_info` where `uid`=?", uid);
            if(row != null){
            	user.set("shop_domain", row.getStr("domain"));
            }
            
            controller.setAttr("user", user);
		}
        
        //还有一些通用参数
		controller.setAttr("app_adaptation_version", PropKit.get("app_adaptation_version"));
		controller.setAttr("seller_qq_group", HotSetting.get("SELLER_QQ_GROUP_URL", ""));
        if("pc".equalsIgnoreCase(controller.getAttr("client_type"))){
        	controller.setAttr("player_qq_group", HotSetting.get("PLAYER_PC_QQ_GROUP_URL", ""));
        }else{
        	controller.setAttr("player_qq_group", HotSetting.get("PLAYER_MOBILE_QQ_GROUP_URL", ""));
        }
		
		inv.invoke();
	}

}
