package cn.jugame.rent.interceptor;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;

import cn.jugame.jumq.util.Common;
import cn.jugame.util.RequestUtils;


public class IPInterceptor implements Interceptor{
	
	@Override
	public void intercept(Invocation inv) {
        Controller c = inv.getController();
        
		//只允许内部IP访问
		String ip = RequestUtils.getUserIp(c.getRequest());
		
		String[] acceptIps = Common.array_filter(PropKit.get("kefu.accept_ip", "").split(","));
		for(String acc : acceptIps){
			//有白名单
			if(acc.equalsIgnoreCase(ip)){
				inv.invoke();
				return;
			}
		}
		
		c.setAttr("error", "拒绝访问");
		c.render("/view/error.html");
	}
}
