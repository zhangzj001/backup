package cn.jugame.rent.interceptor;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;

import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.RequestUtils;

public class AppInterceptor implements Interceptor{
	@Override
	public void intercept(Invocation inv) {
		//如果是来自App的，则自始至终都认为是来自App
		Controller controller = inv.getController();
		if("1".equals(RequestUtils.getParameter(controller.getRequest(), "isApp", "0"))){
			controller.setSessionAttr("isApp", "1");
		}
		String ua = controller.getRequest().getHeader("User-Agent");

		//是否来自App
        //总是从session中获取一次值并写入模板变量中
        String isApp = controller.getSessionAttr("isApp");
        if(StringUtils.isNotBlank(ua) && (ua.contains("cn.jhw.hwzh") || ua.contains("cn.jhw.cwzh"))){
			isApp = "1";
			controller.setAttr("isRentApp", true);
			controller.setSessionAttr("isApp", isApp);
			controller.setSessionAttr("isRentApp", true);
		}
		controller.setAttr("isApp", isApp == null ? "0" : isApp);
//		logger.info("请求用户IP:"+ Common.getIp(controller.getRequest())+"---请求用户uid："+controller.getSessionAttr("uid")+"---请求的url"+controller.getRequest().getRequestURL());
		inv.invoke();
	}

}
