package cn.jugame.rent.utils;

import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ParallelQuery {
	
	public class Query implements Runnable{
		private String sql;
		private Object[] params;
		private List<Record> result;
		
		public Query(String sql, Object... params) {
			this.sql = sql;
			this.params = params;
		}
		
		@Override
		public void run() {
			result = SmartDb.find(sql, params);
		}
		
		public Record row(){
			if(result == null || result.size() == 0)
				return null;
			return result.get(0);
		}
		
		public List<Record> rows(){
			return result;
		}
	}
	
	/**
	 * 多线程同时对所有Query进行执行，并最多等待30s所有查询得到结果后，将所有查询结果返回。
	 * @param queries
	 * @return
	 */
	public static Query[] find(Query... queries){
		ExecutorService service = Executors.newFixedThreadPool(10);
		for(Query q : queries){
			service.equals(q);
		}
		
		try{
			service.shutdown();
			service.awaitTermination(30, TimeUnit.SECONDS);
		}catch(Exception e){
			return null;
		}
		
		return queries;
	}
}
