package cn.jugame.rent.utils;

import com.jfinal.kit.PropKit;
import org.apache.commons.lang.StringEscapeUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Timothy on 2017/6/19.
 */
public class TemplateOrderUtils {

    private static Map<Integer, String> orderStatusMap = new HashMap();

    public TemplateOrderUtils() {
        orderStatusMap.put(0, "未付款");
        orderStatusMap.put(2, "已支付");
        orderStatusMap.put(6, "交易完成");
        orderStatusMap.put(8, "交易取消");
        orderStatusMap.put(100, "未付款");
    }


    public static Map<Integer, String> getStatus() {
        return orderStatusMap;
    }

    /**
     * 获取显示的状态名称
     * @param status
     * @return
     */
    public static String getName(int status) {
        return orderStatusMap.get(status);
    }

    /**
     * 是否显示结束时间, 已支付 已发货 交易完成时显示
     * @param status
     * @return
     */
    public static boolean isShowEndTime(int status) {
        return (status == 2 || status == 6 || status == 100);
    }

    public static String encodeHTML(String string) {
        return StringEscapeUtils.escapeHtml(string);
    }
    
    /**
     * 四舍五入保留2位小数
     * @param n
     * @return
     */
    public static double round(double n){
    	return Common.round(n, 2);
    }

    /**
     * 订单求助的描述
     * @param helpType
     * @return
     */
    public static String getOrderHelpDesc(int helpType){
        if(helpType == 1)
            return "5分钟内号主将提供新密码，等待中...";
        if(helpType == 2)
            return "5分钟内号主将改密并解除账号异常，等待中...";
        if(helpType == 3)
            return "5分钟内号主将提供验证码，等待中...";
        return "";
    }
    /**
     * 获取登录器下载链接
     * @param loginCompany 登录器的发布方
     * */
    public static String getAutoLoginKitUrl(String loginCompany){
    	//租号长尾端 的下载链接 
        if("UPromote".equals(loginCompany)){
            return encodeHTML(PropKit.get("loginkey.downloadUrl.promote"));
        }
        //端游上号器下载地址
        else if("jugameRent".equals(loginCompany)){
        	return encodeHTML(PropKit.get("loginKey.downloadUrl.pcgame"));
        } 
        //手游交易助手下载地址，自带上号器
        else{
            return encodeHTML(PropKit.get("loginkey.downloadUrl"));
        }
    }

}
