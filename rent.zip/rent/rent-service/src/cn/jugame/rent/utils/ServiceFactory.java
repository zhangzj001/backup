package cn.jugame.rent.utils;

import com.jfinal.kit.PropKit;

public class ServiceFactory {
    private static PlatformService ps;
    static{
        PlatformServiceConfig psConf = new PlatformServiceConfig();
        psConf.setDubboRegistUrl(PropKit.get("dubbo.regist_url"));
        psConf.setHttpServiceCaller(PropKit.get("http_service.caller"));
        psConf.setHttpServiceSignkey(PropKit.get("http_service.signKey"));
        psConf.setHttpServiceStatEnable(PropKit.getInt("http_service.statEnable"));
        psConf.setHttpServiceTimeout(PropKit.getInt("http_service.timeout"));
        psConf.setHttpServiceUrl(PropKit.get("http_service.url"));

        ps = new PlatformService(psConf);
    }

    public static <T> T get(Class<? extends T> clazz){
        return ps.get(clazz);
    }
}
