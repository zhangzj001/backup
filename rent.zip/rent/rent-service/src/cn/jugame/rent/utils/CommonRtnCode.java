package cn.jugame.rent.utils;

/**
 * Created by Administrator on 2017/7/13.
 */
public class CommonRtnCode {

    /**
     * token为空
     */
    public final static int TOKEN_INVALID = 500;
    public final static String MSG_TOKEN_INVALID = "请先登录";

    /**
     * token过期
     */
    public final static int TOKEN_EXPIRED = 501;
    public final static String MSG_TOKEN_EXPIRED = "登录状态过期, 请重新登录(501)";

    /**
     * token和uid不匹配
     */
    public final static int TOKEN_UID_NOT_MATCH = 502;
    public final static String MSG_TOKEN_UID_NOT_MATCH = "登录状态过期, 请重新登录(502)";

    /**
     * token过期
     */
    public final static int TOKEN_SYS_EXCEPTION = 599;
    public final static String MSG_TOKEN_SYS_EXCEPTION = "系统异常";
}
