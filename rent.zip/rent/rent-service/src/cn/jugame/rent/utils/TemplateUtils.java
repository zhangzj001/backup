package cn.jugame.rent.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import com.jfinal.kit.Prop;
import com.jfinal.kit.PropKit;
import org.apache.commons.lang.StringUtils;

import cn.jugame.rent.bean.HotSetting;

/**
 * Created by Timothy on 2017/8/10.
 */
public class TemplateUtils {
	public static String formatNumber(BigDecimal num) {
		DecimalFormat df = new DecimalFormat("###.#");
		return df.format(num);
	}
	
	public static Double round(Double amount){
		return Common.round(amount, 2);
	}
	
	public static String hotSetting(String key){
		String val = CacheUtil.get(key);
		if(StringUtils.isBlank(val)){
			val = HotSetting.get(key, "");
			CacheUtil.set(key, 60, val);
		}
		return val;
	}
	
	public static Double toYuan(Integer fen){
		return Common.round(fen/100.0, 2);
	}
	
	public static String formatProductName(String name){
		int n = 30;
		if(name.length() > n){
			return name.substring(0, n) + "…";
		}
		return name;
	}

	public static String getLogin(String relativePath){
		String currentUrl = PropKit.get("rent_service_host","http://z.8868.cn")+relativePath;
		StringBuffer loginUrl = new StringBuffer(PropKit.get("login_url"))
				.append("?currentUrl=" + Common.url_encode(currentUrl))
				.append("&onceLogin=1")
				.append("&sn=rent");
		return  loginUrl.toString();

	}

	public static String getLoginSingle(String relativePath){
		String currentUrl = PropKit.get("rent_service_host","http://z.8868.cn")+relativePath;
		StringBuffer loginUrl = new StringBuffer(PropKit.get("login_url"))
				.append("?currentUrl=" + Common.url_encode(currentUrl));

		return  loginUrl.toString();

	}

	public static String getAppLoginSingle(String relativePath){
		String currentUrl = PropKit.get("rent_service_host","http://z.8868.cn")+relativePath+"?user_get_newcomer_gift=1";
		StringBuffer loginUrl = new StringBuffer(PropKit.get("login_url"))
				.append("?currentUrl=" + Common.url_encode(currentUrl) );

		return  "/user/login?currentUrl="+Common.url_encode(loginUrl.toString());

	}

}
