package cn.jugame.rent.utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by jiangshishan on 2018/1/25.
 */
public class TemplateUserFrontUtils {


	//个人中心前端订单列表显示
	private static Map<Integer, String> orderStatusMap = new LinkedHashMap<>();

	//个人中心前端商品列表显示
	private static Map<Integer, String> productStatusMap = new LinkedHashMap<>();
	public TemplateUserFrontUtils() {
		orderStatusMap.put(0, "待付款");
		orderStatusMap.put(888, "待处理");
		orderStatusMap.put(2, "租用中");
		orderStatusMap.put(8, "退款中");
		orderStatusMap.put(999, "售后处理");

		productStatusMap.put(7, "已上架");
		productStatusMap.put(8, "已下架");
		productStatusMap.put(3, "待审核");
		productStatusMap.put(202, "保护期");
	}

	/**
	 * 获取个人中心订单状态集合
	 * @return
	 */
	public static Map<Integer, String> getOrderStatus() {
		return orderStatusMap;
	}
	/**
	 * 获取个人中心商品状态集合
	 * @return
	 */
	public static Map<Integer, String> getProductStatus() {
		return productStatusMap;
	}


	/**
	 * 获取订单显示的状态名称
	 * @param status
	 * @return
	 */
	public static String getOrderStatusName(int status) {
		return orderStatusMap.get(status);
	}

	/**
	 * 获取商品状态的展示名称
	 * @param productType
	 * @return
	 */
	public static String getProductStatusName(int productType){
		return productStatusMap.get(productType);
	}

}
