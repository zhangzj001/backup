package cn.jugame.rent.utils;


import cn.jugame.rent.bean.Product;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.apache.commons.lang.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Timothy on 2017/6/19.
 */
public class TemplateProductUtils {

    private static Map<Integer, String> productStatusMap = new HashMap<>();
    
    private static Map<Integer, String> productTypeMap = new HashMap<>();

    public TemplateProductUtils() {
        productStatusMap.put(3, "待审核");
        productStatusMap.put(7, "可租");
        productStatusMap.put(8, "已下架");
        productStatusMap.put(201, "出租中");
        productStatusMap.put(202, "保护中");

        
        productTypeMap.put(1, "游戏账号");
        productTypeMap.put(2, "视频VIP");
        productTypeMap.put(3, "长租号");
    }


    public static Map<Integer, String> getStatus() {
        return productStatusMap;
    }
    
    /**
     * 获取显示的状态名称
     * @param status
     * @return
     */
    public static String getName(int status) {
        return productStatusMap.get(status);
    }
    
    /**
     * 获取商品类型的展示名称
     * @param productType
     * @return
     */
    public static String getProductTypeName(int productType){
    	return productTypeMap.get(productType);
    }

    /**
     * 获取月-日的日期格式
     * */
    public static String getMonthDayDate(String date){
        SimpleDateFormat tansferedFormat = new SimpleDateFormat("MM月dd日");
        SimpleDateFormat  format= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        String transferedDate = null;
        if(StringUtils.isEmpty(date)){
            return null;
        }
        try {
            Date transferDate = format.parse(date);
            transferedDate = tansferedFormat.format(transferDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return transferedDate;
    }

    /**根据游戏名称获取汉语拼音首字母简写**/
    public static String getGameShortName(String gameId){
        String gameShortName = "";
        Record gameConf = SmartDb.findFirst("select game_short_name from game_conf where game_id = ?",gameId);
        if(gameConf != null){
            gameShortName = gameConf.getStr("game_short_name");
        }
        return  gameShortName;
    }

    public static String getVipLoginTips(int vipLoginType){
        if(vipLoginType == Product.VIP_LOGIN_TYPE_MOBILE)
            return "手机登录";
        if(vipLoginType == Product.VIP_LOGIN_TYPE_QQ)
            return "QQ登录";
        if(vipLoginType == Product.VIP_LOGIN_TYPE_WECHAT)
            return "微信登录";
        if(vipLoginType == Product.VIP_LOGIN_TYPE_BLOG)
            return "微博登录";
        return "";
    }
}
