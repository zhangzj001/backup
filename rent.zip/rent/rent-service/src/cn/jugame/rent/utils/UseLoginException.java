package cn.jugame.rent.utils;

/**
 * Created by Administrator on 2017/7/13.
 */
public class UseLoginException extends Exception {

    public int code;
    public String msg;

    public UseLoginException(int code, String msg) {
        super(msg);
        this.code = code;
        this.msg = msg;
    }
}
