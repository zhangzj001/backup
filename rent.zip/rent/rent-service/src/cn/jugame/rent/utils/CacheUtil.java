package cn.jugame.rent.utils;

import com.jfinal.plugin.redis.Redis;
import com.jfinal.plugin.redis.RedisCache;

public class CacheUtil {
    private static RedisCache cache = Redis.use("rent_redis");
    
    public static boolean set(String key, int exp, Object value) {
    	cache.setex(key, exp, value);
    	return true;
    }
    
    public static boolean del(String key) {
    	cache.del(key);
    	return true;
    }
    
    public static <T> T get(String key) {
    	return cache.get(key);
    }
    
    public static long incr(String key, int exp) {
        return incr(key, 1, exp);
    }
    
    public static long incr(String key, long delta, int exp) {
    	long r = cache.incrBy(key, delta);
    	cache.expire(key, exp);
    	return r;
    }
    
    public static long decr(String key, int exp) {
        return decr(key, 1, exp);
    }
    
    public static long decr(String key, long delta, int exp) {
    	long r = cache.decrBy(key, delta);
    	cache.expire(key, exp);
    	return r;
    }
    
    public static boolean add(String key, int exp, Object value){
    	return cache.setnx(key, exp, value);
    }
    
    public static long addCount(String key, long delta){
    	return cache.incrBy(key, delta);
    }
    
    public static long getCount(String key){
    	return cache.incrBy(key, 0);
    }
}
