package cn.jugame.rent.utils;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;

public class UsernameUtil {
	private static Logger logger = Loggers.rentLog();
    private static IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);

    /**
     * 根据UID获取用户信息，并组装出一个可用于展示的用户名称
     * @param uid
     * @return
     */
    public static String getUserName(int uid){
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        }catch(Exception e){
            logger.error("error", e);
        }

        return getUserName(bean, uid);
    }

    public static String getUserName(cn.jugame.account_center.service.vo.MemberBean bean, int uid){
        //获取失败了，则使用UID，保留最后4位即可
		String uidValue = String.valueOf(uid);
        if(bean == null || bean.getData() == null){
            int idx = uidValue.length() - 4;
            if(idx >= 0)
                return "***" + uidValue.substring(idx);
            return uidValue;
        }

        //先用昵称
        Member member = (Member)bean.getData();
        String s = member.getNickName();
        if(StringUtils.isNotBlank(s))
            return s;

        s = member.getMobile();
        if(StringUtils.isNotBlank(s)){
            return s.substring(0, 4) + "****" + s.substring(s.length()-3);
        }

		return "***" + uidValue.substring(uidValue.length() - 4);
    }
}
