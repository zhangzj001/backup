package cn.jugame.rent.bean;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.service.common.util.idbuilder.IDBuilder;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class Coupon {
	private static Logger logger = Loggers.rentLog();
	
	/** 优惠券状态：上架 */
	public static final int STATUS_ONSALE = 1;
	
	/** 优惠券状态：下架 */
	public static final int STATUS_OFFSALE = 0;
	
	//------------------------------------------------------------------
	/** 优惠券类型：打折券 */
	public static final int TYPE_DISCOUNT_OFF = 1;
	/** 优惠券类型：立减券 */
	public static final int TYPE_DIRECTLLY_OFF = 2;
	
	
	//------------------------------------------------------------------
	/** 领取规则：用户领取 */
	public static final int TAKEN_TYPE_USER = 1;
	/** 领取规则：系统发放 */
	public static final int TAKEN_TYPE_SYSTEM = 2;

	//------------------------------------------------------------------
	/** 优惠券是否通知用户：否 */
	public static  final int IS_NOTIFY_NO= 0;
	/** 优惠券是否通知用户：是 */
	public static  final int IS_NOTIFY_YES = 1;
	
	
	/** 优惠券 活动类型  所有人*/
	public static final String  ACTION_TYPE_DEFAULT="default";
	/** 优惠券 活动类型  新人礼包*/
	public static final String  ACTION_TYPE_NEWCOMER="newcomer";
	/** 优惠券 活动类型  老用户*/
	public static final String  ACTION_TYPE_OLDER="older";
	/** 优惠券 活动类型  新用户*/
	public static final String  ACTION_TYPE_NEWCOMER_ALONE="newcomer_alone";
	
	
	/***优惠券 是否每天重置领取次数  否*/
	public static final int DATE_RESET_TIMES_NO = 0;
	/***优惠券 是否每天重置领取次数  是*/
	public static final int DATE_RESET_TIMES_YES = 1;

	//--------------------------------------------------------------------
	/**
	 * 将用户的代金券使用次数+1
	 * @param uid
	 * @param couponUseId
	 */
	public static boolean increaseUserCoupon(int uid, String couponUseId){
	    if(StringUtils.isBlank(couponUseId))
	        return true;
		int n = SmartDb.update("update `user_coupon` set `left_times`=`left_times`+1 where `uid`=? and `use_id`=?", uid, couponUseId);
		return n!=0;
	}
	
	/**
	 * 用户代金券使用次数-1，同时设置使用时间
	 * @param uid
	 * @param couponUseId
	 * @param useTime 若为null则不设置
	 */
	public static boolean decreaseUserCoupon(int uid, String couponUseId, String useTime){
	    if(StringUtils.isBlank(couponUseId))
	        return true;
		int n = SmartDb.update("update `user_coupon` set `left_times`=`left_times`-1, `last_order_time`=? where `uid`=? and `use_id`=?", useTime, uid, couponUseId);
		return n!=0;
	}
	
	/**
	 * 获取用户可用的优惠券
	 * @param uid
	 * @param useId
	 * @return
	 */
	public static Record getUserCoupon(int uid, String useId){
		if(StringUtils.isBlank(useId))
			return null;
		
		String today = Common.now("yyyy-MM-dd");
		return SmartDb.findFirst("select * from `user_coupon` where `uid`=? and `use_id`=? and `beg_date`<=? and `end_date`>=? and `left_times`>0 limit 1", uid, useId, today, today);
	}
	
	
	/**
	 * 判断用户的优惠券是否适用于指定的商品
	 * 若不符合指定的商品，则判断该商品是不是扶持商品，且判断该优惠券是否适用扶持商品
	 * @param userCoupon
	 * @param product
	 * @return
	 */
	public static boolean notFitCoupon(Record userCoupon, Record product){
		//是否匹配商品类型
		if(notFitProductType(userCoupon, product))
			return true;
		
		//是否匹配游戏
		if(notFitGameId(userCoupon, product))
			return true;
		
		//是否超过每日使用次数限额
		if(notFitDayLimit(userCoupon))
			return true;
		
		//是否符合扶持类型
		if(notFitSupportCoupon(userCoupon, product))
			return true;
		
		return false;
	}

	/***
	 * 判断该商品是否为扶持商品，若为扶持商品则判断该优惠券是否适用于扶持商品
	 * @param userCoupon
	 * @param product
	 * @return
	 */
	private static boolean notFitSupportCoupon(Record userCoupon, Record product) {
		// 判断是否为扶持商品
		if (product.getInt("support_type") != 1)
			return false;
		String validSupportType = userCoupon.getStr("valid_support_type");
		if (StringUtils.isBlank(validSupportType))
			return false;

		JSONArray json = null;
		try{
			json = JSONArray.fromObject(validSupportType);
		}catch(Exception e){
			//解析错误，保守起见，不给用这张优惠券
			logger.error("notFitSupportCoupon: parse error, userCoupon.id=>" + userCoupon.getInt("id"), e);
			return true;
		}
		if(json.size()==0)
			return false;
		
		int supportType = product.getInt("support_type");
		for (int i = 0; i < json.size(); i++) {
			if (supportType == json.getInt(i)) {
				return false;
			}
		}
		return true;
	}
	
	
	/**
	 * 判断优惠券是否适用商品的类型
	 * @param userCoupon
	 * @param product
	 * @return
	 */
	private static boolean notFitProductType(Record userCoupon, Record product){
		String productTypeFilter = userCoupon.getStr("valid_product_type");
		if(StringUtils.isBlank(productTypeFilter))
			return false;
		
		JSONArray json = null;
		try{
			json = JSONArray.fromObject(productTypeFilter);
		}catch(Exception e){
			//解析错误，保守起见，不给用这张优惠券
			logger.error("notFitProductType: parse error, userCoupon.id=>" + userCoupon.getInt("id"), e);
			return true;
		}
		
		//如果没有配置，说明适配全部！
		if(json.size() == 0)
			return false;
		
		int productType = product.getInt("product_type");
		for(int i=0; i<json.size(); ++i){
			if(productType == json.getInt(i))
				return false;
		}
		return true;
	}
	
	private static boolean notFitGameId(Record userCoupon, Record product){
		String gameIdFitler = userCoupon.getStr("valid_game_id");
		if(StringUtils.isBlank(gameIdFitler))
			return false;
		
		JSONArray json = null;
		try{
			json = JSONArray.fromObject(gameIdFitler);
		}catch(Exception e){
			//解析错误，保守起见，不给用这张优惠券
			logger.error("notFitGameId: parse error, userCoupon.id=>" + userCoupon.getInt("id"), e);
			return true;
		}

		//如果没有配置，说明适配全部！
		if(json.size() == 0)
			return false;
		
		String gameId = product.getStr("game_id");
		for(int i=0; i<json.size(); ++i){
			if(gameId.equalsIgnoreCase(json.getString(i)))
				return false;
		}
		return true;
	}
	
	/**
	 * 判断优惠券每日使用量是否达到上限
	 * @param userCoupon
	 * @return
	 */
	private static boolean notFitDayLimit(Record userCoupon){
		int dayLimit = userCoupon.getInt("day_limit");
		if(dayLimit > 0){
			Record row = SmartDb.findFirst("select count(id) as _count from `order` where `buyuser_uid`=? and `order_status`=? and `coupon_use_id`=? and `order_finish_time`>=? and `order_finish_time`<=?", 
					userCoupon.getInt("uid"), Order.ORDER_STATUS_FINISH, userCoupon.getStr("use_id"), Common.now("yyyy-MM-dd 00:00:00"), Common.now("yyyy-MM-dd 23:59:59"));
			//该优惠券每次使用次数已达上限！
			if(row.getLong("_count") >= dayLimit)
				return true;
		}
		
		return false;
	}
	
	/**
	 * 领取优惠券，强制指定优惠券的可使用日期
	 * @param uid
	 * @param coupon
	 * @param begDate
	 * @param endDate
	 * @return
	 */
	public static boolean take(int uid, Record coupon, String begDate, String endDate){
		String couponId = coupon.getStr("coupon_id");
		
		Record userCoupon = new Record();
		userCoupon.set("use_id", IDBuilder.productIdBuilder("CO"));
		userCoupon.set("coupon_id", couponId);
		userCoupon.set("name", coupon.getStr("name"));
		userCoupon.set("info", coupon.getStr("info"));
		userCoupon.set("pic", coupon.getStr("pic"));
		userCoupon.set("type", coupon.getInt("type"));
		userCoupon.set("discount", coupon.getBigDecimal("discount"));
		userCoupon.set("max_discount_amount", coupon.getInt("max_discount_amount"));
		userCoupon.set("amount_off", coupon.getInt("amount_off"));
		userCoupon.set("uid", uid);
		userCoupon.set("beg_date", begDate);
		userCoupon.set("end_date", endDate);
		userCoupon.set("c_time", Common.now());
		userCoupon.set("times", coupon.getInt("times"));
		userCoupon.set("left_times", coupon.getInt("times"));
		userCoupon.set("min_rental",coupon.getInt("min_rental"));
		userCoupon.set("valid_product_type", coupon.getStr("valid_product_type"));
		userCoupon.set("valid_game_id", coupon.getStr("valid_game_id"));
		userCoupon.set("status", Coupon.STATUS_ONSALE);
		userCoupon.set("day_limit", coupon.getInt("day_limit"));
		userCoupon.set("target_url", coupon.getStr("target_url"));
		userCoupon.set("valid_support_type", coupon.getStr("valid_support_type"));
		//这是一个可无限次使用的优惠券，将left_times设置为一个巨大的值即可
		if(coupon.getInt("times") <= 0){
			userCoupon.set("left_times", 999999999);
		}
		if(!SmartDb.save("user_coupon", userCoupon)){
			logger.error("用户【" + uid + "】领取优惠券【" + couponId + "】失败了，sql=>" + SmartDb.lastQuery());
			return false;
		}
		
		return true;
	}
	
	/**
	 * 领取优惠券，使用优惠券指定的有效期，从当前时间开始计算！
	 * @param uid
	 * @param coupon
	 * @return
	 */
	public static boolean take(int uid, Record coupon){
		String begDate = Common.show_time(coupon.getDate("beg_date"));
		if(StringUtils.isBlank(begDate)) {
			begDate = Common.now("yyyy-MM-dd");
		}
		String endDate = Common.addDay(begDate, coupon.getInt("valid_days"), "yyyy-MM-dd");
		
		return take(uid, coupon, begDate, endDate);
	}
	
	/**
	 * 发放代金券礼包
	 */
	public static void gift(String promoteConf, int uid){
		String today = Common.now("yyyy-MM-dd");
		int step = 0;
		List<KeyValue<Integer>> list = parsePromoteCoupons(promoteConf);
		for(KeyValue<Integer> kv : list){
			String couponId = kv.getKey();
			int day = kv.getValue();
			
			Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=?", couponId);
			if(coupon == null){
				logger.error("拉新推广配置中存在一个不存在的优惠券ID：" + couponId);
				continue;
			}
			
			String begDate = Common.show_time(coupon.getDate("beg_date"));
			if(StringUtils.isBlank(begDate)) {
				begDate = Common.now("yyyy-MM-dd");
			}
			String endDate = Common.addDay(begDate, coupon.getInt("valid_days"), "yyyy-MM-dd");
			if(day > 0){
				begDate = Common.addDay(today, step, "yyyy-MM-dd");
				endDate = Common.addDay(begDate, day, "yyyy-MM-dd");
				step += day+1;
			}
			
			if(!Coupon.take(uid, coupon, begDate, endDate)){
				logger.error("用户【" + uid + "】领取礼包优惠券失败了！couponId=>" + couponId);
				continue;
			}
		}
	}

	/**
	 * 发放新人礼包
	 * isSupport   0-非扶持区领新人礼包      1-扶持区领取新人礼包   2-扶持区领取扶持商品优惠券，且该优惠券不在新人礼包中
	 */
	public static void newComerGift(int uid,int isSupport){

		Record member = User.getMember(uid);
		member.keep("uid");
		member.set("has_newcomer_gift", User.USER_HAS_NEWCOMER_GIFT);
		if(SmartDb.update("member", "uid", member)){
			List<Record> newComerGift = null;
			if(isSupport==0)
				newComerGift=getNewcomerGift(uid);
			else
				newComerGift=getNewcomerGift(uid,isSupport);
			for(Record coupon:newComerGift){
				String begDate = Common.show_time(coupon.getDate("beg_date"));
				if(StringUtils.isBlank(begDate)) {
					begDate = Common.now("yyyy-MM-dd");
				}
				String endDate = Common.addDay(begDate, coupon.getInt("valid_days"), "yyyy-MM-dd");
				if(!Coupon.take(uid, coupon, begDate, endDate)){
					logger.error("用户【" + uid + "】领取新人礼包优惠券失败了！couponId=>" + coupon.getStr("coupon_id"));
					continue;
				}
			}
		}else{
			logger.error("用户【" + uid + "】领取新人礼包优惠券失败了！" );
		}


	}

	/**
	 * 获取新人礼包优惠券
	 * */
	public static  List<Record> getNewcomerGift(){
		List<Record> gift = SmartDb.find("SELECT * FROM coupon WHERE action_type = ? AND taken_type = ? AND `status` = ?", PropKit.get("newcomer.gift","newcomer"),TAKEN_TYPE_USER,STATUS_ONSALE);
		return gift;
	}
	
	/**
	 * 获取新人礼包优惠券
	 * */
	public static  List<Record> getNewcomerGift(int uid){
		List<Record> gift = SmartDb.find("SELECT * FROM coupon a WHERE action_type = ? AND taken_type = ? AND `status` = ? and    not exists (select *  from `user_coupon`  b where uid =?   and b.coupon_id = a.coupon_id)", PropKit.get("newcomer.gift","newcomer"),TAKEN_TYPE_USER,STATUS_ONSALE,uid);
		return gift;
	}

	/**
	 * 更新用户优惠券的通知状态为已通知
	 * @param coupons
	 * @return
	 */
	public static void notifyUserNewCoupon(List<Record> coupons){
		for(Record coupon : coupons){
			int id = coupon.getInt("id");
			coupon.keep("id");
			coupon.set("is_notify",Coupon.IS_NOTIFY_YES);
			if(!SmartDb.update("user_coupon",coupon)){
				logger.error("更新优惠券通知状态错误"+id);
			}
		}


	}

	
	private static List<KeyValue<Integer>> parsePromoteCoupons(String promoteConf){
		List<KeyValue<Integer>> list = new ArrayList<>();
		
		String[] ss = Common.array_filter(promoteConf.split(";"));
		for(String s : ss){
			String[] cc = Common.array_filter(s.split(":"));
			KeyValue<Integer> kv = new KeyValue<>();
			if(cc.length == 1){
				kv.setKey(cc[0]);
				kv.setValue(0);
			}else{
				kv.setKey(cc[0]);
				kv.setValue(Integer.parseInt(cc[1]));
			}
			list.add(kv);
		}
		return list;
	}
	
	/***
	 * 获取新人礼包中用户未领取过的优惠券
	 * @param uid
	 * @return
	 */
	public static List<Record> getNewcomerGift(Integer uid,Integer isSupport){
		List<Record> gifts =null;
		if(isSupport == 1) {
			gifts = SmartDb.find("select * from `coupon` a   where  action_type =?  AND taken_type = ? AND `status` = ? and    not exists (select *  from `user_coupon`  b where uid =?   and b.coupon_id = a.coupon_id ) ", PropKit.get("newcomer.gift","newcomer"),TAKEN_TYPE_USER,STATUS_ONSALE,uid);
		    return gifts!=null?gifts:new ArrayList<Record>();
		}else {
			gifts = SmartDb.find("select * from `coupon` a   where  action_type =?  AND taken_type = ? AND `status` = ? and    not exists (select *  from `user_coupon`  b where uid =?   and b.coupon_id = a.coupon_id ) ", PropKit.get("default.gift","default"),TAKEN_TYPE_USER,STATUS_ONSALE,uid);
			return getSupportGift(gifts,Product.SUPPORT_TYPE_SUPPORTED);
		}
	}
	
	/**
	 * 从coupons中筛选出扶持类型为supportType的优惠券
	 * @param coupons
	 * @param supportType
	 * @return
	 */
	public static List<Record> getSupportGift(List<Record>  coupons,int supportType){
		List<Record>  list = new ArrayList<Record>();
		if(coupons!=null&&coupons.size()>0) {
			for (Record row : coupons) {
				JSONArray array = new JSONArray();
				try {
					if(StringUtils.isNotBlank(row.get("valid_support_type")))
					      array = JSONArray.fromObject(row.get("valid_support_type"));
				} catch (Exception e) {
					logger.error("error parsing jsonarray: " + row.get("coupon_id"), e);
				}
				for (int i = 0; i < array.size(); i++) {
					if (array.getInt(i) == supportType) {
						list.add(row);
					}
				}
			}
		}
		return list;
	}
	
	
	/****
	 * 判断用户是否领取了coupons中的所有优惠券
	 * @param coupons
	 * @param userCoupons
	 * @return
	 */
	public static boolean  isReceiveAllCoupons(List<Record> coupons,List<Record> userCoupons ){
		if(coupons==null||coupons.size()==0)
			return true;
		if(userCoupons==null||userCoupons.size()==0)
			return false;
		int couponSize= 0;
		for(Record coupon :coupons ) {
			for(Record userCoupon :userCoupons) {
				if(coupon.getStr("coupon_id").equals(userCoupon.getStr("coupon_id"))) {
					couponSize++;
					break;
				}
			}
		}
		if(couponSize>0&&couponSize==coupons.size())
			return true;
		
		return false;
	}
}
