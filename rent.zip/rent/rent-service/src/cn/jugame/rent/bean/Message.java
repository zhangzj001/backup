package cn.jugame.rent.bean;

public class Message {
    //------------------------------------------------------------------
    /**
     * 消息状态：已读
     */
    public final static int MESSAGE_STATUS_READ = 2;
    /**
     * 消息状态：未读
     */
    public static final int MESSAGE_STATUS_UNREAD = 1;
    /**
     * 消息状态：不可见
     */
    public static final int MESSAGE_STATUS_INVALID = 0;


    /**
     * 消息任务状态：新建
     */
    public static final int MESSAGETASK_STATUS_NEW = 0;
    /**
     * 消息任务状态：已同步
     */
    public static final int MESSAGETASK_STATUS_SEND = 2;
    /**
     * 消息任务：启用
     */
    public static final int MESSAGETASK_STATUS_ENABLED = 1;
    /**
     * 消息任务：停用
     */
    public static final int MESSAGETASK_STATUS_DISABLED = 0;

    /**
     * 消息类型：订单消息
     */
    public final static int MESSAGE_TYPE_ORDER = 1;
    /**
     * 消息类型：优惠券消息
     */
    public static final int MESSAGE_TYPE_COUPON = 2;
    /**
     * 消息类型：系统消息
     */
    public static final int MESSAGE_TYPE_SYSTEM = 3;
}
