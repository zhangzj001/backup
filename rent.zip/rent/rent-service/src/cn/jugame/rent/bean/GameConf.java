package cn.jugame.rent.bean;

import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by zimT_T on 2017/9/27.
 */
public class GameConf {

    /** 类型：游戏 */
    public static final int TYPE_GAME = 1;

    /** 类型：VIP */
    public static final int TYPE_VIP = 2;

    /** 类型：CDK */
    public static final int TYPE_CDK = 4;

    /** 类型：端游 */
    public static final int TYPE_PC_GAME = 5;

    //------------------------------------------------------------------
    /** 状态：上线 */
    public static final int STATUS_ENABLE = 1;

    /** 状态：下线 */
    public static final int STATUS_DISABLE = 0;

    //------------------------------------------------------------------
    /** 标记为热游 */
    public static final int TAG_HOT = 1;

    /** 标记为普通游戏/普通账号 */
    public static final int TAG_NORMAL = 0;


    /**游戏配置的关键词状态：不启用 */
    public static final int KEYWORD_INVALID = 0;

    /**游戏配置的关键词状态：启用 */
    public static final int KEYWORD_VALID = 1;
    
    /** 该游戏类型是否支持求助   支持 **/
    public static final int SUPPORT_HELP_YES = 1;
    
    /** 该游戏类型是否支持求助   不支持 **/
    public static final int SUPPORT_HELP_NO = 0;
    
    /**
     * 获取游戏配置的关键词
     * @param gameId
     * @return
     */
    public static List<Map<String,String>> getGameKeywords(String gameId){
        Record gameKeywords = SmartDb.findFirst("SELECT *  FROM game_keyword WHERE game_id = ? and status = ? ",gameId, KEYWORD_VALID);
        List<Map<String,String>> gameKeywordsList = new LinkedList<>();
        if(gameKeywords != null && gameKeywords.get("keyword") != null && gameKeywords.get("url") != null){
            String[] keywords = gameKeywords.getStr("keyword").split(",");
            for(String ky : keywords){
                Map<String,String> keywordBox = new HashMap<>();
                keywordBox.put("keyword",ky);
                keywordBox.put("keyword_url", gameKeywords.getStr("url").replace("{$keyword}",ky).replace("{$game_id}",gameId));
                gameKeywordsList.add(keywordBox);
            }
        }
        return gameKeywordsList;
    }
}
