package cn.jugame.rent.bean;

public class Index {
	/**app 首页  banner**/
	public static final String RENT_APP_BANNER = "rent_app_banner";
	
	/**ios 首页  banner**/
	public static final String RENT_IOS_BANNER = "rent_ios_banner";
	
	/**wap 首页  banner**/
	public static final String RENT_WAP_BANNER = "rent_wap_banner";
	
}
