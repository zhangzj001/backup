package cn.jugame.rent.bean;

public class Mall {
	/** 商城商品类型：租号优惠券 */
	public static final int TYPE_BEAN_COUPON = 1;
	
	/** 商城商品类型：RMB租号券 */
	public static final int TYPE_RMB_COUPON = 2;

	/** 流量券 */
	public static final int TYPE_DATA_TRAFFIC_COUPON = 3;
	
}
