package cn.jugame.rent.bean;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.account_center.service.vo.UserAuthInfo;
import cn.jugame.pay.http.api.Authentication;
import cn.jugame.rent.utils.*;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.List;

public class User {
    private static Logger logger = Loggers.rentLog();

    /**
     * 封禁租号行为
     */
    public static final int TYPE_FORBIDDEN = 1;

    /**
     * 取消租号手续费
     */
    public static final int TYPE_NO_FEE = 2;

    /**
     * 禁止发布商品
     */
    public static final int TYPE_NO_PRODUCT = 3;

    /**
     * 免审核
     */
    public static final int TYPE_NO_VERIFY = 4;

    //---------------------------------------------------------------------
    /**
     * 卖家等级：普通号主
     */
    public static final int SELL_LEVEL_NORMAL = 0;

    /**
     * 卖家等级：银牌号主
     */
    public static final int SELL_LEVEL_SILVER = 1;

    /**
     * 卖家等级：金牌号主
     */
    public static final int SELL_LEVEL_GOLD = 2;

    /**
     * 号主升级申请通过
     **/
    public static final int SELL_UPGRADELEVEL_PASS = 1;
    /**
     * 号主升级申请新建
     **/
    public static final int SELL_UPGRADELEVEL_NEW = 0;

    /**
     * 号主升级申请不通过
     **/
    public static final int SELL_UPGRADELEVEL_FAIL = 2;

    /**
     * 号主自动升级
     **/
    public static final int SELL_LEVEL_AUTOMANAGE = 1;

    /**
     * 号主手动升级
     **/
    public static final int SELL_LEVEL_MANUAL = 0;

    /**
     * 是否领取新人礼包：是
     **/
    public static final int USER_HAS_NEWCOMER_GIFT = 1;
    /**
     * 是否领取新人礼包：否
     **/
    public static final int USER_NOT_NEWCOMER_GIFT = 0;

    /***号主是否支持商品扶持:是***/
    public static final int USER_IS_SUPPORT = 1;

    /***号主是否支持商品扶持:否***/
    public static final int USER_IS_NOT_SUPPORT = 0;

    /**
     * 是否加入商品临河
     * /**
     * 获取当前用户是否处于type指定的状态中
     *
     * @param uid
     * @param type
     * @return
     */
    public static Record userSpecial(int uid, int type) {
        String now = Common.now();
        Record row = SmartDb.findFirst("select * from `user_special` where `uid`=? and `type`=? and `beg_time`<=? and `end_time`>=?", uid, type, now, now);
        return row;
    }

    /**
     * 添加用户特殊控制标识
     *
     * @param buyuserUid
     * @param type
     * @param begDate
     * @param endDate
     * @param remark
     * @return
     */
    public static boolean addUserSpecial(int buyuserUid, int type, String begDate, String endDate, String remark) {
        Record u = new Record();
        u.set("uid", buyuserUid);
        u.set("type", type);
        u.set("c_time", Common.now());
        u.set("beg_time", begDate);
        u.set("end_time", endDate); //暂时统一封禁1000天
        u.set("remark", remark);
        return SmartDb.save("user_special", u);
    }

    /**
     * 获取用户信息，如果没有则会自动加锁创建一条记录
     *
     * @param uid
     * @return
     */
    public static Record getMember(int uid) {
        DistLocker locker = new DistLocker(uid + "_initMember");
        locker.lock(PropKit.getInt("displock.timeout"));
        try {
            Record row = SmartDb.findFirst("select * from `member` where `uid`=?", uid);
            if (row == null) {
                //没有记录的话就创建一条
                row = new Record();
                row.set("uid", uid);
                row.set("reputation_score", 100); //调高10分，然后再每天降1分降到100，可以让新用户的商品排名靠前！
                row.set("play_score", 100);
                row.set("c_time", Common.now());
                row.set("promote_uid", 0);
                row.set("has_promote_gift", 0);
                row.set("sell_level", SELL_LEVEL_NORMAL);
                if (!SmartDb.save("member", row)) {
                    logger.error("新建用户失败了，uid=>" + uid + ", sql=>" + SmartDb.lastQuery());
                }
            }

            //新建的用户项，重新从数据库获取一次
            row = SmartDb.findFirst("select * from `member` where `uid`=?", uid);

            return row;
        } catch (Throwable e) {
            logger.error("initMember.error", e);
            return null;
        } finally {
            locker.unlock();
        }
    }

    /**
     * 获取卖家信誉分（如果数据没有记录则初始化一条）
     *
     * @param sellerUid
     * @return
     */
    public static int getSellerReputationScore(int sellerUid) {
        Record row = getMember(sellerUid);
        if (row == null)
            return 100;
        return row.getInt("reputation_score");
    }

    /**
     * 扣减卖家信誉分
     *
     * @param sellerUid
     * @param score
     */
    public static void decreaseReputationScore(int sellerUid, int score, String remark) {
        Record row = getMember(sellerUid);
        if (row == null)
            return;

        //自营UID不设置
        if (isSelfUid(sellerUid))
            return;

        int repuScore = row.getInt("reputation_score") - score;
        if (repuScore < 0) {
            repuScore = 0;
            remark += "（信誉分已降至0）";
        }
        row.keep("uid");
        row.set("reputation_score", repuScore);
        SmartDb.update("member", "uid", row);

        //记录日志
        saveScoreLog("reputation_score", sellerUid, remark);
    }

    /**
     * 增加卖家信誉分
     *
     * @param sellerUid
     * @param score
     */
    public static void increaseReputationScore(int sellerUid, int score, String remark) {
        Record row = getMember(sellerUid);
        if (row == null)
            return;

        //自营UID不设置
        if (isSelfUid(sellerUid))
            return;

        int repuScore = row.getInt("reputation_score") + score;
        if (repuScore > 100) {
            repuScore = 100;
            remark += "（信誉分已满）";
        }
        row.keep("uid");
        row.set("reputation_score", repuScore);
        SmartDb.update("member", "uid", row);

        //记录日志
        saveScoreLog("reputation_score", sellerUid, remark);
    }

    /**
     * 获取用户当天的自助撤单次数
     *
     * @return
     */
    public static int getSelfCancelCount(int buyuserUid) {
        String key = selfCancelKey(buyuserUid);
        return (int) CacheUtil.getCount(key);
    }

    /**
     * 用户当天的自助撤单次数+1
     *
     * @param buyuserUid
     */
    public static void increaseSelfCancelCount(int buyuserUid) {
        String key = selfCancelKey(buyuserUid);
        CacheUtil.addCount(key, 1);
    }

    private static String selfCancelKey(int buyuserUid) {
        return buyuserUid + "_" + Common.now("yyyy-MM-dd") + "_cancelOrder";
    }

    /**
     * 获取玩家信誉分
     *
     * @param buyuserUid
     * @return
     */
    public static int getBuyuserPlayScore(int buyuserUid) {
        Record row = getMember(buyuserUid);
        if (row == null)
            return 100;
        return row.getInt("play_score");
    }


    /**
     * 扣减玩家信誉分
     *
     * @param buyuserUid
     * @param score
     */
    public static void decreasePlayScore(int buyuserUid, int score, String remark) {
        decreasePlayScoreProxy(buyuserUid, score, remark, "玩家信誉分已扣至0分，封禁1000天");
    }

    /**
     * 扣减玩家信誉分
     *
     * @param buyuserUid
     * @param score
     */
    public static void decreasePlayScoreProxy(int buyuserUid, int score, String remark, String userRemark) {

        Record row = getMember(buyuserUid);
        if (row == null)
            return;

        //最多降到0
        int playScore = row.getInt("play_score") - score;
        if (playScore <= 0) {
            playScore = 0;
            remark += "（信誉分已降为0）";

            //买家信誉分掉到0，顺便判处无期徒刑
            if (null == User.userSpecial(buyuserUid, User.TYPE_FORBIDDEN)) {
                String now = Common.now();
                if (!User.addUserSpecial(buyuserUid, User.TYPE_FORBIDDEN, now, Common.addDay(now, 1000), userRemark)) {
                    logger.error("玩家信誉分扣至0分后执行买家封禁失败了");
                }
            }
        }

        row.keep("uid");
        row.set("play_score", playScore);
        SmartDb.update("member", "uid", row);

        //记录日志
        saveScoreLog("play_score", buyuserUid, remark);
    }

    /**
     * 增加玩家信誉分
     *
     * @param buyuserUid
     * @param score
     */
    public static void increasePlayScore(int buyuserUid, int score, String remark) {
        Record row = getMember(buyuserUid);
        if (row == null)
            return;

        int playScore = row.getInt("play_score") + score;
        if (playScore > 100) {
            playScore = 100;
            remark += "（信誉分已满）";
        }

        row.keep("uid");
        row.set("play_score", playScore);
        SmartDb.update("member", "uid", row);

        //记录日志
        saveScoreLog("play_score", buyuserUid, remark);
    }

    private static void saveScoreLog(String type, int uid, String content) {
        Record log = new Record();
        log.set("uid", uid);
        log.set("type", type);
        log.set("c_time", Common.now());
        log.set("content", content);
        SmartDb.save("user_score_log", log);
    }

    /**
     * 判断是否为自营UID
     *
     * @param uid
     * @return
     */
    public static boolean isSelfUid(Integer uid) {
        if (uid == null)
            return false;
        String conf = PropKit.get("self_uid");
        if (StringUtils.isBlank(conf))
            return false;
        String[] ss = Common.array_filter(conf.split(","));

        return Common.in(String.valueOf(uid), ss);
    }

    /**
     * 判断是否为新手礼包用户
     *
     * @param uid
     * @return
     */
    public static boolean isNewcomerGiftUser(int uid) {
        boolean isNewUser = false;
        Record order = SmartDb.findFirst("select * from `order` where buyuser_uid = ?", uid);
        Record user = SmartDb.findFirst("select * from member m  where m.uid = ? and m.has_newcomer_gift = ?  ", uid, User.USER_HAS_NEWCOMER_GIFT);
        if (user == null && order == null) {
            isNewUser = true;
        }
        return isNewUser;
    }

    /**
     * 判断是否为新手礼包用户
     *
     * @param uid
     * @return
     */
    public static boolean isNewcomerReceiveGiftUser(int uid) {
        boolean isNewUser = false;
        Record order = SmartDb.findFirst("select * from `order` where buyuser_uid = ?", uid);
        Record user = SmartDb.findFirst("select * from member m  where m.uid = ? and  has_newcomer_gift = ?", uid, User.USER_HAS_NEWCOMER_GIFT);
        logger.info("user=========" + user);
        logger.info("order=====" + order);
        if (user != null && order == null) {
            isNewUser = true;
        }
        return isNewUser;
    }

    /**
     * 判断是否为新用户
     *
     * @param uid
     * @return
     */
    public static boolean isNewcomer(int uid) {
        boolean isNewUser = false;
        Record order = SmartDb.findFirst("select * from `order` where buyuser_uid = ?", uid);
        if (order == null) {
            isNewUser = true;
        }
        return isNewUser;
    }

    /**
     * 判断用户是否领取新手礼包
     *
     * @param uid
     * @return
     */
    public static boolean hadNewcomerGift(int uid) {
        Record user = SmartDb.findFirst("select * from member where has_newcomer_gift = ? and uid = ?", User.USER_HAS_NEWCOMER_GIFT, uid);
        return user == null ? false : true;
    }

    /**
     * 判断用户新手礼包是否使用完
     *
     * @param uid
     * @return
     */
    public static boolean hadNewcomerGiftLeft(int uid) {
        boolean hadNewcomerGiftLeft = false;
        Record user = SmartDb.findFirst("SELECT * FROM user_coupon u LEFT JOIN coupon c ON u.`coupon_id` = c.`coupon_id` WHERE u.`status` = ? AND u.end_date > NOW() AND u.left_times > 0 AND u.uid = ? AND c.action_type = ?", Coupon.STATUS_ONSALE, uid, PropKit.get("newcomer.gift", "newcomer"));
        if (hadNewcomerGift(uid) && user != null) {
            hadNewcomerGiftLeft = true;
        }
        return hadNewcomerGiftLeft;
    }

    /**
     * 是否开启用户新人礼包领取入口
     *
     * @param uid
     * @return
     */
    public static boolean newcomerGiftValid(int uid) {
        boolean isNewcomerGiftUser = (uid == 0 || User.isNewcomerGiftUser(uid));
        List<Record> newcomerGift = Coupon.getNewcomerGift();
        return (isNewcomerGiftUser && newcomerGift != null && newcomerGift.size() > 0) || (uid != 0 && User.hadNewcomerGift(uid) && User.hadNewcomerGiftLeft(uid));

    }


    public static String getBindMobile(int uid) {
        IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
        String mobile = null;
        //获取平台用户信息
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        } catch (Exception e) {
            logger.error("error", e);
            return mobile;
        }

        if (bean == null || bean.getCode() != MemberBean.OK || bean.getData() == null) {
            logger.info("验证是否绑定手机号码失败，从平台获取用户信息失败，uid【" + uid + "】");
            if (bean != null) {
                logger.info("平台返回信息【" + bean.getMsg() + "】");
            }
            return mobile;
        }

        cn.jugame.account_center.service.vo.Member member = (Member) bean.getData();
        if (StringUtils.isNotBlank(member.getMobile())) {
            mobile = member.getMobile();
        }
        return mobile;
    }

    /**
     * 判断是否已实名认证
     *
     * @param uid
     * @return true-已认证    false-未认证
     */
    public static boolean checkBindRealName(int uid) {
        Authentication authentication = new Authentication("setting.properties");
        String str = authentication.checkUserHasAuthed(String.valueOf(uid));
        logger.info("调用平安实名认证返回的信息，uid【" + uid + "】 -- 【" + str + "】");
        JSONObject jsonObject = JSONObject.fromObject(str);
        //返回1 表示平安接口已经实名认证了
        if (jsonObject.getInt("code") == 1) {
            logger.info("uid【" + uid + "】已经在支付实名认证");
            return true;
        } else {
            logger.info("uid【" + uid + "】支付接口没有实名认证，返回msg【" + jsonObject.getString("msg"));
        }
        IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
        MemberBean<UserAuthInfo> memberBean = accountCenterService.getUserAuthInfo(uid);
        if (memberBean == null || memberBean.getData() == null ||
                StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())) {
            return false;
        }
        return true;
    }

    /**
     * 获取号主升级的级别
     */
    public static int getSellerUpgradeLevel(int sellerUid, double succOrderRate, double score, int currLevel) {
        //1.获取用户号主综合评分和成单率
        int sellerUpgradeLevel = 0;
        if (User.getSellerReputationScore(sellerUid) < PropKit.getInt("seller.sign_reputation_score")) {
            return sellerUpgradeLevel;
        }
        if (succOrderRate >= Double.parseDouble(PropKit.get("seller.silver_upper_order_rate")) && score >= PropKit.getInt("seller.silver_upper_bound")) {
            sellerUpgradeLevel = User.SELL_LEVEL_SILVER;
        }

        if (succOrderRate >= Double.parseDouble(PropKit.get("seller.gold_upper_order_rate")) && score >= PropKit.getInt("seller.gold_upper_bound")) {
            sellerUpgradeLevel = User.SELL_LEVEL_GOLD;
        }

        if (currLevel >= sellerUpgradeLevel) {
            sellerUpgradeLevel = -1;
        }
        return sellerUpgradeLevel;
    }
}
