package cn.jugame.rent.bean;


import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.Iterator;
import java.util.List;

public class Product {

	private static Logger logger = Loggers.rentLog();

	/** 待审核 */
	public static final int STATUS_VERIFY = 3;
	/** 上架 */
	public static final int STATUS_ONSALE = 7;
	/** 下架 */
	public static final int STATUS_OFFSALE = 8;
	/** 出租中 */
	public static final int STATUS_RENT = 201;
	/** 保护中，订单完成后提供商品一小段时间的保护期以方便号主修改密码，此时期内不允许下单，但是可以由号主直接解除并上线 */
	public static final int STATUS_PROTECTED = 202;
	/** 商品已删除**/
	public static final int STATUS_DELETE = 999;
	//-------------------------------------------------------
	/** 用户截图 */
	public static final int PIC_TYPE_USER = 1;
	/** 系统截图 */
	public static final int PIC_TYPE_SYSTEM = 2;

	//-------------------------------------------------------
	/** 租赁方式：时租 */
	public static final int RENT_TYPE_HOUR = 1;
	/** 租赁方式：日租 */
	public static final int RENT_TYPE_DAY = 2;
	/** 租赁方式：长租 */
	public static final int RENT_TYPE_LONGTERM = 3;
	/** 租赁方式：包夜 */
	public static final int RENT_TYPE_NIGHT = 4;
	/** 租赁方式：一口价 */
	public static final int RENT_TYPE_FIXED_PRICE = 5;

	//-------------------------------------------------------
	/** 商品分类：游戏（手游） */
	public static final int PRODUCT_TYPE_GAME = 1;
	/** 商品分类：会员 */
	public static final int PRODUCT_TYPE_VIP = 2;
	/** 商品分类：CDK */
	public static final int PRODUCT_TYPE_CDK = 4;
	/** 商品分类：游戏（端游） */
	public static  final int PRODUCT_TYPE_PCGAME = 5;
	//-------------------------------------------------------
	/** 押金类型：号主押金 */
	public static final int GUARANTEE_DEPOSIT_TYPE_USER = 1;
	/** 押金类型：平台押金 */
	public static final int GUARANTEE_DEPOSIT_TYPE_PLATFORM = 2;

	//-------------------------------------------------------
    /** 举报类型：未处理 */
    public static final int REPORT_WAITING = 0;
    /** 举报类型：已处理 */
    public static final int REPORT_FINISH = 1;

    //-------------------------------------------------------
    /** CDK状态：未使用 */
    public static final int CDK_STATUS_VALID = 0;

    /** CDK状态：已使用 */
    public static final int CDK_STATUS_USED = 1;

    /** CDK状态：已锁定 */
    public static final int CDK_STATUS_LOCKED = 100;


    /** 登录模式：账号密码登录**/
    public static final int LOGIN_ACCOUNTPASSWORD =1;

	/** 登录模式：端游账号登号器自动登录**/
	public static final int LOGIN_PC_AUTOKIT = 2;

	/** 登录模式：手游账号登号器自动登录**/
	public static final int LOGIN_MOBILE_AUTOKIT = 3;


	/**保证金状态：新建 **/
	public static final int GUNRANTEE_AMOUNT_STATUS_NEW = 0;

	/**保证金状态：已支付 **/
	public static final int GUNRANTEE_AMOUNT_STATUS_PAYED = 1;

	/**保证金状态：已退款 **/
	public static final int GUNRANTEE_AMOUNT_STATUS_REFUNDED = 2;
	
	/**保证金状态：已扣除*/
	public static final int GUNRANTEE_AMOUNT_STATUS_DEDUCTED = 3;
	
	
	/** 商品装饰支付状态：新建  **/
	public static final int DECORATE_PAYMENT_STATUS_NEW = 0;
	
	/** 商品装饰支付状态：已支付  **/
	public static final int DECORATE_PAYMENT_STATUS_PAYED = 1;
	
	/** 商品装饰支付状态：已退款  **/
	public static final int  DECORATE_PAYMENT_STATUS_REFUNDED  = 2;
	
	/**保证金状态：已失效 **/
	public static final int DECORATE_PAYMENT_STATUS_INVALID  = 3;

	/**推荐商品 **/
	public static final int PRODUCT_RECOMMEND = 1;
	
	//------------------------------------------------------------
	/** 渠道所属平台：Android */
	public static final int CHANNEL_PLATFORM_ANDROID = 1;
	
	/** 渠道所属平添：IOS */
	public static final int CHANNEL_PLATFORM_IOS = 2;
	
	/** 渠道所属平台：PC */
	public static final int CHANNEL_PLATFORM_PC = 3;
	
	
	/**  商品扶持类型：无扶持 **/
	public static final int SUPPORT_TYPE_NO_SUPPORT = 0;
	
	/**  商品扶持类型：普通号主扶持 **/
	public static final int SUPPORT_TYPE_SUPPORTED = 1;
	
	/**  商品扶持类型：扶持商品不满足条件**/
	public static final int SUPPORT_TYPE_DISSATISFY = 2;
	
	/**  商品扶持类型：扶持审核中 **/
	public static final int SUPPORT_TYPE_VERIFY = 999;
	
	/** 视频VIP登录方式  手机号码登录  **/
	public static final int VIP_LOGIN_TYPE_MOBILE = 1;
	
	/** 视频VIP登录方式  QQ登录  **/
	public static final int VIP_LOGIN_TYPE_QQ = 2;
	
	/** 视频VIP登录方式  微信登录  **/
	public static final int VIP_LOGIN_TYPE_WECHAT = 3;
	
	/** 视频VIP登录方式  微博登录  **/
	public static final int VIP_LOGIN_TYPE_BLOG = 4;
	
	/** 视频VIP登录方式  手机号码登录 中文显示 **/
	public static final String VIP_LOGIN_TYPE_MOBILE_CN ="手机号码登录";
	
	/** 视频VIP登录方式  QQ登录  中文显示**/
	public static final String VIP_LOGIN_TYPE_QQ_CN ="QQ登录";
	
	/** 视频VIP登录方式  微信登录  中文显示**/
	public static final String VIP_LOGIN_TYPE_WEBCHAT_CN ="微信登录";
	
	/** 视频VIP登录方式  微博登录  中文显示**/
	public static final String VIP_LOGIN_TYPE_BLOG_CN ="微博登录";
	
	
	/** 反馈  问题类型   游戏反馈**/
	public static final int SUGGESTION_CATEGORY_ID = 5;
	
	/** 反馈  反馈来源   租号**/
	public static final int SUGGESTION_SOURCE = 2;
	
	/** 反馈  是否已处理  未处理**/
	public static final int SUGGESTION_IS_HANDLED = 1;

	/** 信誉分 扶持商品最低信誉分 **/
	public static final int SUPPORT_REPUTATION_SCORE_MIN=94;
	
	/** 是否有商品装扮   否 **/
	public static final int PRODUCT_NO_DECORATE = 0;
	
	/** 是否有商品装扮   是 **/
	public static final int PRODUCT_DECORATE = 1;

	/**
	 * 当前是否存在非下架的商品
	 * @param sellerUid
	 * @param gameId
	 * @param channelId
	 * @param gameLoginId
	 * @return
	 */
	public static boolean isDuplicateProduct(int productType, int sellerUid, String gameId, String channelId, String gameLoginId, String productId){
		List<Record> rows = null;
		int max = 1;
		if(productType == Product.PRODUCT_TYPE_VIP){
			//会员VIP没有channel_id
			rows = SmartDb.find("select * from `product` where `seller_uid`=? and `game_id`=? and `game_login_id`=? and `status` not in (?,?)",
					sellerUid, gameId, gameLoginId, Product.STATUS_OFFSALE,Product.STATUS_DELETE);
		}else{
			rows = SmartDb.find("select * from `product` where `seller_uid`=? and `game_id`=? and `channel_id`=? and `game_login_id`=? and `status` not in (?,?)",
					sellerUid, gameId, channelId, gameLoginId, Product.STATUS_OFFSALE,Product.STATUS_DELETE);
		}

		if(rows.size() > max)
			return true;
		//但如果商品ID不在这几个商品之中的一个，也说明是重复上架了！
		if(rows.size() == max && !inProduct(rows, productId))
			return true;

		return false;
	}

	private static boolean inProduct(List<Record> rows, String productId){
		for(Record row : rows){
			if(row.getStr("product_id").equalsIgnoreCase(productId))
				return true;
		}
		return false;
	}

	/**
	 * 商品上架
	 * @param productId 商品ID
	 * @param sellerUid 卖家UID，用于获取其信誉分
	 * @param isVerify 是否因审核而上架
	 * @return
	 */
	public static boolean onsale(String productId, int sellerUid, boolean isVerify){
		String now = Common.now();

		Record product = new Record();
		product.set("product_id", productId);
		product.set("status", Product.STATUS_ONSALE);
		product.set("onsale_time", now);
		product.set("modify_time", now);
		if(isVerify){
			product.set("verify_time", now);
		}

		//自动重新上架时，更新一下卖家信誉分
		Record member = User.getMember(sellerUid);
		product.set("reputation_score", member.getInt("reputation_score"));
		//如果是端游，则用端游的号主等级，其他一律用手游的号主等级
		Record row = SmartDb.findFirst("select * from product where product_id = ?",productId);
		if(row.getInt("product_type")==Product.PRODUCT_TYPE_PCGAME)
			product.set("sell_level", member.getInt("pc_sell_level"));
		else
		    product.set("sell_level", member.getInt("sell_level"));

		if(!SmartDb.update("product", "product_id", product)){
			logger.error("商品上架失败了，productId=>" + product.getStr("product_id") + ", sql=>" + SmartDb.lastQuery());
			return false;
		}

		// 将账号添加到交易黑名单
		product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product != null){
			addBlacklist(product.getStr("game_login_id"), product.getStr("channel_id"), product.getStr("channel_name"));
		}else{
			logger.error("onsale: 发生了诡异的一幕，商品不见了！！！productId=>" + productId);
		}

		return true;
	}

	/**
	 * 下架商品
	 * @param productId 商品ID
	 * @param reason 下架原因
	 * @param isVerify 是否因审核才下架的
	 * @return
	 */
	public static boolean offsale(String productId, String reason, boolean isVerify){
		String now = Common.now();
		Record product = new Record();
		product.set("product_id", productId);
		product.set("modify_time", now);
		product.set("offsale_time", now);
		if(isVerify){
			product.set("verify_time", now);
		}
		product.set("offsale_reason", reason);
		product.set("status", Product.STATUS_OFFSALE);
		if(!SmartDb.update("product", "product_id", product)){
			logger.error("下架商品失败了，productId=>" + productId + ", sql=>" + SmartDb.lastQuery());
			return false;
		}

		// 将账号从交易黑名单移除！
		product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product != null){
			removeBlacklist(product.getStr("game_login_id"), product.getStr("channel_id"));
		}else{
			logger.error("offsale: 发生了诡异的一幕，商品不见了！！！productId=>" + productId);
		}

		return true;
	}

	private static void addBlacklist(String account, String channelId, String channelName){
		Record row = SmartDb.findFirst("select * from `account_blacklist` where `account`=? and `channel_id`=?", account, channelId);
		if(row != null)
			return;

		row = new Record();
		row.set("account", account);
		row.set("channel_id", channelId);
		row.set("channel_name", channelName);
		row.set("c_date", Common.now());
		SmartDb.save("account_blacklist", row);
	}

	private static void removeBlacklist(String account, String channelId){
		SmartDb.update("delete from `account_blacklist` where `account`=? and `channel_id`=?", account, channelId);
	}

	/**根据商品id或者商品推广id获取商品**/
	public static Record getProduct(String productId){
		Record product = SmartDb.findFirst("select * from product where product_id=?", productId);
		if(product == null){
			product = SmartDb.findFirst("select * from product where product_promote_id=?", productId);
		}
		return product;
	}

	/**扣除商品保证金**/
	public static boolean deductedSellerGuaranteeAmount(String productId){
		Record product = SmartDb.findFirst("select * from `product` where product_id=?", productId);
		if(product == null){
			logger.error("扣除保证金时对应的商品【" + productId + "】不存在！");
			return false;
		}
		
		if(product.getInt("seller_guarantee_amount") <= 0) {
			logger.info("商品【"+productId+"】已经没有保证金了，不用扣了");
			return false;
		}

        int result = SmartDb.update(
                "update `product` set `seller_guarantee_amount` = ?, `fee_rate_discount` = ? , seller_guarantee_deducted_time = ? where `product_id` = ?",
                0, 1.0, Common.now(), productId);
        if (result == 0) {
            logger.error("扣除商品保证金失败：" + productId);
            return false;
		}
		
		//从保证金订单中找到最后一条已支付的保证金订单
		Record gaOrder = SmartDb.findFirst("select * from `guarantee_amount_order` where `product_id`=? and `status`=? order by `id` desc limit 1", 
				productId, Product.GUNRANTEE_AMOUNT_STATUS_PAYED);
		if(gaOrder == null){
			logger.error("扣除保证金时没有找到对应的保证金订单，productId=>" + productId);
			return false;
		}
		
		String payId = gaOrder.getStr("pay_id");
		int amount = gaOrder.getInt("amount");
		//将保证金订单改成已扣除状态
		gaOrder.keep("id");
		gaOrder.set("status", Product.GUNRANTEE_AMOUNT_STATUS_DEDUCTED);
		if(!SmartDb.update("guarantee_amount_order", "id", gaOrder)){
			logger.error("扣除保证金时更新保证金订单失败了！productId=>" + productId + ", payId=>" + payId);
			return false;
		}
		
		return PaymentFactory.get().deductGuarantee(product, payId, amount);
	}

	/**删除商品**/
	public static boolean deleteProduct(String productId){
		int result = SmartDb.update("update `product` set `status` = ? , `seller_guarantee_amount` = ? , `fee_rate_discount` = ? where `status` = ? and `product_id` = ?",
				Product.STATUS_DELETE,0,1.0,Product.STATUS_OFFSALE,productId);
		if(result == 0){
			logger.error("删除商品失败："+productId);
			return false;
		}
		return true;
	}

    /**
     * 用户请求商品列表时的排序ID
     * @param controller
     * @return
     */
	public static Integer getSortId(Controller controller){
		try{
			String sortId = controller.getCookie("sortid");
			if(StringUtils.isBlank(sortId)){
				//如果cookie没有，就从session获取
				sortId = controller.getSessionAttr("sortid");
			}
			if(StringUtils.isBlank(sortId)){
				return null;
			}
			
			return Integer.parseInt(sortId);
		}catch(Exception e){
			return null;
		}
	}
	
	/***
	 * 如果uid不在数组uids中，则对uid隐藏vipGameIds中的视频商品
	 * @param uids
	 * @param vipGameIds
	 * @param rows
	 * @param uid
	 */
	public static void hiddenVipProduct(String[] uids,String[] vipGameIds,List<Record> rows,String uid) {
		if(!Common.arrayContainsString(uids, uid.toString())) {
			Iterator it = rows.iterator();
			while(it.hasNext()) {
				Record row = (Record) it.next();
				if(Common.arrayContainsString(vipGameIds, row.getStr("game_id"))) {
					it.remove();
				}
			}
		}
	}

    /**
     * 判断用户当前商品数量是否超过了限制。
     * @param uid
     * @param immuneProducts 豁免商品ID（豁免的商品不参与商品限制计数）
     * @return
     */
	public static boolean tooManyProducts(int uid, List<String> immuneProducts){
	    Record member = SmartDb.findFirst("select * from member where uid=?", uid);
	    //异常情况，交给外部逻辑去处理
	    if(member == null)
	        return false;

	    int sellLevel = member.getInt("sell_level");
	    if(sellLevel != User.SELL_LEVEL_NORMAL)
	        return false;

	    //普通号主的限制
        String sql = "select count(id) as _count from `product` where `status` not in (?, ?) and `seller_uid`=?";
        if(immuneProducts != null && immuneProducts.size() > 0){
            sql += " and product_id not in ('" + Common.join(immuneProducts.toArray(new String[0]), "','") + "')";
        }
        Record row = SmartDb.findFirst(sql, Product.STATUS_OFFSALE, Product.STATUS_DELETE, uid);
        return row.getInt("_count") >= PropKit.getInt("product.max_product_count");
    }
}
