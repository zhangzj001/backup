package cn.jugame.rent.bean;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.google.common.collect.Lists;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.slf4j.Logger;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class Order {
	private static Logger logger = Loggers.rentLog();

	/** 新建状态 */
	public final static int ORDER_STATUS_NEW = 0;
	
	/** 支付中（续租时使用） */
	public final static int ORDER_STATUS_PAYING = 100;
	
	/** 已支付/已出租 */
	public final static int ORDER_STATUS_PAID = 2;
	
	/** 订单完成 */
	public final static int ORDER_STATUS_FINISH = 6;
	
	/** 订单取消 */
	public final static int ORDER_STATUS_CANCEL = 8;

    /**
     * 复合订单状态：待处理（用于筛选）
     */
    public final static int ORDER_IN_SOLVE = 888;

    /**
     * 复合订单状态：售后处理（用于筛选）
     */
    public final static int ORDER_IN_ARBITRATE = 999;
	
	//--------------------------------------------------------
	/** 订单还未支付 */
	public final static int ORDER_NOT_PAY = 0;
	
	/** 订单已支付 */
	public final static int ORDER_PAID = 1;
	
	//--------------------------------------------------------
	/** 订单未退款 */
	public final static int ORDER_NOT_REFUND = 0;
	
	/** 订单已退款 */
	public final static int ORDER_REFUNDED = 1;
	
	//--------------------------------------------------------
	/** 订单未被动终止 */
	public final static int ORDER_NOT_TERMINATED = 0;
	
	/** 订单被动终止 */
	public final static int ORDER_TERMINATED = 1;
	
	//--------------------------------------------------------
	/** 首租 */
	public final static int ORDER_RELET_FIRST = 1;
	/** 续租 */
	public final static int ORDER_RELET_CONTINUE = 2;
	
	//--------------------------------------------------------
	/** 买家申诉（自助撤单） */
	public final static int BUYUSER_ARBITRATION = 1;
	
	/** 无买家申诉（无自助撤单） */
	public final static int BUYUSER_NO_ARBITRATE = 0;
	
	/** 买家自动撤单（抢单失败撤单） */
	public final static int BUYUSER_COMPETITION_FAIL = 2;

    /** 买家自动撤单（号主求助超时未响应撤单） */
    public final static int BUYUSER_ASKHELP_TIMEOUT = 3;

    /** 买家自动撤单（向第三方下单失败撤单） */
    public final static int BUYUSER_ORDERREQUEST_FAIL = 4;

    //--------------------------------------------------------
	/** 卖家仲裁（自助仲裁） */
	public final static int SELLUSER_ARBITRATE = 1;

	/** 无卖家仲裁（无自助仲裁） */
	public final static int SELLUSER_NO_ARBITRATE = 0;
	
	/** 卖家确认撤单 */
	public final static int SELLUSER_CONFIRM_CANCEL = 2;
	
	/** 卖家仲裁失败 */
	public final static int SELLUSER_ARBITRATE_FAIL = 100;
	
	/** 卖家仲裁成功 */
	public final static int SELLUSER_ARBITRATE_SUCC = 200;
	
	
	//--------------------------------------------------------
	/** 撤单证据类型：买家撤单 */
	public final static int EVIDENCE_TYPE_BUYUSER = 1;
	
	/** 撤单证据类型：卖家仲裁 */
	public final static int EVIDENCE_TYPE_SELLUSER = 2;
	
	
	//--------------------------------------------------------
	/** 仲裁审核：等待审核 */
	public final static int EVIDENCE_ARBITRATE_WAITING = 0;
	
	/** 仲裁审核：不通过仲裁 */
	public final static int EVIDENCE_ARBITRATE_FAIL = 1;
	
	/** 仲裁审核：支持仲裁 */
	public final static int EVIDENCE_ARBITRATE_SUCC = 2;

	/** 惩罚方式:支持仲裁扣除押金和买家信誉分**/
	public final static int PUNISHMENT_ALL_BUYER = 1;

    /** 惩罚方式:支持仲裁不惩罚买家**/
    public final static int PUNISHMENT_DO_NOTHING = 2;

    /** 惩罚方式:支持仲裁扣除买家信誉分**/
    public final static int PUNISHMENT_DECREASE_BUYERSCORE = 3;

    //--------------------------------------------------------
    /** 订单处于正常状态，不需要帮助 */
    public final static int ORDER_NO_HELP = 0;

    /** 订单处于等待帮助状态 */
    public final static int ORDER_HELP = 1;

    /** 订单处于求助完成状态 */
    public final static int ORDER_HELP_FINISH = 2;

    //--------------------------------------------------------
    /** 订单求助：等待卖家处理 */
    public final static int HELP_STATUS_WAITING = 0;

    /** 订单求助：卖家帮助完成 */
    public final static int HELP_STATUS_OK = 1;

    /** 订单求助：求助失败（卖家不解决or解决不了） */
    public final static int HELP_STATUS_FAIL =  2;

    //--------------------------------------------------------
    /** 订单求助类型：密码错误 */
    public final static int HELP_TYPE_PASSWORD = 1;

    /** 订单求助类型：账号冻结 */
    public final static int HELP_TYPE_ACCOUNT_FROZEN = 2;

    /** 订单求助类型：验证码 */
    public final static int HELP_TYPE_AUTHCODE = 3;

    //--------------------------------------------------------
    /** 无责取消订单 */
    public final static int FREE_CANCEL = 1;

    /** 有责取消订单 */
    public final static int NOT_FREE_CANCEL = 2;
    
    //--------------------------------------------------------
    /** 订单资金锁定状态：还未转账 */
    public final static int DELAY_TRANSFER_NOT_FINISH = 0;

    /** 订单资金锁定状态：已转账 */
    public final static int DELAY_TRANSFER_FINISH = 1;

    /** 订单来源 来源平台 */
    public final static int ORDER_FROM_PLATFORM= 1;

    /** 订单来源 来源用户推广 */
    public final static int ORDER_FROM_USERPROMOTE = 2;
    /** 订单来源 来源用户联合推广 */
    public final static int ORDER_FROM_USERSPONSORED = 3;

    /** 订单未扣除保证金 */
    public final static  int ORDER_NOTDEDUCTED_GUARANTEE=0;
    /** 订单扣除保证金 */
    public final static  int ORDER_DEDUCTED_GUARANTEE=1;

    //--------------------------------------------------------
    /** 登号码状态：不可用 */
    public final static int LOGINKEY_STATUS_INVALID = 0;
    /** 登号码状态：可用 */
    public final static int LOGINKEY_STATUS_VALID = 1;

    /** 取消来源：上号器失败无责取消 */
    public final static int CANCEL_LOGINKEY_FAIL = 1;
    
    
    /** 订单参团状态  不可参与 */
    public final static int LOTTERY_GROUP_NO = 0;
    /** 订单参团状态  可参与皮肤抽奖活动 */
    public final static int LOTTERY_GROUP_SKIN = 1;
    /** 订单参团状态  已参与 */
    public final static int LOTTERY_GROUP_ALREADY = 2;
    /** 订单参团状态  可参与优惠券抽奖活动 */
    public final static int LOTTERY_GROUP_COUPON = 3;
    
    //---------------------------------------------------------
    /** 撤单申请：新建 */
    public static final int ORDER_CANCEL_APPLY_NEW = 0;
    /** 撤单申请：通过撤单 */
    public static final int ORDER_CANCEL_APPLY_SUCCESS = 1;
    /** 撤单申请： 不通过撤单*/
    public static final int ORDER_CANCEL_APPLY_FAIL = 2;
    
    /** 撤单申请：客服超时未处理 */
    public static final int ORDER_CANCEL_APPLY_TIMEOUT = 999; //超时未处理，又系统自动设置为这个状态

    //---------------------------------------------------------
    /** 求助信息发送人：玩家 */
    public static final int HELP_MESSAGE_SENDER_BUYUSER = 1;
    /** 求助信息发送人：号主 */
    public static final int HELP_MESSAGE_SENDER_SELLUSER = 2;
    /** 求助信息发送人：系统 */
    public static final int HELP_MESSAGE_SENDER_SYSTEM = 99;


	//----------------------------------------------------------------------
	/**
	 * 计算出实际需要转账给卖家的租金（已扣除手续费）
	 * @return
	 */
	public static Double getOrderPayAmountToSelluser(Record order, Record successApply){
		double orderFee = order.getBigDecimal("order_fee").doubleValue();
		
		int rental = getRental(order, successApply);
		if(rental <= 0)
			return 0d;
		
		//如果这笔订单是商铺非自有商品的加价单，则实际给卖家的租金应该扣除掉加价部分的金额
		if(order.getInt("shop_markup_amount") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
			int shopMarkupAmount = (int)(1.0d * order.getInt("shop_markup_amount") * rental / order.getInt("order_pay_amount"));
			//所以给号主的钱应该是
			rental = rental - shopMarkupAmount;
		}
		
		Double amount = deductFee(rental, orderFee);
    	logger.info("订单【" + order.getStr("order_id") + "】扣除手续费后剩余资金为：" + amount + "元");
    	
    	//如果有合租者，将合租者的金额也扣掉
    	if(order.getInt("cooperation_uid") > 0){
	    	double coopFeeRate = order.getBigDecimal("coop_fee_rate").doubleValue();
	    	amount = Common.round(amount*(1-coopFeeRate), 2);
	    	logger.info("订单【" + order.getStr("order_id") + "】有合租者【" + order.getInt("cooperation_uid") + "】，分成比例: " + coopFeeRate + "，分成后剩余资金：" + amount);
    	}
    	return amount;
	}
	
	/**
	 * 计算合租者的租金
	 * @param order
	 * @param successApply
	 * @return
	 */
	public static Double getOrderPayAmountToCooperation(Record order, Record successApply){
		double orderFee = order.getBigDecimal("order_fee").doubleValue();
		
		int rental = getRental(order, successApply);
		if(rental <= 0)
			return 0d;
		
		//没有合租者
		if(order.getInt("cooperation_uid") <= 0){
			return 0d;
		}
		
		//先扣除手续费
		Double amount = deductFee(rental, orderFee);
		double coopFeeRate = order.getBigDecimal("coop_fee_rate").doubleValue();
		amount = Common.round(amount*coopFeeRate, 2);
		
		logger.info("订单【" + order.getStr("order_id") + "】分成给合租者【" + order.getInt("cooperation_uid") + "】的资金为：" + amount + "元");
		return amount;
	}
	
	/**
	 * 计算商铺商品的加价金额，如果商品是商铺自有的，那么加价金额为0（因为不涉及分成）；若商铺非自有的，则会按实际计算出分成金额
	 * @param order
	 * @param successApply
	 * @return
	 */
	public static Double getOrderPayAmountToShopMarkup(Record order, Record successApply){
		int rental = getRental(order, successApply);
		if(rental <= 0)
			return 0d;
		
		//如果这笔订单是商铺非自有商品的加价单
		int amount = 0;
		if(order.getInt("shop_markup_amount") > 0 && order.getInt("shop_uid").intValue() != order.getInt("selluser_uid").intValue()){
			amount = (int)(1.0d * order.getInt("shop_markup_amount") * rental / order.getInt("order_pay_amount"));
		}
		
		double markupAmount = Common.round(amount/100.0, 2);
		logger.info("订单【" + order.getStr("order_id") + "】的加价金额为: " + markupAmount + "元");
		
		return markupAmount;
	}
	
	/**
	 * 计算订单的租金价格（还未扣除手续费）
	 */
	private static Integer getRental(Record order, Record successApply){
		String orderId = order.getStr("order_id");
		//如果没有起租，卖家不用收钱了
        if(order.getDate("rent_start_time") == null || order.getInt("is_free_cancel") == Order.FREE_CANCEL){
        	//免责撤单的时候，如果该用户有过多笔续租，则已经续租完成的租赁单费用将被收取
        	int currReletsAmount = getCurrentReletsAmount(orderId);
        	int returnAmount = order.getInt("order_pay_amount") - currReletsAmount;
        	if(returnAmount <= 0)
        		returnAmount = 0;
        	return returnAmount;
        }

        long startTime = order.getDate("rent_start_time").getTime();
        long endTime = order.getDate("rent_end_time").getTime();
        //如果都还没有订单结束时间，就以当前时间计算。
        long finishTime = System.currentTimeMillis();
        if(order.getDate("order_finish_time") != null) {
            finishTime = order.getDate("order_finish_time").getTime();
        }
        //如果订单有撤单申请时间，以撤单申请时间为finishTme
        if(successApply != null && order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
            finishTime = successApply.getDate("c_time").getTime();
        }
        //如果finishTime在startTime之前，依然认为这笔订单从未开始过
        if(finishTime < startTime){
        	return 0;
        }

        //计算实际应得的租金，给卖家的钱向下取整
        //如果订单是完成的，直接获取租金全额，如果订单是取消的，则需要计算
        int orderPayAmount = order.getInt("order_pay_amount");
        if(order.getInt("order_status") != Order.ORDER_STATUS_FINISH) {
            orderPayAmount = getPartPayAmount(startTime, endTime, finishTime, orderPayAmount, false);
        }
        return orderPayAmount;
	}
	
	/**
	 * 扣减手续费后的金额，返回值单位为元！
	 * @param payAmount 租金，单位为分
	 * @param feeRate 手续费率
	 * @return 计算扣除手续费后的金额，注意此时单位变成了元！！
	 */
	private static Double deductFee(Integer payAmount, double feeRate){
		Double amount = (double)payAmount; //转成double型便于计算
		if(feeRate > 0.001){
            double feeAmount = amount * feeRate; //单位依然是分
			//超过1分钱都收手续费
			if(feeAmount >= 1){
				amount -= feeAmount;
			}
		}
		return Common.round(amount / 100.0, 2);
	}

    /**
     * 按用户实际租赁时间计算该订单应收取的实际租金
     * @param order
     * @return
     */
	public static Double getOrderRefundAmountToBuyuser(Record order, Record successApply){
	    //如果订单是完成的，一分钱都不用返还给玩家
        if(order.getInt("order_status") == Order.ORDER_STATUS_FINISH)
            return 0d;

	    int orderPayAmount = order.getInt("order_pay_amount");
	    int amountOff = order.getInt("amount_off");

	    //用户的实付金额
        int realAmount = orderPayAmount - amountOff;
        if(realAmount <= 0)
            realAmount = 0;

        //如果没有租赁开始时间，说明该订单可能都没开始就要退款了，返回实付金额即可
        //如果是免责撤单，退款租金也是全部实付金额
        if(order.getDate("rent_start_time") == null || order.getInt("is_free_cancel") == Order.FREE_CANCEL) {
        	//免责撤单的时候，如果该用户有过多笔续租，则已经续租完成的租赁单费用将被收取，而还在续租期内的租赁单费用全额退还
        	int currReletsAmount = getCurrentReletsAmount(order.getStr("order_id"));
        	
        	//用户当前的实付金额
        	currReletsAmount -= amountOff;
        	
        	Double amount = Common.round(currReletsAmount/100.0, 2);
        	logger.info("订单【" + order.getStr("order_id") + "】免责撤单，退还给玩家的资金：" + amount + "元");
        	return amount;
        }

        long startTime = order.getDate("rent_start_time").getTime();
        long endTime = order.getDate("rent_end_time").getTime();
        //如果都还没有订单结束时间，就以当前时间计算。
        long finishTime = System.currentTimeMillis();
        if(order.getDate("order_finish_time") != null){
            finishTime = order.getDate("order_finish_time").getTime();
        }
        
        //如果finishTime在startTime之前，依然认为这笔订单从未开始过
        if(finishTime < startTime){
        	return Common.round(realAmount / 100.0, 2);
        }
        //如果订单有撤单申请时间，以撤单申请时间为finishTme
        if(successApply != null && order.getInt("order_status") == Order.ORDER_STATUS_CANCEL && successApply != null){
            finishTime = successApply.getDate("c_time").getTime();
        }
        //玩家实际需要支付的租金，收买家的钱向上取整
        int shouldPayAmount = getPartPayAmount(startTime, endTime, finishTime, realAmount, true);

        //退还给玩家的租金 = 总实付租金 - 应支付租金
        int amount = realAmount - shouldPayAmount;
        if(amount < 0)
            amount = 0;

        //转成元
        return Common.round(amount / 100.0, 2);
	}

	/**
	 * 获取订单当前出租中的租赁单所有租金总和。
	 * @param orderId 订单ID
	 * @return
	 */
	private static int getCurrentReletsAmount(String orderId){
		//有可能租赁单已经先被设置为取消状态了
		Record row = SmartDb.findFirst(
				"select sum(order_pay_amount) as order_pay_amount from `order_relet` where `order_id`=? and `status` in (?, ?) and `pay_success_time` is not null",
				orderId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_CANCEL);
		//没有需要退费的租赁单了
		if(row == null || row.getBigDecimal("order_pay_amount") == null){
			return 0;
		}
		return row.getBigDecimal("order_pay_amount").intValue();
	}

    /**
     * 根据实际情况计算应收租金。
     * @param startTime
     * @param endTime
     * @param stopTime
     * @param amount
     * @param roundUp
     * @return
     */
    private static Integer getPartPayAmount(long startTime, long endTime, long stopTime, int amount, boolean roundUp){
        //租期已到
        if(endTime <= stopTime){
            return amount;
        }

        //租期没到，按每30分钟作为一个时间段计算比例
        long _30min = 1800 * 1000L;
        long timelong = endTime - startTime;
        int n = (int)(timelong / _30min);
        if(timelong % _30min != 0)
            n++;

        //计算每30分钟应收多少钱
        int price = amount / n;

        long useTime = stopTime - startTime;
        int m = (int)(useTime / _30min);
        //如果向上取整：不满30分钟按30分钟计算。
        if(roundUp && useTime % _30min != 0)
            m++;
        return price * m;
    }
	
    /**
     * 判断订单流程是否已经结束<br>
     * 1. 订单状态必须是完成或者取消<br>
     * 2. 订单如果是免责取消则必然是流程已完结。<br>
     * 3. 订单如果是有责，若是仲裁完成了，也同样是流程已完结。<br>
     * 4. 订单如果是有责，且已经过了仲裁期，则是流程完结。<br>
     * 5. 其余情况都是流程还未完成。<br>
     * @param order
     * @return
     */
	public static boolean scheduleEnd(Record order){
		String orderId = order.getStr("order_id");
		//状态不是成功或者结束，肯定订单流程还没结束
		if(order.getInt("order_status") != Order.ORDER_STATUS_CANCEL && order.getInt("order_status") != Order.ORDER_STATUS_FINISH){
			logger.info("Order.scheduleEnd -- 订单【" + orderId + "】不是成功或者失败状态，订单流程尚未结束！");
			return false;
		}
		
		//如果订单是免责的，那么流程已经结束了
		if(order.getInt("is_free_cancel") == Order.FREE_CANCEL
                || order.getInt("quick_refund") == 1){
			return true;
		}

		//如果订单是有责，且已经仲裁完成或者号主同意撤单，那么流程也结束了
		int selluserArbitrate = order.getInt("is_selluser_arbitrate");
		if(selluserArbitrate == Order.SELLUSER_CONFIRM_CANCEL 
				|| selluserArbitrate == Order.SELLUSER_ARBITRATE_FAIL 
				|| selluserArbitrate == Order.SELLUSER_ARBITRATE_SUCC){
			return true;
		}
		
		//如果订单是有责，其它情况看是否超过了仲裁期
		long now = System.currentTimeMillis();
		if(now > order.getDate("order_finish_time").getTime()+1000L*PropKit.getInt("order.arbitrate_timeout")){
			return true;
		}else{
			logger.info("Order.scheduleEnd -- 订单【" + orderId + "】还没有过仲裁时间，还没有结束流程！");
		}
		
		return false;
	}

    /**
     * 是否免责撤单
     * 	玩家信誉分>=95分，同时在15分钟内撤单，同时是当天头两次撤单 --> 免责
     * @param uid
     * @param order
     * @return
     */
    public static boolean isFreeCancel(int uid, Record order){
        //首先订单必须是已支付的状态
        if(order.getInt("order_status") != Order.ORDER_STATUS_PAID)
            return false;

        Record firstRelet = SmartDb.findFirst("select * from `order_relet` where `order_id`=? and `type`=? limit 1", order.getStr("order_id"), Order.ORDER_RELET_FIRST);
        //是否超过15分钟
        if(firstRelet.getDate("pay_success_time").getTime() + PropKit.getInt("order.self_cancel_order.timeout")*1000L < System.currentTimeMillis()){
            return false;
        }

        //是否头两次撤单
        String today = Common.show_time(System.currentTimeMillis(), "yyyy-MM-dd 00:00:00");
        Record cancelCount = SmartDb.findFirst("select count(id) as _count from `order` where `buyuser_uid`=? and `order_status`=? and `order_ispay`=? and `order_finish_time`>=?",
                uid, Order.ORDER_STATUS_CANCEL, Order.ORDER_PAID, today);
        if(cancelCount.getInt("_count") >= PropKit.getInt("order.self_cancel_order.max_count"))
            return false;

        //信誉分是否>=95分
        Record member = SmartDb.findFirst("select * from `member` where `uid`=?", uid);
        if(member.getInt("play_score") < 95)
            return false;

        return true;
    }

    /**
     * 撤单后是否需要延迟退款
     * @param order
     * @param isFreeCancel
     * @return
     */
    public static boolean isDelayRefund(Record order, boolean isFreeCancel){
        //如果有保证金，就一定是延迟24小时到账
        if(order.getInt("seller_guarantee_amount") > 0)
            return true;

        //如果是有责撤单，一定是24小时后退款
        if(!isFreeCancel)
            return true;

        //免责若有押金，也要延迟24小时
        if(order.getInt("order_guarantee_deposit") > 0)
            return true;

        //这里是免责无押金无保证金的情况，不需要延迟
        return false;
    }



    /**
     * 获取号主订单列表，如果获取的是数量，返回的列表只有一个元素
     * @param uid 号主UID
     * @param status 需要的订单逻辑状态，非实际数据库中的订单状态
     * @param fieldType 数据类型，0-获取数据列表，1-获取数量
     * @param offset 偏移量，>=0时有效
     * @param limit 获取数量，>=0时有效
     * @return
     */
    public static List<Record> getSelluserOrders(int uid, int status, int fieldType, int offset, int limit){
        String fields = "o.*";
        if(fieldType == 1)
            fields = "count(o.id) as _count";

        //售后处理 = 仲裁审核期 + 等待仲裁结果 的订单
        if(status == ORDER_IN_ARBITRATE){
            long arbitrateTimeLimit = System.currentTimeMillis() - PropKit.getInt("order.show_arbitrate_timeout")*1000L;

            //XXX 这个sql不用占位符，方便清晰地看它想干啥！
            String sql = "select " + fields + " from `order` o left join `order_cancel_evidence` oc on o.`order_id`=oc.`order_id` where "
                    +"o.`selluser_uid`=" + uid + " and o.`order_status` in (" + Order.ORDER_STATUS_FINISH + ", " + Order.ORDER_STATUS_CANCEL + ") and o.`order_ispay`=" + Order.ORDER_PAID //基本条件
                    + " and ("
                    + " (o.`is_selluser_arbitrate`=" + Order.SELLUSER_ARBITRATE + " and oc.`pass`=0)"  //等待仲裁审核结果的订单
                    //XXX 下面这行sql表示的可以仲裁的订单，就是把 orderCanArbitrate 方法翻译过来！！可以对照着看。
                    + " or (o.`quick_refund`!=1 and o.`is_selluser_arbitrate`=" + Order.SELLUSER_NO_ARBITRATE + " and o.`order_finish_time`>='" + Common.show_time(arbitrateTimeLimit) + "' and (o.`seller_guarantee_amount`>0 || o.`is_free_cancel`=" + Order.NOT_FREE_CANCEL + "))" //当前支持审核的订单
                    + ")";
            if(offset >= 0 && limit >= 0) {
                sql += " order by o.id desc limit " + offset + ", " + limit;
            }
            logger.info(sql);
            return SmartDb.find(sql);
        }

        //待处理 = 等待求助响应的订单
        if(status == ORDER_IN_SOLVE){
            String sql = "select " + fields + " from `order_help` oh left join `order` o on oh.order_id=o.order_id where" +
                    " o.`selluser_uid`=? and o.`order_ispay`=? and o.`order_status`=?"
                    + " and oh.`status`=? and oh.`selluser_uid`=?";
            if(offset >= 0 && limit >= 0) {
                sql += " order by o.id desc limit " + offset + ", " + limit;
            }
            return SmartDb.find(sql, uid, Order.ORDER_PAID, Order.ORDER_STATUS_PAID, Order.HELP_STATUS_WAITING, uid);
        }

        //其余订单可以直接使用status字段值
        List<Object> params = Lists.newArrayList(uid, Order.ORDER_PAID);
        String sql = "select " + fields + " from `order` o where `selluser_uid`=? and `order_ispay`=?";
        if(status != -1){
            sql += " and `order_status`=?";
            params.add(status);
        }
        if (offset >= 0 && limit >= 0) {
            sql += " order by o.id desc limit " + offset + ", " + limit;
        }
        return SmartDb.find(sql, params.toArray());
    }

    /**
     * 获取玩家订单列表，如果是获取数量，返回的列表只有一个元素
     * @param uid 号主UID
     * @param status 需要的订单逻辑状态，非实际数据库中的订单状态
     * @param fieldType 数据类型，0-获取数据列表，1-获取数量
     * @param offset 偏移量，>=0时有效
     * @param limit 获取数量，>=0时有效
     * @return
     */
    public static List<Record> getBuyuserOrders(int uid, int status, int fieldType, int offset, int limit){
        String fields = "o.*";
        if(fieldType == 1)
            fields = "count(o.id) as _count";

        //售后处理 = 等待撤单审核的订单
        if(status == ORDER_IN_ARBITRATE){
            String sql = "select " + fields + " from `order_cancel_apply` oc left join `order` o on oc.order_id=o.order_id where o.`buyuser_uid`=? and o.`order_status`=? and oc.`status`=?";
            if(offset >= 0 && limit >= 0) {
                sql += " order by o.id desc limit " + offset + ", " + limit;
            }
            return SmartDb.find(sql, uid, Order.ORDER_STATUS_PAID, 0);
        }

        //其余订单可以直接使用status字段值
        String sql = "select " + fields + " from `order` o where `buyuser_uid`=?";
        List<Object> params = Lists.newArrayList(uid);
        if(status != -1){
            sql += " and `order_status`=?";
            params.add(status);
        }
        //如果是撤单状态，标记为“等待退款”的那类型订单
        if(status == Order.ORDER_STATUS_CANCEL){
            sql += " and `order_isterminate`=? and `order_isrefund_guarantee`=? and `order_ispay`=? and `is_buyuser_arbitrate`=?";
            params.add(Order.ORDER_NOT_TERMINATED);
            params.add(Order.ORDER_NOT_REFUND);
            params.add(Order.ORDER_PAID);
            params.add(Order.BUYUSER_ARBITRATION);
        }
        if(offset >= 0 && limit >= 0) {
            sql += " order by o.id desc limit " + offset + ", " + limit;
        }
        return SmartDb.find(sql, params.toArray());
    }
    
    
    //测试
    public static void main(String[] args) {
        Record order = new Record();
        order.set("order_id", "test-order");
        order.set("order_status", 8);
        order.set("order_fee", new BigDecimal(0.15));
        order.set("order_pay_amount", 400);
        order.set("amount_off", 0);
        order.set("rent_start_time", new Date(Common.strtotime("2018-04-25 18:14:13", "yyyy-MM-dd HH:mm:ss")));
        order.set("order_finish_time", new Date(Common.strtotime("2018-04-25 17:12:46", "yyyy-MM-dd HH:mm:ss")));
        order.set("rent_end_time", new Date(Common.strtotime("2018-04-25 20:14:13", "yyyy-MM-dd HH:mm:ss")));
        order.set("is_free_cancel", 2);

        double buyuserRefundAmount = getOrderRefundAmountToBuyuser(order, null);
        double selluserAmount = getOrderPayAmountToSelluser(order, null);
        System.out.println("buyuserRefundAmount => " + buyuserRefundAmount);
        System.out.println("selluserAmount => " + selluserAmount);
    }
}
