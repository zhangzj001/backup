package cn.jugame.rent.bean;

import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.slf4j.Logger;

public class Loginkey {
    private static Logger logger = Loggers.rentLog();

    /** 登号器配置生效 */
    public static final int CONFIG_STATUS_VALID = 1;
    /** 登号器配置失效 */
    public static final int CONFIG_STATUS_INVALID = 0;

    /** 手游上号器登录*/
    public static final int LOGIN_ON_MOBILE = 3;
    /** pc上号器登录 */
    public static final int LOGIN_ON_PC = 2;

    /** 密钥状态：生效 */
    public static final int STATUS_VALID = 1;
    /** 密钥状态：失效 */
    public static final int STATUS_INVALID = 0;


    /**
    * 根据渠道id和游戏id获取上号器的配置
    * @param gameId
	* @param channelId
    * **/
    public static int getLoginType(String gameId,String channelId){

        int loginType = 1;
        //1.根据渠道号和游戏id读取配置
        Record loginKeyConfig = SmartDb.findFirst("SELECT * FROM login_key_config WHERE `status` = ? and game_id = ? and channel_id = ? ", Loginkey.CONFIG_STATUS_VALID,gameId,channelId);

        if(loginKeyConfig != null){
            if(loginKeyConfig.get("login_client_type" ) != null){
                loginType = loginKeyConfig.getInt("login_client_type");
            }
        }

        return loginType;
    }

    /**
     * 根据游戏id获取上号器的配置
     * @param gameId
     * **/
    public static int getLoginTypeByGameId(String gameId){

        int loginType = 1;
        //1.根据渠道号和游戏id读取配置
        Record loginKeyConfig = SmartDb.findFirst("SELECT * FROM login_key_config WHERE `status` = ? and game_id = ? ", Loginkey.CONFIG_STATUS_VALID,gameId);

        if(loginKeyConfig != null){
            if(loginKeyConfig.get("login_client_type" ) != null){
                loginType = loginKeyConfig.getInt("login_client_type");
            }
        }

        return loginType;
    }


}
