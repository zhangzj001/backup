package cn.jugame.rent.bean;

import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;

public class HotSetting {
	public static String get(String key, String defaultVal){
		Record row = SmartDb.findFirst("select * from `hot_setting` where `key`=?", key);
		if(row == null)
			return defaultVal;
		return row.getStr("value");
	}
	
	public static int getInt(String key, int defaultVal){
		Record row = SmartDb.findFirst("select * from `hot_setting` where `key`=?", key);
		if(row == null)
			return defaultVal;
		return Integer.parseInt(row.getStr("value"));
	}
}
