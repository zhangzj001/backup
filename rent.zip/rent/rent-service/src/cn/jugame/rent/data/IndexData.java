package cn.jugame.rent.data;

import cn.jugame.rent.api.constants.ParamConstant;
import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.GameConf;
import cn.jugame.rent.bean.Index;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.page.service.Platforms;
import cn.jugame.rent.utils.Common;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能：获取首页的数据
 * 创建日期：2018-05-21
 *
 * @author jiangshishan
 */
public class IndexData {
    private static IndexData instance = new IndexData();

    private IndexData() {
    }

    public static IndexData getInstance() {
        return instance;
    }

    public Map<String, Object> get(IndexParam param) {
        Map<String, Object> indexDto = new HashMap<>();

        //首页幻灯片
        List<Record> mainBoards = Platforms.singleton.getBanners(PropKit.get("index.main_boards_tag"));
        //首页VIP专区预留的幻灯片
        List<Record> vipBoards = Platforms.singleton.getBanners(PropKit.get("index.vip_boards_tag"));

        //热门游戏
        List<Record> hotGames = Platforms.singleton.getGames(GameConf.TYPE_GAME, GameConf.TAG_HOT, 8);
        for (Record row : hotGames) {
            row.set("product_count", 0);
        }
        //热门VIP
        List<Record> hotVips = Platforms.singleton.getGames(GameConf.TYPE_VIP, GameConf.TAG_HOT, 6);
        //热门端游
        List<Record> hotPCGames = Platforms.singleton.getGames(GameConf.TYPE_PC_GAME, GameConf.TAG_HOT, 6);
        for (Record row : hotPCGames) {
            row.set("product_count", 0);
        }

        //优选游戏账号商品，必须信誉分达到100分
        List<Record> gameProducts = Platforms.singleton.getRecommendedProducts(5, Product.PRODUCT_TYPE_GAME);
        //优选VIP商品，必须信誉分达到100分
        List<Record> vipProducts = Platforms.singleton.getRecommendedProducts(3, Product.PRODUCT_TYPE_VIP);
        //公告
        List<Record> announcements = Platforms.singleton.getAnnoucements(false);

        //最近成功的订单
        List<Record> gameOrders = Platforms.singleton.getLatestSuccOrders(Product.PRODUCT_TYPE_GAME, ParamConstant.HOME_PAGE_NEWS_LIMIT);
        List<Record> vipOrders = Platforms.singleton.getLatestSuccOrders(Product.PRODUCT_TYPE_VIP, ParamConstant.HOME_PAGE_NEWS_LIMIT);
        gameOrders.addAll(vipOrders);

        //最近活动公告
        List<Record> actvityAnnouncements = Platforms.singleton.getAnnoucements(true);
        //新人礼包
        List<Record> newcomerGift = Coupon.getNewcomerGift();
        //获取用户未使用的优惠券
        List<Record> userCoupons = null;
        List<Record> userNotifyCoupons = null;
        if (param.getUid() > 0) {
            Integer uid = param.getUid();
            String now = Common.now("yyyy-MM-dd");
            userCoupons = SmartDb.find("SELECT * FROM `user_coupon` WHERE `uid`=? AND `status`=? AND `end_date`>=?  AND `left_times`>0 ORDER BY c_time DESC", uid, Coupon.STATUS_ONSALE, now);
            userNotifyCoupons = SmartDb.find("SELECT * FROM `user_coupon` WHERE `uid`=? AND `status`=? AND `end_date`>=?  AND `left_times`>0 AND is_notify = ? ORDER BY c_time DESC", uid, Coupon.STATUS_ONSALE, now, Coupon.IS_NOTIFY_NO);
        }

        //获取wap模块信息
        List<Record> activities = Platforms.singleton.getIndexActivities(Index.RENT_WAP_BANNER, param.getClientFrom());

        //获取app模块信息
        List<Record> mainNavs = Platforms.singleton.getIndexActivities(Index.RENT_APP_BANNER, param.getClientFrom());

        //这个是omr的，需要动态拼接imei码
        for (Record mainNav : mainNavs) {
            if (mainNav.getStr("url").contains("redirectOmr") && StringUtils.isNotBlank(param.getImei())) {
                mainNav.set("url", mainNav.getStr("url") + "?imei=" + param.getImei() + "#disablePullToRefresh");
            }
        }

        indexDto.put("mainBoards", mainBoards);
        indexDto.put("vipBoards", vipBoards);
        indexDto.put("hotGames", hotGames);
        indexDto.put("hotVips", hotVips);
        indexDto.put("hotPcGames", hotPCGames);
        indexDto.put("gameProducts", gameProducts);
        indexDto.put("vipProducts", vipProducts);
        indexDto.put("announcements", announcements);
        indexDto.put("recentOrder", gameOrders);
        indexDto.put("newcomerGift", newcomerGift);
        indexDto.put("userCoupons", userCoupons);
        indexDto.put("userNotifyCoupons", userNotifyCoupons);
        indexDto.put("actvityAnnouncements", actvityAnnouncements);
        indexDto.put("activities", activities);
        indexDto.put("mainNavs", mainNavs);
        return indexDto;
    }
}
