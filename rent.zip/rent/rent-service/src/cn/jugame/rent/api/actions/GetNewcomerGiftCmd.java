package cn.jugame.rent.api.actions;

import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.NeedLogin;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import net.sf.json.JSONObject;
import org.slf4j.Logger;

@BusiAction(service="app.getNewcomerGift")
@NeedLogin
public class GetNewcomerGiftCmd extends BaseCmd {
    private final  static Logger log = Loggers.rentLog();

    @Override
    public JSONObject process() throws Exception {
        JSONObject rtnData = new JSONObject();

        //已经领取过，没下过单的
        if(User.isNewcomerReceiveGiftUser(uid)) {
        	rtnData.put("ok", true);
        	rtnData.put("url", PropKit.get("rent_service_host")+"/coupon/getNewCommerGiftPage?is_receive=1&uid="+uid+"&index=");
            return BaseUtil.buildSuccessResp("已领取过", rtnData);
        }
        
        //发放优惠券
        if(!User.isNewcomerGiftUser(uid)){
            rtnData.accumulate("ok",false);
            return  BaseUtil.buildSuccessResp("领取失败", rtnData);
        }
        DistLocker locker = new DistLocker("newcomergift_" +uid );
        boolean succ = false;
        try{
            succ = locker.lock();
            if(!succ){
                log.error("newcomergift_加锁失败，uid=>" + uid);
                return  BaseUtil.buildFailResp("系统繁忙请稍后再试",null);

            }
            Coupon.newComerGift(uid,0);
        }finally{
            if(succ) locker.unlock();
        }

        rtnData.put("ok", true);
        rtnData.put("url", PropKit.get("rent_service_host")+"/coupon/getNewCommerGiftPage?is_receive=1&uid="+uid+"&index=");
        return BaseUtil.buildSuccessResp("领取成功", rtnData);
    }
}
