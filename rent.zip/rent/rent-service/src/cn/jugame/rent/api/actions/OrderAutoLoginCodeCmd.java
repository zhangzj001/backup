package cn.jugame.rent.api.actions;

import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

@BusiAction(service="rent.get_order_info")
//@NeedLogin
public class OrderAutoLoginCodeCmd extends BaseCmd{
	private final  static Logger log = Loggers.rentLog();
	@Override
	public JSONObject process() throws Exception {
		String key = dataJson.getString("login_key");
		if(StringUtils.isBlank(key)){
			return buildResp(false, "没有登号码");
		}
		boolean isRoot = extInfo.optBoolean("root",false);
		if(isRoot){
			return BaseUtil.buildFailResp("您的手机环境存在风险，暂时无法上号，您可通过联系客服免责撤单，款将即刻退回您的余额",null);
		}
		Record row = SmartDb.findFirst("select * from order_loginkey ol left join `order` o on ol.order_id = o.order_id where ol.loginkey=?", key);
		if(row == null){
			return BaseUtil.buildFailResp("钥匙无效或已过期，请重新输入",null);
		}
		
		if(row.getInt("status") == Order.LOGINKEY_STATUS_INVALID || (row.getInt("order_status") != Order.ORDER_STATUS_PAID && row.getInt("order_status") != Order.ORDER_STATUS_PAYING)){
			return BaseUtil.buildFailResp("钥匙无效或已过期，请重新输入",null);
		}
		if(row.getDate("valid_time").getTime() < System.currentTimeMillis()){
			return BaseUtil.buildFailResp("钥匙无效或已过期，请重新输入",null);
		}
		JSONObject rtnData = new JSONObject();
		rtnData.put("order_id", row.get("order_id"));
		rtnData.put("game_server",  row.get("game_partition_name"));
		rtnData.put("game_id", row.get("game_id"));
		rtnData.put("game_name",  row.get("game_name"));
		rtnData.put("channel_name",  row.get("channel_name"));
		rtnData.put("rent_start_time", Common.show_time(row.getDate("rent_start_time")));
		rtnData.put("rent_end_time",  Common.show_time(row.getDate("rent_end_time")));

		
		Record gameConf = SmartDb.findFirst("select * from game_conf where game_id = ?",  row.getStr("game_id"));
		JSONObject pkgObj = JSONObject.fromObject(gameConf.getStr("package_code"));
		if(pkgObj == null){
			return BaseUtil.buildFailResp("服务配置无效或已过期，请重新输入:",null);
		}
		JSONObject channelObj = pkgObj.optJSONObject(row.getStr("channel_id"));
		String downUrl = channelObj.optString("url");
		String pkg = channelObj.optString("pkg");
		rtnData.put("game_down_url", downUrl);
		rtnData.put("pkg_name", pkg);

		rtnData.put("game_account", row.get("selluser_game_account"));
		rtnData.put("game_pwd", row.get("selluser_game_pwd"));
		return BaseUtil.buildSuccessResp("获取成功",rtnData);
	}

}
