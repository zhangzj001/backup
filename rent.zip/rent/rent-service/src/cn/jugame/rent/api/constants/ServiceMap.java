package cn.jugame.rent.api.constants;

import com.jfinal.kit.PropKit;

import java.util.*;

public class ServiceMap {
    private final static HashMap<String, String> _seller_service = new HashMap<String, String>();
    private final static HashMap<String, String> _buyer_service = new HashMap<String, String>();

    private final static LinkedHashMap<String, List> _mainNav_service = new LinkedHashMap<>();
    private final static HashMap<String, String> _ucenter_service = new HashMap<>();
    private final static HashMap<String, String> _mainUrl_service = new HashMap<>();

    static {
        //------------------------------------------------------------------
        //  号主个人中心服务
        //------------------------------------------------------------------
        _seller_service.put("推荐有奖", PropKit.get("rent_service_host") + "/user/mypromote");       //推荐服务
        _seller_service.put("意见反馈", "http://m.8868.cn/user/userfeedback.html"); //意见反馈服务
        _seller_service.put("黑名单", PropKit.get("rent_service_host") + "/user/getBlackListForSellerPage"); //黑名单
//        _seller_service.put("个人推广", PropKit.get("rent_service_host") + "/user/sellerPromote#disablePullToRefresh"); //个人推广
        _seller_service.put("实名认证", PropKit.get("rent_service_host") + "/user/realnameAuth");

        //------------------------------------------------------------------
        //  玩家个人中心服务
        //------------------------------------------------------------------
        /*   _buyer_service.put("推荐有奖", PropKit.get("app_rent_host")+ "/user/mypromote");       //推荐服务*/
        _buyer_service.put("意见反馈", "http://m.8868.cn/user/userfeedback.html"); //意见反馈服务
        _buyer_service.put("实名认证", PropKit.get("rent_service_host") + "/user/realnameAuth");


        //------------------------------------------------------------------
        // 主页菜单服务
        //------------------------------------------------------------------
        _mainNav_service.put("手游帐号", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/syzh.png", PropKit.get("rent_service_host") + "/games/"));
        _mainNav_service.put("端游帐号", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/dyzh.png", PropKit.get("rent_service_host") + "/pcgames"));
        _mainNav_service.put("视频VIP", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/shipinghuiyuan.png", PropKit.get("rent_service_host") + "/vip/"));
        _mainNav_service.put("优质账号", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/yzzh.png", "http://m.8868.cn/page/activity_1243/index.html"));
        _mainNav_service.put("王者皮肤", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/qxw.png", "http://wz.8868.cn/pfzq/new/zhpf.html"));
        _mainNav_service.put("租送优惠", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/zsyh.png", "http://m.8868.cn/page/activity_1232/index.html"));
        _mainNav_service.put("体验卡 ", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/tiyanka.png", PropKit.get("rent_service_host") + "/cdk/"));
        _mainNav_service.put("商户入驻", Arrays.asList(PropKit.get("rent_service_host") + "/icons/index_icon/shrz.png", "http://m.8868.cn/page/activity_1173/index.html"));
        //------------------------------------------------------------------
        //  主页更多游戏和更多vip链接
        //------------------------------------------------------------------
        _mainUrl_service.put("more_games_url", PropKit.get("rent_service_host") + "/allGames");       //更多游戏
        _mainUrl_service.put("more_vips_url", PropKit.get("rent_service_host") + "/vip/"); //更多Vip
        _mainUrl_service.put("more_game_products_url", PropKit.get("rent_service_host") + "/product/list?is_recommend_product=1&game_type=1");
        _mainUrl_service.put("more_pc_games_url", PropKit.get("rent_service_host") + "/allGames?type=5");

        //------------------------------------------------------------------
        //  主页更多游戏和更多vip链接
        //------------------------------------------------------------------
        _mainUrl_service.put("newcomer_gift_url", PropKit.get("rent_service_host") + "/coupon/newcomerGift?index=");//新人礼包页面

        //------------------------------------------------------------------
        // 个人中心
        //------------------------------------------------------------------
        _ucenter_service.put("seller_promote_url", PropKit.get("rent_service_host") + "/user/sellerPromote#disablePullToRefresh");
    }


    public final static HashMap<String, String> getService(int userType) {
        return userType == ParamConstant.USER_TYPE_SELLER ? _seller_service : _buyer_service;

    }

    public final static HashMap<String, List> getMainNavService() {
        return _mainNav_service;
    }

    public final static String getMainUrlServices(String key) {
        return _mainUrl_service.get(key);
    }

}
