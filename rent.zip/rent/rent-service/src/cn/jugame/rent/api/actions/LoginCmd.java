package cn.jugame.rent.api.actions;

import cn.jugame.account_center.commons.BusiConstant;
import cn.jugame.account_center.commons.RtnCode;
import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.constants.ParamConstant;
import cn.jugame.rent.api.entity.LoginReqEntity;
import cn.jugame.rent.api.utils.AccountUtil;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.api.utils.SmsUtil;
import cn.jugame.rent.utils.CacheUtil;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.MD5;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@BusiAction(service = "account.login")
public class LoginCmd extends BaseCmd {

	private final static Logger log = Loggers.rentLog();
	// 登录方式
	private final static List<String> loginTypeList = Collections
			.unmodifiableList(Arrays.asList("mobile", "wechat", "sms", "qq"));

	// 登录请求实体
	private LoginReqEntity req;

	private SmsUtil smsUtil;

	public LoginCmd() {
		super();
		smsUtil = new SmsUtil();

	}

	@Override
	public JSONObject process() throws Exception {
		if (dataJson == null || !(dataJson instanceof JSONObject)) {
			return BaseUtil.buildFailResp("data为空或者类型为空" + dataJson, null);
		}
		req = BaseUtil.parseJson2Obj(dataJson.toString(), LoginReqEntity.class);
		if (StringUtils.isEmpty(req.getType())) {
			return BaseUtil.buildFailResp("登录类型为空", null);
		}
		String loginType = req.getType();
		log.info("loginType ====> " + req.getType());
		if (!loginTypeList.contains(req.getType())) {
			return BaseUtil.buildFailResp("登录类型非法", null);
		}

		if ("mobile".equals(req.getType())
				&& (StringUtils.isEmpty(req.getMobile()) || StringUtils.isEmpty(req.getPasswd()))) {
			return BaseUtil.buildFailResp("手机号、登录密码不能为空", null);
		}
		if ("wechat".equals(req.getType()) && req.getWechat().isEmpty()) {
			return BaseUtil.buildFailResp("accessToken不能为空", null);
		}
		if("qq".equals(req.getType()) && req.getQq().isEmpty()){
            return BaseUtil.buildFailResp("QQ登录信息不能为空", null);
        }

		String loginResult = "";

		switch (loginType.toLowerCase()) {
			case "mobile":
				loginResult = loginByMobile();
				break;
			case "wechat":
				loginResult = loginByWechat();
				break;
			case "sms":
				loginResult = loginBySms();
				break;
            case "qq":
                loginResult = loginByQq();
                break;
			default:
				return BaseUtil.buildFailResp("请选择其他登录方式", null);
		}
		JSONObject loginObj = null;
		try {
			loginObj = JSONObject.fromObject(loginResult);
		} catch (Exception e) {
			log.error("loginObject不是一个json：" + dataJson + "------" + loginResult);
		}
		if (loginObj == null || loginObj.isEmpty()) {
			if (StringUtils.isEmpty(loginResult)) {
				log.error("loginJson is empty");
				return BaseUtil.buildFailResp("登录失败", null);
			} else {
				return BaseUtil.buildFailResp(loginResult, null);
			}
		}
		String token = loginObj.optString("token", loginToken);
		int uid = loginObj.optInt("uid", 0);
		JSONObject rtnData = new JSONObject();
		rtnData.put("uid", uid);
		rtnData.put("token", token);
		log.info("用户ip" + _clientIP + "---请求入参---" + dataJson + "---登录请求返回的用户id：" + uid);
		return BaseUtil.buildSuccessResp("登录成功", rtnData);
	}

	/**
	 * 使用手机号和密码登录
	 */
	private String loginByMobile() {
		AccountBean loginBean = accountService.login(req.getMobile(), req.getPasswd(), ParamConstant.ACCOUNT_BUSI);
		if (loginBean == null) {
			return "";
		}

		if (loginBean == null || loginBean.getCode() != RtnCode.OK) {
            log.error("手机号登录失败，mobile: " + req.getMobile() + ", password:" + req.getPasswd() + ", clientIP=>" + _clientIP + ", error_msg=>" + (loginBean != null ? loginBean.getMsg() : ""));
            return null;
		}
		return JSONObject.fromObject(loginBean.getData()).toString();
	}

	//FIXME 微信改版
//	private String callWechat(){
//        String url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + weixinConfig.getAppid()
//                + "&secret=" + weixinConfig.getAppSecret()
//                + "&code=" + code + "&grant_type=authorization_code";
//    }

	/**
	 * 使用微信登录
	 */
	private String loginByWechat() {
		AccountBean loginBean = null;
		JSONObject wechatInfo = req.getWechat();
		String headImg = wechatInfo.optString("headimgurl", "");
		String nickname = wechatInfo.optString("nickname", "");
		String unionId = wechatInfo.optString("unionid", "");
		String accessToken = wechatInfo.optString("access_token", "");
		String openId = wechatInfo.optString("openid", "");
		MemberBean memberBean = accountService.queryUidByOpenId(openId, BusiConstant.APP_BUSI, unionId);
		boolean isExist = (memberBean != null && memberBean.getCode() == MemberBean.OK && memberBean.getData() != null);
		String busi = _clientOS + "rent";
		if (!isExist) {
			JSONObject userInfo = AccountUtil.getWechatUserInfo(accessToken, openId);
			if (userInfo != null && !userInfo.isEmpty()) {
				nickname = userInfo.getString("nickname");
				headImg = userInfo.getString("headimgurl");
			}
			if (StringUtils.isEmpty(unionId)) {
				return "";
			}
			String orderEntrance = _clientOS.equalsIgnoreCase("Android") ? "app" : "iOS";
			loginBean = accountService.registByWeiX(unionId, openId, req.getMobile(), nickname, headImg, this._clientIP,
					_clientAI, orderEntrance, true, busi);
		} else {
			loginBean = accountService.loginByWX(openId, busi);
		}
		if (loginBean == null || loginBean.getCode() != RtnCode.OK) {
            log.error("注册/登录微信失败，accessToken: " + accessToken + ", clientIP=>" + _clientIP + ", error_msg=>" + (loginBean != null ? loginBean.getMsg() : ""));
            return null;
		}

		return JSONObject.fromObject(loginBean.getData()).toString();
	}

	private String loginByQq(){
        JSONObject qq = req.getQq();

        String accessToken = qq.optString("access_token", BusiConstant.APP_BUSI);

        AccountBean existBean = accountService.checkUserExistByQQAccessToken(accessToken);
        JSONObject existInfoJson = null;
        boolean isExist;
        try{
            existInfoJson = JSONObject.fromObject(existBean.getData());
            isExist = existInfoJson.getBoolean("isExist");
        }catch(Exception e){
            return null;
        }

        AccountBean loginBean;
        if (!isExist) {
            String orderEntrance = _clientOS.equalsIgnoreCase("Android") ? "app" : "iOS";
            loginBean = accountService.registByQQ(accessToken, _clientIP, orderEntrance, true, BusiConstant.APP_BUSI, _clientAI, "");
        } else {
            loginBean = accountService.loginByQQ(accessToken, BusiConstant.APP_BUSI);
        }

        if (loginBean == null || loginBean.getCode() != RtnCode.OK) {
            log.error("注册/登录QQ失败，accessToken: " + accessToken + ", clientIP=>" + _clientIP + ", error_msg=>" + (loginBean != null ? loginBean.getMsg() : ""));
            return null;
        }
        return JSONObject.fromObject(loginBean.getData()).toString();
    }

	/**
	 * 使用验证码登录
	 */
	private String loginBySms() {
		// 防止用户无限刷，一天一台设备只让调用5次
		String limitKey = MD5
				.encode("LoginWithNoPasswdCmd" + req.getMobile() + Common.show_time(new Date(), "yyyy-MM-dd"));
		Integer times = (Integer) CacheUtil.get(limitKey);
		if (times == null) {
			times = 0;
		}
		if (times > 5) {
			return null;
		}
		String busi = ParamConstant.ACCOUNT_BUSI;
		CacheUtil.set(limitKey, CACHE_24_hour, times + 1);
		if (smsUtil.validateCode(req.getMobile(), req.getVcode(), req.getVcodeType())) {
			String userTerrace = _clientOS.equalsIgnoreCase("Android") ? "app" : "iOS";
			MemberBean bean = accountService.loginByDynamicDigital(req.getMobile(), req.getVcode(), _clientIP, _clientAI, userTerrace, _clientAI, busi);
			if (bean == null || bean.getCode() != MemberBean.OK || StringUtils.isBlank(String.valueOf(bean.getData()))) {
                log.error("注册/登录QQ失败，mobile: " + req.getMobile() + ", error_msg=>" + (bean != null ? bean.getMsg() : ""));
                return null;
			}

			JSONObject obj = JSONObject.fromObject(bean.getData());
			return obj.toString();
		}
		return null;
	}

}
