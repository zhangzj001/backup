package cn.jugame.rent.api.actions;

import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.constants.ServiceMap;
import cn.jugame.rent.api.utils.AccountUtil;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.api.utils.ResponseDataFormatUtil;
import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.data.IndexData;
import cn.jugame.rent.data.IndexParam;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@BusiAction(service = "app.home_page")
public class IndexViewCmd extends BaseCmd {

    private final static Logger log = Loggers.rentLog();

    @Override
    public JSONObject process() throws Exception {
        //判断用户是否登录
        if (StringUtils.isNotEmpty(loginToken) && uid == null) {
            uid = AccountUtil.isUserLogin(loginToken);
        }
        JSONObject indexPage = new JSONObject();

        IndexParam param = new IndexParam();
        param.setClientFrom(_clientAI);
        param.setImei(getExValue(_clientEX, "imei"));
        if (uid != null && uid > 0) {
            param.setUid(uid);
        }

        Map<String, Object> indexDto = IndexData.getInstance().get(param);

        //新人礼包
        List<Record> newcomerGift = (List<Record>) (indexDto.get("newcomerGift"));
        boolean isNewcomer = ((uid == null || User.isNewcomerGiftUser(uid)) && newcomerGift != null && newcomerGift.size() > 0) || User.isNewcomerReceiveGiftUser(uid)/*(uid != null && User.hadNewcomerGift(uid) && User.hadNewcomerGiftLeft(uid))*/;
        indexPage.accumulate("is_newcomer", isNewcomer);
        if ((uid == null || User.isNewcomerGiftUser(uid)) && newcomerGift != null && newcomerGift.size() > 0) {
            indexPage.accumulate("newcomer_url", ServiceMap.getMainUrlServices("newcomer_gift_url"));
            indexPage.accumulate("newcomer_gift", ResponseDataFormatUtil.getNewcomerGift(newcomerGift));
        } else if (uid != null && User.isNewcomerReceiveGiftUser(uid)) {
            indexPage.accumulate("newcomer_url", PropKit.get("rent_service_host") + "/coupon/getNewCommerGiftPage?is_receive=1&uid=" + uid + "&index=");
        }
        //获取首页活动信息
        //indexPage.accumulate("main_nav",ResponseDataFormatUtil.getMainNav());
        indexPage.accumulate("main_nav", ResponseDataFormatUtil.getMainNav((List<Record>) (indexDto.get("mainNavs"))));

        indexPage.accumulate("main_boards", ResponseDataFormatUtil.getHomeBoards((List<Record>) (indexDto.get("mainBoards"))));
        indexPage.accumulate("vip_boards", ResponseDataFormatUtil.getHomeBoards((List<Record>) (indexDto.get("vipBoards"))));
        indexPage.accumulate("games", ResponseDataFormatUtil.getHomeHotGamesOrVips((List<Record>) (indexDto.get("hotGames"))));
        indexPage.accumulate("vips", ResponseDataFormatUtil.getHomeHotGamesOrVips((List<Record>) (indexDto.get("hotVips"))));
        indexPage.accumulate("pc_games", ResponseDataFormatUtil.getHomeHotGamesOrVips((List<Record>) (indexDto.get("hotPcGames"))));
        indexPage.accumulate("game_products", ResponseDataFormatUtil.getHomeRecommendProducts((List<Record>) (indexDto.get("gameProducts"))));
        indexPage.accumulate("vip_products", ResponseDataFormatUtil.getHomeRecommendProducts((List<Record>) (indexDto.get("vipProducts"))));
        indexPage.accumulate("announcement", ResponseDataFormatUtil.getHomeAnnouncements((List<Record>) (indexDto.get("announcements"))));
        indexPage.accumulate("actvity_announcements", ResponseDataFormatUtil.getHomeAnnouncements((List<Record>) (indexDto.get("actvityAnnouncements"))));
        indexPage.accumulate("recent_success_info", ResponseDataFormatUtil.getHomeRecentSuccessOrderNews((List<Record>) (indexDto.get("recentOrder"))));
        indexPage.accumulate("more_pc_games_url", ServiceMap.getMainUrlServices("more_pc_games_url"));
        indexPage.accumulate("more_games_url", ServiceMap.getMainUrlServices("more_games_url"));
        indexPage.accumulate("more_game_products_url", ServiceMap.getMainUrlServices("more_game_products_url"));
        indexPage.accumulate("more_vips_url", ServiceMap.getMainUrlServices("more_vips_url"));
        //获取用户有多少未使用的优惠券
        List<Record> userCoupons = (List<Record>) (indexDto.get("userCoupons"));
        indexPage.accumulate("userCoupons", userCoupons != null ? userCoupons.size() : 0);
        //获取未提醒用户的优惠券
        List<Record> userNotifyCoupons = (List<Record>) (indexDto.get("userNotifyCoupons"));

        if (!isNewcomer && userNotifyCoupons != null && userNotifyCoupons.size() > 0) {
            int endIndex = userNotifyCoupons.size() >= PropKit.getInt("coupon.notify.size", 4) ? PropKit.getInt("coupon.notify.size", 4) : userNotifyCoupons.size();
            indexPage.accumulate("userNotifyCoupons", ResponseDataFormatUtil.getHomeCoupons(userNotifyCoupons.subList(0, endIndex)));
            Coupon.notifyUserNewCoupon(userNotifyCoupons);
        } else {
            indexPage.accumulate("userNotifyCoupons", null);
        }

        return BaseUtil.buildSuccessResp("获取首页数据成功", indexPage);
    }

    private String getExValue(String ex, String key) {
        Map<String, Object> map = new HashMap<String, Object>();
        if (StringUtils.isBlank(ex))
            return "";
        String[] array = ex.split("\\|");
        for (String str : array) {
            if (StringUtils.isBlank(str))
                continue;
            String[] arr = str.split(":");
            if (arr == null || arr.length == 0)
                continue;
            if (arr[0].equals(key)) {
                if (arr.length < 2)
                    continue;
                return arr[1];
            }
        }
        return "";
    }

}
