package cn.jugame.rent.api.utils;


import cn.jugame.rent.api.constants.ParamConstant;
import cn.jugame.util.helper.misc.ChecksumHelper;
import cn.jugame.util.helper.net.HttpHelper;
import com.jfinal.kit.PropKit;
import net.sf.json.JSONObject;

import java.util.Map;
import java.util.TreeMap;

/**
 * ClassName:SmsUtil <br/>
 * Function: 发送验证码和校验验证码 <br/>
 * Date:     2015年12月25日 上午10:56:07 <br/>
 *
 * @author solom
 * @see
 * @since JDK 1.7
 */
public class SmsUtil {
    private String appKey;
    private String signName;
    private String smsId;
    private String smsUrl;
    private HttpHelper client;
    private String secretKey;

    public SmsUtil() {
        appKey = PropKit.get("appsms.app_key");
        signName = PropKit.get("appsms.sign_name");
        smsId = PropKit.get("appsms.sms_id");
        smsUrl = PropKit.get("appsms.url");
        secretKey = PropKit.get("appsms.secret_key");
        client = new HttpHelper();
    }

    public JSONObject sendSmsCode(String mobile) {
        JSONObject rtnData = new JSONObject();
        Map<String, String> params = new TreeMap<String, String>();
        params.put("appKey", appKey);
        params.put("signName", signName);
        params.put("smsId", smsId);
        params.put("mobile", mobile);
        String vcode = ChecksumHelper.getChecksum(params, secretKey);
        String url = String.format("%s/send/smscode?appKey=%s&signName=%s&smsId=%s&mobile=%s&vcode=%s", smsUrl, appKey, signName, smsId, mobile, vcode);
        String response = sendRequest(url);
        if (response == null) {
            rtnData.put("is_send", false);
            rtnData.put("msg", "短信发送失败");
        }
        JSONObject res = JSONObject.fromObject(response);
        if (res.getInt("code") != 0) {
            rtnData.put("is_send", false);
            rtnData.put("msg", res.getString("msg"));
            return rtnData;
        }
        rtnData.put("is_send", true);
        rtnData.put("msg", "ok");
        return rtnData;
    }

    public boolean validateSmsCode(String mobile, String code) {
        Map<String, String> params = new TreeMap<String, String>();
        params.put("appKey", appKey);
        params.put("code", code);
        params.put("smsId", smsId);
        params.put("mobile", mobile);
        String vcode = ChecksumHelper.getChecksum(params, secretKey);
        String url = String.format("%s/validate/smscode?appKey=%s&code=%s&smsId=%s&mobile=%s&vcode=%s", smsUrl, appKey, code, smsId, mobile, vcode);
        String response = sendRequest(url);
        if (response == null) {
            return false;
        }
        JSONObject res = JSONObject.fromObject(response);
        if (!res.getBoolean("data")) {
            return false;
        }
        return true;
    }

    public boolean validateVoiceCode(String mobile, String code) {
        Map<String, String> params = new TreeMap<String, String>();
        params.put("appKey", appKey);
        params.put("code", code);
        params.put("mobile", mobile);
        String vcode = ChecksumHelper.getChecksum(params, secretKey);
        String url = String.format("%s/validate/voicecode?appKey=%s&mobile=%s&code=%s&vcode=%s", smsUrl, appKey, mobile, code, vcode);
        String response = sendRequest(url);
        if (response == null) {
            return false;
        }
        JSONObject res = JSONObject.fromObject(response);
        if (!res.getBoolean("data")) {
            return false;
        }
        return true;
    }

    public boolean validateCode(String mobile, String code, int type) {
        boolean flag = false;
        switch (type) {
            case ParamConstant.VCODE_TEXT:
                flag = validateSmsCode(mobile, code);
                break;
            case ParamConstant.VCODE_VOICE:
                flag = validateVoiceCode(mobile, code);
                break;
            default:
                break;
        }
        return flag;
    }

    public JSONObject sendVoiceCode(String mobile) {
        JSONObject rtnData = new JSONObject();
        Map<String, String> params = new TreeMap<String, String>();
        params.put("appKey", appKey);
        params.put("mobile", mobile);
        String vcode = ChecksumHelper.getChecksum(params, secretKey);
        String url = String.format("%s/send/voicecode?appKey=%s&mobile=%s&vcode=%s", smsUrl, appKey, mobile, vcode);
        String response = sendRequest(url);
        if (response == null) {
            rtnData.put("is_send", false);
            rtnData.put("msg", "短信发送失败");
            return rtnData;
        }
        JSONObject res = JSONObject.fromObject(response);
        if (res.getInt("code") != 0) {
            rtnData.put("is_send", false);
            rtnData.put("msg", res.getString("msg"));
            return rtnData;
        }
        rtnData.put("is_send", true);
        rtnData.put("msg", "ok");
        return rtnData;
    }

    private String sendRequest(String url) {
        return client.doGet(url);
    }
}