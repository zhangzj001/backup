package cn.jugame.rent.api.utils;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.commons.RtnCode;
import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.rent.utils.CacheUtil;
import cn.jugame.rent.utils.ServiceFactory;
import com.jfinal.kit.HttpKit;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;

public class AccountUtil {
    private final static String WECHAT_URL = "https://api.weixin.qq.com/sns/userinfo?access_token=%s&openid=%s";
    private static final IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
    public static JSONObject getWechatUserInfo(String accessToken, String openId) {
        if (StringUtils.isEmpty(accessToken) || StringUtils.isEmpty(openId)) {
            return null;
        }
        JSONObject result = null;
        String res = "";
        String url = String.format(WECHAT_URL, accessToken, openId);

        res = HttpKit.get(url);

        if (StringUtils.isBlank(res)) {
            return result;
        }
        result = JSONObject.fromObject(res);
        return result;
    }

    public static Integer isUserLogin(String loginToken){
        Integer uid= null;
        String cacheKey = "rentapi_" + loginToken;
        JSONObject dataJson = CacheUtil.get(cacheKey);
        boolean isLogin =false;
        if (dataJson != null) {
            isLogin = dataJson.optBoolean("isLogin", false);

        }else{
            // 接口判断
            AccountBean account = accountCenterService.checkLoginByToken(loginToken);
            if (account != null && account.getCode() == RtnCode.OK) {
                dataJson = JSONObject.fromObject(account.getData());
                isLogin = dataJson.optBoolean("isLogin", false);
            }
        }
        if (isLogin) {
            // 设置用户UID
            uid = dataJson.getInt("uid");
            // 写入缓存
            CacheUtil.set(cacheKey, 10 * 60, dataJson);
        }
        return  uid;
    }
}
