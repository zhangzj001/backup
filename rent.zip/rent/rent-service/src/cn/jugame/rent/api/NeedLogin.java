package cn.jugame.rent.api;

import java.lang.annotation.*;

/**
 * 带此注解的action，需要登录才能调用，同事action内会被设置uid字段
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface NeedLogin {
}
