package cn.jugame.rent.api.utils;

import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.rent.api.constants.ParamConstant;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;

public class BaseUtil {

    public static JSONObject buildSuccessResp(String msg,JSONObject data){
        return getResponse(ParamConstant.RESPONSE_SUCCESS,msg,data);
    }

    public static JSONObject buildFailResp(String msg,JSONObject data){
        return getResponse(ParamConstant.RESPONSE_FAIL,msg,data);
    }

    public static JSONObject buildExceptionResp(String msg,JSONObject data){
        return getResponse(ParamConstant.RESPONSE_EXCEPTION,msg,data);
    }

    public static JSONObject getResponse(int code,String msg,JSONObject data){
        JSONObject response = new JSONObject();
        response.accumulate("code",code);
        response.accumulate("msg",msg);
        response.accumulate("data",data != null ? data : new JSONObject());
        return response;

    }

    public static <T> T parseJson2Obj(String jsonData, Class<T> c) {
        if (null == jsonData) {
            return null;
        }
        Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        T obj = gson.fromJson(jsonData.trim(), c);
        return obj;
    }

}
