package cn.jugame.rent.api;

import java.io.File;
import java.io.FileFilter;
import java.net.URL;
import java.util.Enumeration;
import java.util.Map;

import com.jfinal.kit.StrKit;

public class BusiActionScanUtil {

	// 扫描指定包下的BusiAction注解
	public static void scan(final String packageName, Map<String, Class<?>> serviceClzMap) {

		String packagePath = packageName.replace(".", "/");

		try {
			Enumeration<URL> urls = BusiActionScanUtil.class.getClassLoader().getResources(packagePath);
			while (urls.hasMoreElements()) {
				URL url = urls.nextElement();
				System.out.println(url.getPath() + "--" + url.getProtocol());
				if (null != url) {
					String protocol = url.getProtocol();
					if ("file".equalsIgnoreCase(protocol)) {
						addClass(url.getPath(), packageName, serviceClzMap);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//
	private static void addClass(String pathName, String packageName, Map<String, Class<?>> serviceClzMap) {
		File[] files = new File(pathName).listFiles(new FileFilter() {
			public boolean accept(File pathname) {
				if (pathname.getName().endsWith(".class") || pathname.isDirectory()) {
					System.out.println("load pathname:" + pathname);
					return true;
				}
				return false;
			}
		});

		if (files == null) {
			return;
		}

		for (File f : files) {
			String fileName = f.getName();
			if (f.isFile()) {
				String className = fileName.substring(0, fileName.lastIndexOf("."));
				if (!StrKit.isBlank(className)) {
					className = packageName + "." + className;
				}

				System.out.println("--find class:" + className);
				checkAndAdd(className, serviceClzMap);
			} else {
				String subPathname = fileName;
				if (!StrKit.isBlank(fileName)) {
					subPathname = pathName + "/" + subPathname;
				}

				String subPackagename = fileName;
				if (!StrKit.isBlank(subPackagename)) {
					subPackagename = packageName + "." + subPackagename;
				}

				// 递归拉
				addClass(subPathname, subPackagename, serviceClzMap);
			}

		}
	}

	private static void checkAndAdd(String clzName, Map<String, Class<?>> serviceClzMap) {
		Class<?> clz = null;
		try {
			clz = Class.forName(clzName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return;
		}

		BusiAction annotation = clz.getAnnotation(BusiAction.class);
		if (annotation == null) {
			return;
		}

		String service = annotation.service().trim();
		if (!StrKit.isBlank(service)) {

			// 如果service已经有了，且值还不一样，说明service有写重复的哦
			if (serviceClzMap.get(service) != null) {
				System.err.println("dup service" + service + " already set\"" + serviceClzMap.get(service)
						+ "\" conflict with \"" + clzName + "\"");
			}

			serviceClzMap.put(service, clz);
			System.out.println("clzName--" + annotation.service());
		}
	}

}
