package cn.jugame.rent.api.actions;


import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.api.utils.ResponseDataFormatUtil;
import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.User;
import com.jfinal.plugin.activerecord.Record;
import net.sf.json.JSONObject;

import java.util.List;

@BusiAction(service="app.newcomerGiftPage")
public class NewcomerGiftCmd extends BaseCmd {

    @Override
    public JSONObject process() throws Exception {
        JSONObject indexPage = new JSONObject();
        List<Record> newcomerGift = Coupon.getNewcomerGift();
        indexPage.accumulate("newcomer_gift", ResponseDataFormatUtil.getNewcomerGift(newcomerGift));
        //是否领取新人礼包
        indexPage.accumulate("has_newcomer_gift",uid != null && User.hadNewcomerGift(uid));
        //优惠券是否已用
        indexPage.accumulate("has_newcomer_gift_left",uid != null && User.hadNewcomerGiftLeft(uid));
        return BaseUtil.buildSuccessResp("获取首页数据成功",indexPage);
    }
}
