package cn.jugame.rent.api;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.commons.RtnCode;
import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.rent.utils.CacheUtil;
import cn.jugame.rent.utils.CommonRtnCode;
import cn.jugame.rent.utils.ServiceFactory;
import cn.jugame.rent.utils.UseLoginException;
import com.jfinal.kit.StrKit;
import net.sf.json.JSONObject;

public class NeedLoginHandler {
	private static final IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);

	public static void doCheck(BaseCmd cmd) throws UseLoginException {
		NeedLogin needLogin = cmd.getClass().getAnnotation(NeedLogin.class);

		// 不需要检查登录信息
		if (needLogin == null) {
			return;
		}

		// token为空
		if (StrKit.isBlank(cmd.loginToken)) {
			throw new UseLoginException(CommonRtnCode.TOKEN_INVALID, CommonRtnCode.MSG_TOKEN_INVALID);
		}

		String cacheKey = "rentapi_" + cmd.loginToken;

		JSONObject dataJson = CacheUtil.get(cacheKey);
		if (dataJson == null) { // 缓存取不到数据
			// 接口判断
			AccountBean account = accountCenterService.checkLoginByToken(cmd.loginToken);
			if (account != null && account.getCode() == RtnCode.OK) {
				dataJson = JSONObject.fromObject(account.getData());

				// 写入缓存
				CacheUtil.set(cacheKey, 10 * 60, dataJson);
			}
		}

		if (dataJson != null) {
			boolean isLogin = dataJson.optBoolean("isLogin", false);
			if (isLogin) {
				// 设置用户UID
				cmd.uid = dataJson.getInt("uid");
				return;
			} else {
				throw new UseLoginException(CommonRtnCode.TOKEN_EXPIRED, CommonRtnCode.MSG_TOKEN_EXPIRED);
			}
		}

		// 判断异常
		throw new UseLoginException(CommonRtnCode.TOKEN_SYS_EXCEPTION, CommonRtnCode.MSG_TOKEN_SYS_EXCEPTION);
	}
}
