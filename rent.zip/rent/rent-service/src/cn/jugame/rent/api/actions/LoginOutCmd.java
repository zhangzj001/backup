package cn.jugame.rent.api.actions;

import cn.jugame.account_center.commons.RtnCode;
import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.utils.BaseUtil;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;


@BusiAction(service="account.logout")
public class LoginOutCmd extends BaseCmd{


    @Override
    public JSONObject process() throws Exception {
        if (StringUtils.isEmpty(loginToken)) {
           return BaseUtil.buildFailResp("参数错误",null);
        }
        AccountBean bean = accountService.logout(loginToken, "app");
        if (bean == null) {
            return BaseUtil.buildFailResp("注销失败",null);
        }
        if (bean.getCode() != RtnCode.OK) {
            return BaseUtil.buildFailResp("注销失败",null);
        }
        JSONObject rtnData = new JSONObject();
        rtnData.put("is_logout", true);

        return BaseUtil.buildSuccessResp("注销成功", rtnData);
    }
}
