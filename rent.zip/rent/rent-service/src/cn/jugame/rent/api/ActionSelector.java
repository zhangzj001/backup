package cn.jugame.rent.api;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jfinal.kit.StrKit;

import net.sf.json.JSONObject;

public class ActionSelector {
	private static Logger logger = LoggerFactory.getLogger(ActionSelector.class);

	// 扫描的包
	private static final String ACTIONS_PACKAGENAME = "cn.jugame.rent.api.actions";

	// 注解中的service->类名
	private static final Map<String, Class<?>> ACTION_MAP = new HashMap<String, Class<?>>();

	// 初始化，应用启动时调用
	public static void init() {
		ACTION_MAP.clear();
		BusiActionScanUtil.scan(ACTIONS_PACKAGENAME, ACTION_MAP);
	}

	// 获取Action
	public static BaseCmd select(String body, int encodeType) throws Exception {
		if (StrKit.isBlank(body)) {
			throw new Exception("post body is null");
		}

		logger.info("parse body:" + body);

		// 解析body json
		JSONObject reqJson = JSONObject.fromObject(body);
		if (reqJson == null) {
			throw new Exception("parse json error");
		}

		// 解析全部参数
		String reqId = reqJson.getString("id");
		String reqService = reqJson.getString("service");
		JSONObject reqClient = reqJson.getJSONObject("client");
		JSONObject reqExtInfo = reqJson.getJSONObject("extInfo");
		JSONObject reqData = reqJson.getJSONObject("data");

		// 简单的参数校验
		if (StrKit.isBlank(reqId) || StrKit.isBlank(reqService) || reqClient == null || reqExtInfo == null
				|| reqData == null) {
			throw new Exception("bad param");
		}

		// 选择处理action
		Class<?> clz = ACTION_MAP.get(reqService);
		if (clz == null) {
			throw new Exception("service:" + reqService + " no action mapping");
		}

		// 构造处理对象
		try {
			BaseCmd cmd = (BaseCmd) clz.newInstance();
			cmd.setParam(reqId, reqClient, reqExtInfo, reqData, reqService);
			cmd.setEncodeType(encodeType);

			// 判断是否需要登录
//			NeedLoginHandler.doCheck(cmd);

			// 返回cmd
			return cmd;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
}
