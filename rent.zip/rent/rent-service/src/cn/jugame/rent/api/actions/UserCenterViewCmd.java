package cn.jugame.rent.api.actions;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.NeedLogin;
import cn.jugame.rent.api.constants.ParamConstant;
import cn.jugame.rent.api.constants.ServiceMap;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.api.utils.ResponseDataFormatUtil;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.page.service.GameCenterService;
import cn.jugame.rent.page.service.Platforms;
import cn.jugame.rent.page.service.SellerBlackListService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.ServiceFactory;
import cn.jugame.rent.utils.UsernameUtil;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@BusiAction(service = "app.user_center_page")
@NeedLogin
public class UserCenterViewCmd extends BaseCmd {
    private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);

    @Override
    public JSONObject process() throws Exception {
        JSONObject userCenterPage = new JSONObject();

        MemberBean<?> bean = accountCenterService.findMemberByUid(uid);
        String headimg = "";
        if (bean != null && bean.getData() != null) {
            Member member = (Member) bean.getData();
            headimg = member.getHeadimgurl();
        }
        String nickName = UsernameUtil.getUserName(bean, uid);
        userCenterPage.accumulate("headimg", headimg);
        userCenterPage.accumulate("nickName", nickName + " (uid: " + uid + ")");
        //获取用户基本信息
        //通过平台成功交易订单赚的钱
        double revenue = 0;
        Record row = SmartDb.findFirst("select sum(order_pay_amount * (1 - order_fee)) as _sum from `order` where selluser_uid=? and order_status=?", uid, Order.ORDER_STATUS_FINISH);
        if (row != null && row.get("_sum") != null) {
            revenue = Common.round(row.getBigDecimal("_sum").doubleValue() / 100.0, 2);
        }

        userCenterPage.accumulate("revenue", revenue);
        //在租号平台获取这个用户的信息
        Record member = User.getMember(uid);
        //玩家+号主信誉分
        userCenterPage.accumulate("reputation_score", member.getInt("reputation_score"));
        userCenterPage.accumulate("play_score", member.getInt("play_score"));
        //玩家资产: 余额 + 优惠券数量 + 开心豆
        {
            MemberBean<?> mb = accountCenterService.queryBalance(uid);
            userCenterPage.accumulate("balance", mb.getData());

            Record nRow = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=? and  `end_date`>=? and `left_times`>0 limit 1", uid, Common.now());
            //Record nRow = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=? and `beg_date`<=? and `end_date`>=? and `left_times`>0 limit 1", uid, Common.now(), Common.now());
            userCenterPage.accumulate("coupon_count", nRow.getLong("_count"));

            int beanCount = GameCenterService.instance.getBeanCount(uid);
            userCenterPage.accumulate("bean_count", beanCount);
        }

        int sellLevel = member.getInt("sell_level");
        //判断号主是否满足签约条件（非签约号主）
        int sellerUpgradeLevel = 0;
        Record userRankInfo = SmartDb.findFirst("select * from seller_score where uid = ?", uid);
        if (userRankInfo != null) {
            Double succOrderRate = userRankInfo.getBigDecimal("succ_order_rate").doubleValue();
            Double score = userRankInfo.getBigDecimal("score").doubleValue();
            sellerUpgradeLevel = User.getSellerUpgradeLevel(uid, succOrderRate, score, member.getInt("sell_level"));

        }
        if (sellLevel == User.SELL_LEVEL_NORMAL && sellerUpgradeLevel > User.SELL_LEVEL_NORMAL) {
            userCenterPage.accumulate("reach_sign_line", true);
        } else {
            userCenterPage.accumulate("reach_sign_line", false);
        }


        //如果是签约号主，有锁定的资金
        Record lockAmountRow = SmartDb.findFirst("select sum(`amount`) as _amount from `order_delay_transfer` where `uid`=? and `status`=?", uid, Order.DELAY_TRANSFER_NOT_FINISH);
        if (lockAmountRow.getBigDecimal("_amount") != null) {
            userCenterPage.accumulate("lock_amount", Common.round(lockAmountRow.getBigDecimal("_amount").intValue() / 100.0, 2)); //转成元来展示
        } else {
            userCenterPage.accumulate("lock_amount", 0);
        }

        //号主等级
        userCenterPage.accumulate("sell_level", sellLevel);
        //判断玩家被多少玩家拉黑，最近三天是否有拉黑记录
        int blackItemCounts = SellerBlackListService.instance.getAmountOfBlackListByUserId(uid);
        int blackItemRecentCounts = SellerBlackListService.instance.getUserBlackListIn3Day(uid);
        if (blackItemCounts >= PropKit.getInt("seller.uncivilized_blackitem_counts") && blackItemRecentCounts > 0) {
            userCenterPage.accumulate("uncivilized_rent_user", true);
        }
        //玩家“退款中”、玩家“仲裁中” 和 号主“待处理” 的订单数量
        {
            //退款中的订单数量
            List<Record> rows = Order.getBuyuserOrders(uid, Order.ORDER_STATUS_CANCEL, 1, -1, -1);
            userCenterPage.accumulate("buyuser_refunding_order_count", rows.get(0).getInt("_count"));

            //售后处理中的订单数量，for买家
            rows = Order.getBuyuserOrders(uid, Order.ORDER_IN_ARBITRATE, 1, -1, -1);
            userCenterPage.accumulate("buyuser_arbitrating_order_count", rows.get(0).getInt("_count"));

            //待处理的订单数量, for卖家
            rows = Order.getSelluserOrders(uid, Order.ORDER_IN_SOLVE, 1, -1, -1);
            userCenterPage.accumulate("selluser_solving_order_count", rows.get(0).getInt("_count"));

            //售后处理的订单数量，for卖家
            rows = Order.getSelluserOrders(uid, Order.ORDER_IN_ARBITRATE, 1, -1, -1);
            userCenterPage.accumulate("selluser_arbitrating_order_count", rows.get(0).getInt("_count"));
        }


        //个人中心banner
        String sql = "SELECT a.* FROM pt_banner_images a INNER JOIN pt_banner b ON a.banner_id = b.id AND b.tag = ? and a.status = 1 and b.status = 1 and (down_time >= NOW() or down_time is null) and (up_time < NOW() OR up_time IS NULL) ORDER BY weight ASC";
        List<Record> mainBoards = SmartDb.get("platform").find(sql, PropKit.get("index.ucenter_boards_tag"));
        userCenterPage.accumulate("boards", ResponseDataFormatUtil.getUserCenterBoards(mainBoards));

        //个人服务列表
        List<JSONObject> servicesInfo = new ArrayList<>();
        for (Map.Entry<String, String> entry : ServiceMap.getService(ParamConstant.USER_TYPE_BUYER).entrySet()) {
            servicesInfo.add(new JSONObject().accumulate("title", entry.getKey()).accumulate("target_url", entry.getValue()));
        }

        List<JSONObject> sellServicesInfo = new ArrayList<>();
        for (Map.Entry<String, String> entry : ServiceMap.getService(ParamConstant.USER_TYPE_SELLER).entrySet()) {
            sellServicesInfo.add(new JSONObject().accumulate("title", entry.getKey()).accumulate("target_url", entry.getValue()));
        }
        userCenterPage.accumulate("buyuser_service", JSONArray.fromObject(servicesInfo));
        userCenterPage.accumulate("selluser_service", JSONArray.fromObject(sellServicesInfo));

        //获取用户红包数
        userCenterPage.accumulate("redpack_count", Platforms.singleton.getUserRedvdlopCount(uid));

        return BaseUtil.buildSuccessResp("获取个人中心数据成功", userCenterPage);
    }

}
