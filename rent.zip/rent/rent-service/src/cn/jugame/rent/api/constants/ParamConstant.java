package cn.jugame.rent.api.constants;

public class ParamConstant {
    //首页成功订单记录数
    public static  final int HOME_PAGE_NEWS_LIMIT = 3;

    //返回成功
    public static  final int RESPONSE_SUCCESS = 0;

    //返回失败
    public static  final int RESPONSE_FAIL = 1;

    //系统异常
    public static  final int RESPONSE_EXCEPTION = -1;

    //号主
    public static final int USER_TYPE_SELLER = 2;

    //玩家
    public static  final int USER_TYPE_BUYER = 1;

    //用户中心业务
    public final static String ACCOUNT_BUSI = "app";

    /**
     * 文字验证码
     */
    public static final int VCODE_TEXT = 0;

    /**
     * 语音验证码
     */
    public static final int VCODE_VOICE = 1;
}
