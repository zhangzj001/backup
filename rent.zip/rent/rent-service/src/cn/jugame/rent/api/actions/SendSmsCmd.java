package cn.jugame.rent.api.actions;

import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.BusiAction;
import cn.jugame.rent.api.utils.BaseUtil;
import cn.jugame.rent.api.utils.SmsUtil;
import net.sf.json.JSONObject;

@BusiAction(service="account.send_sms")
public class SendSmsCmd extends BaseCmd {
    private SmsUtil smsUtil;
    public SendSmsCmd(){
        super();
        smsUtil = new SmsUtil();

    }
    @Override
    public JSONObject process() {
       /* SmsUtil smsUtil = new SmsUtil();*/
        JSONObject rtnData = new JSONObject();
        if(dataJson == null || ! (dataJson instanceof JSONObject )){
            return BaseUtil.buildFailResp("data为空或者类型为空"+dataJson,null);
        }
        String reason = dataJson.optString("reason");
        String mobile = dataJson.optString("mobile");
        String type = dataJson.optString("type");
        if ("register".equalsIgnoreCase(reason)) {
            AccountBean memberBean = accountService.checkUserExistByMobile(mobile);
            if (memberBean != null && memberBean.getCode() == MemberBean.OK) {
                JSONObject dataObj = JSONObject.fromObject(memberBean.getData());
                boolean isNotExist = dataObj.getBoolean("isExist");
                if (isNotExist) {
                    rtnData.put("is_send", false);
                    rtnData.put("msg", "该手机号已注册");
                    BaseUtil.buildFailResp("该手机号已注册",rtnData);
                }
            }
        }
        try {
            switch (type) {
                case "text":
                    rtnData = smsUtil.sendSmsCode(mobile);
                    break;
                case "voice":
                    rtnData = smsUtil.sendVoiceCode(mobile);
                    break;
                default:
                    rtnData = smsUtil.sendSmsCode(mobile);
                    break;
            }
        } catch (Exception e) {
            rtnData.put("is_send", false);
            rtnData.put("msg", "短信发送失败"+e.getMessage());
            return BaseUtil.buildFailResp("短信发送失败", rtnData);
        }
        return  BaseUtil.buildSuccessResp("短信发送成功", rtnData);
    }
}
