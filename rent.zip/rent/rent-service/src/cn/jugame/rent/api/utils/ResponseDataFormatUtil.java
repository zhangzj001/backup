package cn.jugame.rent.api.utils;


import cn.jugame.rent.api.constants.ServiceMap;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.utils.Common;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 功能：处理调用api返回的结果
 * 创建日期：2018-04-12
 * @author jiangshishan
 *
 */
public class ResponseDataFormatUtil {



    /**
     * 处理首页主导航的放回结果
     * Examples:
     *
     * @param
     * @return     JSONArray 格式化的主导航数据
     * @exception
     */
    public static JSONArray getMainNav(){
        HashMap<String,List> navItems = ServiceMap.getMainNavService();
        JSONArray navs = new JSONArray();
        for(Map.Entry<String,List>entry:navItems.entrySet()){
            JSONObject menu = new JSONObject();
            menu.put("title",entry.getKey());
            List<String> urls = entry.getValue();
            menu.put("pic_url",urls.get(0));
            menu.put("target_url",urls.get(1));
            navs.add(menu);
        }

        return navs;
    }
    
    /**
     * 处理首页主导航的放回结果
     * Examples:
     *
     * @param    mainNavs
     * @return     JSONArray 格式化的主导航数据
     * @exception
     */
    public static JSONArray getMainNav(List<Record> mainNavs){
        JSONArray navs = new JSONArray();
        for(Record nav : mainNavs){
            JSONObject menu = new JSONObject();
            menu.put("title",nav.getStr("title"));
            menu.put("pic_url",nav.getStr("img"));
            menu.put("target_url",nav.getStr("url"));
            navs.add(menu);
        }

        return navs;
    }
    
    /**
     * 处理首页的幻灯片返回结果
     * Examples:
     *
     * @param       boards
     * @return     JSONArray 格式化的幻灯片数据
     * @exception
     */
    public static JSONArray getHomeBoards(List<Record> boards){

        HashMap<String,String> dataStruct = new HashMap<>();
        dataStruct.put("pic_url","image_url");
        dataStruct.put("target_url","alink");
        return getHomeCommonResult(boards,dataStruct);
    }

    /**
     * 处理首页的热门游戏和视频的返回结果
     * Examples:
     *
     * @param       hotItems
     * @return     JSONArray 格式化的游戏和视频vip数据
     * @exception
     */
    public static JSONArray getHomeHotGamesOrVips(List<Record> hotItems){
        HashMap<String,String> dataStruct = new HashMap<>();
        dataStruct.put("game_id","game_id");
        dataStruct.put("game_name","game_name");
        dataStruct.put("icon_url","icon_url");
        dataStruct.put("product_count","product_count");
        dataStruct.put("game_short_name","game_short_name");
        dataStruct.put("tag1","tag1");
        dataStruct.put("tag1_url","tag1_url");
        dataStruct.put("tag2","tag2");
        dataStruct.put("tag2_url","tag2_url");
        return getListUrlResult(getHomeCommonResult(hotItems,dataStruct));
    }

    /**
     * 处理首页的推荐游戏和视频的返回结果
     * Examples:
     *
     * @param       products
     * @return     JSONArray 格式化的推荐商品数据
     * @exception
     */
    public static JSONArray getHomeRecommendProducts(List<Record> products){
        HashMap<String,String> dataStruct = new HashMap<>();
        dataStruct.put("product_id","product_id");
        dataStruct.put("game_pic","game_pic");
        dataStruct.put("game_name","game_name");
        dataStruct.put("name","name");
        dataStruct.put("sell_level","sell_level");
        dataStruct.put("trade_hour","trade_hour");
        dataStruct.put("price_hour","price_hour");
        dataStruct.put("seller_guarantee_amount","seller_guarantee_amount");
        dataStruct.put("guarantee_deposit","guarantee_deposit");
        dataStruct.put("game_short_name","game_short_name");
        return getDetailUrlResult(getHomeCommonResult(products,dataStruct));
    }
    /**
     * 处理首页的公告的返回结果
     * Examples:
     *
     * @param       announcements
     * @return     JSONArray 格式化的幻灯片数据
     * @exception
     */
    public  static JSONArray getHomeAnnouncements(List<Record> announcements){
        HashMap<String,String> dataStruct = new HashMap<>();

        dataStruct.put("title","title");
        dataStruct.put("id","announcement_id");
        dataStruct.put("url","url");
        return getAnnouncementUrlResult(getHomeCommonResult(announcements,dataStruct));
    }
    /**
     * 处理首页的成功订单的返回结果
     * Examples:
     *
     * @param       successOrders
     * @return     JSONArray 格式化的订单成功数据
     * @exception
     */
    public static  JSONArray getHomeRecentSuccessOrderNews(List<Record> successOrders){
        HashMap<String,String> dataStruct = new HashMap<>();
        dataStruct.put("product_type","product_type");
        dataStruct.put("buyuser_uid","buyuser_uid");
        dataStruct.put("game_name","game_name");
        JSONArray handledResult = getHomeCommonResult(successOrders,dataStruct);
        JSONArray results = new JSONArray();
        for(Object info : handledResult){
            JSONObject itemInfo = JSONObject.fromObject(info);
            itemInfo.accumulate("product_type_name",itemInfo.optInt("product_type") == Product.PRODUCT_TYPE_VIP ?"会员VIP":"游戏账号");
            itemInfo.put("description","用户"+itemInfo.optInt("buyuser_uid") + "租用了" + itemInfo.optString("game_name") + "账号");
            results.add(itemInfo);
        }
        return  results;
    }

    public static JSONArray getUserCenterBoards(List<Record> boards){
        HashMap<String,String> dataStruct = new HashMap<>();
        dataStruct.put("pic_url","image_url");
        dataStruct.put("target_url","alink");
        return getHomeCommonResult(boards,dataStruct);
    }


    public static JSONArray getNewcomerGift(List<Record> gift){
        HashMap<String,String> dataStruct = new HashMap<>();
        dataStruct.put("coupon_id","coupon_id");
        dataStruct.put("pic","pic");
        dataStruct.put("name","name");
        return getHomeCommonResult(gift,dataStruct);
    }
    /**
     * 通用数据集合处理
     * Examples:
     *
     * @param       items
     * @return     JSONArray 格式化数据
     * @exception
     */
    public static JSONArray getHomeCommonResult(List<Record> items, HashMap<String,String> dataStruct){
        JSONArray result = new JSONArray();
        if(items == null){
            return result;
        }
        for(Record item: items) {
            JSONObject itemInfo = new JSONObject();
            for(Map.Entry<String,String>entry:dataStruct.entrySet()){
                itemInfo.accumulate(entry.getKey(),item.get(entry.getValue()));
            }
            result.add(itemInfo);
        }
        return  result;
    }

    /**
     * 修改 jsonarray 通过字段game_short_name 获取 游戏商品列表链接数据
     * Examples:
     *
     * @param       items
     * @return     JSONArray 格式化数据
     * @exception
     */
    public static JSONArray getListUrlResult(JSONArray items){
        JSONArray result = new JSONArray();
        for(Object item:items){
            JSONObject itemInfo = JSONObject.fromObject(item);
            itemInfo.accumulate("target_url", PropKit.get("rent_service_host")+"/"+itemInfo.getString("game_short_name")+"/");
            result.add(itemInfo);
        }
        return result;
    }

    /**
     * 修改 jsonarray 通过字段product_id 获取 为商品详情链接数据
     * Examples:
     *
     * @param       items
     * @return     JSONArray 格式化数据
     * @exception
     */
    public static JSONArray getDetailUrlResult(JSONArray items){
        JSONArray result = new JSONArray();
        for(Object item:items){
            JSONObject itemInfo = JSONObject.fromObject(item);
            itemInfo.accumulate("target_url", PropKit.get("rent_service_host")+"/"+itemInfo.getString("game_short_name")+"/"+itemInfo.getString("product_id")+".html");
            result.add(itemInfo);
        }
        return result;
    }

    /**
     * 修改 jsonarray 通过字段product_id 获取 为商品详情链接数据
     * Examples:
     *http://m.8868.cn/announcement/detail-#(el.id).html?isApp=1
     * @param       items
     * @return     JSONArray 格式化数据
     * @exception
     */
    public static JSONArray getAnnouncementUrlResult(JSONArray items){
        JSONArray result = new JSONArray();
        for(Object item:items){
            JSONObject itemInfo = JSONObject.fromObject(item);
            itemInfo.accumulate("target_url", PropKit.get("platform.url","http://m.8868.cn")+"/announcement/detail-"+itemInfo.getString("id")+".html?isApp=1");
            result.add(itemInfo);
        }
        return result;
    }
    /**
     * 处理首页的优惠券的返回结果
     * Examples:
     *
     * @param       coupons
     * @return     JSONArray 格式化的优惠券
     * @exception
     */
    public  static JSONArray getHomeCoupons(List<Record> coupons){
        HashMap<String,String> dataStruct = new HashMap<>();

        dataStruct.put("name","name");
        dataStruct.put("pic","pic");
        return getHomeCommonResult(coupons,dataStruct);
    }

    /**
     * 处理消息盒子的返回结果
     * Examples:
     * @param       messages
     * @return     JSONArray 格式化的优惠券
     * @exception
     */
    public  static JSONArray getMessages(List<Record> messages){
        JSONArray result = new JSONArray();
        for(Record item:messages){
            JSONObject itemInfo = new JSONObject();
            itemInfo.put("id",item.getInt("id"));
            itemInfo.put("title",item.getStr("title"));
            itemInfo.put("content",item.getStr("content"));
            itemInfo.put("status",item.getInt("status"));
            itemInfo.put("type",item.getInt("message_type"));
            itemInfo.put("target_url",item.getStr("target_url"));
            itemInfo.put("receive_time", Common.show_time(item.getDate("recv_time")));
            result.add(itemInfo);
        }
        return result;

    }
}
