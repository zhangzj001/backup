package cn.jugame.rent.api;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.rent.utils.ServiceFactory;
import net.sf.json.JSONObject;

public abstract class BaseCmd {
	
	public final static int ENCODE_TYPE_M1 = 1;
	public final static int ENCODE_TYPE_M2 = 2;

    public final static Integer CACHE_30_MIN = 30 * 60;

    public final static Integer CACHE_15_MIN = 15 * 60;

    public final static Integer CACHE_5_MIN = 5 * 60;

    public final static Integer CACHE_24_hour = 24 * 60 * 60;
    public String reqId;

    public JSONObject client;

    public JSONObject extInfo;

    public JSONObject dataJson;

    //用户中心服务
    protected IAccountCenterService accountService = ServiceFactory.get(IAccountCenterService.class);// 用户中心服务
    //扩展参数 token
    public String loginToken;


    //用户UID --- 如果有必要会设置用户UID
    public Integer uid;

    //请求的接口名
    public String reqService;

    // 操作系统
    protected String _clientOS;

    public String _clientIP;
    // app标志
    public String _clientAI;
    // 其他参数： 机型，分辨率，当前联网类型等
    protected String _clientEX;
    
    protected int encodeType = ENCODE_TYPE_M2;    

    public void setEncodeType(int encodeType){
    	this.encodeType = encodeType;
    }
    
    public int getEncodeType() {
		return encodeType;
	}

    public void setParam(String reqId, JSONObject client, JSONObject extInfo, JSONObject dataJson, String reqService) {
        this.reqId = reqId;
        this.client = client;
        this.extInfo = extInfo;
        this.dataJson = dataJson;
        this.reqService = reqService;



        this.loginToken = extInfo.getString("token");
        _clientEX = client.optString( "ex", "");
        _clientAI = client.optString( "ai", "");
        _clientOS = client.optString("os", "android");
     /*   // 从EX参数中取imei, model
        String[] exArr = _clientEX.split("\\|");
        for (int i = 0; i != exArr.length; i++) {
            String exItem = exArr[i];
            String[] itemPair = exItem.split("\\:", 2);
            if (itemPair.length == 2) {
                if (itemPair[0].trim().equalsIgnoreCase("ip")) {
                    _clientIP = itemPair[1].trim();
                }
            }
        }
*/
//        System.out.println(String.format("reqService->%s, reqId->%s, datajson->%s, token->%s",
//                reqService, reqId, dataJson.toString(), this.loginToken));
    }

    protected JSONObject buildResp(boolean succ, String msg, JSONObject data){
        JSONObject json = new JSONObject();
        json.put("success", succ);
        json.put("msg", msg);
        if(data != null)
            json.put("data", data);
        return json;
    }
    
    protected JSONObject buildResp(boolean succ, String msg){
    	return buildResp(succ, msg, null);
    }



    //处理请求
    public abstract JSONObject process() throws Exception;
}

