package cn.jugame.rent.api.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.sf.json.JSONObject;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginReqEntity {
    private String type; //mobile,wechat,sms(短信登录)
    private String mobile;//手机登录
    private String passwd;//手机登录密码
    private JSONObject wechat;//微信登录object
    private JSONObject qq;//QQ登录object
    private String vcode;//验证码
    private int vcodeType;//验证码类型
}
