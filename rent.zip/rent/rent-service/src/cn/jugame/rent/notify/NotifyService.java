package cn.jugame.rent.notify;

import cn.j8.consul.ServiceCaller;
import cn.j8.json.Json;
import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.maven.model.Notifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 消息通知服务
 */
public class NotifyService {

    private NotifyService() {
    }

    public final static NotifyService instance = new NotifyService();

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private ServiceCaller serviceCaller = new ServiceCaller(PropKit.get("consul.host"), "rent-notify");

    private Map<String, Object> buildParam(Object... kvs){
        if(kvs.length % 2 != 0)
            return null;

        Map<String, Object> params = new TreeMap<>();
        for(int i=0; i<kvs.length; ++i){
            params.put(String.valueOf(kvs[i]), kvs[++i]);
        }
        return params;
    }

    /**
     * 发送求助通知给号主
     * @param orderId
     * @param helpReason
     */
    public void sendHelpMessageToSelluser(String orderId, String helpReason){
        Map<String, Object> param = buildParam("orderId", orderId, "helpReason", helpReason);
        serviceCaller.call("/notify/sendHelpMessageToSelluser", param);
    }

    /**
     * 发送求助成功的通知给玩家
     * @param orderId
     */
    public void sendHelpFinishMessageToBuyuser(String orderId){
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendHelpFinishMessageToBuyuser", param);
    }

    /**
     * 发送号主求助超时未响应短信给买家和号主
     * @param orderId
     */
    public void sendHelpTimeOutMessageToBuyuser(String orderId) {
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendHelpTimeOutMessageToBuyuser", param);
    }

    /**
     * 发送号主无法协助而同意撤单的通知给玩家
     */
    public void sendHelpFailMessageToBuyuser(String orderId){
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendHelpFailMessageToBuyuser", param);
    }

    /**
     * 发送撤单消息给号主
     * @param orderId
     * @param cancelReason
     */
    public void sendOrderCancelMessageToSelluser(String orderId, String cancelReason){
        Map<String, Object> param = buildParam("orderId", orderId, "cancelReason", cancelReason);
        serviceCaller.call("/notify/sendOrderCancelMessageToSelluser", param);
    }

    /**
     * 发送撤单成功消息给玩家
     * @param orderId
     * @param isDelayRefund
     */
    public void sendOrderCancelMessageToBuyuser(String orderId, boolean isDelayRefund){
        Map<String, Object> param = buildParam("orderId", orderId, "isDelayRefund", isDelayRefund);
        serviceCaller.call("/notify/sendOrderCancelMessageToBuyuser", param);
    }

    /**
     * 发送下单成功信息
     *
     * @param orderId
     */
    public void sendAddOrderToSelluser(String orderId) {
        logger.info("sendAddOrderToSelluser ---> orderId: " + orderId);
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendAddOrderToSelluser", param);
    }

    /**
     * 发送下单失败信息
     *
     * @param orderId
     */
    public void sendAddOrderFailToBuyuser(String orderId) {
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendAddOrderFailToBuyuser", param);
    }

    /**
     * 发送号主停止订单消息给玩家
     *
     * @param orderId
     */
    public void sendOrderStopToBuyuser(String orderId) {
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendOrderStopToBuyuser", param);
    }

    /**
     * 发送仲裁成功信息给玩家
     *
     * @param orderId
     */
    public void sendArbitrateSuccessToBuyuser(String orderId) {
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendArbitrateSuccessToBuyuser", param);
    }

    /**
     * 发送订单完成消息给号主
     * @param orderId
     */
    public void sendOrderFinishMessageToSelluser(String orderId){
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendOrderFinishMessageToSelluser", param);
    }

    /**
     * 发送订单完成消息给玩家
     * @param orderId
     */
    public void sendOrderFinishMessageToBuyuser(String orderId){
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendOrderFinishMessageToBuyuser", param);
    }

    /**
     * 发送订单将近结束给玩家
     * @param orderId
     */
    public void sendOrderNearlyEndMessageToBuyuser(String orderId) {
        Map<String, Object> param = buildParam("orderId", orderId);
        serviceCaller.call("/notify/sendOrderNearlyEndMessageToBuyuser", param);
    }

    /***
     * 发送商品被推荐通知给号主
     * @param selluserUid
     */
    public void sendProductRecommendedMessageToSelluser(int selluserUid) {
        Map<String, Object> param = buildParam("selluserUid", selluserUid);
        serviceCaller.call("/notify/sendProductRecommendedMessageToSelluser", param);
    }

    /**
     * 发送优惠券到期通知给玩家
     *
     * @param uid
     * @param couponName
     * @return
     */
    public void sendCouponOutDateRemindMessageToBuyuser(int uid, String couponName) {
        Map<String, Object> param = buildParam("uid", uid, "couponName", couponName);
        serviceCaller.call("/notify/sendCouponOutDateRemindMessageToBuyuser", param);
    }


    /***
     * 发送第一次撤单申请失败消息给玩家
     * @param orderId
     * @param checkReason
     */
    public void sendFirstCancelApplyFailMessageToBuyuser(String orderId, String checkReason) {
        Map<String, Object> param = buildParam("orderId", orderId, "checkReason", checkReason);
        serviceCaller.call("/notify/sendFirstCancelApplyFailMessageToBuyuser", param);
    }

    /***
     * 发送第二次撤单申请失败消息给玩家
     * @param orderId
     * @param checkReason
     */
    public void sendSecondCancelApplyFailMessageToBuyuser(String orderId, String checkReason) {
        Map<String, Object> param = buildParam("orderId", orderId, "checkReason", checkReason);
        serviceCaller.call("/notify/sendSecondCancelApplyFailMessageToBuyuser", param);
    }

    /**
     * 发送号主等级变动消息给号主
     * @param uid
     * @param currLevel
     * @param previousLevel
     */
    public void sendSellerLevelChangeMessageToSelluser(int uid, int currLevel, int previousLevel) {
        Map<String, Object> param = buildParam("uid", uid, "currLevel", currLevel, "previousLevel", previousLevel);
        serviceCaller.call("/notify/sendSellerLevelChangeMessageToSelluser", param);
    }

    /**
     * 发送订单出售成功消息给号主
     *
     * @param orderId
     * @param store  剩余库存
     */
    public void sendOrderSoldMessageToSelluser(String orderId, int store) {
        Map<String, Object> param = buildParam("orderId", orderId, "store", store);
        serviceCaller.call("/notify/sendOrderSoldMessageToSelluser", param);
    }

    /**
     * 发送扣除商品保证金通知给号主
     * @param uid
     * @param selluserPhonenum
     */
    public void sendDeductProductGuaranteeMessageToSelluser(int uid, String selluserPhonenum){
        Map<String, Object> param = buildParam("uid", uid, "selluserPhonenum", selluserPhonenum);
        serviceCaller.call("/notify/sendDeductProductGuaranteeMessageToSelluser", param);
    }

    /**
     * 发送商品扶持审核失败给号主
     * @param productId
     */
    public void sendProductSupportFailMessageToSelluser(String productId){
        Map<String, Object> param = buildParam("productId", productId);
        serviceCaller.call("/notify/sendProductSupportFailMessageToSelluser", param);
    }

    /**
     * 发送JSPUH的运营类消息
     * @param uids
     * @param title
     * @param brief
     * @param content
     */
    public void sendJpushMessage(Integer[] uids, String title, String brief, String content){
        StringBuffer sb = new StringBuffer();
        for(int i=0; i<uids.length; ++i){
            sb.append(uids[i]).append("`");
        }
        if(sb.length() > 0)
            sb.setLength(sb.length() - 1);
        Map<String, Object> param = buildParam("uids", sb.toString(), "title", title, "brief", brief, "content", content);
        serviceCaller.call("/notify/sendJpushMessage", param);
    }
}
