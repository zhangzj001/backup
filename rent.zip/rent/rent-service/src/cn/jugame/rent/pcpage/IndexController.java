package cn.jugame.rent.pcpage;

import cn.jugame.rent.bean.GameConf;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.interceptor.UserInfoInterceptor;
import cn.jugame.rent.page.service.Platforms;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.UsernameUtil;
import com.google.common.collect.Lists;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.xiaoleilu.hutool.lang.Dict;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;

import java.util.List;
import java.util.Map;

@Before(UserInfoInterceptor.class)
public class IndexController extends cn.jugame.rent.page.IndexController{
	
	private List<Dict> getBanners(String tag){
		List<Record> banners = Platforms.singleton.getBanners(tag);
		List<Dict> list = Lists.newArrayList();
		for(Record banner : banners){
			list.add(Dict.create()
					.set("title", banner.getStr("name"))
					.set("pic_url", banner.getStr("image_url"))
					.set("target_url", banner.getStr("alink")));
		}
		return list;
	}
	
	@Override
	public void index(){
		//顶栏幻灯片
		{
			List<Dict> topBanners = getBanners(PropKit.get("pc.index_top_banner"));
			if(topBanners.size() > 0){
				setAttr("top_banner", topBanners.get(0));
			}
		}
		
		//首页轮播的banner
		{
			setAttr("main_banners", getBanners(PropKit.get("pc.index_main_banner")));
		}
		
		//热门游戏先获取处理，方便重用
		int hotMax = 20;
		int totalMax = 50;
		List<Record> hotMobileGames = Platforms.singleton.getGames(GameConf.TYPE_GAME, GameConf.TAG_HOT, hotMax);
		List<Record> hotPcGames = Platforms.singleton.getGames(GameConf.TYPE_PC_GAME, GameConf.TAG_HOT, hotMax);
		List<Record> hotVips = Platforms.singleton.getGames(GameConf.TYPE_VIP, GameConf.TAG_HOT, hotMax);
		
		//左侧列表
		Dict showList = Dict.create();
		{
			//排行前4的端游
			List<Record> games = Platforms.singleton.getGames(GameConf.TYPE_PC_GAME, GameConf.TAG_HOT, 4);
			
			//补上每个游戏对应的其它信息
			List<Map<String, Object>> gList = toMap(games);
			for(Map<String, Object> g : gList){
				//关键字列表
				List<Dict> kwList = Lists.newArrayList();
				List<Record> keywords = SmartDb.find("select * from `game_keyword` where `game_id`=? and `status`=?", g.get("game_id"), GameConf.STATUS_ENABLE);
				for(Record kw : keywords){
					for(String word : Common.array_filter(kw.getStr("keyword").split(","))){
						word = word.trim();
						String url = kw.getStr("url").replaceAll("\\{\\$game_id\\}", kw.getStr("game_id"))
													.replaceAll("\\{\\$game_name\\}", kw.getStr("game_name"))
													.replaceAll("\\{\\$keyword\\}", word);
						kwList.add(Dict.create().set("word", word).set("url", url));
					}
				}
				g.put("keywords", kwList);
				
				//渠道列表
				JSONObject rtn = getChannels(g.get("game_id").toString());
				JSONArray channels = new JSONArray();
				if(rtn.getInt("code") == 0){
					channels = rtn.getJSONArray("channels");
				}
				g.put("channels", channels);
			}
			showList.set("games", gList);
			
			//另外再加三个标签: 手游专区、端游专区、影视专区
			//手游专区
			Dict mGames = Dict.create()
					.set("hot", toMap(hotMobileGames))
					.set("list", toMap(Platforms.singleton.getGames(GameConf.TYPE_GAME, -1, totalMax)));
			showList.set("m_games", mGames);
			
			//端游专区
			Dict pcGames = Dict.create()
					.set("hot", toMap(hotPcGames))
					.set("list", toMap(Platforms.singleton.getGames(GameConf.TYPE_PC_GAME, -1, totalMax)));
			showList.set("pc_games", pcGames);
			
			//影视专区
			Dict vips = Dict.create()
					.set("hot", toMap(hotVips))
					.set("list", toMap(Platforms.singleton.getGames(GameConf.TYPE_VIP, -1, totalMax)));
			showList.set("vips", vips);
		}
		setAttr("show_list", showList);
		
		//帮助中心！
		{
			setAttr("helps", getHelpInfo(PropKit.get("pc.index_announcement_help_ctgid"), 2));
		}
		
		//最新成交信息
		{
			List<Dict> news = Lists.newArrayList();
			
			int n = 3;
			List<Record> gameOrders = Platforms.singleton.getLatestSuccOrders(Product.PRODUCT_TYPE_GAME, n);
			List<Record> vipOrders = Platforms.singleton.getLatestSuccOrders(Product.PRODUCT_TYPE_VIP, n);
	        for(int i=0; i<n; ++i){
	        	if(i < gameOrders.size()){
		        	Record gameOrder = gameOrders.get(i);
		        	String title = "用户" + UsernameUtil.getUserName(gameOrder.getInt("buyuser_uid")) + "租用了" + gameOrder.getStr("game_name") + "账号";
		        	news.add(Dict.create().set("title", title).set("product_type", gameOrder.getInt("product_type")));
	        	}
	        	
	        	if(i < vipOrders.size()){
		        	Record vipOrder = vipOrders.get(Math.min(i, n-1));
		        	String title = "用户" + UsernameUtil.getUserName(vipOrder.getInt("buyuser_uid")) + "租用了" + vipOrder.getStr("game_name") + "账号";
		        	news.add(Dict.create().set("title", title).set("product_type", vipOrder.getInt("product_type")));
	        	}
	        }
	        
	        setAttr("news", news);
		}
		
		//热门游戏-端游、手游、影视VIP
		{
			int n = 9;
			setAttr("hot_pc_games", toMap(subList(hotPcGames, n)));
			setAttr("hot_m_games", toMap(subList(hotMobileGames, n)));
			setAttr("hot_vips", toMap(subList(hotVips, n)));
		}
		
		//帮助指引banner
		{
			setAttr("help_banners", getBanners(PropKit.get("pc.index_help_banner")));
		}
		
		//优质端游
		{
			List<Record> products = Platforms.singleton.getRecommendedProducts(4, Product.PRODUCT_TYPE_PCGAME);
			setAttr("hot_pc_products", product2map(products));
		}
		
		//优质手游
		{
			List<Record> products = Platforms.singleton.getRecommendedProducts(4, Product.PRODUCT_TYPE_GAME);
			setAttr("hot_m_products", product2map(products));
		}
		
		//活动专区
		{
			setAttr("activity_banners", getBanners(PropKit.get("pc.index_activity_banner")));
		}
		
		//各种帮助
		{
			//玩家帮助
			setAttr("buyuser_fqa", getHelpInfo(PropKit.get("pc.index_buyuser_help_ctgid"), 6));
			//号主帮助
			setAttr("selluser_fqa", getHelpInfo(PropKit.get("pc.index_selluser_help_ctgid"), 6));
			//常见问题
			setAttr("common_fqa", getHelpInfo(PropKit.get("pc.index_common_help_ctgid"), 6));
		}
		
		//友情链接
		{
			List<Record> links = SmartDb.get("platform").find("select * from `links` where `platform`=2 order by `weight` desc");
			setAttr("links", toMap(links));
		}
		
		render("index.html");
	}
	
	private <E> List<E> subList(List<E> list, int toIndex){
		if(list == null || list.size() == 0)
			return list;
		
		return list.subList(0, Math.min(toIndex, list.size()));
	}
	
	private List<Dict> getHelpInfo(String categoryId, int n){
		List<Dict> helpList = Lists.newArrayList();
		List<Record> helpInfos = Platforms.singleton.getHelpInfos(categoryId, n);
		for(Record helpInfo : helpInfos){
			helpList.add(Dict.create()
					.set("title", helpInfo.getStr("help_title"))
					.set("url", PropKit.get("pc.help_info_url").replaceAll("\\{id\\}", helpInfo.getInt("help_id").toString()))
			);
		}
		return helpList;
	}
	
	/**
	 * 端游版全部游戏
	 */
	@Override
	public void allGames(){
		super.allGames();
		//如果有发生错误
		String err = getAttr("error");
		if(StringUtils.isNotBlank(err)){
			return;
		}
		render("allgames.html");
	}
	
	//租送优惠静态页
	public void zsyh(){
		String[] tags = new String[21]; //就预留20个给运营用
		tags[0] = PropKit.get("pc.zsyh_banner");
		for(int i=1; i<tags.length; ++i){
			tags[i] = PropKit.get("pc.zsyh_banner") + i;
		}
		
		List<Record> banners = Platforms.singleton.getBannerInfo(tags);
		List<Dict> data = Lists.newArrayList();
		for(Record banner : banners){
			List<Record> bannerImgs = Platforms.singleton.getBannerImages(banner.getInt("id"));
			Dict dict = Dict.create()
					.set("title", banner.getStr("name"))
					.set("banners", toMap(bannerImgs));
			data.add(dict);
		}
		setAttr("data", data);
		
		render("static/zsyh.html");
	}
	
	//商家入驻静态页
	public void sjrz(){
		render("static/sjrz.html");
	}
	
	//下载租号APP静态页
	public void zhapp(){
		render("static/zhapp.html");
	}
	
	//优质账号静态页
	public void yzzh(){
		String[] tags = new String[21]; //就预留20个给运营用
		tags[0] = PropKit.get("pc.yzzh_banner");
		for(int i=1; i<tags.length; ++i){
			tags[i] = PropKit.get("pc.yzzh_banner") + i;
		}
		
		List<Record> banners = Platforms.singleton.getBannerInfo(tags);
		List<Dict> data = Lists.newArrayList();
		for(Record banner : banners){
			List<Record> bannerImgs = Platforms.singleton.getBannerImages(banner.getInt("id"));
			Dict dict = Dict.create()
					.set("title", banner.getStr("name"))
					.set("banners", toMap(bannerImgs));
			data.add(dict);
		}
		setAttr("data", data);
		
		render("static/yzzh.html");
	}
	
	public void dlGame(){
		String gameId = getPara("game_id");
		Record game = SmartDb.findFirst("select * from game_conf where game_id=?", gameId);
		if(game == null){
			errorPage("不存在的游戏");
			return;
		}
		
		setAttr("game_name", game.getStr("game_name"));
		
		//百度网盘的地址
//		setAttr("download_link", "https://pan.baidu.com/s/1olARFiASXMMNhDpVbMeVvA");
//		setAttr("download_code", "az8e");
		
		setAttr("download_link", game.getStr("download_link"));
		setAttr("download_code", game.getStr("download_code"));
		
		render("static/download_game.html");
	}
}
