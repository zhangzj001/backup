package cn.jugame.rent.pcpage;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.jfinal.aop.Before;

import cn.jugame.rent.interceptor.UserInfoInterceptor;


@Before(UserInfoInterceptor.class)
public class ProductController extends cn.jugame.rent.page.ProductController {
	@Override
	public void detail() {
		super.detail();
		// 如果有发生错误
		String err = getAttr("error");
		if (StringUtils.isNotBlank(err)) {
			return;
		}
		render("detail.html");
	}

	@Override
	public void list() {
		super.list();
		// 如果有发生错误
		String err = getAttr("error");
		if (StringUtils.isNotBlank(err)) {
			return;
		}

		String dt = getPara("dt");
		//需要html片段
		if("part".equalsIgnoreCase(dt)){
			render("_list.html");
			return;
		}
		//加载整页
		render("list.html");
	}

}
