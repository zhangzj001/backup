package cn.jugame.rent.pcpage;

import org.apache.commons.lang.StringUtils;

import com.jfinal.aop.Before;

import cn.jugame.rent.interceptor.UserInfoInterceptor;

@Before(UserInfoInterceptor.class)
public class GameRentController extends cn.jugame.rent.page.GameRentController {
	@Override
	public void index() {
		super.index();
		// 如果有发生错误
		String err = getAttr("error");
		if (StringUtils.isNotBlank(err)) {
			return;
		}
		render("index.html");
	}

	@Override
	public void rentdetail() {
		super.rentdetail();
		// 如果有发生错误
		String err = getAttr("error");
		if (StringUtils.isNotBlank(err)) {
			return;
		}
		render("rentdetail.html");
	}

	@Override
	public void rentVipDetail() {
		super.rentVipDetail();
		// 如果有发生错误
		String err = getAttr("error");
		if (StringUtils.isNotBlank(err)) {
			return;
		}
		render("rentvipdetail.html");
	}
}
