package cn.jugame.rent.pcpage;

import org.apache.commons.lang.StringUtils;

import com.jfinal.aop.Before;

import cn.jugame.rent.interceptor.UserInfoInterceptor;

@Before(UserInfoInterceptor.class)
public class OrderController extends cn.jugame.rent.page.SafeOrderController{
	@Override
	public void prepare() {
		super.prepare();
		
		//如果有发生错误
		String err = getAttr("error");
		if(StringUtils.isNotBlank(err)){
			return;
		}
		render("prepare.html");
	}
	
	public void loginkit(){
		render("loginkit.html");
	}
}
