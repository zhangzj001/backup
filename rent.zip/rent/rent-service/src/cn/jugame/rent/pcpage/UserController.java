package cn.jugame.rent.pcpage;

import cn.jugame.rent.interceptor.UserInfoInterceptor;
import cn.jugame.rent.interceptor.VisitLogInterceptor;
import cn.jugame.rent.utils.Common;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import org.apache.commons.lang.StringUtils;

@Before(UserInfoInterceptor.class)
public class UserController extends cn.jugame.rent.page.UserController{
	@Override
	public void login(){
		String currentUrl = getPara("currentUrl");
		if(StringUtils.isBlank(currentUrl)){
			currentUrl = PropKit.get("rent_service_host");
		}

		Integer uid = getSessionAttr("uid");
		if(uid != null){
			redirect(currentUrl);
			return;
		}
		
		String jugameFr = getCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME);
        if(StringUtils.isBlank(jugameFr))
            jugameFr = "pcrent";
        setAttr("jugame_fr", jugameFr);
		setAttr("currentUrl", Common.url_encode(currentUrl));
		render("login.html");
	}
	
	public void regist(){
		String currentUrl = getPara("currentUrl");
		if(StringUtils.isBlank(currentUrl)){
			currentUrl = PropKit.get("rent_service_host");
		}

		Integer uid = getSessionAttr("uid");
		if(uid != null){
			redirect(currentUrl);
			return;
		}

		String jugameFr = getCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME);
        if(StringUtils.isBlank(jugameFr))
            jugameFr = "pcrent";
        setAttr("jugame_fr", jugameFr);
		setAttr("currentUrl", Common.url_encode(currentUrl));
		render("regist.html");
	}
}
