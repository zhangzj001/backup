package cn.jugame.rent.pcpage;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.commons.RtnCode;
import cn.jugame.account_center.service.vo.AccountBean;
import cn.jugame.rent.api.utils.SmsUtil;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.UserInfoInterceptor;
import cn.jugame.rent.page.BaseController;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.pay.ZhifuWay;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import com.google.common.collect.Lists;
import com.jfinal.aop.Before;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.List;

@Before({LoginInterceptor.class, UserInfoInterceptor.class})
public class PayController extends BaseController{
	
	private Logger logger = Loggers.rentLog();

	private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
	
	private SmsUtil smsUtil = new SmsUtil();
	
	/**
	 * PC端支付首页 
	 */
	public void index(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			orderId = getAttr("order_id");
		}
		
		//获取客户端类型
		String platform = "web";
		String pf = getSessionAttr("pf");
		if("android".equalsIgnoreCase(pf)||"ios".equalsIgnoreCase(pf)||"wap".equalsIgnoreCase(pf)) {
			platform = "wap";
		}
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
		
		//当前正在等待支付的支付单
		Record relet = SmartDb.findFirst("select * from `order_relet` where `order_id`=? and `status`=? order by `id` desc limit 1", orderId, Order.ORDER_STATUS_NEW);
		if(relet == null){
			errorPage("当前订单已经完成支付或者取消支付。");
			return;
		}
		
		//获取PC端的支付策略
		IPayment payment = PaymentFactory.get();
		List<ZhifuWay> ways = payment.getStrateges(platform);
		if(ways.size() == 0){
			errorPage("获取支付方式时发生了一些错误，请稍后重试");
			return;
		}
		
		//计算需要支付的金额数目
		int payAmount = relet.getInt("order_pay_amount");
		int amountOff = relet.getInt("amount_off");
		payAmount -= amountOff;
		if(payAmount < 0)
			payAmount = 0;
		
		//如果是首租单 还需要加上押金
		if(relet.getInt("type") == Order.ORDER_RELET_FIRST){
			payAmount += order.getInt("order_guarantee_deposit");
		}
		
		//如果是0元单，直接重定向到pay接口进行支付
		if(payAmount <= 0){
			String payUrl = "/pc/pay/pay?pay_id=" + relet.getStr("pay_id")+"&platform="+platform;
			redirect(payUrl);
			return;
		}

		//非0元单
		setAttr("pay_id", relet.getStr("pay_id"));
		setAttr("pay_amount", Common.round(payAmount/100.0, 2));
		setAttr("product_name", order.getStr("product_name"));
		
		List<JSONObject> zfWays = Lists.newArrayList();
		//非0元单才需要支付金额
		for(ZhifuWay way : ways){
			//余额支付和银联支付的强行不加入
			if(ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey()) || ZhifuWay.UNIONPAY_KEY.equalsIgnoreCase(way.getPayKey())){
				continue;
			}
			zfWays.add(way.toJson());
		}
		setAttr("zhifu_ways", zfWays);
		
		//用户余额
//		cn.jugame.account_center.service.vo.MemberBean mb = accountCenterService.queryBalance(uid);
//       setAttr("balance", mb.getData());
		setAttr("balance", PaymentFactory.get().getAvailableBalance(uid));
        setAttr("balance_paykey", ZhifuWay.BALANCE_KEY);
//        setAttr("bind_mobile",User.getBindMobile(uid)!=null?1:0);
        setAttr("bind_mobile", 1); //FIXME 已经不走下单时绑定手机号的逻辑了，但是页面改动比较大，这里先暂时统一设置已经绑定手机号，避免触发对应页面逻辑
        setAttr("mobile", User.getBindMobile(uid));
        setAttr("zhifu_type",0);//订单支付为 0 ， 保证金支付为 1
        setAttr("platform",platform);
		
        
		render("index.html");
	}
	
	/**
	 * 保证金支付页
	 */
	public void guanIndex(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		String payId = getPara("pay_id");
		if(StringUtils.isBlank(payId)){
			errorPage("没有支付单ID");
			return;
		}
		
		Record guanOrder = SmartDb.findFirst("select * from `guarantee_amount_order` where `pay_id`=?", payId);
		if(guanOrder == null){
			errorPage("不存在的支付单");
			return;
		}
		
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", guanOrder.getStr("product_id"));
		if(product == null){
			errorPage("不存在的商品");
			return;
		}
		
		String platform = "web";
		String pf = getSessionAttr("pf");
		if("android".equalsIgnoreCase(pf)||"ios".equalsIgnoreCase(pf)||"wap".equalsIgnoreCase(pf)) {
			platform = "wap";
		}
		
		//获取PC端的支付策略
		IPayment payment = PaymentFactory.get();
		List<ZhifuWay> ways = payment.getStrateges(platform);
		if(ways.size() == 0){
			errorPage("获取支付方式时发生了一些错误，请稍后重试");
			return;
		}
		
		
		int payAmount = guanOrder.getInt("amount");
		
		setAttr("pay_id", payId);
		setAttr("pay_amount", Common.round(payAmount/100.0, 2));
		setAttr("product_name", product.getStr("name"));
		
		List<JSONObject> zfWays = Lists.newArrayList();
		for(ZhifuWay way : ways){
			//余额支付和银联支付的强行不加入
			if(ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey()) || ZhifuWay.UNIONPAY_KEY.equalsIgnoreCase(way.getPayKey())){
				continue;
			}
			zfWays.add(way.toJson());
		}
		setAttr("zhifu_ways", zfWays);
		
		//用户余额
		//cn.jugame.account_center.service.vo.MemberBean mb = accountCenterService.queryBalance(uid);
        //setAttr("balance", mb.getData());
		setAttr("balance", PaymentFactory.get().getAvailableBalance(uid));
        setAttr("balance_paykey", ZhifuWay.BALANCE_KEY);
//        setAttr("bind_mobile",User.getBindMobile(uid)!=null?1:0);
        setAttr("bind_mobile", 1); //FIXME 已经不走下单时绑定手机号的逻辑了，但是页面改动比较大，这里先暂时统一设置已经绑定手机号，避免触发对应页面逻辑
        setAttr("mobile", User.getBindMobile(uid));
        setAttr("zhifu_type",1);//订单支付为 0 ， 保证金支付为 1
        
        render("index.html");
	}
	
	/**
	 * 执行支付
	 */
	public void pay(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		//获取客户端类型
		String platform = "web";
		String pf = getSessionAttr("pf");
		if(StringUtils.isBlank(pf))
			pf="pc";
		if("android".equalsIgnoreCase(pf)||"ios".equalsIgnoreCase(pf)||"wap".equalsIgnoreCase(pf)) {
			platform = "wap";
		}
		
		String payId = getPara("pay_id");
		if(StringUtils.isBlank(payId)){
			errorPage("不存在的支付单");
			return;
		}
		
		String payKey = getPara("pay_way");

		//先获取一次支付策略列表
		IPayment payment = PaymentFactory.get();
		List<ZhifuWay> ways = payment.getStrateges(platform);
		
		ZhifuWay way = ZhifuWay.parse(payKey, ways, platform);
		if(way == null){
			errorPage("错误的支付方式");
			return;
		}
		
		String ip = Common.getIp(getRequest());
		logger.info("支付单【" + payId + "】 - IP=>" + ip + ", way=>" + way.toJson());
		
		
		if("android".equalsIgnoreCase(pf)) {
			if(getSessionAttr("isRentApp")!=null&&(boolean)getSessionAttr("isRentApp") == true) {
			   pf = "app";	
			}else if(getSessionAttr("isApp") != null) {
				pf = "app8868";	
			}
		}
		
		//只要有用余额就必须要有支付密码
		String payPasswd = getPara("pay_passwd");
		if(StringUtils.isBlank(payPasswd) && (way.isMix() || ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey())) && StringUtils.isNotBlank(way.getPayWay())){
			errorPage("请输入支付密码之后再进行支付");
			return;
		}
		
		String orderId = "", 
				productName = "",
				productId = "";
		
		//先尝试从租号订单获取数据，若没有则尝试从保证金订单获取数据
		JSONObject json = null;
		{
			Record relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
			if(relet != null){
				Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", relet.getStr("order_id"));
				if(order == null){
					errorPage("不存在的订单");
					return;
				}
				
				//如果订单已经超时撤单，则不再允许支付
				if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
					errorPage("您的订单已经因为超时未支付而撤单，请重新下单。");
					return;
				}
				if(relet.getInt("status") == Order.ORDER_STATUS_CANCEL){
					errorPage("您的支付单已经因为超时未支付而撤销，请重新支付。");
					return;
				}
				
				orderId = order.getStr("order_id");
				productName = order.getStr("product_name");
				productId = order.getStr("product_id");
				
				json = PaymentFactory.get().payOrder(payId, way, payPasswd, ip,pf);
				if(json == null){
					errorPage("支付订单时发生了一些错误，请稍后重试");
					return;
				}
				
				//支付类型是“订单”
				json.put("pay_type", "order");
			}
			//尝试从保证金订单获取
			else{
				//注意这个relet是个保证金订单
				relet = SmartDb.findFirst("select * from `guarantee_amount_order` where `pay_id`=?", payId);
				if(relet != null) {
					Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", relet.getStr("product_id"));
					if(product == null){
						errorPage("支付单信息错误，无法支付！");
						return;
					}
					
					orderId = payId;
					productName = product.getStr("name");
					productId = product.getStr("product_id");
					
					json = PaymentFactory.get().payGuarantee(product, payId, relet.getInt("amount"), way, payPasswd, ip,pf);
					if(json == null){
						errorPage("支付保证金时发生了一些错误，请稍后重试");
						return;
					}
					
					//支付类型是“订单”
					json.put("pay_type", "product");
				}
				//尝试从商品装饰支付获取订单
				else {
					Record productDecorate = SmartDb.findFirst("select * from product_decorate_payment  where pay_id = ? limit 1", payId);
					if (productDecorate == null) {
						errorPage("不存在的支付单");
						return;
					}
					json = PaymentFactory.get().payProductDecorate(productDecorate, payId, productDecorate.getInt("amount"), way, payPasswd, ip,pf);
					if(json == null){
						errorPage("支付保证金时发生了一些错误，请稍后重试");
						return;
					}
					orderId = payId;
					productName = "新春商品装饰";
					//支付类型是“商品装饰”
					json.put("pay_type", "decorate");
				}
				
			}
		}
		
		if(json.getInt("code") != 0){
			errorPage(json.getString("msg"));
			return;
		}
		
		setAttr("pay_id", payId);
		setAttr("order_id", orderId);
		setAttr("product_name", productName);
		setAttr("product_id", productId);
		setAttr("pay_type", json.get("pay_type"));
		//bondOrder   bond-支付保证金     order-支付订单
		//setAttr("bondOrder",payId.equals(orderId)?"bond":"order");
		//根据不同的返回数据，调起不同的页面
		String rtnPayWay = json.getString("pay_way");
		if("balance".equalsIgnoreCase(rtnPayWay)){
			logger.info("订单【" + orderId + " -- " + payId + "】余额支付成功！");
			render("pay_succ.html");
			return;
		}
		if("alipay".equalsIgnoreCase(rtnPayWay)){
			logger.info("订单【" + orderId + " -- " + payId + "】支付宝支付提交成功！");
			//重定向到支付服务页，让支付服务跳去支付宝
			redirect(json.getString("alipay_url"));
			return;
		}
		
		if("wechat".equalsIgnoreCase(rtnPayWay)){
			logger.info("订单【" + orderId + " -- " + payId + "】微信支付提交成功！订单来自【"+pf+"】");
			if("app".equals(pf)||"app8868".equals(pf)) {
				JSONObject payInfo = JSONObject.fromObject(json.get("payInfo"));
				renderJson(buildResp(0, "请求成功", new KeyValue<>("appId",payInfo.getString("appid")) ,
						new KeyValue<>("partnerId",payInfo.getString("partnerid")),
						new KeyValue<>("prepayId",payInfo.getString("prepayid")),
						new KeyValue<>("package",payInfo.getString("package")),
						new KeyValue<>("timestamp",payInfo.getString("timestamp")),
						new KeyValue<>("noncestr",payInfo.getString("noncestr")),
						new KeyValue<>("sign",payInfo.getString("sign")),
						new KeyValue<>("orderId",orderId),
						new KeyValue<>("productId",productId),
						new KeyValue<>("payType",json.get("pay_type")),
						new KeyValue<>("productName",productName)
						//new KeyValue<>("bondOrder",payId.equals(orderId)?"bond":"order")
						));
				return ;
			}else {
				//微信是个傻逼，返回一个支付二维码
				setAttr("qr_code", json.getString("qr_code"));
				setAttr("product_name", productName);
				setAttr("pay_amount", json.get("pay_amount"));
				render("wx_pay.html");
				return;
			}
		}
		
		errorPage("您的订单支付时发生了一些错误，如有问题请联系客服！");
		return;
	}
	
	public void payEnd(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		String payId = getPara("pay_id");
		
		//先从租号订单获取一次数据
		Record relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
		if(relet != null){
			String orderId = relet.getStr("order_id");
			Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
			if(order == null){
				renderJson(buildResp(0, "不存在的订单"));
				return;
			}
			if(order.getInt("buyuser_uid").intValue() != uid.intValue()){
				renderJson(buildResp(0, "非本人订单"));
				return;
			}
			
			int orderStatus = order.getInt("order_status");
			//如果类型是CDK，那么属于购买行为，订单完成了就可以跳转了
			if(order.getInt("product_type") == Product.PRODUCT_TYPE_CDK){
				//订单完成了，那就是支付完成了
				if(orderStatus == Order.ORDER_STATUS_FINISH || orderStatus == Order.ORDER_STATUS_CANCEL){
					renderJson(buildResp(0, "ok"));
					return;
				}
				renderJson(buildResp(1, "等待支付中"));
			}
			//其它类型，说明是租赁，订单在出租中状态就可以跳转了
			//如果订单还在等待支付/新建状态，则返回1
			else{
				//新建+续租中，那就是“等待支付中”
				if(orderStatus == Order.ORDER_STATUS_NEW || orderStatus == Order.ORDER_STATUS_PAYING){
					renderJson(buildResp(1, "等待支付中"));
					return;
				}
				renderJson(buildResp(0, "finish"));
			}
		}
		//再从保证金订单获取一次数据
		else{
			relet = SmartDb.findFirst("select * from `guarantee_amount_order` where `pay_id`=?", payId);
			if(relet !=null) {
				if(relet.getInt("uid").intValue() != uid.intValue()){
					renderJson(buildResp(0, "非本人支付单"));
					return;
				}
				
				if(relet.getInt("status") != Product.GUNRANTEE_AMOUNT_STATUS_NEW){
					renderJson(buildResp(0, "finish"));
					return;
				}
				renderJson(buildResp(1, "等待支付中"));
			}else {
				Record   productDecorate =SmartDb.findFirst("select * from product_decorate_payment  where pay_id = ? limit 1",payId);
				if(productDecorate == null){
					errorPage("不存在的支付单");
					return;
				}
				if(productDecorate.getInt("status") != Product.DECORATE_PAYMENT_STATUS_NEW) {
					renderJson(buildResp(0, "finish"));
					return;
				}
				renderJson(buildResp(1, "等待支付中"));
			}
			
		}
	}
	
	/**
	 * 重置支付密码
	 * **/
	public void resetPayPwd() {
		int resetType = getParaToInt("reset_type");
		Integer uid = getSessionAttr("uid");
		if(uid == null || uid ==0) {
			uid = getParaToInt("uid");
		}
		if(uid == null || uid ==0) {
			renderJson(buildResp(Common.RESPONSE_FAIL, "uid不能为空"));
			return;
		}
		String newPayPwd = getPara("new_pay_pwd");
		if(StringUtils.isBlank(newPayPwd)) {
			renderJson(buildResp(Common.RESPONSE_FAIL, "新支付密码不能为空"));
			return;
		}
		newPayPwd = newPayPwd.trim();
		if(newPayPwd.length() < 6 || newPayPwd.length() > 16) {
			renderJson(buildResp(Common.RESPONSE_FAIL, "新支付密码必须在6-16位字符之间"));
			return;
		}
		
		if(resetType == 1) {  //手机验证码方式修改支付密码
			String mobile = getPara("mobile");
			if(StringUtils.isBlank(mobile)) {
				renderJson(buildResp(Common.RESPONSE_FAIL, "手机号码不能为空"));
				return;
			}
			String vcode = getPara("vcode");
			if(StringUtils.isBlank(vcode)) {
				renderJson(buildResp(Common.RESPONSE_FAIL, "验证码不能为空"));
				return;
			}
			//判断验证码
			if(!smsUtil.validateSmsCode(mobile, vcode)) {
				renderJson(buildResp(Common.RESPONSE_FAIL, "验证码错误"));
				return;
			}
			//重置支付密码
			AccountBean accountBean = accountCenterService.resetPayPasswd(uid, newPayPwd);
			//判断是否重置成功
			if(accountBean != null && accountBean.getData()!=null && accountBean.getCode() == RtnCode.OK) {
				renderJson(buildResp(Common.RESPONSE_SUCCESS, "设置支付密码成功"));
				return;
			}
			if(accountBean != null) {
				logger.info("uid【"+uid+"】根据短信验证码设置支付密码返回信息【"+accountBean.getMsg()+"】");
			}
			renderJson(buildResp(Common.RESPONSE_FAIL, "设置支付密码失败"));
			return;
		}else if(resetType == 2) { //原支付密码方式修改支付密码
			String oldPayPwd = getPara("old_pay_pwd");
			if(StringUtils.isBlank(oldPayPwd)) {
				renderJson(buildResp(Common.RESPONSE_FAIL, "原支付密码不能为空"));
				return;
			}
			//验证原支付密码是否正确
			AccountBean oldAccountBean  = accountCenterService.checkPayPasswd(uid, oldPayPwd);
			if(oldAccountBean == null || oldAccountBean.getCode() != RtnCode.OK || oldAccountBean.getData() ==null) {
				renderJson(buildResp(Common.RESPONSE_FAIL, "原支付密码错误"));
				return;
			}else {
				logger.info("uid【"+uid+"】验证支付密码返回code【"+oldAccountBean.getCode()+"】");
				logger.info("uid【"+uid+"】验证支付密码返回data【"+oldAccountBean.getData()+"】");
				logger.info("uid【"+uid+"】验证原支付密码返回信息【"+oldAccountBean.getMsg()+"】");
				JSONObject jsonObject = JSONObject.fromObject(oldAccountBean.getData());
				boolean isOK = jsonObject.getBoolean("isOK");
				if(!isOK) {
					renderJson(buildResp(Common.RESPONSE_FAIL, "原支付密码错误"));
					return;
				}
			}
			//重置支付密码
			AccountBean accountBean = accountCenterService.resetPayPasswd(uid, newPayPwd);
			//判断重置是否成功
			if(accountBean != null && accountBean.getData()!=null && accountBean.getCode() == RtnCode.OK) {
				renderJson(buildResp(Common.RESPONSE_SUCCESS, "设置支付密码成功"));
				return;
			}
			if(accountBean != null) {
				logger.info("uid【"+uid+"】根据短信验证码设置支付密码返回信息【"+accountBean.getMsg()+"】");
			}
			renderJson(buildResp(Common.RESPONSE_FAIL, "设置支付密码失败"));
			return;
		}
		
		renderJson(buildResp(Common.RESPONSE_FAIL, "错误的重置支付密码方式"));
		return;
	}
	
	/**
	 * 商品装饰支付页
	 */
	public void decorateIndex() {
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		String payId = getPara("pay_id");
		if(StringUtils.isBlank(payId)){
			errorPage("不存在的支付单");
			return;
		}
		
		Record productDecorate = SmartDb.findFirst("select * from product_decorate_payment  where pay_id = ? limit 1",payId);
		if(productDecorate == null) {
			errorPage("不存在的支付单");
			return;
		}
		  //获取客户端类型
  		String platform = "web";
  		String pf = getSessionAttr("pf");
  		if("android".equalsIgnoreCase(pf)||"ios".equalsIgnoreCase(pf)||"wap".equalsIgnoreCase(pf)) {
  			platform = "wap";
  		}
		IPayment payment = PaymentFactory.get();
		List<ZhifuWay> ways = payment.getStrateges(platform);
		if(ways.size() == 0){
			errorPage("获取支付方式时发生了一些错误，请稍后重试");
			return;
		}
		List<JSONObject> zfWays = Lists.newArrayList();
		//非0元单才需要支付金额
		for(ZhifuWay way : ways){
			//余额支付和银联支付的强行不加入
			if(ZhifuWay.BALANCE_KEY.equalsIgnoreCase(way.getPayKey()) || ZhifuWay.UNIONPAY_KEY.equalsIgnoreCase(way.getPayKey())){
				continue;
			}
			zfWays.add(way.toJson());
		}
		setAttr("pay_id", payId);
		setAttr("pay_amount", Common.round(productDecorate.getInt("amount")/100.0, 2));
		setAttr("product_name", "商品装饰支付");
        setAttr("zhifu_ways", zfWays);
		
    
		setAttr("balance", PaymentFactory.get().getAvailableBalance(uid));
        setAttr("balance_paykey", ZhifuWay.BALANCE_KEY);
//        setAttr("bind_mobile",User.getBindMobile(uid)!=null?1:0);
        setAttr("bind_mobile", 1); //FIXME 已经不走下单时绑定手机号的逻辑了，但是页面改动比较大，这里先暂时统一设置已经绑定手机号，避免触发对应页面逻辑
        setAttr("mobile", User.getBindMobile(uid));
        setAttr("zhifu_type",1);//订单支付为 0 ， 保证金支付为 1
        setAttr("platform",platform);
        

        setAttr("pay_type", "decorate");
        
		render("index.html");
	}
}
