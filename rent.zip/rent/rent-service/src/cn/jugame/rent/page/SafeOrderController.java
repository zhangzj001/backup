package cn.jugame.rent.page;

import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.PCForwardInterceptor;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

@Before(LoginInterceptor.class)
public class SafeOrderController extends OrderController{
	private Logger logger = Loggers.rentLog();
	
	@Override
	@Before(PCForwardInterceptor.class)
	public void prepare() {
		super.prepare();
	}
	
	@Override
	public void add(){
		String productId = getPara("product_id");
		if(StringUtils.isBlank(productId)){
			errorPage("没有指定商品下单");
			return;
		}
		DistLocker locker = new DistLocker(productId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("下单加锁失败，productId=>" + productId);
				errorPage("服务器发生了一些错误，下单失败了");
				return;
			}
			super.add();
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public void goPay() {
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有指定订单");
			return;
		}
		DistLocker locker = new DistLocker(orderId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("继续支付失败，orderId=>" + orderId);
				errorPage("服务器发生了一些错误，继续支付失败了");
				return;
			}
			super.goPay();
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	@Override
	public void relet() {
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有指定订单");
			return;
		}
		
		DistLocker locker = new DistLocker(orderId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("续租失败，orderId=>" + orderId);
				errorPage("服务器发生了一些错误，续租失败了");
				return;
			}
			super.relet();
		}finally{
			if(succ) locker.unlock();
		}
	}

	@Override
	public void reletAdd() {
		final String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有指定订单");
			return;
		}
		DistLocker locker = new DistLocker(orderId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("续租操作失败，orderId=>" + orderId);
				errorPage("服务器发生了一些错误，续租操作失败了");
				return;
			}
			super.reletAdd();
		}finally{
			if(succ) locker.unlock();
		}
	}

	@Override
	public void arbitrate() {
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("您没有选择订单进行自助仲裁操作。");
			return;
		}

		DistLocker locker = new DistLocker(orderId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("自助仲裁失败，orderId=>" + orderId);
				errorPage("服务器发生了一些错误，仲裁失败了。");
				return;
			}
			super.arbitrate();
		}finally {
			if(succ) locker.unlock();
		}
	}

	@Override
	public void confirmCancel() {
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("您没有选择订单进行确认撤单操作。");
			return;
		}

		DistLocker locker = new DistLocker(orderId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("确认撤单失败，orderId=>" + orderId);
				errorPage("服务器发生了一些错误，确认撤单失败了。");
				return;
			}
			super.confirmCancel();
		}finally {
			if(succ) locker.unlock();
		}
	}
}
