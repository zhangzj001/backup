package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.slf4j.Logger;

import java.sql.SQLException;

public class BuyuserPunishmentService {
	
	private Logger logger = Loggers.rentLog();
	
	private IPayment payment = PaymentFactory.get();
	
	private BuyuserPunishmentService(){}
	
	public static BuyuserPunishmentService instance = new BuyuserPunishmentService();
	
	private JSONObject buildResp(int code, String msg, KeyValue... params){
		return Common.buildResp(code, msg, params);
	}

    /**
     * 执行惩罚
     * @param order
     * @param cancelReason
     * @param playScore
     */
	public JSONObject punish(Record order, String cancelReason, int playScore){
        if(order.getInt("order_status") == Order.ORDER_STATUS_PAID){
            return punishOnPaid(order, cancelReason, playScore);
        }

        //如果订单已经取消，而且该订单是用户自助撤单的，尝试扣除其租金押金
        //XXX 就算不是自助撤单的，只要卖家能提供证据，也同样支持撤单操作，但是要求客服核实好！
        if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL /*&& order.getInt("is_buyuser_arbitrate") == Order.BUYUSER_ARBITRATION*/){
            return punishOnCancel(order, cancelReason, playScore);
        }

        //---------------------------------------------------------------------------------
        //剩下的情况就必须是订单已完成的状态下才能操作了
        //要求订单必须是已经完成的状态
        return punishOnSuccess(order, cancelReason, playScore);
    }


	/**
	 * 订单不惩罚买家
	 * @param order
	 * @param cancelReason
	 * @param playScore
	 */
	public JSONObject noPunistment(final Record order,final String cancelReason, int playScore){
		try {
			SmartDb.update("update `order` set is_selluser_arbitrate = ? where order_id = ?",Order.SELLUSER_ARBITRATE_SUCC,order.getStr("order_id"));
		}catch (Exception ex){
			return buildResp(5, "惩罚玩家时发生了错误");
		}
		return buildResp(0, "ok");
	}

	/**
	 * 订单惩罚扣除买家信誉分
	 * @param order
	 * @param cancelReason
	 * @param playScore
	 */
	public JSONObject punishByDecreaseScore(final Record order,final String cancelReason, int playScore){
		try {
			User.decreasePlayScore(order.getInt("buyuser_uid"), playScore, cancelReason);
			SmartDb.update("update `order` set is_selluser_arbitrate = ? where order_id = ?",Order.SELLUSER_ARBITRATE_SUCC,order.getStr("order_id"));
		}catch (Exception ex){
			return buildResp(5, "惩罚玩家时发生了错误");
		}
		return buildResp(0, "ok");
	}

	/**
	 * 订单处于“已支付”状态时的买家惩罚方式
	 * @param order
	 * @param cancelReason
	 * @param playScore
	 */
	private JSONObject punishOnPaid(final Record order, final String cancelReason, int playScore){
		String orderId = order.getStr("order_id");
		int buyuserUid = order.getInt("buyuser_uid");
		final String productId = order.getStr("product_id");

        final JSONObject txResult = new JSONObject();
		boolean succ = Db.tx(new IAtom() {
			@Override
			public boolean run() throws SQLException {
				//将订单的所有未完成租赁单设置为取消
				SmartDb.update("update `order_relet` set `status`=?, `cancel_time`=? where `order_id`=? and `status` in (?, ?)", Order.ORDER_STATUS_CANCEL, Common.now(), orderId, Order.ORDER_STATUS_NEW, Order.ORDER_STATUS_PAID);
				
				//完成订单
				String now = Common.now();
				order.keep("order_id");
				order.set("modify_time", now);
				order.set("order_finish_time", now);
				order.set("cancel_time", now);
				order.set("cancel_reason", cancelReason);
				order.set("arbitrate_time", now);
				order.set("arbitrate_reason", cancelReason);
				order.set("is_selluser_arbitrate", Order.SELLUSER_ARBITRATE_SUCC);
				order.set("order_status", Order.ORDER_STATUS_CANCEL);
				order.set("order_isterminate", Order.ORDER_TERMINATED);
				if(!SmartDb.update("order", "order_id", order)){
					logger.error("完成订单失败了，sql=>" + SmartDb.lastQuery());
					txResult.putAll(buildResp(3, "订单终止时发生了系统错误，无法修改订单信息"));
					return false;
				}
				
				//将商品设置为STATUS_PROTECTED状态
				Record product = new Record();
				product.set("product_id", productId);
				product.set("status", Product.STATUS_PROTECTED);
				product.set("last_order_time", now);
				product.set("modify_time", now);
				if(!SmartDb.update("product", "product_id", product)){
					logger.error("订单" + orderId + "在终止时将商品[" + productId + "]设置为保护状态失败了, sql=>" + SmartDb.lastQuery());
					txResult.putAll(buildResp(4, "终止订单时将商品状态设置为‘保护’失败了"));
					return false;
				}
				
				return true;
			}
		});
		if(!succ){
			return txResult;
		}

		//对于租期内撤单的，扣除买家信誉分
		User.decreasePlayScore(buyuserUid, playScore, "号主投诉【" + cancelReason + "】，信誉分-" + playScore);

		//转账给卖家
		if(!payment.orderFailForBoth(orderId)){
			return buildResp(5, "出租中惩罚玩家时订单转账发生了错误");
		}
		return buildResp(0, "ok");
	}
	
	/**
	 * 订单取消后的买家惩罚方式
	 * @param order
	 * @param cancelReason
	 * @param playScore
	 */
	private JSONObject punishOnCancel(Record order, String cancelReason, int playScore){
		String orderId = order.getStr("order_id");
		int buyuserUid = order.getInt("buyuser_uid");

		//设置已扣除押金和租金的状态
		order.keep("order_id");
		order.set("order_isterminate", Order.ORDER_TERMINATED);
		order.set("arbitrate_time", Common.now());
		order.set("arbitrate_reason", cancelReason);
		order.set("is_selluser_arbitrate", Order.SELLUSER_ARBITRATE_SUCC);
		order.set("modify_time", Common.now());
		if(!SmartDb.update("order", "order_id", order)){
			logger.error("订单【" + orderId + "】保存状态失败了");
			return buildResp(3, "执行买家惩罚时保存订单状态失败了");
		}

		if(!payment.orderFailForBoth(orderId)){
			return buildResp(5, "订单取消后惩罚玩家时订单转账给号主发生了错误");
		}
		//扣信誉分 or 封禁
		if(playScore < 0){
			String now = Common.now();
			//对买家执行封禁，如果当前买家已经在封禁期，那就不用管了
			if(null == User.userSpecial(buyuserUid, User.TYPE_FORBIDDEN)){
				if(!User.addUserSpecial(buyuserUid, User.TYPE_FORBIDDEN, now, Common.addDay(now, 1000), "系统封禁，原因: 号主投诉【" + cancelReason + "】")){
					logger.error("订单【" + orderId + "】执行买家封禁失败了");
				}
			}
		}else{
			//扣除买家信誉分
			User.decreasePlayScore(buyuserUid, playScore, "号主投诉【" + cancelReason + "】，信誉分-" + playScore);
		}
		
		return buildResp(0, "ok");
	}
	
	/**
	 * 订单交易完成后的买家惩罚方式
	 * @param order
	 * @param cancelReason
	 * @param playScore
	 */
	private JSONObject punishOnSuccess(Record order, String cancelReason, int playScore){
		if(order.getInt("order_status") != Order.ORDER_STATUS_FINISH){
			return buildResp(2, "不是出租中/交易完成/交易取消的订单，无法执行");
		}
		
		String orderId = order.getStr("order_id");
		int buyuserUid = order.getInt("buyuser_uid");
		
		//订单记录状态
		String now = Common.now();
		logger.info("订单【" + orderId + "】转扣押金给卖家");
		order.keep("order_id");
		order.set("order_isterminate", Order.ORDER_TERMINATED);
		order.set("arbitrate_time", now);
		order.set("arbitrate_reason", cancelReason);
		order.set("is_selluser_arbitrate", Order.SELLUSER_ARBITRATE_SUCC);
		order.set("modify_time", now);
		if(!SmartDb.update("order", "order_id", order)){
			logger.error("订单【" + orderId + "】保存状态失败了");
			return buildResp(3, "执行买家惩罚时保存订单状态失败了");
		}

		if(!payment.orderSuccForGuarantee(orderId)){
			return buildResp(5, "订单成功后惩罚玩家时转账给号主发生了错误");
		}
		
		//直接执行永久封禁
		if(playScore < 0){
			//对买家执行封禁，如果当前买家已经在封禁期，那就不用管了
			if(null == User.userSpecial(buyuserUid, User.TYPE_FORBIDDEN)){
				if(!User.addUserSpecial(buyuserUid, User.TYPE_FORBIDDEN, now, Common.addDay(now, 1000), "系统封禁，原因: 号主投诉【" + cancelReason + "】")){
					logger.error("订单【" + orderId + "】执行买家封禁失败了");
				}
			}
		}else{
			//无需封禁，扣除信誉分即可
			User.decreasePlayScore(buyuserUid, playScore, "号主投诉【" + cancelReason + "】，信誉分-" + playScore);
		}
		
		return buildResp(0, "ok");
	}
}
