package cn.jugame.rent.page.service;

import cn.jugame.redenvelope.api.IRedEnvelopeService;
import cn.jugame.redenvelope.vo.Envelope;
import cn.jugame.redenvelope.vo.EnvelopeStatus;
import cn.jugame.redenvelope.vo.MessageBean;
import cn.jugame.rent.bean.GameConf;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import cn.jugame.service.common.util.bean.DataBean;
import cn.jugame.service.gameproduct.api.IGameService;
import cn.jugame.service.gameproduct.api.IProductService;
import cn.jugame.service.gameproduct.bean.Game;
import cn.jugame.service.gameproduct.bean.ProductSearch;
import cn.jugame.service.gameproduct.constant.ProductTypeGroupConstant;
import com.google.common.collect.Lists;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


public class Platforms {
    private Platforms() {
    }

    public static Platforms singleton = new Platforms();

    private IProductService productService = ServiceFactory.get(IProductService.class);

    private IGameService gameService = ServiceFactory.get(IGameService.class);

    private IRedEnvelopeService iRedEnvelopeService = ServiceFactory.get(IRedEnvelopeService.class);// 红包服务

    private Logger logger = Loggers.rentLog();

    /**
     * 从平台配置获取对应tag值的banner
     *
     * @param tag
     * @return
     */
    public List<Record> getBanners(String tag) {
        String sql = "SELECT a.* FROM pt_banner_images a INNER JOIN pt_banner b ON a.banner_id = b.id AND b.tag = ? and a.status = 1 and b.status = 1 and (down_time >= NOW() or down_time is null) and (up_time < NOW() OR up_time IS NULL) ORDER BY weight ASC";
        List<Record> rows = SmartDb.get("platform", false).find(sql, tag);
        return rows;
    }

    /**
     * 获取平台配置的banner信息
     *
     * @param tags
     * @return
     */
    public List<Record> getBannerInfo(String... tags) {
        String sql = "select * from `pt_banner` where `status`=1 and `tag` in ('" + Common.join(tags, "','") + "') order by `weight` asc";
        return SmartDb.get("platform", false).find(sql);
    }

    /**
     * 获取平台配置的banner图片数据
     *
     * @param bannerId
     * @return
     */
    public List<Record> getBannerImages(int bannerId) {
        String sql = "select * from `pt_banner_images` where `banner_id`=? and `status`=1 order by weight asc";
        return SmartDb.get("platform", false).find(sql, bannerId);
    }

    /**
     * 获取公告列表
     *
     * @param isActivity 是否属于活动公告类型
     * @return
     */
    public List<Record> getAnnoucements(boolean isActivity) {
        String sql = "SELECT * FROM `announcement` WHERE `status` = 0 AND `release_platform`=2 AND validdate>=NOW() ";
        if (isActivity) {
            sql += " AND category_id=?";
        } else {
            sql += " AND category_id!=?";
        }

        return SmartDb.get("platform", false).find(sql, PropKit.get("annoucement.actvity_announcement_type"));
    }

    /**
     * 获取帮助列表
     *
     * @param categoryId
     * @param n
     * @return
     */
    public List<Record> getHelpInfos(String categoryId, int n) {
        String sql = "select * from help_info where category_id = ? and is_show = 1 order by weight desc";
        if (n >= 0) {
            sql += " limit " + n;
        }
        return SmartDb.get("platform", false).find(sql, categoryId);
    }

    /**
     * 获取热门游戏列表
     *
     * @param type 类型
     * @param hot  是否热门
     * @param n    数量
     * @return
     */
    public List<Record> getGames(int type, int hot, int n) {
        String sql = "select * from `game_conf` where `status`=? and product_count >0 ";
        List<Object> param = Lists.newArrayList(GameConf.STATUS_ENABLE);

        if (type >= 0) {
            sql += " and `type`=?";
            param.add(type);
        }
        if (hot >= 0) {
            sql += " and `is_hot`=?";
            param.add(hot);
        }
        sql += " order by `weight` desc";
        if (n >= 0) {
            sql += " limit " + n;
        }

        return SmartDb.get(false).find(sql, param.toArray());
    }

    /**
     * 获取推荐商品列表
     *
     * @param n
     * @param productType
     * @return
     */
    public List<Record> getRecommendedProducts(int n, int productType) {
        //先尝试获取有权重值的商品，如果足够则返回
        List<Record> gameProducts = SmartDb.get(false).find(
                "SELECT p.* FROM product_recommended pr, product p WHERE pr.`product_id` = p.`product_id` AND p.`status`=? AND p.`product_type`=? AND p.`reputation_score`>=100 AND `weight`>0 ORDER BY pr.`weight` DESC LIMIT " + n,
                Product.STATUS_ONSALE, productType);
        if (gameProducts.size() == n)
            return gameProducts;

        //有权重值的商品不足n个，剩下的从weight=0的商品中随机挑选
        n -= gameProducts.size();
        List<Record> moreProducts = SmartDb.get(false).find(
                "SELECT p.* FROM product_recommended pr, product p WHERE pr.`product_id` = p.`product_id` AND p.`status`=? AND p.`product_type`=? AND p.`reputation_score`>=100 AND `weight`=0",
                Product.STATUS_ONSALE, productType);
        //随机挑选剩下的商品
        Collections.shuffle(moreProducts);
        for (int i = 0; i < Math.min(n, moreProducts.size()); ++i) {
            gameProducts.add(moreProducts.get(i));
        }
        return gameProducts;
    }

    /**
     * 获取某个商品类型最近成交的订单（近似的‘最近成交’）
     *
     * @param productType
     * @param n
     * @return
     */
    public List<Record> getLatestSuccOrders(int productType, int n) {
        String sql = "SELECT * FROM `order` WHERE `order_status`=? AND `product_type`=? ORDER BY `id` DESC LIMIT " + n;
        return SmartDb.get(false).find(sql, Order.ORDER_STATUS_FINISH, productType);
    }

    /**
     * 获取平台的热门推荐商品列表
     *
     * @param n
     * @return
     */
    public List<cn.jugame.service.gameproduct.bean.Product> getPlatformHotProduct(int n) {
        ProductSearch ps = new ProductSearch();
        ps.setPlatform("app");
        ps.setProductTypeGroupId(new Integer[]{ProductTypeGroupConstant.ACCOUNT});
        ps.setGameId(null);
        ps.setChannelId(null);
        ps.setSellerUid(null);
        ps.setStatus(null);
        ps.setOnSaleFalg(true);
        ps.setSelWhere("");
        JSONArray sel_order = new JSONArray();
        JSONObject orderObj = new JSONObject();
        // {"key":"price","rule":"ASC"}
        orderObj.put("key", "recommended_time");
        orderObj.put("rule", "DESC");
        sel_order.add(orderObj);
        JSONObject selOrderObj = new JSONObject();
        selOrderObj.put("key", "rec_onsale_time");
        selOrderObj.put("rule", "DESC");
        sel_order.add(selOrderObj);

        ps.setSelOrder(sel_order.toString());
        DataBean<List<cn.jugame.service.gameproduct.bean.Product>> hotProductDataBean = productService.getProductListBySub(ps, 0, n);
        if (hotProductDataBean == null || hotProductDataBean.getCode() != DataBean.OK
                || hotProductDataBean.getData() == null) {
            return new ArrayList<>();
        }

        List<cn.jugame.service.gameproduct.bean.Product> pList = hotProductDataBean.getData();
        for (cn.jugame.service.gameproduct.bean.Product product : pList) {
            product.setWapIconUrl(getCachedGamePic(product.getGameId()));
        }

        return hotProductDataBean.getData();
    }


    private Map<String, Game> cachedPlatformGames = new HashedMap();
    ;

    public String getCachedGamePic(String gameId) {
        Game game = null;
        if (!cachedPlatformGames.containsKey(gameId)) {
            DataBean<Game> gameBean = gameService.getGameById(gameId);
            game = gameBean.getData();
            cachedPlatformGames.put(gameId, game);
        } else {
            game = cachedPlatformGames.get(gameId);
        }

        return game.getGamePic();
    }

    /***
     * 获取用户红包个数
     * @param uid
     * @return
     */
    public int getUserRedvdlopCount(int uid) {
        int[] redEnvelopeStatus = new int[]{EnvelopeStatus.ENVELOPE_TAKEN};
        MessageBean<List<Envelope>> messageBean = iRedEnvelopeService.getUserEnvelopes(String.valueOf(uid), redEnvelopeStatus);
        if (messageBean.getCode() <= 0) {
            messageBean.getMsg();
        }
        List<Envelope> envelopes = messageBean.getData();
        return envelopes != null ? envelopes.size() : 0;
    }

    /****
     * 获取 Activities
     * bannerType  
     */
    public List<Record> getIndexActivities(String bannerType, String clientFrom) {
//        String sql = "SELECT * FROM app_activities WHERE `status`=1 AND `tag`=? AND `start_time`<NOW() AND `end_time`>NOW() ORDER BY weight ASC";
//        List<Record> banners = SmartDb.get("app_recharge_base", false).find(sql, bannerType);
//        if (banners == null)
//            return new ArrayList<Record>();

        //再看看这些banner哪些是支持clientFrom的（数据库对应channel字段）
        int channelId = 0;
        if(StringUtils.isNotBlank(clientFrom)){
            Record appChannel = SmartDb.get("app_recharge_base", false).findFirst("select * from `app_channel` where `name`=?", clientFrom);
            if(appChannel != null) {
                channelId = appChannel.getInt("id");
            }else{
                logger.error("不存在的渠道：" + clientFrom);
            }
        }

        String sql = "SELECT ac.channel_id, a.* FROM app_activities_channel ac LEFT JOIN app_activities a ON ac.activity_id=a.id WHERE " +
                " a.`status`=1 AND a.`tag`=? AND a.`start_time`<NOW() AND a.`end_time`>NOW() ";
        List<Object> params = Lists.newArrayList(bannerType);
        if(channelId > 0){
            sql += " AND ac.channel_id IN (0, ?)";
            params.add(channelId);
        }else{
            sql += " AND ac.channel_id = 0";
        }
        sql += " ORDER BY a.weight ASC";
        List<Record> banners = SmartDb.get("app_recharge_base", false).find(sql, params.toArray());
        return banners;
    }
}
