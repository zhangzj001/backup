package cn.jugame.rent.page.service;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.slf4j.Logger;

import java.util.List;

public class SellerBlackListService {

    public final static int BLACK_USER_STATUS_VALID = 1;
    public final static int BLACK_USER_STATUS_INVALID = 0;
    private Logger logger = Loggers.rentLog();
    private SellerBlackListService(){}
    public final static SellerBlackListService instance = new SellerBlackListService();
    //加入黑名单
    public boolean addUserToBlackList(int userId,String userName,int sellerUid,String orderId,String headimg){
        Record blackExistItem = SmartDb.findFirst("select * from seller_blacklist where seller_id = ? and buyuser_uid = ? and `status` = ? and head_img = ?",sellerUid,userId,SellerBlackListService.BLACK_USER_STATUS_VALID,headimg);
       if(blackExistItem != null ){
           return true;
       }
        Record blackItem = new Record();
        blackItem.set("order_id",orderId);
        blackItem.set("seller_id",sellerUid);
        blackItem.set("c_time", Common.now());
        blackItem.set("status",SellerBlackListService.BLACK_USER_STATUS_VALID);
        blackItem.set("buyuser_uid",userId);
        blackItem.set("buyuser_name",userName);
        if(!SmartDb.save("seller_blacklist",blackItem)){
            logger.error("新增黑名单记录失败：orderId="+orderId+",userId="+userId+",seller_id="+sellerUid);
            return  false;
        }
        return true;
    }

    //删除黑名单
    public boolean deleteUserFromBlackList(int userId,int sellerUid){
        int updateCount = SmartDb.update("DELETE FROM `seller_blacklist` where seller_id = ? and buyuser_uid = ?",sellerUid,userId);
        return updateCount > 0;
    }

    //显示黑名单
    public List<Record> getBlackListForSeller(int sellerUid,int offset,int limit){
        return SmartDb.find("select * from seller_blacklist where seller_id = ? and `status`= ? order by c_time desc limit ?,?",sellerUid,SellerBlackListService.BLACK_USER_STATUS_VALID,offset,limit);
    }


    //查询用户黑名单总数
    public int getBlackListCount(int sellerUid){

           Record countInfo =     SmartDb.findFirst("select count(*) as _count from seller_blacklist where seller_id = ? and `status`= ?",sellerUid,SellerBlackListService.BLACK_USER_STATUS_VALID);
           int count = countInfo.getLong("_count").intValue();
           return count;
    }
    //判断用户是否在号主黑名单
    public boolean judgeUserInBlackList(int userId,int sellerUid){
        Record blackItemCountsRecord = SmartDb.findFirst("select count(*) as _count from seller_blacklist where seller_id = ? and buyuser_uid = ? and `status`= ? ",sellerUid,userId,SellerBlackListService.BLACK_USER_STATUS_VALID);
        int blackItemCounts = blackItemCountsRecord.getLong("_count").intValue();
        return blackItemCounts > 0;
    }

    //获取玩家被多少卖家设置了黑名单
    public int getAmountOfBlackListByUserId(int userId){
        Record blackItemCountsRecord = SmartDb.findFirst("select count(*) as _count from seller_blacklist where buyuser_uid = ?  and `status`= ? and DATE_ADD(c_time, INTERVAL 30 DAY) > NOW()",userId,SellerBlackListService.BLACK_USER_STATUS_VALID);
        int blackItemCounts = blackItemCountsRecord.getLong("_count").intValue();
        return blackItemCounts;
    }

    //判断玩家最近三天是否被拉黑
    public int getUserBlackListIn3Day(int userId){
        Record blackItemCountsRecord = SmartDb.findFirst("select count(*) as _count from seller_blacklist where buyuser_uid = ?  and `status`= ? and DATE_ADD(c_time, INTERVAL 72 HOUR) > NOW()",userId,SellerBlackListService.BLACK_USER_STATUS_VALID);
        int blackItemRecentCounts = blackItemCountsRecord.getLong("_count").intValue();
        return blackItemRecentCounts;
    }
}
