package cn.jugame.rent.page.service;

import cn.jugame.rent.utils.AliyunImageUtils;
import cn.jugame.rent.utils.Loggers;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import org.slf4j.Logger;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.TreeMap;

/**
 * 根据个人UID生成专属二维码
 * 
 * @author zimT_T
 *
 */
public class QrCodeService {
	private static final int BLACK = 0xFF000000;

	private static final int WHITE = 0xFFFFFFFF;
	
	private Logger logger = Loggers.rentLog();
	
	private QrCodeService(){}
	
	public static QrCodeService instance = new QrCodeService();

	private BufferedImage toBufferedImage(BitMatrix matrix) {
		int width = matrix.getWidth();
		int height = matrix.getHeight();
		BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				image.setRGB(x, y, matrix.get(x, y) ? BLACK : WHITE);
			}
		}
		return image;
	}

	private void writeToFile(BitMatrix matrix, String format, File file) throws IOException {
		BufferedImage image = toBufferedImage(matrix);
		if (!ImageIO.write(image, format, file)) {
			throw new IOException("Could not write an image of format " + format + " to " + file);
		}
	}

	private void writeToStream(BitMatrix matrix, String format, OutputStream stream) throws IOException {
		BufferedImage image = toBufferedImage(matrix);
		if (!ImageIO.write(image, format, stream)) {
			throw new IOException("Could not write an image of format " + format);
		}
	}
	
	private byte[] generateImg(String text, int width, int height) throws Exception{
		String format = "png";
		Map<EncodeHintType, Object> hints = new TreeMap<>();
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
		BitMatrix bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, width, height, hints);
		
		ByteArrayOutputStream steam = new ByteArrayOutputStream();
		writeToStream(bitMatrix, format, steam);
		return steam.toByteArray();
	}

	private String _generate(String text, int uid, int width, int height) throws Exception{
		byte[] bytes = generateImg(text, width, height);
		
		String key = "QR_" + uid + "/" + System.currentTimeMillis();
		logger.info("二维码生成阿里云key=>" + key);
		if(!AliyunImageUtils.uploadFile(key, bytes)){
			logger.error("上传到阿里云失败了！");
			return null;
		}
		//拼出这个图片URL
		String url = AliyunImageUtils.getUploadedImgUrl(key);
		logger.info("二维码阿里云图片URL=>" + url);
		return url;
	}
	
	/**
	 * 生成二维码
	 * @param text
	 * @param uid
	 * @return
	 */
	public String generate(String text, int uid){
		try{
			return _generate(text, uid, 250, 250);
		}catch(Exception e){
			logger.error("qr.generate.error", e);
			return null;
		}
	}

	public byte[] generate(String text, int width, int height){
		try{
			return generateImg(text, width, height);
		}catch(Exception e){
			logger.error("qr.generateImage.error", e);
			return null;
		}
	}
}
