package cn.jugame.rent.page;

import cn.jugame.rent.utils.Common;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;

public class QuestionSurveyController extends BaseController {
	public void starAccount() {
		render("start_account.html");
	}
	public void questionForm() {
		render("question_form.html");
	}
	
	public void submitQuestionForm() {
		String mobile = getPara("mobile");
		if(StringUtils.isBlank(mobile)) {
			renderJson(buildResp(Common.RESPONSE_FAIL,"手机号码为空"));
			return;
		}
		String qqNumber = getPara("qq_number");
		if(StringUtils.isBlank(qqNumber)) {
			renderJson(buildResp(Common.RESPONSE_FAIL,"QQ号码为空"));
			return;
		}
		String applyPlayAccount  = getPara("apply_play_account");
	    JSONObject jsonObject = new JSONObject();
	    jsonObject.put("applyPlayAccount", applyPlayAccount);
		Record record = new Record();
		record.set("mobile", mobile);
		record.set("qq_number", qqNumber);
		record.set("question_answer_properties", jsonObject.toString());
		record.set("create_time", Common.now());
		if(!SmartDb.save("question_survey", record)) {
			renderJson(buildResp(Common.RESPONSE_FAIL,"申请领玩账号失败"));
			return;
		}
		renderJson(buildResp(Common.RESPONSE_SUCCESS,"申请领玩账号成功"));
		return;
	}
}
