package cn.jugame.rent.page;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.account_center.service.vo.UserAuthInfo;
import cn.jugame.rent.bean.*;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.PCForwardInterceptor;
import cn.jugame.rent.interceptor.VisitLogInterceptor;
import cn.jugame.rent.page.service.ProductPromotionService;
import cn.jugame.rent.page.service.SecurityService;
import cn.jugame.rent.page.service.SellerBlackListService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.*;
import cn.jugame.service.common.util.idbuilder.IDBuilder;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.jfinal.plugin.redis.Cache;
import com.jfinal.plugin.redis.Redis;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.sql.SQLException;
import java.util.*;

@Before(LoginInterceptor.class)
class OrderController extends BaseController{
	private Logger logger = Loggers.rentLog();
	
	private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
	
	private IPayment payment = PaymentFactory.get();
	
	/**
	 * 下单页
	 */
	@Before(PCForwardInterceptor.class)
	public void prepare(){
		String isSupport = getPara("is_support","0");
		setAttr("is_support", isSupport);
		final Integer buyuserUid = getSessionAttr("uid");
		if(buyuserUid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}

        setAttr("uid", buyuserUid);

		//当前实名情况
        boolean isAuth = true;
        MemberBean<UserAuthInfo> memberBean = accountCenterService.getUserAuthInfo(buyuserUid);
        if (memberBean == null || memberBean.getData() == null ||
                StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())){
            isAuth = false;
        }
        setAttr("is_realname_auth", isAuth);

//        int needRealname = HotSetting.getInt("REALNAME_AUTHORIZED", 0);
        int needRealname = PropKit.getInt("realname.force", 0);
        if(needRealname == 1 && !isAuth) {
            render("../user/realname.html");
            return;
        }

		String productId = getPara("product_id", "");
		Record product = Product.getProduct(productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}

		//判断商品是否出租中
		if(product.getInt("status") == Product.STATUS_RENT ){
			errorPage("该商品太热门已被其他用户锁定，试试其它商品吧！");
			return;
		}
		//记录联合推广商品标志
		setAttr("t_uid",getPara("t_uid"));
		//判断是否玩家是否在号主黑名单中
		boolean isUserInBlackList = SellerBlackListService.instance.judgeUserInBlackList(buyuserUid,product.getInt("seller_uid"));
		if(isUserInBlackList){
			errorPage("该号主限制你访问，请注意文明租号。");
			return;
		}
		//预设押金类型为用户押金，押金值为商品设定值
		setAttr("guarantee_deposit_type", Product.GUARANTEE_DEPOSIT_TYPE_USER);
		setAttr("guarantee_deposit", Common.round(product.getInt("guarantee_deposit")/100.0, 2));
		//如果商品本身没有押金，同时该用户信誉度过低需要征收平台押金，则设置为平台押金值
		int score = User.getBuyuserPlayScore(buyuserUid);
		int platformGuaranteeDeposit = getPlatformGuaranteeDeposit(score);
		if(product.getInt("guarantee_deposit") <= 0 && platformGuaranteeDeposit > 0){
			logger.info("用户【" + buyuserUid + "】买家信誉分=>" + score + "，平台强制收取押金: " + platformGuaranteeDeposit + "分");
			setAttr("guarantee_deposit_type", Product.GUARANTEE_DEPOSIT_TYPE_PLATFORM);
			setAttr("guarantee_deposit", Common.round(platformGuaranteeDeposit/100.0, 2));
		}
		
		//判断一下用户的玩家信誉分是否达标
		if(product.getInt("min_play_score") > score){
			errorPage("您的玩家信誉过低，无法满足号主的租赁要求，不能租赁该商品。");
			return;
		}
			
		//把商品详情返回
		setAttr("product", product2map(product));
		
		//把优惠券取出来
		setAttr("coupons", validCoupons(product.getStr("product_id"), buyuserUid,Integer.parseInt(isSupport)));
		
		//是否处于包夜期间
		setAttr("in_night", Common.inHour(PropKit.getInt("product.in_night_begin"), PropKit.getInt("product.in_night_showprice_end")));
		
		//是否隐藏时租价
		String vipHiddenHourPriceIds = PropKit.get("vip_hidden_hour_price_ids","");
		boolean isHideHourPrice = false;
		if(vipHiddenHourPriceIds.contains(product.getStr("game_id"))) {
			isHideHourPrice = true;
		}
		setAttr("isHideHourPrice", isHideHourPrice);
		
		//包夜时间段
		setAttr("in_night_begin", PropKit.getInt("product.in_night_begin"));
		setAttr("in_night_end", PropKit.getInt("product.in_night_end"));
		setAttr("product_id", productId);
		setAttr("is_recommend",getParaToInt("is_recommend",0));
		setAttr("t_uid",getPara("t_uid",""));
		setAttr("bind_mobile",User.getBindMobile(buyuserUid)!=null?1:0);
		render("prepare.html");
	}
	
	private List<Map<String, Object>> validCoupons(String productId, int uid,int isSupport){
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			renderJson(buildResp(2, "不存在的商品"));
			return new ArrayList<>();
		}
		
		//如果是游戏账号或者会员VIP，选用时租价进行优惠计算。
		int amount = product.getInt("price_hour");
		
		//找到这个用户可用的优惠券
		String now = Common.now("yyyy-MM-dd");
		List<Record> rows = SmartDb.find("select * from `user_coupon` where `uid`=? and `status`=? and `beg_date`<=? and `end_date`>=? and `left_times`>0", uid, Coupon.STATUS_ONSALE, now, now);
		Iterator<Record> it = rows.iterator();
		while(it.hasNext()){
			int realAmount = amount;
			Record row = it.next();
			//如果不适配商品类型，去除掉这个优惠券
			if(Coupon.notFitCoupon(row, product)||notFitSupportCoupon(row, isSupport)){
				it.remove();
				continue;
			}
			
			//计算每个优惠券得到的优惠价，注意有可能会得到负数，越小的负数说明越优惠
			if(row.getInt("type") == Coupon.TYPE_DIRECTLLY_OFF){
				realAmount -= row.getInt("amount_off");
			}
			else if(row.getInt("type") == Coupon.TYPE_DISCOUNT_OFF){
				int off = (int)(amount * row.getBigDecimal("discount").doubleValue());
				if(off > row.getInt("max_discount_amount"))
					off = row.getInt("max_discount_amount");
				realAmount -= off;
			}
			
			row.set("real_amount", realAmount);
		}
		
		//按优惠后的价格排序
		Collections.sort(rows, new Comparator<Record>() {

			public int compare(Record o1, Record o2) {
				if(o1.getInt("min_rental") == o2.getInt("min_rental"))
					return 0;
				else if(o1.getInt("min_rental") > o2.getInt("min_rental"))
					return 1;
				else
					return -1;
			}
		});
		Map<String, String> format = new TreeMap<>();
		format.put("beg_date", "yyyy-MM-dd");
		format.put("end_date", "yyyy-MM-dd");
		return toMap(rows, format);
	}
	
	/**
	 * 若不是扶持区或者列表中的扶持商品下的订单，不给用扶持优惠券
	 * */
	private boolean notFitSupportCoupon(Record coupon,int isSupport) {
		if(isSupport==0) {
			String validSupportType = coupon.getStr("valid_support_type");
			if (StringUtils.isBlank(validSupportType))
				return false;

			JSONArray json = null;
			try{
				json = JSONArray.fromObject(validSupportType);
			}catch(Exception e){
				//解析错误，保守起见，不给用这张优惠券
				logger.error("notFitSupportCoupon: parse error, userCoupon.id=>" + coupon.getInt("id"), e);
				return true;
			}
			if(json.size()==0)
				return false;
			for (int i = 0; i < json.size(); i++) {
				if ( Product.SUPPORT_TYPE_SUPPORTED == json.getInt(i)) {
					return true;
				}
			}
		}
		return false;
	}
	
	private String generateOrderId(){
		return "RENTORD-" + Common.now("yyMMdd-HHmmssSSS") + String.format("%02d", Common.rand(0, 99));
	}
	
	private String generateReletId(){
		return IDBuilder.productIdBuilder("RELET");
	}
	
	/**
	 * 下单
	 */
	public void add(){
		//1. 获取承租方信息
		final Integer buyuserUid = getSessionAttr("uid");
		if(buyuserUid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		//判断是否为续租
		if(StringUtils.isNotEmpty(getPara("order_id"))){
			reletAdd();
			return;
		}
		
		final String productId = getPara("product_id");
		//2. 判断商品是否上架状态
		final Record product = Product.getProduct(productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}
		
		//获取游戏配置
		final Record gameConf = SmartDb.findFirst("select * from `game_conf` where `game_id`=? limit 1", product.getStr("game_id"));
		if(gameConf == null){
			errorPage("不存在的游戏");
			return;
		}
		
		//判断是否从推荐商品下单
		Record recommendProduct = SmartDb.findFirst("select * from product_recommended where product_id = ? ",productId);
		int isRecommend = recommendProduct != null ? Product.PRODUCT_RECOMMEND:0 ;
		if(product.getInt("status") != Product.STATUS_ONSALE){
			logger.info("用户【" + buyuserUid + "】准备下单租赁商品【" + productId + "】失败了，因为商品不在上架状态");
			errorPage("该商品目前还没上架出租，无法下单");
			return;
		}
		
		//该商品已经被用户下单了
		if(isAlreadyOrdered(product.getStr("product_id"), buyuserUid)){
			errorPage("该商品您已经成功下单，若支付失败请在<a href='/user/myorders'>“我的订单”</a>中重新支付。");
			return;
		}
		
		MemberBean<?> mb = accountCenterService.findMemberByUid(buyuserUid);
		if(mb == null || mb.getData() == null){
			errorPage("不存在的用户");
			return;
		}
		final Member buyuser = (Member)mb.getData();
		
		//3. 获取出租方信息
		final int selluserUid = product.getInt("seller_uid");
		mb = accountCenterService.findMemberByUid(selluserUid);
		if(mb == null || mb.getData() == null){
			errorPage("获取号主数据出错，该商品暂时无法下单");
			return;
		}
		final Member selluser = (Member)mb.getData();
		
		//不允许租自己的号
		if(buyuserUid.intValue() == selluserUid){
			errorPage("无法租赁自己放租的账号");
			return;
		}
		
		//该买家是否已经被加入黑名单而不允许租号
		if(inBlackList(buyuserUid)){
			errorPage("因您之前存在恶意租号行为，平台目前对您处于封禁状态，暂时无法租号");
			return;
		}

		//4. 租赁时间是否达到商品最短租赁时间
		final String now = Common.now();
		final int buyCount = getParaToInt("buy_count", 1);
		if(buyCount >= PropKit.getInt("product.max_buy_count") && !isPrerogative(buyuserUid)){
			errorPage("您单次租赁时长太多了，请重新选择。");
			return;
		}
		final int rentType = getParaToInt("rent_type", Product.RENT_TYPE_HOUR);
		if(!isEnoughRentTime(product, rentType, buyCount)){
			errorPage("没有达到商品最低租赁时间，无法出租");
			return;
		}
		//如果是包夜，那必须是夜晚了才行！
		if(rentType == Product.RENT_TYPE_NIGHT){
			int begHour = PropKit.getInt("product.in_night_begin");
			int endHour = PropKit.getInt("product.in_night_showprice_end");
			if(!Common.inHour(begHour, endHour)){
				errorPage("只能在" + begHour + "点到" + endHour + "点期间才能包夜！");
				return;
			}
		}
		
		//客服休息时间，用户如果撤单2次及以上，则不给下单。
		int begHour = PropKit.getInt("product.in_night_begin");
		int endHour = PropKit.getInt("product.in_night_end");
		if(Common.inHour(begHour, endHour)) {
			Record cancelApply = SmartDb.findFirst("select count(id) as _count from order_cancel_apply  where buyuser_uid =? and c_time >= ? and c_time <= ?",
					buyuserUid,Common.now("yyyy-MM-dd 01:00:00"),Common.now("yyyy-MM-dd 07:00:00"));
			if(cancelApply.getLong("_count")>=2) {
				errorPage("因您在客服休闲时间撤单数过多，在此期间您不能再下单。");
				return;
			}
		}
		
		//押金类型
		final int guaranteeDepositType = getParaToInt("guarantee_deposit_type", Product.GUARANTEE_DEPOSIT_TYPE_USER);
		
		//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		//是否使用优惠券
		final String couponUseId = getPara("use_id");
		final Record userCoupon = Coupon.getUserCoupon(buyuserUid, couponUseId);
		if((StringUtils.isNotBlank(couponUseId) && !"0".equals(couponUseId))  && userCoupon == null){
			errorPage("优惠券不存在或者优惠券已过期。");
			return;
		}
		
		//确定该优惠券可用于当前商品类型
		if(userCoupon != null && Coupon.notFitCoupon(userCoupon, product)){
			errorPage("您的优惠券不适用当前下单的商品类型。");
			return;
		}

		final int score = User.getBuyuserPlayScore(buyuserUid);
		final String orderId = generateOrderId();
		final String payId = generateReletId();
		
		//看看卖家是否为签约卖家
		Record member = User.getMember(selluserUid);
		int _sellLevel = member.getInt("sell_level");
		//如果是来自端游，使用端游的号主等级设置
		if(gameConf.getInt("type") == GameConf.TYPE_PC_GAME){
			_sellLevel = member.getInt("pc_sell_level");
		}
		final int sellLevel = _sellLevel;

		//判断一下用户的玩家信誉分是否达标
		if(product.getInt("min_play_score") > score){
			errorPage("您的玩家信誉过低，无法满足号主的租赁要求，不能租赁该商品。");
			return;
		}
		
		//如果今天已经超时未支付了n笔，禁止下单
		if(tooManyNoPayOrders(buyuserUid) && !isPrerogative(buyuserUid)){
			errorPage("您今日无法下单，因为您今日已经超时未支付太多笔订单了！");
			return;
		}

		if(!SecurityService.singleton.orderAddGuard(product.getStr("game_id"), buyuserUid) && !isPrerogative(buyuserUid)){
			errorPage("您今日无法下单，因为您今日已经下过太多笔订单了！");
			return;
		}

		//扶持商品
		String supportType = getPara("is_support","0");
		
		//0-普通商品 1-商品类表扶持商品   2-扶持区商品   3-新人礼包券页面商品
		boolean isSupportTemp = false;
		if(("1".equals(supportType)||"2".equals(supportType)) && product.getInt("support_type") == Product.SUPPORT_TYPE_SUPPORTED)
			isSupportTemp = true;
		boolean isSupport = isSupportTemp;
		
		//订单来源，是否来自号主自推广
		int orderSourceType = productId.equals(product.getStr("product_promote_id")) ? Order.ORDER_FROM_USERPROMOTE : Order.ORDER_FROM_PLATFORM;
		boolean isPromote = (orderSourceType == Order.ORDER_FROM_USERPROMOTE);
		
		logger.info("准备创建订单【" + orderId + "】-【" + payId + "】");
		boolean succ = Db.tx(new IAtom() {
			@Override
			public boolean run() throws SQLException {
				//5. 计算租赁总价，然后下单！！
				int count = buyCount;
				int price = ((rentType == Product.RENT_TYPE_HOUR || rentType == Product.RENT_TYPE_FIXED_PRICE) ? product.getInt("price_hour") : product.getInt("price_day")); //单价
				int orderPayAmount = price * count; //租金
				//如果是长租号，价格改为一口价
				if(rentType == Product.RENT_TYPE_LONGTERM){
					orderPayAmount = price = product.getInt("longterm_first_price");
					count = product.getInt("min_rent_time"); //长租号起租件数固定为起租时长，单位月
				}
				//如果是包夜
				if(rentType == Product.RENT_TYPE_NIGHT){
					orderPayAmount = price = product.getInt("price_night");
					count = 1;
				}
				//如果是一口价
				if(rentType == Product.RENT_TYPE_FIXED_PRICE){
					orderPayAmount = price; //直接使用时租价作为一口价
				}
				
				int orderGuaranteeDisposit = product.getInt("guarantee_deposit"); //押金
				//如果商品没有押金，而对用户又要需要收平台押金，则要带上平台押金
				int platformGuaranteeDeposit = getPlatformGuaranteeDeposit(score);
				if(orderGuaranteeDisposit == 0 && platformGuaranteeDeposit > 0){
					logger.info("强制征收用户【" + buyuserUid + "】-商品【" + productId + "】的下单押金:" + platformGuaranteeDeposit + "分");
					orderGuaranteeDisposit = platformGuaranteeDeposit;
				}
				int totalAmount = orderPayAmount + orderGuaranteeDisposit; //总金额
				
				//计算优惠金额
				int amountOff = getAmountOff(userCoupon, orderPayAmount);
				if(userCoupon != null){
					logger.info("订单【" + buyuserUid + "】使用了优惠券【" + couponUseId + "】，减免金额: " + amountOff);
				}

				//判断订单金额是否超过限制
				if(totalAmount > PropKit.getInt("pay.original_route_refund_limit",500) * 100){
					errorPage("订单金额超过系统限制");
					return false;
				}
				//选择相应的优惠活动
				Record promotion = ProductPromotionService.instance.findBestMatchPromotionActivity(rentType,count,product.getStr("product_id"));
				if(promotion != null){
					if(rentType == Product.RENT_TYPE_DAY){
						orderPayAmount -= promotion.getInt("promote_gift_money");
						totalAmount  -= promotion.getInt("promote_gift_money");
						orderPayAmount = orderPayAmount < 0 ? 0:orderPayAmount;
						totalAmount = totalAmount< 0 ? 0:totalAmount;
					}
				}

				//按手续费从高到底设置的逻辑去做优先级判断
				int feeType = BaseController.FEE_TYPE_NORMAL;
				if(isSupport){
					feeType = BaseController.FEE_TYPE_SUPPORT;
				}else if(isPromote){
					feeType = BaseController.FEE_TYPE_PROMOTE;
				}
				
				//创建订单
				Record order = new Record();
				order.set("order_id", orderId);
				order.set("order_time", now);
				order.set("modify_time", now);
				order.set("order_status", Order.ORDER_STATUS_NEW);
				order.set("order_amount", totalAmount);
				order.set("order_pay_amount", orderPayAmount);
				order.set("guarantee_deposit_type", guaranteeDepositType);
				order.set("order_guarantee_deposit", orderGuaranteeDisposit);
				order.set("amount_off", amountOff);
				order.set("coupon_use_id", couponUseId);
				order.set("order_fee", getOrderFee(product.getStr("game_id"), selluserUid, productId, feeType)); //下单时是啥费率就是啥费率，这笔单不应随后面运营的费率修改而改变！
				order.set("order_ispay", Order.ORDER_NOT_PAY);
				order.set("order_isrefund_rental", Order.ORDER_NOT_REFUND);
				order.set("order_isrefund_guarantee", Order.ORDER_NOT_REFUND);
				order.set("order_isterminate", Order.ORDER_NOT_TERMINATED);
				order.set("buyuser_uid", buyuserUid);
				order.set("buyuser_qq", buyuser.getQq());
				order.set("buyuser_phonenum", buyuser.getMobile());
				order.set("selluser_uid", selluserUid);
				order.set("selluser_qq", selluser.getQq());
				order.set("selluser_phonenum", selluser.getMobile());
				order.set("selluser_game_account", product.getStr("game_login_id"));
				order.set("selluser_game_pwd", product.getStr("game_login_password"));
				order.set("selluser_game_role_name", product.getStr("game_role_name"));
				order.set("selluser_game_role_level", product.getStr("game_user_level"));
				order.set("selluser_game_login_type",product.getInt("game_login_type"));
				order.set("game_id", product.getStr("game_id"));
				order.set("game_name", product.getStr("game_name"));
				order.set("game_pic", product.getStr("game_pic"));
				order.set("game_type", gameConf.getInt("type"));
				order.set("game_partition_id", product.getStr("game_partition_id"));
				order.set("game_partition_name", product.getStr("game_partition_name"));
				order.set("channel_id", product.getStr("channel_id"));
				order.set("channel_name", product.getStr("channel_name"));
				order.set("product_id", product.getStr("product_id"));
				order.set("product_name", product.getStr("name"));
				order.set("product_price", price);
				order.set("order_source_type", orderSourceType);
				order.set("order_origin_price", orderPayAmount);
				order.set("product_origin_price", price);

				//FIXME 为了运营实验
				int productType = product.getInt("product_type");
				if(productType == 99)
					productType = 1;
				order.set("product_type", productType);
				order.set("sell_level", sellLevel);
				order.set("seller_online_begin_time", product.getInt("seller_online_begin_time"));
				order.set("seller_online_end_time", product.getInt("seller_online_end_time"));
				order.set("seller_guarantee_amount",product.getInt("seller_guarantee_amount"));
				order.set("remark",isRecommend);
				order.set("order_source", Integer.parseInt(supportType));
				//下单来源，默认是wap
				String orderFr = "wap";
				if("1".equals(getSessionAttr("isApp"))){
					orderFr = "app";
				}
				//如果是来自ios的，则标记为ios；来自pc的就标记为pc
				String pf = getSessionAttr("pf");
				if("ios".equalsIgnoreCase(pf) || "pc".equalsIgnoreCase(pf)){
					orderFr = pf;
				}
				
				order.set("order_fr", orderFr);
				//平台归属渠道
                String jugameFr = getCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME);
                if(StringUtils.isBlank(jugameFr))
                    jugameFr = "rent";
                order.set("jugame_fr", jugameFr);

                //是否支持求助
                order.set("support_help", product.getInt("support_help"));

                //获取下单时的IP
                order.set("order_ip", Common.getIp(getRequest()));
                order.set("device_id", getCookie("did")); //下单设备ID，来自cookie

                //如果是合租商品
                if(product.getInt("cooperation_uid") > 0){
                	//要找到对应的商铺配置
                	Record row = SmartDb.findFirst("select * from `shop_product_royalty` where `product_id`=?", productId);
                	if(row != null){
	                	order.set("cooperation_uid", product.getInt("cooperation_uid"));
	                	order.set("coop_fee_rate", Common.round(row.getInt("royalty")/100.0, 2));
                	}else{
                		logger.error("对商品【" + productId + "】下单时，商品信息中存在合租者UID【" + product.getInt("cooperation_uid") + "】，但是没有找到对应shop_product_royalty的配置");
                	}
                }

                //先记录商品快照
                String productSnapshot = getProductSnapshot(product).toString();
                Record orderSnapshot = new Record();
                orderSnapshot.set("order_id", orderId);
                orderSnapshot.set("product_snapshot", productSnapshot);
                if(!SmartDb.save("order_product_snapshot", orderSnapshot)){
                    logger.error("创建订单失败! productId=>" + productId + ", sql => " + SmartDb.lastQuery());
                    errorPage("记录商品快照时发生了错误，请稍后再试。");
                    return false;
                }

                //记录订单详情
				if(!SmartDb.save("order", order)){
					logger.error("创建订单失败! productId=>" + productId + ", sql => " + SmartDb.lastQuery());
					errorPage("创建订单时发生了错误，请稍后再试。");
					return false;
				}

                //创建续租单
				Record relet = new Record();
				relet.set("order_id", orderId);
				relet.set("pay_id", payId);
				relet.set("order_pay_amount", orderPayAmount);
				relet.set("product_price", price);
				relet.set("rent_type", rentType);
				relet.set("create_time", now);
				relet.set("type", Order.ORDER_RELET_FIRST);
				relet.set("status", Order.ORDER_STATUS_NEW);
				relet.set("coupon_use_id",couponUseId);
				relet.set("amount_off",amountOff);
				relet.set("order_origin_price", orderPayAmount);
				//设置优惠活动信息
				if(promotion != null) {
					relet.set("promote_type", rentType);
					relet.set("promote_unit", promotion.getInt("promote_unit"));
					if(rentType == Product.RENT_TYPE_HOUR){
						relet.set("promote_gift_time",promotion.getInt("promote_gift_time"));
						count += promotion.getInt("promote_gift_time");
					}else{
						relet.set("promote_gift_money",promotion.getInt("promote_gift_money"));
					}
				}
				relet.set("buy_count", count);
				if(!SmartDb.save("order_relet", relet)){
					logger.error("创建租赁单失败! productId=>" + productId + ", orderId=>" + orderId + ", sql => " + SmartDb.lastQuery());
					errorPage("创建支付单时发生了错误，暂时无法出租");
					return false;
				}

				if(SmartDb.update("update `product` set `status` = ? WHERE product_id = ?",Product.STATUS_RENT,product.getStr("product_id")) <= 0){
					logger.error("下单时使用更新商品状态出错" + SmartDb.lastQuery());
					errorPage("下单时使用更新商品状态出错"+orderId);
					return false;
				}
				//优惠券可用次数-1
				if(userCoupon != null && !Coupon.decreaseUserCoupon(buyuserUid, couponUseId, Common.now())){
					logger.error("商品【" + productId + "】下单时使用优惠券失败了，sql=>" + SmartDb.lastQuery());
					errorPage("下单时使用优惠券发生了错误。");
					return false;
				}
				
				return true;
			}
		});
		if(!succ){
			logger.error("下单事务执行失败，orderId=>" + orderId + "， payId=>" + payId);
			return;
		}
		
		int isNewVersion = getParaToInt("is_new_version", 0);
		String clientType = getAttr("client_type");
        //FIXME 因为微信支付存在问题，需要让app的也使用wap版本的支付页面，所以注释掉isNewVersion的判断
		if(!"pc".equalsIgnoreCase(clientType)/* && isNewVersion==0*/){
			String html = payment.payOrder(payId, Common.getIp(getRequest()));
			if(StringUtils.isBlank(html)){
				errorPage("订单支付时发生了一些意外，请联系客服处理。");
				return;
			}
			renderHtml(html);
			return;
		}

		//6. 下单成功了，通知支付服务
		redirect("/pc/pay/index?order_id=" + orderId);
	}
	
	private boolean tooManyNoPayOrders(int buyuserUid){
		Record row = SmartDb.findFirst("select count(id) as _count from `order` where `buyuser_uid`=? and `order_status`=? and `order_ispay`=? and `order_finish_time`>=? and `order_finish_time`<=?",
				buyuserUid, Order.ORDER_STATUS_CANCEL, Order.ORDER_NOT_PAY, Common.now("yyyy-MM-dd 00:00:00"), Common.now("yyyy-MM-dd 23:59:59"));
		return row.getLong("_count") >= PropKit.getInt("order.max_nopay_count");
	}
	
	private int getAmountOff(Record userCoupon, int orderPayAmount){
		if(userCoupon == null)
			return 0;
		if(orderPayAmount < userCoupon.getInt("min_rental")){
			return 0;
		}
		//如果是立减券
		if(userCoupon.getInt("type") == Coupon.TYPE_DIRECTLLY_OFF){
			int amountOff = userCoupon.getInt("amount_off");
			//立减券已经超过了租金，那么立减金额设置为租金等额
			if(amountOff > orderPayAmount)
				amountOff = orderPayAmount;
			return amountOff;
		}
		//如果是打折券
		if(userCoupon.getInt("type") == Coupon.TYPE_DISCOUNT_OFF){
			int maxOff = userCoupon.getInt("max_discount_amount");
			double offRate = userCoupon.getBigDecimal("discount").doubleValue();
			//因为offRate是几折，所以减少的金额应该用1减这个比例来算
			int amountOff = orderPayAmount - (int)(orderPayAmount*offRate);
			if(amountOff > maxOff)
				amountOff = maxOff;
			if(amountOff < 0)
				amountOff = 0;
			return amountOff;
		}
		return 0;
	}
	
	private boolean isAlreadyOrdered(String productId, int buyuserUid){
		Record row = SmartDb.findFirst("select `id` from `order` where `product_id`=? and `buyuser_uid`=? and `order_status` not in (?, ?) limit 1", productId, buyuserUid, Order.ORDER_STATUS_FINISH, Order.ORDER_STATUS_CANCEL);
		return row != null;
	}



	private boolean inBlackList(int uid){
		return null != User.userSpecial(uid, User.TYPE_FORBIDDEN);
	}
	
	private int getPlatformGuaranteeDeposit(int score){
		if(score >= 95)
			return 0;
		else if(score >= 90 && score < 95)
			return 300;
		else if(score >= 80 && score < 90)
			return 500;
		else if(score >= 70 && score < 80)
			return 1000;
		else if(score >= 50 && score < 70)
			return 3000;
		else if(score >= 30 && score < 50)
			return 7000;
		else
			return 10000;
	}
	
	/**
	 * 订单继续支付
	 */
	public void goPay(){
		final Integer buyuserUid = getSessionAttr("uid");
		if(buyuserUid == null){
			errorPage("请登录后再进行续租操作");
			return;
		}
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有指定订单");
			return;
		}
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
		
		if(order.getInt("order_status") == Order.ORDER_STATUS_FINISH){
			errorPage("您的订单已经交易完成，无法继续支付。");
			return;
		}
		if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
			errorPage("您的订单已经取消，无法继续支付。");
			return;
		}
		//判断商品是否出租中
		Record product = SmartDb.findFirst("select * from `product` where product_id = ?",order.getStr("product_id"));
		if(product.getInt("status") == Product.STATUS_RENT &&  buyuserUid.intValue() != order.getInt("buyuser_uid")){
			errorPage("该商品太热门已被其他用户锁定，试试其它商品吧！");
			return;
		}
		//获取该订单的未支付的租赁单
		//注意：当前总之至多只有一个未支付的租赁单存在
		Record relet = SmartDb.findFirst("select * from `order_relet` where `order_id`=? and `status`=? limit 1", orderId, Order.ORDER_STATUS_NEW);
		if(relet == null){
			errorPage("当前订单已经支付成功，如果需要续租请先进行续租操作后继续支付。");
			return;
		}
		
		int isNewVersion = getParaToInt("is_new_version", 0);
		String clientType = getAttr("client_type");
		//FIXME 因为微信支付存在问题，需要让app的也使用wap版本的支付页面，所以注释掉isNewVersion的判断
		if(!"pc".equalsIgnoreCase(clientType)/* && isNewVersion==0*/){
			String html = payment.payOrder(relet.getStr("pay_id"), Common.getIp(getRequest()));
			if(StringUtils.isBlank(html)){
				errorPage("订单支付时发生了一些意外，请联系客服处理。");
				return;
			}
			renderHtml(html);
			return ;
		}

		//pc采用不同的支付方式
		//String clientType = getAttr("client_type");
		//if("pc".equalsIgnoreCase(clientType)){
		redirect("/pc/pay/index?order_id=" + orderId);
		return;
		//}
		
/*		String html = payment.payOrder(relet.getStr("pay_id"), Common.getIp(getRequest()));
		if(StringUtils.isBlank(html)){
			errorPage("订单支付时发生了一些意外，请联系客服处理。");
			return;
		}
		renderHtml(html);*/
	}
	
	private boolean isEnoughRentTime(Record product, int rentType, int buyCount){
		if(rentType == Product.RENT_TYPE_HOUR){
			//最低租赁时长是小时
			int minHours = product.getInt("min_rent_time");
			return buyCount >= minHours;
		}
		
		return true;
	}
	
	private JSONObject getProductSnapshot(Record product){
		JSONObject json = toJson(product);
		
		//商品图片
		List<Record> pics = SmartDb.find("select * from product_picture where product_id=?", product.getStr("product_id"));
		json.put("pics", toJson(pics));

		List<Record> promotions = ProductPromotionService.instance.findProductPromotionActivity(product.getStr("product_id"));
		json.put("promotions", toJson(promotions));

		return json;
	}

	public void relet() {
		final String orderId = getPara("order_id", "");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有指定订单");
			return;
		}

		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}

		//订单只要在出租中的状态下才允许续租
		if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
			errorPage("当前订单不是'出租中'，无法续租");
			return;
		}


		String productId = order.getStr("product_id");
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}
		setAttr("guarantee_deposit_type", Product.GUARANTEE_DEPOSIT_TYPE_USER);
		setAttr("guarantee_deposit", Common.round(0, 2));
		setAttr("order", order2map(order));
		setAttr("order_id",orderId);
		setAttr("product_id",productId);
		//把优惠券取出来
		setAttr("coupons", validCoupons(product.getStr("product_id"), order.getInt("buyuser_uid"),order.getInt("order_source")));
		Map<String, Object> data = product2map(product);
		setAttr("product", data);

		render("prepare.html");
	}

	/**
	 * 订单续租
	 */
	public void reletAdd(){
		final Integer buyuserUid = getSessionAttr("uid");
		if(buyuserUid == null){
			errorPage("请登录后再进行续租操作");
			return;
		}
		
		final String orderId = getPara("order_id", "");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有指定订单");
			return;
		}
		final int buyCount = getParaToInt("buy_count", 1);
		if(buyCount >= PropKit.getInt("product.max_buy_count")){
			errorPage("您续租的租赁时长太多了，请重新选择。");
			return;
		}
		final int rentType = getParaToInt("rent_type", Product.RENT_TYPE_HOUR);
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
		
		//订单只要在出租中的状态下才允许续租
		if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
			errorPage("当前订单不是'出租中'，无法续租");
			return;
		}
		
		//保证这个订单是这个用户的订单
		if(order.getInt("buyuser_uid") != buyuserUid.intValue()){
			errorPage("只能对自己的订单进行续租操作");
			return;
		}
		
		//当前用户不在黑名单中
		if(inBlackList(buyuserUid)){
			errorPage("因您之前存在恶意租号行为，平台目前对您处于封禁状态，暂时无法续租");
			return;
		}


		//获取商品信息
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", order.getStr("product_id"));
		if(product == null){
			errorPage("不存在的商品");
			return;
		}

		//是否使用优惠券
		final String couponUseId = getPara("use_id");
		final Record userCoupon = Coupon.getUserCoupon(buyuserUid, couponUseId);
		if(StringUtils.isNotBlank(couponUseId) && userCoupon == null){
			errorPage("优惠券不存在或者优惠券已过期。");
			return;
		}

		//确定该优惠券可用于当前商品类型
		if(userCoupon != null && Coupon.notFitCoupon(userCoupon, product)){
			errorPage("您的优惠券不适用当前下单的商品类型。");
			return;
		}
		
		//确保当前订单没有未支付的租赁单
		Record reletCount = SmartDb.findFirst("select count(id) as _count from `order_relet` where `order_id`=? and `status`=?", orderId, Order.ORDER_STATUS_NEW);
		if(reletCount.getLong("_count") > 0){
			errorPage("当前订单还有未支付的续租单，请继续完成支付或者等待过期后再进行续租");
			return;
		}
		
		//确保当前时间还能续租
		long validTime = System.currentTimeMillis() + PropKit.getInt("order.pay_timeout")*1000;
		logger.info("订单【" + orderId + "】 -- relet_add.validTime => " + System.currentTimeMillis() + " , date=>" + Common.show_time(System.currentTimeMillis()));
		logger.info("订单【" + orderId + "】 -- relet_add.validTime => " + validTime + " , date=>" + Common.show_time(validTime));
		logger.info("订单【" + orderId + "】 -- relet_add.rent_end_time => " + order.getDate("rent_end_time").getTime() + " , date=>" + Common.show_time(order.getDate("rent_end_time").getTime()));
		if(validTime > order.getDate("rent_end_time").getTime()){
			errorPage("当前订单已经过了续租期，已经无法续租，可以在订单结束之后再次下单租赁该号。");
			return;
		}
		
		//当前订单续租的话，是否足以支持订单超时
		if(order.getDate("rent_end_time").getTime() - System.currentTimeMillis() < PropKit.getInt("order.pay_timeout")*1000L){
			errorPage("您的订单即将结束，无法进行续租了。");
			return;
		}
		
		//创建续租单
		final String now = Common.now();
		final String payId = generateReletId();
		boolean succ = Db.tx(new IAtom() {
			@Override
			public boolean run() throws SQLException {
				//计算续租金额
				int price = rentType == Product.RENT_TYPE_HOUR ? product.getInt("price_hour") : product.getInt("price_day");
				//如果是长租号，取长租号每个月续租价格
				if(rentType == Product.RENT_TYPE_LONGTERM){
					price = product.getInt("longterm_relet_price");
				}

				int orderPayAmount = price * buyCount; //支付金额
				//选择相应的优惠活动
				int count = buyCount;
				Record promotion = ProductPromotionService.instance.findBestMatchPromotionActivity(rentType,buyCount,product.getStr("product_id"));
				if(promotion != null){
					if(rentType == Product.RENT_TYPE_HOUR){
						count += promotion.getInt("promote_gift_time");
					}else{
						orderPayAmount -= promotion.getInt("promote_gift_money");
						orderPayAmount = orderPayAmount < 0 ? 0:orderPayAmount;
					}
				}
				//计算这次续租的起始结束时间
				String rentStartTime = Common.show_time(order.getDate("rent_end_time"));
				String rentEndTime = rentType == Product.RENT_TYPE_DAY ? Common.addDay(rentStartTime, count) : Common.addHour(rentStartTime, count);
				if(rentType == Product.RENT_TYPE_LONGTERM){
					rentEndTime = Common.addDay(rentStartTime, count*31); //按31天算一个月
				}

				//计算优惠金额
				int amountOff = getAmountOff(userCoupon, orderPayAmount);
				if(userCoupon != null){
					logger.info("订单【" + buyuserUid + "】使用了优惠券【" + couponUseId + "】，减免金额: " + amountOff);
				}

				Record relet = new Record();
				relet.set("order_id", orderId);
				relet.set("pay_id", payId);
				relet.set("order_pay_amount", orderPayAmount);
				relet.set("product_price", price);
				relet.set("rent_type", rentType);
				//设置优惠活动信息
				if(promotion != null) {
					relet.set("promote_type", rentType);
					relet.set("promote_unit", promotion.getInt("promote_unit"));
					if(rentType == Product.RENT_TYPE_HOUR){
						relet.set("promote_gift_time",promotion.getInt("promote_gift_time"));
					}else{
						relet.set("promote_gift_money",promotion.getInt("promote_gift_money"));
					}
				}
				relet.set("buy_count", count);
				relet.set("rent_start_time", rentStartTime);
				relet.set("rent_end_time", rentEndTime);
				relet.set("create_time", now);
				relet.set("type", Order.ORDER_RELET_CONTINUE);
				relet.set("status", Order.ORDER_STATUS_NEW);
				relet.set("coupon_use_id",couponUseId);
				relet.set("amount_off",amountOff);
				relet.set("order_origin_price", orderPayAmount);
				if(!SmartDb.save("order_relet", relet)){
					logger.error("保存续租单失败：" + SmartDb.lastQuery());
					errorPage("创建续租单失败了");
					return false;
				}
				int n = SmartDb.update("update `order` set `order_status`=?, `modify_time`=? where `order_id`=?", Order.ORDER_STATUS_PAYING, now, orderId);
				if(n == 0){
					logger.error("修改订单状态为‘续租中’失败了，orderId=>" + orderId + ", sql=>" + SmartDb.lastQuery());
					errorPage("修改订单状态失败了");
					return false;
				}
				//优惠券可用次数-1
				if(userCoupon != null && !Coupon.decreaseUserCoupon(buyuserUid, couponUseId, Common.now())){
					logger.error("商品【" + product.getStr("product_id") + "】下单时使用优惠券失败了，sql=>" + SmartDb.lastQuery());
					errorPage("下单时使用优惠券发生了错误。");
					return false;
				}
				return true;
			}
		});
		//事务执行失败了
		if(!succ)
			return;
		
		int isNewVersion = getParaToInt("is_new_version", 0);
		String clientType = getAttr("client_type");
        //FIXME 因为微信支付存在问题，需要让app的也使用wap版本的支付页面，所以注释掉isNewVersion的判断
		if(!"pc".equalsIgnoreCase(clientType)/* && isNewVersion==0*/){
			String html = payment.payOrder(payId, Common.getIp(getRequest()));
			if(StringUtils.isBlank(html)){
				errorPage("订单支付时发生了一些意外，请联系客服处理。");
				return;
			}
			renderHtml(html);
			return ;
		}

		redirect("/pc/pay/index?order_id=" + orderId);
		return;
	}

	/**
	 * FIXME 买卖双方的聊天窗！暂时无用，仅作为技术储备先留着！
	 */
	public void meeting(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行撤单操作。");
			return;
		}

		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有订单号");
			return;
		}

		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}

		//确保订单的卖家是这个人！
		if(uid.intValue() != order.getInt("selluser_uid").intValue()){
			errorPage("不是您出租的订单，您无法处理！");
			return;
		}

		//确保当前订单是处于已支付状态的
		if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
			errorPage("该订单当前不是‘出租中’状态，无法发起协助！");
			return;
		}

		setAttr("order", toMap(order));
		setAttr("uid", uid);
		setAttr("type", "selluser");
		render("meeting.html");
	}

	/**
	 * 是否为特权UID
	 * @param uid
	 * @return
	 */
	private boolean isPrerogative(int uid){
		String conf = PropKit.get("prerogative.uid");
		if(StringUtils.isBlank(conf)){
			return false;
		}
		
		String[] uids = Common.array_filter(conf.split(","));
		return Common.in(String.valueOf(uid), uids);
	}
	
	/**
	 * 卖家查看撤单原因
	 */
	public void cancelCheck(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行查看撤单操作。");
			return;
		}
		
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有订单号");
			return;
		}
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}

		//确保订单是已撤单的
		if(order.getInt("order_status") != Order.ORDER_STATUS_CANCEL){
			errorPage("该订单不是“交易取消”的订单，无法查看撤单详情。");
			return;
		}
		
		//是否已经超过了24小时，超过时限之后不支持自助仲裁！
		setAttr("enable_arbitrate", orderCanArbitrate(order));
        setAttr("order", order2map(order));
		//如果是用户自助撤单取消的订单，获取详情内容
		if(order.getInt("is_buyuser_arbitrate") == Order.BUYUSER_ARBITRATION){
			//从撤单证据中取出撤单内容
			Record row = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", orderId);
			if(row != null){
				setAttr("cancel_reason", row.getStr("cancel_reason"));
				List<String> pics = new ArrayList<>();
				try{
					JSONArray arr = JSONArray.fromObject(row.getStr("pics"));
					for(int i=0; i<arr.size(); ++i){
						pics.add(arr.getString(i));
					}
				}catch(Exception e){
					logger.error("获取订单【" + orderId + "】的自助撤单详情时发生了错误！");
				}
				setAttr("pics", pics);
			}
		}

		//查询取消申请记录
		Record cancelApply = SmartDb.findFirst("select * from `order_cancel_apply` where `order_id`=? and `status`=? order by `c_time` desc", orderId, Order.ORDER_CANCEL_APPLY_SUCCESS);
		if(cancelApply != null){
			setAttr("check_reason", cancelApply.get("check_reason"));
		}
		
		//统一上号器的取消原因为上号器环境风险
		if(StringUtils.isNotEmpty(order.getStr("cancel_reason"))){
			if(order.getStr("cancel_reason").indexOf("上号器") >= 0){
				setAttr("cancel_reason","上号器环境风险");
			}else{
				setAttr("cancel_reason",order.getStr("cancel_reason"));
			}
		}
		render("cancel_check.html");
	}
	
	/**
	 * 卖家确认撤单
	 */
	public void confirmCancel(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行查看撤单操作。");
			return;
		}
		
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有订单号");
			return;
		}
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
		
		//确保是卖家身份
		if(order.getInt("selluser_uid").intValue() != uid.intValue()){
			errorPage("您不是这笔订单的号主，无权进行撤单确认。");
			return;
		}
		
		//确保订单是已撤单的
		if(order.getInt("order_status") != Order.ORDER_STATUS_CANCEL){
			errorPage("该订单不是“交易取消”的订单，无法进行撤单确认。");
			return;
		}
		
		//已经仲裁成功了
		if(order.getInt("order_isterminate") == Order.ORDER_TERMINATED){
			errorPage("您已经成功仲裁了这笔订单，无需再确认撤单。");
			return;
		}
		
		//是否已经在仲裁中了？
		if(order.getInt("is_selluser_arbitrate") == Order.SELLUSER_ARBITRATE){
			errorPage("您已经成功发起了仲裁，请耐心等待平台客服复核结果。");
			return;
		}
		
		//是否已经确认过撤单了？
		if(order.getInt("is_selluser_arbitrate") == Order.SELLUSER_CONFIRM_CANCEL){
			errorPage("您已经对该订单进行了撤单确认，无需重复操作。");
			return;
		}
		
		//确保在时限内
		if(System.currentTimeMillis() - order.getDate("order_finish_time").getTime() > PropKit.getInt("order.arbitrate_timeout")*1000L){
			errorPage("您的订单已经超过了24小时时限，无法进行撤单确认。");
            return;
		}

		logger.info("订单【" + orderId + "】由卖家【" + uid + "】确认撤单中...");

		//保存订单
		order.keep("order_id");
		order.set("modify_time", Common.now());
		order.set("is_selluser_arbitrate", Order.SELLUSER_CONFIRM_CANCEL);
		if(!SmartDb.update("order", "order_id", order)){
			logger.error("撤单确认时保存订单【" + orderId + "】信息失败了，sql=>" + SmartDb.lastQuery());
			errorPage("平台保存您的确认撤单信息时发生了一些错误。");
			return;
		}
		
		//如果是自助撤单的，同时将撤单证据标记为“已通过”
		Record evidence = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", orderId);
		if(evidence != null){
			evidence.keep("order_id");
			evidence.set("pass", Order.EVIDENCE_ARBITRATE_FAIL); //设置为买家胜出！
			evidence.set("remark", "号主确认撤单");
			if(!SmartDb.update("order_cancel_evidence", "order_id", evidence)){
				logger.error("订单【" + orderId + "】保存设置撤单证据为‘通过’时失败了，sql=>" + SmartDb.lastQuery());
			}
		}

		render("confirm_cancel.html");
	}
	
	/**
	 * 号主发起仲裁
	 */
	public void arbitrate(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行查看撤单操作。");
			return;
		}
		
		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("没有订单号");
			return;
		}
		String arbitrateReason = getPara("arbitrate_reason");
		if(StringUtils.isBlank(arbitrateReason)){
			errorPage("请认真填写仲裁原因！");
			return;
		}
		
		String arbitrateReasonEx = getPara("arbitrate_reason_ex","");
		
		//自助仲裁的证据图片
		String[] pics = getParaValues("pic");
		if(pics == null) pics = new String[0]; //做一层保险
		if(pics.length == 0){
			errorPage("请至少上传1张证据截图");
			return;
		}
		if(pics.length > 10){
			errorPage("最多上传10张证据截图");
			return;
		}
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
		
		//确保是卖家身份
		if(order.getInt("selluser_uid").intValue() != uid.intValue()){
			errorPage("您不是这笔订单的号主，无权进行仲裁。");
			return;
		}
		//确保订单已支付
		if(order.getInt("order_ispay").intValue() != Order.ORDER_PAID){
			errorPage("该订单未支付，无需进行仲裁。");
			return;
		}
		//确保订单是已撤单的
		if(order.getInt("order_status") != Order.ORDER_STATUS_CANCEL && order.getInt("order_status") != Order.ORDER_STATUS_FINISH){
			errorPage("该订单不是“交易取消”/“交易成功”的订单，无法进行仲裁。");
			return;
		}
		
		//已经仲裁成功了
		if(order.getInt("order_isterminate") == Order.ORDER_TERMINATED){
			errorPage("您已经成功仲裁了这笔订单，无需重复仲裁。");
			return;
		}
		
		//是否已经在仲裁中了？
		if(order.getInt("is_selluser_arbitrate") == Order.SELLUSER_ARBITRATE){
			errorPage("您已经成功发起了仲裁，请耐心等待平台客服复核结果。");
			return;
		}
		
		//是否已经确认过撤单了？
		if(order.getInt("is_selluser_arbitrate") == Order.SELLUSER_CONFIRM_CANCEL){
			errorPage("您已经对该订单进行了撤单确认，若希望发起仲裁请联系客服操作。");
			return;
		}
		
		//确保在仲裁时限内
		if(!orderCanArbitrate(order)){
			errorPage("您的订单当前不支持仲裁操作。");
			return;
		}

		//保存订单
		order.keep("order_id");
		order.set("modify_time", Common.now());
		order.set("is_selluser_arbitrate", Order.SELLUSER_ARBITRATE);
		order.set("arbitrate_reason", arbitrateReason);
		if(!SmartDb.update("order", "order_id", order)){
			logger.error("发起仲裁时保存订单【" + orderId + "】信息失败了，sql=>" + SmartDb.lastQuery());
			errorPage("平台保存您的仲裁请求时发生了一些错误，请先联系客服进行订单仲裁吧。");
			return;
		}

		//重新获取这个订单信息
		order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		
		JSONArray json = new JSONArray();
		for(String pic : pics){
			json.add(pic);
		}
		
		//记录仲裁信息
		logger.info("更新仲裁订单："+orderId+"-"+arbitrateReason+"-"+json.toString());
		
		Record evidence = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", orderId);
		boolean exists = evidence != null;
		if(!exists){
			evidence = new Record();
			evidence.set("order_id", orderId);
			evidence.set("type", Order.EVIDENCE_TYPE_SELLUSER);
			evidence.set("pass", 0);
			evidence.set("c_time", Common.now());
		}else{
			evidence.keep("order_id");
		}
		evidence.set("arbitrate_reason", htmlEncode(arbitrateReason));
		evidence.set("arbitrate_reason_ex", arbitrateReasonEx);
		evidence.set("arbitrate_pics", json.toString());
		evidence.set("arbitrate_time", Common.now());
		if(!exists){
			if(!SmartDb.save("order_cancel_evidence", evidence)){
				logger.error("order_cancel_evidence新建记录失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				errorPage("系统在为您创建仲裁信息时发生了错误，请稍后重试。");
				return;
			}
		}else{
			if(!SmartDb.update("order_cancel_evidence", "order_id", evidence)){
				logger.error("订单【" + orderId + "】保存证据数据时失败了，arbitrateReason=>" + arbitrateReason + ", pics=>" + json.toString() + ", sql=>" + SmartDb.lastQuery());
				errorPage("平台保存您的仲裁请求时发生了一些错误，请先联系客服进行订单仲裁吧。");
				return;
			}
		}
		
		logger.info("订单【" + orderId + "】已由卖家【" + uid + "】发起了仲裁！");
		
		render("arbitrate.html");
	}

    /**
     * 仲裁详情
     */
    public void arbitrateDetail(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请登录后再进行查看撤单操作。");
            return;
        }

        String orderId = getPara("order_id");
        if(StringUtils.isBlank(orderId)){
            errorPage("没有订单号");
            return;
        }

        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if(order == null){
            errorPage("不存在的订单");
            return;
        }

        //确保订单是已完成的
        if(order.getInt("order_status") != Order.ORDER_STATUS_CANCEL && order.getInt("order_status") != Order.ORDER_STATUS_FINISH){
            errorPage("该订单不是已完成的订单，无法查看仲裁详情。");
            return;
        }

        //看看仲裁情况
        Record evidence = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", orderId);
        if(evidence.getDate("arbitrate_time") == null){
            errorPage("当前订单并没有号主仲裁，无法查看。");
            return;
        }

        //看看是号主还是玩家
        boolean isSelluser = order.getInt("selluser_uid").intValue() == uid.intValue();

        //如果是玩家，那么要求这个仲裁申请是通过的才行
        if(!isSelluser && evidence.getInt("pass") != Order.EVIDENCE_ARBITRATE_SUCC){
            errorPage("当前订单没有仲裁，无法查看。");
            return;
        }

        //给出仲裁详情
        setAttr("order_id", orderId);
        setAttr("is_selluser", isSelluser);

        Map<String, Object> arbitrate = new TreeMap<>();
        arbitrate.put("punishment_way", evidence.getInt("punishment_way"));
        arbitrate.put("arbitrate_reason", evidence.getStr("arbitrate_reason"));
        arbitrate.put("arbitrate_time", Common.show_time(evidence.getDate("arbitrate_time")));

        String picsStr = evidence.getStr("arbitrate_pics");
        JSONArray pics = new JSONArray();
        if(StringUtils.isNotBlank(picsStr)) {
            try{
                pics = JSONArray.fromObject(picsStr);
            }catch(Exception e){
                //...
            }
        }
        logger.info("xxxxxxxxxxxx=>" + pics.toString());
        arbitrate.put("arbitrate_pics", pics);
        setAttr("arbitrate", arbitrate);

        render("arbitrate_detail.html");
    }
	
    /**
     * 锁定资金列表
     */
    public void delayAmounts(){
    	final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请先登录。");
            return;
        }
        
        List<Record> rows = SmartDb.find("select od.*, o.game_pic, o.product_name from `order_delay_transfer` od left join `order` o on od.order_id=o.order_id where od.`uid`=? and od.`status`=?", uid, Order.DELAY_TRANSFER_NOT_FINISH);
        setAttr("orders", toMap(rows));
        render("delays.html");
    }

	/**
	 * 拉黑玩家
	 * 
	 **/
	public void addUserToBlackList(){
		final Integer sellerUid = getSessionAttr("uid");
		if(sellerUid == null){
			errorPage("请登录后再进行下单操作");
			return;
		}
		
		int buyuserUid = getParaToInt("buyuser_uid", 0);
		boolean isSucc = false;
		String orderId = getPara("order_id");
		logger.info("增加黑名单：号主id-" + sellerUid + ",玩家id-" + buyuserUid + ",订单号-" + orderId);
		Record order = SmartDb.findFirst(
				"select * from `order` where order_id = ? and selluser_uid = ? and order_ispay = ? and buyuser_uid = ?",
				orderId, sellerUid, Order.ORDER_PAID, buyuserUid);
		if (order == null) {
			errorPage("订单不存在");
			return;
		}
		
		//如果是特权UID，不允许被拉黑
		if(isPrerogative(buyuserUid)){
			errorPage("该用户是平台管理员，无法加入黑名单，如有问题请联系客服处理。");
			return;
		}
		
		if (SellerBlackListService.instance.judgeUserInBlackList(buyuserUid, sellerUid)) {
			errorPage("该玩家已被你拉黑。");
			return;
		}
		if (SellerBlackListService.instance.getAmountOfBlackListByUserId(
				buyuserUid) >= PropKit.getInt("seller.uncivilized_blackitem_counts") - 1) {
			User.decreasePlayScore(buyuserUid, 3, "被号主拉黑次数过多，订单id：" + orderId + ",信誉分-5分");
		}

		// 玩家当天已被多名号主拉黑
		if (!SecurityService.singleton.userBlackGuard(buyuserUid)) {
			logger.info("当天被多名号主拉黑:" + buyuserUid + "-orderId--" + orderId);
			User.decreasePlayScoreProxy(buyuserUid, 100, "被号主举报，扣除信誉分", "当天被多名号主拉黑");
		}

		// 玩家当天某小时内存在刷单行为
		if (!SecurityService.singleton.userOrderBlackGuard(buyuserUid)) {
			logger.info("当天某时段存在刷单行为:" + buyuserUid + "-orderId--" + orderId);
			User.decreasePlayScoreProxy(buyuserUid, 100, "被号主举报，扣除信誉分", "当天某时段存在刷单行为");
		}

		// 3.获取用户头像和昵称
		MemberBean<?> bean = null;
		try {
			bean = accountCenterService.findMemberByUid(buyuserUid);
		} catch (Exception e) {
			logger.error("error", e);
		}
		String headimg = "";
		if(bean != null && bean.getData() != null){
			Member member = (Member)bean.getData();
			headimg = member.getHeadimgurl();
		}

		if(buyuserUid > 0 && StringUtils.isNotEmpty(orderId)) {
			isSucc = SellerBlackListService.instance.addUserToBlackList(buyuserUid, UsernameUtil.getUserName(buyuserUid), sellerUid, orderId,headimg);
		}
		if(isSucc) {
			renderJson(Common.buildResp(Common.RESPONSE_SUCCESS,"拉黑玩家成功"));
		}else{
			renderJson(Common.buildResp(Common.RESPONSE_FAIL,"拉黑玩家失败"));
		}

	}
	/**
	 *撤单实例demo页面
	 * **/
	public void cancelApplyDemo(){
		render("self_cancel_demo.html");
	}

	/**
	 * 撤单实例demo页面
	 */
	public void downloadLoginDemo(){
		redirect("/pc/order/loginkit");
	}



	/**
	 * 获取订单最匹配优惠活动
	 *
	 **/
	public void findBestMatchPromotion(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行操作");
			return;
		}
		String productId = getPara("product_id","");
		int rentType = getParaToInt("rent_type",0);
		int rentCount = getParaToInt("buy_count",0);

		if(StringUtils.isEmpty(productId) || rentType == 0 || rentCount == 0){
			logger.error("参数错误：productId="+productId+"--rentType="+rentType+"--rentCount="+rentCount);
			renderJson(Common.buildResp(Common.RESPONSE_FAIL,"参数错误"));
		}
		 Record product = Product.getProduct(productId);
		 if(product == null){
			 errorPage("不存在的商品");
			 return;
		 }
		Record promotion = ProductPromotionService.instance.findBestMatchPromotionActivity(rentType,rentCount,product.getStr("product_id"));
		if(promotion == null){
			renderJson(Common.buildResp(Common.RESPONSE_FAIL,"未找到匹配优惠活动"));
		}else{
			String title = "";
			int promoteGift = 0;
			if(rentType == ProductPromotionService.PROMOTION_TYPE_DAY){
				promoteGift = (int)Common.round(promotion.getInt("promote_gift_money")/100.0, 0);
				title = "租"+promotion.getInt("promote_unit")+"天";

			}else{
				promoteGift = promotion.getInt("promote_gift_time");
				title = "租"+promotion.getInt("promote_unit")+"送"+promoteGift;
			}
			renderJson(Common.buildResp(Common.RESPONSE_SUCCESS,"找到匹配优惠活动", new KeyValue[]{
				new KeyValue<>("data",title),
				new KeyValue<>("promote_gift",promoteGift)
			}));
		}
	}

	
	/**
	 * 通过订单详情页扫描用户的端游上号二维码<br>
	 * 对应 /api/pongQrOrder 接口
	 */
	public void pingQrOrder(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再扫码上号");
			return;
		}
		
		String qrkey = getPara("qrkey");
		if(StringUtils.isBlank(qrkey)){
			errorPage("没有扫码标识");
			return;
		}
		
		String orderId = getPara("order_id");
		//验证订单
		Record order = SmartDb.findFirst("select * from `order` where order_id=?", orderId);
		if(order == null){
			errorPage("不存在订单号，请使用租号APP进行扫码上号！");
			return;
		}
		
		if(order.getInt("order_status") != Order.ORDER_STATUS_PAID && order.getInt("order_status") != Order.ORDER_STATUS_PAYING){
			errorPage("订单尚未支付或者已经结束");
			return;
		}
		
		if(uid.intValue() != order.getInt("buyuser_uid")){
			errorPage("这不是您的订单，无法扫码上号");
			return;
		}
		
		Record loginkeyRow = SmartDb.findFirst("select * from `order_loginkey` where `order_id`=?", orderId);
		if(loginkeyRow == null){
			errorPage("您的订单生成上号码失败了，请联系客服进行撤单处理。");
			return;
		}
		
		if(loginkeyRow.getInt("status") != Order.LOGINKEY_STATUS_VALID){
			errorPage("您的订单上号码已经失效，无法扫码上号。");
			return;
		}
		
		String loginkey = loginkeyRow.getStr("loginkey");
		//看看扫码标识是否已经过期了
        Cache cache = Redis.use("rent_redis");
        if(!cache.exists(qrkey)){
        	errorPage("扫码标识已经过期了，请在端游上号器中重新尝试扫码上号。");
        	return;
        }

		//将对应的上号码填入
        cache.set(qrkey, loginkey);
        cache.expire(qrkey, 60);
		
        setAttr("order_id", orderId);
		render("pingQrOrder.html");
	}
}
