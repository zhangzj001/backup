package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.slf4j.Logger;

import java.sql.SQLException;

/**
 * 出售商品支付完成时
 */
public class OnSellPaySuccessService {
    private OnSellPaySuccessService(){}

    public static OnSellPaySuccessService instance = new OnSellPaySuccessService();

    private Logger logger = Loggers.rentLog();
    
    private IPayment payment = PaymentFactory.get();

    public JSONObject onPaySuccess(Record relet){
        return onPaySuccess(relet, System.currentTimeMillis(), "", "", PropKit.get("order.pay_strategy"));
    }

    public JSONObject onPaySuccess(Record relet, long payFinishTime, String zhifuPlatformWayId, String zhifuPlatformWayName, String strategeId){
        String payId = relet.getStr("pay_id");

        String orderId = relet.getStr("order_id");
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", relet.getStr("order_id"));
        if(order == null){
            logger.error("支付服务后台回调时传入了一个不存在订单，其租赁单ID=>" + payId);
            return Common.buildResp(1, "不存在的订单");
        }

        //获取商品信息
        Record product = SmartDb.findFirst(" /*FORCE_MASTER*/select * from `product` where `product_id`=?", order.getStr("product_id"));
        if(product == null){
            logger.error("支付服务后台回调时传入了一个不存在的商品，其租赁单ID=>" + payId);
            return Common.buildResp(1, "不存在的商品");
        }

        //先将一些有用的数据取出
        final int productType = order.getInt("product_type");
        final int buyuserUid = order.getInt("buyuser_uid");
        final String productName = order.getStr("product_name");
        final int selluserUid = order.getInt("selluser_uid");
        final String productId = order.getStr("product_id");

        //r如果当前租赁单已经因为超时未支付而取消了，此时退款已经在 OrderReletFinishTask中触发了，这里无需理会。
        if(relet.getInt("status") == Order.ORDER_STATUS_CANCEL){
//            if(!PaymentService.instance.refund(buyuserUid,orderId,payId)){
//                logger.error("订单【" + orderId + "】-租赁单【" + payId + "】原路退款给用户【" + buyuserUid + "】失败了");
//                return Common.buildResp(3, "租赁单在原路退款时发生了错误。");
//            }

            return Common.buildResp(2, "该租赁单已经因超时未支付自动撤单，支付金额已原路退回。");
        }

        //确保当前租赁单还未支付完成。
        if(relet.getInt("status") != Order.ORDER_STATUS_NEW){
            return Common.buildResp(2, "该租赁单已经完成支付");
        }

        //出售商品类型！！
        Record sellProduct = null;
        if(productType == Product.PRODUCT_TYPE_CDK){
            sellProduct = sellCdk(order, relet);
        }
        //XXX 以后有其他类型在这里追加逻辑




        final Record thing = sellProduct;
        final Record fOrder = order;
        final Record fRelet = relet;
        boolean succ = Db.tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                String now = Common.now();

                //购买的商品，肯定是直接成功的！
                //修改租赁单信息
                fRelet.keep("pay_id");
                fRelet.set("pay_success_time", Common.show_time(payFinishTime));
                fRelet.set("zhifu_platform_way_id", zhifuPlatformWayId);
                fRelet.set("zhifu_platform_way_name", zhifuPlatformWayName);
                fRelet.set("zhifu_strategy_id", strategeId);
                if(thing != null) {
                    fRelet.set("rent_start_time", now);
                    fRelet.set("rent_end_time", now);
                    fRelet.set("finish_time", now);
                    fRelet.set("status", Order.ORDER_STATUS_FINISH);
                }
                if(!SmartDb.update("order_relet", "pay_id", fRelet)){
                    logger.error("修改租赁单【" + payId + "】信息失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                    return false;
                }

                //修改订单信息
                fOrder.keep("order_id");
                fOrder.set("order_ispay", Order.ORDER_PAID);
                if(thing != null) {
                    fOrder.set("modify_time", now);
                    fOrder.set("rent_start_time", now);
                    fOrder.set("rent_end_time", now);
                    fOrder.set("order_finish_time", now);
                    fOrder.set("order_status", Order.ORDER_STATUS_FINISH);
                }

                //根据不同的类型有不同的数据填入方式
                if(productType == Product.PRODUCT_TYPE_CDK) {
                    if(thing != null) {
                        fOrder.set("selluser_game_account", thing.getStr("cdkey"));  //姑且用这个字段存值吧
                    }
                    if(!SmartDb.update("order", "order_id", fOrder)){
                        logger.error("修改订单【" + orderId + "】信息失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                        return false;
                    }
                    if(thing != null) {
                        //标记这个cdk已经被使用了
                        thing.keep("id");
                        thing.set("status", Product.CDK_STATUS_USED);
                        if (!SmartDb.update("product_cdk", "id", thing)) {
                            logger.error("修改商品CDK信息失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                            return false;
                        }
                    }
                    product.keep("id");
                    product.set("status",Product.STATUS_ONSALE);
                    if (!SmartDb.update("product", "id", product)) {
                        logger.error("修改商品信息失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                        return false;
                    }
                }
                //XXX 以后有其他类型在这里追加逻辑

                return true;
            }
        });

        if(!succ){
            return Common.buildResp(4, "修改订单信息失败了");
        }

        if(thing == null){
            //撤单 --> 通知卖家 + 买家无需24小时等待 + 属于免责撤单
        	String cancelReason = "商品CDK无法发货系统自动撤单";
        	OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
        	cancelInfo.setBuyuserArbitrate(Order.BUYUSER_NO_ARBITRATE);
        	cancelInfo.setCancelReason(cancelReason);
        	cancelInfo.setCancelReasonEx("");
        	cancelInfo.setDeductSelluserGuarantee(false);
        	cancelInfo.setDelayRefund(false);
        	cancelInfo.setFreeCancel(true);
        	cancelInfo.setProductOffsale(true);
        	cancelInfo.setProductOffsaleReason(cancelReason);
            JSONObject result = new OrderCancelService(false).cancel(orderId, cancelInfo);
            if(result == null || result.getInt("code") != 0){
                logger.error("商品CDK无法发货系统自动撤单，orderId=>" + orderId);
            }
            logger.error("订单【" + orderId + "】获取售卖商品失败了！");
            return Common.buildResp(3, "获取售卖商品失败了");
        }

        //重新获取订单详情
        if(!payment.orderSuccForRental(orderId)){
        	logger.error("订单" + orderId + "转款出售金失败了！！！");
        	return Common.buildResp(5, "订单转款出售金给卖家失败了");
        }

        //通知
        if(productType == Product.PRODUCT_TYPE_CDK){
            Record count = SmartDb.findFirst("select count(id) as _count from `product_cdk` where `product_id`=? and `status`=?", productId, Product.CDK_STATUS_VALID);
            //通知
            NotifyService.instance.sendOrderSoldMessageToSelluser(orderId, count.getInt("_count"));
        }

        return Common.buildResp(0, "ok");
    }

    /**
     * 获取一个CDK商品
     * @param order
     * @param relet
     * @return
     */
    private Record sellCdk(final Record order, final Record relet){
        String orderId = order.getStr("order_id");
        String productId = order.getStr("product_id");
        //先锁定一个CDK
        int n = SmartDb.update("update `product_cdk` set `status`=?, `order_id`=? where `product_id`=? and `status`=? limit 1", Product.CDK_STATUS_LOCKED, orderId, productId, Product.CDK_STATUS_VALID);
        //没有可用的CDK了，此订单需要撤单！
        if(n == 0){
            return null;
        }
        //获取这个CDK
        final Record cdk = SmartDb.findFirst(" /*FORCE_MASTER*/ select * from `product_cdk` where `status`=? and `order_id`=? limit 1", Product.CDK_STATUS_LOCKED, orderId);
        //不管出于什么原因，反正锁定失败了！
        if(cdk == null){
            return null;
        }

        return cdk;
    }
}
