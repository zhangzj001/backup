package cn.jugame.rent.page;

import cn.jugame.M2;
import cn.jugame.rent.api.ActionSelector;
import cn.jugame.rent.api.BaseCmd;
import cn.jugame.rent.api.NeedLoginHandler;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.interceptor.VisitLogInterceptor;
import cn.jugame.rent.page.service.QrCodeService;
import cn.jugame.rent.utils.*;
import com.jfinal.aop.Clear;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.jfinal.plugin.redis.Cache;
import com.jfinal.plugin.redis.Redis;
import com.jfinal.render.RenderException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import javax.servlet.ServletOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

//清除所有拦截器！这些方法是给app使用的，不需要拦截器功能！
@Clear()
public class ApiController extends BaseController {

    private static Logger logger = Loggers.rentLog();
    
    private static Logger eventLogger = Loggers.eventLog();
    
    // 获取post body
 	private static int parseStream(byte[] buf, StringBuffer body) {
 		if (buf == null || buf.length == 0) {
 			logger.error("input s is null");
 			return -1 ;
 		}

 		try {
 			int rtn = 0;
 			//如果是M1加密了
 			if(M1.isEncoded(buf)){
 				StringBuffer dest = new StringBuffer();
 				rtn = M1.decode(buf, dest);
 				if (rtn != 0) {
 					logger.error("M1 decode error. rtn:" + rtn);
 					return 0;
 				}
 				body.append(dest.toString());
 				return BaseCmd.ENCODE_TYPE_M1;
 			}
 			//不是M1加密，尝试走M2加密方式
 			else if(isM2Encoded(buf)){
 				byte[] dest = M2.decodeBytes(buf);
 				if(dest == null || dest.length == 0){
 					logger.error("M2 decode error!");
 					return 0;
 				}
 				body.append(new String(dest, "UTF-8"));
 				return BaseCmd.ENCODE_TYPE_M2;
 			}
 			//没有加密
 			else{
 				body.append(new String(buf, "UTF-8"));
 				return 0;
 			}
 		} catch (Exception e) {
 			e.printStackTrace();
 			logger.error("meet exception, return null");
 		}

 		return -1;
 	}
 		
 	private static boolean isM2Encoded(byte[] buf){
 		String head = new String(buf, 0, 4);
 		return "JGM2".equalsIgnoreCase(head);
 	}


    public void index() {
        long tStart = System.currentTimeMillis();

        JSONObject rtn = new JSONObject();

        //判断请求方法， 只支持Post
        if(!getRequest().getMethod().equalsIgnoreCase("POST")) {
            rtn.put("code", -1);
            rtn.put("msg", "bad request method");
            renderJson(rtn);
            return;
        }

		StringBuffer bodyBuf = new StringBuffer();
		int encodeType = parseStream(getPostData(), bodyBuf);

        BaseCmd cmd = null;
        try {
            cmd = ActionSelector.select(bodyBuf.toString(), encodeType);

			// 判断是否需要登录
			NeedLoginHandler.doCheck(cmd);
            
            setCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME,cmd._clientAI,60*60);
            cmd._clientIP = Common.getIp(getRequest());
            JSONObject dataJson = cmd.process();
            //用户信息
            String cacheKey = "rentapi_" + cmd.loginToken;
            logger.info("请求用户IP:"+ Common.getIp(getRequest())+"---请求用户uid："+CacheUtil.get(cacheKey)+"---请求的url："+getRequest().getRequestURL()+"---请求的服务名："+cmd.reqService);
            if("account.logout".equals(cmd.reqService)){
                Enumeration<String> sessions = getSession().getAttributeNames();
                while (sessions.hasMoreElements()){
                    removeSessionAttr(sessions.nextElement());
                }

            }
            rendContent(dataJson.toString(), encodeType);
            return;
        } catch (UseLoginException loginException) {
            rtn.put("code", loginException.code);
            rtn.put("msg", loginException.msg);
            rtn.put("uid", -1);
            rendContent(rtn.toString(), encodeType);
            return;
        } catch (Exception e) {
            logger.error("error", e);
            rtn.put("code", 900);
            rtn.put("msg", e.toString());
            rendContent(rtn.toString(), encodeType);
            return;
        } finally {
            long tEnd = System.currentTimeMillis();
            logger.info((cmd == null ? "" : cmd.reqService) + ", cost:" + (tEnd - tStart));
        }
    }

    //输出加密后的内容
    private void rendContent(String content, int encodeType) {
        ServletOutputStream sss = null;
        try {
            getResponse().setHeader("Pragma", "no-cache");
            getResponse().setHeader("Cache-Control", "no-cache");
            getResponse().setDateHeader("Expires", 0);
            getResponse().setCharacterEncoding("UTF-8");    // 与 contentType 分开设置
            getResponse().setContentType("application/octet-stream");

            byte[] encodingByteArr = content.getBytes("UTF-8");
            if(encodeType == BaseCmd.ENCODE_TYPE_M1){
            	encodingByteArr = M1.encode(content.getBytes("UTF-8"));
            }
            else if(encodeType == BaseCmd.ENCODE_TYPE_M2){
            	encodingByteArr = M2.encodeBytes(content.getBytes("UTF-8"));
            }
            else{
            	encodingByteArr = content.getBytes("UTF-8");
            }

            sss = getResponse().getOutputStream();
            sss.write(encodingByteArr);
            sss.flush();

        } catch (IOException e) {
            logger.error("error", e);
            throw new RenderException(e);
        }
        finally {
            if (sss != null) {
                try {
                    sss.close();
                } catch (IOException ignore) {
                }
            }
            //必须有, renderNull, 框架就不会在render空什么的了
            if(encodeType >= 0) {
                renderNull();
            }
        }

    }

	/**
	 * @deprecated
	 * PC上号器获取登录账密
	 */
	public void pclogin()
	{
		eventLogger.info("action=pclogin`desc=还有人在调用这个接口偷东西");
		String loginkey = getPara("loginkey");
		JSONObject resp = getOrderInfo(loginkey);
		renderJson(resp);
//		renderNull();
	}
	
	/**
	 * 由端游上号器调用该接口，获取一张二维码图和一个对应的qrkey
	 */
	public void getQrCode(){
		String sKey = "loginkit_qrcode";
		String qrkey = getSessionAttr(sKey);
		if(StringUtils.isBlank(qrkey)){
			qrkey = Common.md5(getSession().getId());
			setSessionAttr(sKey, qrkey);
		}
		
		//将这个key写入redis
        Cache cache = Redis.use("rent_redis");
        cache.set(qrkey, "");
        cache.expire(qrkey, 60);
		
        //将二维码返回
		String url = PropKit.get("rent_service_host") + "/order/pingQrOrder?qrkey=" + qrkey;
		byte[] imgData = QrCodeService.instance.generate(url, 200, 200);
		
		JSONObject data = new JSONObject()
				.accumulate("qrkey", qrkey)
				.accumulate("qrcode", Base64.encode(imgData));
		
		JSONObject json = new JSONObject()
				.accumulate("succ", true)
				.accumulate("msg", "ok")
				.accumulate("data", data);
		renderJson(json);
	}
	
	/**
	 * 由端游上号器调用该接口，获取用户订单扫描结果<br>
	 * 对应 /order/pingQrOrder 接口
	 */
	public void pongQrOrder(){
		String qrkey = getPara("qrkey");
		if(StringUtils.isBlank(qrkey)){
			renderText("");
			return;
		}

        Cache cache = Redis.use("rent_redis");
        //只有还有效，就延长至60s
        if(cache.exists(qrkey)){
        	cache.expire(qrkey, 60);
        }
        
        String loginkey = cache.get(qrkey);
        if(StringUtils.isBlank(loginkey))
        	renderText("");
        else{
        	eventLogger.info("t=" + Common.now() + "`action=qrloginkey`loginkey=" + loginkey);
        	renderText(loginkey);
        }
	}
	
	public void getordertest(){
		String loginkey = getPara("loginkey");

		URLConnectionHttpFetcher fetcher = new URLConnectionHttpFetcher();
		String content = fetcher.gets("http://miaochong.jugame.cn/loginkit-order.php?loginkey=" + loginkey);
		JSONObject json = JSONObject.fromObject(content);
		JSONObject data = json.getJSONObject("data");
		
		try{
			String password = data.getString("selluser_game_pwd");
			password = Base64.encode(M1.encode(password.getBytes("UTF-8")));
			data.put("selluser_game_pwd", password);
		}catch(Exception e){
			//
		}
		
		//m2加密
		rendContent(json.toString(), BaseCmd.ENCODE_TYPE_M2);
	}
	
	public void getorder(){
		String loginkey = getPara("loginkey");
		JSONObject resp = getOrderInfo(loginkey);
		rendContent(resp.toString(), BaseCmd.ENCODE_TYPE_M2);
	}

	public void orderstatus(){
		String loginkey = getPara("loginkey");
		JSONObject resp = getOrderInfo(loginkey);
		if(resp.getBoolean("succ")){
			//将其他字段都去掉，就保留剩余时间
			JSONObject data = resp.getJSONObject("data");
			
			JSONArray keys = data.names();
			for(int i=0; i<keys.size(); ++i){
				String key = keys.getString(i);
				if(!"left_time_secs".equals(key)){
					data.remove(key);
				}
			}
		}
		renderJson(resp);
	}

	private boolean matchSimilarProc(Set<String> includeProcs, String proc){
		for(String includeProc : includeProcs){
			if(includeProc.toLowerCase().contains(proc.toLowerCase()))
				return true;
		}
		return false;
	}
	
	private JSONObject getOrderInfo(String loginkey){
		if(StringUtils.isBlank(loginkey)){
			logger.info("loginkey=>" + loginkey + ", msg=>没有登号码");
			return new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "没有登号码")
					.accumulate("data", new JSONObject());
		}
		
		Record row = SmartDb.findFirst("select o.order_status, o.selluser_game_account, o.selluser_game_pwd, o.game_id, o.channel_id, ol.* from order_loginkey ol left join `order` o on ol.order_id = o.order_id where ol.loginkey=?", loginkey);
		if(row == null 
				|| row.getInt("status") == Order.LOGINKEY_STATUS_INVALID
				|| row.getDate("valid_time").getTime() < System.currentTimeMillis()){
			logger.info("loginkey=>" + loginkey + ", msg=>登录钥匙无效或已过期，请重新输入");
			return new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "登录钥匙无效或已过期，请重新输入")
					.accumulate("data", new JSONObject());
		}
		
		if(row.getInt("order_status") != Order.ORDER_STATUS_PAID && row.getInt("order_status") != Order.ORDER_STATUS_PAYING){
			logger.info("loginkey=>" + loginkey + ", msg=>订单已过期");
			return new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "订单已过期")
					.accumulate("data", new JSONObject());
		}
		
		//计算剩余秒数
		long leftTimeSecs = (row.getDate("valid_time").getTime() - System.currentTimeMillis()) / 1000;
		
		//获取账号密码
		String passwd = null;
		try{
			byte[] bs = row.getStr("selluser_game_pwd").getBytes("UTF-8");
			passwd = Base64.encode(M1.encode(bs));
		}catch(Exception e){
			logger.info("loginkey=>" + loginkey + ", msg=>获取登录密码失败，请联系客服撤单。", e);
			return new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "获取登录密码失败，请联系客服撤单。")
					.accumulate("data", new JSONObject());
		}

		//获取相关的游戏进程
		Set<String> includeProcs = new TreeSet<>();
		//获取相关的游戏窗口类
		Set<String> includeWinclass = new TreeSet<>();
		Record conf = SmartDb.findFirst("select * from login_key_config where game_id=? and channel_id=?", row.getStr("game_id"), row.getStr("channel_id"));
		if(conf != null && StringUtils.isNotBlank(conf.getStr("game_procs"))){
			for(String proc : Common.array_filter(conf.getStr("game_procs").split(","))){
				includeProcs.add(proc);
			}
		}
		if(conf != null && StringUtils.isNotBlank(conf.getStr("game_winclass"))){
			for(String winclass : Common.array_filter(conf.getStr("game_winclass").split(","))){
				includeWinclass.add(winclass);
			}
		}
		String[] procs = includeProcs.toArray(new String[0]);
		String[] winclasses = includeWinclass.toArray(new String[0]);
		
		
		//获取同平台其它游戏进程名字
		String[] excludeProcs = new String[0];
		if(conf != null){
			List<Record> otherConfs = SmartDb.find("select * from login_key_config where `login_client_name`=? and `id`!=?", conf.getStr("login_client_name"), conf.getInt("id"));
			Set<String> procSet = new TreeSet<>();
			for(Record other : otherConfs){
				for(String proc : Common.array_filter(other.getStr("game_procs").split(","))){
					//该进程如果在白名单中，就不要加入黑名单，因为进程名有可能会重名...暂时没药救
//					if(includeProcs.contains(proc))
					if(matchSimilarProc(includeProcs, proc))
						continue;
					procSet.add(proc);
				}
			}
			
			//如果是wegame平台的，要把cf带进去
			if("wegame".equalsIgnoreCase(conf.getStr("login_client_name"))){
				List<Record> cfConfs = SmartDb.find("select * from `login_key_config` where `login_client_name`='cf'");
				for(Record cfConf : cfConfs){
					for(String proc : Common.array_filter(cfConf.getStr("game_procs").split(","))){
//						if(includeProcs.contains(proc))
						if(matchSimilarProc(includeProcs, proc))
							continue;
						procSet.add(proc);
					}
				}
			}
			
			excludeProcs = procSet.toArray(new String[0]);
		}
		
		//打印version日志
		eventLogger.info("loginkey=" + loginkey + "`order_id=" + row.getStr("order_id") + "`version=" + getPara("version", ""));

		JSONObject data = new JSONObject()
				.accumulate("order_id", row.getStr("order_id"))
				.accumulate("selluser_game_account", row.getStr("selluser_game_account"))
				.accumulate("selluser_game_pwd", passwd)
				.accumulate("game_id", row.getStr("game_id"))
				.accumulate("rel_procs", Common.join(procs, ","))
				.accumulate("rel_winclass", Common.join(winclasses, ","))
				.accumulate("exclude_procs", Common.join(excludeProcs, ","))
				.accumulate("platform", row.getStr("login_client_name"))
				.accumulate("left_time_secs", leftTimeSecs);
		return new JSONObject()
				.accumulate("succ", true)
				.accumulate("msg", "ok")
				.accumulate("data", data);
	}
	
	/**
	 * 测试接口
	 */
	public void screenshot(){
		byte[] bs = getPostData();
		if(bs.length == 0){
			renderJson(new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "no data"));
			return;
		}

		//解码
		bs = M2.decodeBytes(bs);
		if(bs == null){
			renderJson(new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "数据格式错误"));
			return;
		}
		
		int firstDotIdx = 0;
		for(; firstDotIdx<bs.length; ++firstDotIdx){
			if(bs[firstDotIdx] == '`'){
				break;
			}
		}
		
		int secondDotIdx = firstDotIdx + 1;
		for(; secondDotIdx<bs.length; ++secondDotIdx){
			if(bs[secondDotIdx] == '`'){
				break;
			}
		}
		
		if(firstDotIdx >= bs.length || secondDotIdx >= bs.length){
			renderJson(new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "数据解析失败"));
			return;
		}
		
		//分成三段，格式为  loginkey + '`' + name + '`' + imgdata
		byte[] loginkeyBytes = new byte[firstDotIdx];
		byte[] nameBytes = new byte[secondDotIdx - firstDotIdx - 1];
		byte[] imgData = new byte[bs.length - firstDotIdx - secondDotIdx - 2];
		System.arraycopy(bs, 0, loginkeyBytes, 0, loginkeyBytes.length);
		System.arraycopy(bs, loginkeyBytes.length + 1, nameBytes, 0, nameBytes.length);
		System.arraycopy(bs, loginkeyBytes.length + nameBytes.length + 2, imgData, 0, imgData.length);
		
		String loginkey;
		String imgName;
		try{
			loginkey = new String(loginkeyBytes, "UTF-8");
			imgName = new String(nameBytes, "UTF-8");
		}catch(Exception e){
			renderJson(new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "无法解析字段值"));
			return;
		}
		
		//反查订单详情
		Record order = SmartDb.findFirst("select o.* from `order_loginkey` ol left join `order` o on ol.order_id=o.order_id where ol.loginkey=? limit 1", loginkey);
		if(order == null){
			renderJson(new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "不存在的订单"));
			return;
		}
		String orderId = order.getStr("order_id");
		
		//将imgData传给阿里云
		String key = orderId + "/" + imgName;
		if(!AliyunImageUtils.uploadFile(key, imgData)){
			renderJson(new JSONObject()
					.accumulate("succ", false)
					.accumulate("msg", "上传阿里云失败"));
			return;
		}

		String imgUrl = AliyunImageUtils.getUploadedImgUrl(key);
		
		//存储到订单截图表
		Record row = SmartDb.findFirst("select * from `order_screenshot` where `order_id`=? and `img_name`=?", orderId, imgName);
		if(row == null){
			row = new Record();
			row.set("order_id", orderId);
			row.set("order_loginkey", loginkey);
			row.set("img_name", imgName);
			row.set("img_url", imgUrl);
			row.set("create_time", Common.now());
			if(!SmartDb.save("order_screenshot", row)){
				logger.error("记录订单【" + orderId + "】的截图时失败了，imgName=>" + imgName + "!sql=>" + SmartDb.lastQuery(), SmartDb.getException());
			}
		}else{
			//覆盖旧的
			row.keep("id");
			row.set("img_url", imgUrl);
			row.set("create_time", Common.now());
			if(!SmartDb.update("order_screenshot", "id", row)){
				logger.error("修改订单【" + orderId + "】的截图时失败了，imgName=>" + imgName + "!sql=>" + SmartDb.lastQuery(), SmartDb.getException());
			}
		}
		
		renderJson(new JSONObject()
				.accumulate("succ", true)
				.accumulate("msg", "ok"));
	}
}
