package cn.jugame.rent.page;

import cn.jugame.rent.bean.Product;
import cn.jugame.rent.page.service.OnRentPaySuccService;
import cn.jugame.rent.page.service.OnSellPaySuccessService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.helper.misc.ChecksumHelper;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;

public class OrderCallbackController extends BaseController{
	
	private Logger logger = Loggers.callbackLog();
	
	private IPayment payment = PaymentFactory.get();
	
	/**
	 * 支付前台回调接口
	 */
	public void frontend(){
		StringBuffer log = new StringBuffer("收到支付服务前端回调，参数：\n");
		Enumeration<String> enu = getParaNames();
		while(enu.hasMoreElements()){
			String key = enu.nextElement();
			log.append(key).append("=").append(getPara(key)).append("\n");
		}
		log.append("-----------------------------");
		logger.info(log.toString());
		
		String payId = getPara("orderId");
		if(StringUtils.isBlank(payId)){
			errorPage("没有租赁单ID");
			return;
		}
		
		Record relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
		if(relet == null){
			errorPage("不存在的订单");
			return;
		}
		
		//跳到订单详情去
		redirect("../order/detail?order_id=" + relet.getStr("order_id"));
	}
	
	/**
	 * 支付后台回调接口
	 */
	public void backend(){
		//给你一个示例：
		//complateTime=1497864695023&orderId=RELET-170619-173113569-CB4466&recvAmount=0.0&vcode=fe809d2c04156f5ce094aca902a3015c&status=20
		String payId = getPara("orderId");
		String recvAmount = getPara("recvAmount");
		long payFinishTime = getParaToLong("completeTime", 0L);
		String strategeId = getPara("strategeId");
		String zhifuPlatformWayId = getPara("zhifuPlatformWayId");
		String zhifuPlatformWayName = getPara("payWay");
		
		logger.info("收到支付后端回调，payId=>" + payId + ", payFinishTime=>" + Common.show_time(payFinishTime));
		if(!backendCommon()){
			logger.info("backendCommon 失败了！");
			return;
		}

		//查询当前租赁单
		Record relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
		if(relet == null){
			logger.error("支付服务后台回调时传入了一个不存在租赁单ID=>" + payId);
			renderJson(buildResp(1, "不存在的租赁单"));
			return;
		}

		//获取当前订单
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", relet.getStr("order_id"));
		if(order == null){
		    logger.error("支付服务后台回调传入了一个不存在的订单，orderId=>" + relet.getStr("order_id"));
            renderJson(buildResp(1, "不存在的订单"));
            return;
        }
		
		//记录下这一次支付回调的金额
		payment.onOrderPaySucc(payId);

		DistLocker locker = new DistLocker(relet.getStr("order_id"));
		try{
		    locker.lock(PropKit.getInt("displock.timeout"));

		    //根据商品类型使用不同的回调服务
            if(order.getInt("product_type") == Product.PRODUCT_TYPE_CDK){
                JSONObject json = OnSellPaySuccessService.instance.onPaySuccess(relet, payFinishTime, zhifuPlatformWayId, zhifuPlatformWayName, strategeId);
                renderJson(json);
            }else {
                JSONObject json = OnRentPaySuccService.instance.onPaySuccess(relet, payFinishTime, zhifuPlatformWayId, zhifuPlatformWayName, strategeId);
                renderJson(json);
            }
        }finally {
		    locker.unlock();
        }
    }

    /**
	 * 商品保证金订单前端回调接口
	 * */
    public void guaranteeAmountFronted(){
		StringBuffer log = new StringBuffer("收到保证金支付服务前端回调，参数：\n");
		Enumeration<String> enu = getParaNames();
		while(enu.hasMoreElements()){
			String key = enu.nextElement();
			log.append(key).append("=").append(getPara(key)).append("\n");
		}
		log.append("-----------------------------");
		logger.info(log.toString());

		String payId = getPara("orderId");
		if(StringUtils.isBlank(payId)){
			errorPage("没有保证金支付ID");
			return;
		}

		Record guaranteeAmountOrder = SmartDb.findFirst(" /*FORCE_MASTER*/ select * from `guarantee_amount_order` where `pay_id`=?", payId);
		if(guaranteeAmountOrder == null){
			errorPage("不存在的订单");
			return;
		}

		String productId = guaranteeAmountOrder.get("product_id");
		//查询当前商品
		Record product = SmartDb.findFirst(" /*FORCE_MASTER*/ select * from `product` where `product_id`=?", productId);
		if(product == null){
			logger.error("商品不存在ID=>" +  guaranteeAmountOrder.get("product_id"));
			renderJson(buildResp(1, "商品不存在"));
			return;
		}
		//跳到发布成功页面
		String msg = product.getInt("status")==Product.STATUS_VERIFY ? "保证金设置成功，商品审核通过后自动上架.":"保证金设置成功.";
		setAttr("msg",msg);
		setAttr("product_id",productId);
		redirect("../rent/setSellerGuaranteeAmountSuccess?msg="+msg+"&product_id="+productId);
	}

	/**
	 * 商品保证金订单后端回调接口
	 * */
	public void guaranteeAmountBackend(){
		//complateTime=1497864695023&orderId=RELET-170619-173113569-CB4466&recvAmount=0.0&vcode=fe809d2c04156f5ce094aca902a3015c&status=20
		String payId = getPara("orderId");
		String recvAmount = getPara("recvAmount");
		long payFinishTime = getParaToLong("completeTime", 0L);
		String strategeId = getPara("strategeId");
		String zhifuPlatformWayId = getPara("zhifuPlatformWayId");
		String zhifuPlatformWayName = getPara("payWay");
		if(!backendCommon()){
			return;
		}
		//查询当前保证金订单
		Record guaranteeAmountOrder = SmartDb.findFirst(" /*FORCE_MASTER*/ select * from `guarantee_amount_order` where `pay_id`=?", payId);
		if(guaranteeAmountOrder == null){
			logger.error("支付服务后台回调时传入了一个不存在保证金订单ID=>" + payId);
			renderJson(buildResp(1, "不存在的保证金订单"));
			return;
		}

		String productId = guaranteeAmountOrder.get("product_id");
		//查询当前商品
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			logger.error("商品不存在ID=>" +  guaranteeAmountOrder.get("product_id"));
			renderJson(buildResp(1, "商品不存在"));
			return;
		}
		int payAmount = guaranteeAmountOrder.getInt("amount");
		//更新保证金支付订单信息
		guaranteeAmountOrder.keep("id");
		guaranteeAmountOrder.set("status",Product.GUNRANTEE_AMOUNT_STATUS_PAYED);
		guaranteeAmountOrder.set("pay_time", Common.show_time(payFinishTime));
		if(!SmartDb.update("guarantee_amount_order", "id", guaranteeAmountOrder)){
			logger.error("保证金交易保存数据失败，payId=>" + payId + "， sql=>" + SmartDb.lastQuery());
			renderJson(buildResp(4, "保存保证金交易数据失败"));
			return;
		}
		//更新商品保证金信息和手续费折扣信息


	    logger.info("设置保证金更新参数："+(int)(Double.parseDouble(recvAmount) * 100)+"-"+PropKit.get("product.guarantee_amount_discount")+"-"+payAmount+"-"+payId);
		int amount = (int)(Double.parseDouble(recvAmount) * 100) > 0 ? ((int)(Double.parseDouble(recvAmount) * 100)) : payAmount;
		int result = SmartDb.update("update `product` set  `seller_guarantee_amount` = ? , `fee_rate_discount` = ?,`seller_guarantee_time` = ? where `id` = ?",
				amount,PropKit.get("product.guarantee_amount_discount"),Common.now(),product.getInt("id"));
		if(result == 0){
			logger.error("更新商品保证金数据失败，product_id=>" + productId + "， sql=>" + SmartDb.lastQuery());
			renderJson(buildResp(4, "更新商品保证金数据失败"));
			return;
		}

		
		//记录下这一次支付回调的金额
		payment.onGuaranteePaySucc(product, payId, amount);;

		renderJson(buildResp(0, "ok"));


	}
	
	/***
	 * 商品装饰支付订单前端回调接口
	 */
	public void decorateFronted() {
		StringBuffer log = new StringBuffer("收到商品装饰支付服务前端回调，参数：\n");
		Enumeration<String> enu = getParaNames();
		while(enu.hasMoreElements()){
			String key = enu.nextElement();
			log.append(key).append("=").append(getPara(key)).append("\n");
		}
		log.append("-----------------------------");
		logger.info(log.toString());

		String payId = getPara("orderId");
		if(StringUtils.isBlank(payId)){
			errorPage("没有保证金支付ID");
			return;
		}

		Record productDecorate = SmartDb.findFirst(" /*FORCE_MASTER*/ select * from `product_decorate_payment` where `pay_id`=?", payId);
		if(productDecorate == null){
			errorPage("不存在的订单");
			return;
		}
		redirect("../user/myproducts");
	}
	
	/***
	 * 商品装饰支付订单后端回调接口
	 */
	public void decorateBackend() {
		String payId = getPara("orderId");
		logger.info("商品装饰支付订单后端回调接口,payId【"+payId+"】");
		long payFinishTime = getParaToLong("completeTime", 0L);
		if(!backendCommon()){
			return;
		}
		//查询当前保证金订单
		Record productDecorate = SmartDb.findFirst(" /*FORCE_MASTER*/ select * from `product_decorate_payment` where `pay_id`=?", payId);
		if(productDecorate == null){
			logger.error("支付服务后台回调时传入了一个不存在商品装饰支付订单ID=>" + payId);
			renderJson(buildResp(1, "不存在的商品装饰支付订单"));
			return;
		}
		
		//更新商品装饰标签
		SmartDb.update("update product set is_decorate = ? where seller_uid = ? and status != ?",
				Product.PRODUCT_DECORATE,productDecorate.getInt("uid"),Product.STATUS_DELETE);
		
		//将钱转到平台
		if(!payment.deductProductDecorate(productDecorate.getInt("uid"), payId, productDecorate.getInt("amount"))) {
			logger.error("商品装饰支付状态平台失败，payId=>" + payId);
		}
		
		//更新保证金支付订单信息
		productDecorate.keep("id");
		productDecorate.set("status",Product.DECORATE_PAYMENT_STATUS_PAYED);
		productDecorate.set("pay_time", Common.show_time(payFinishTime));
		productDecorate.set("invalid_time", Common.show_time(payFinishTime+PropKit.getInt("decorate_invalid_day",1)*24*3600*1000));
		if(!SmartDb.update("product_decorate_payment", "id", productDecorate)){
			logger.error("商品装饰支付交易保存数据失败，payId=>" + payId + "， sql=>" + SmartDb.lastQuery());
			renderJson(buildResp(4, "保存商品装饰支付交易数据失败"));
			return;
		}

		renderJson(buildResp(0, "ok"));
	}

	/**
	 * 支付回调后端通用处理
	 *
	 * */
	private boolean backendCommon(){
		String payId = getPara("orderId"); //租赁单ID
		if(StringUtils.isBlank(payId)){
			renderJson(buildResp(1, "没有租赁单ID"));
			return false;
		}

		String vcode = getPara("vcode", "");

		//验签
		Map<String, String> params = new TreeMap<String, String>();
		StringBuffer log = new StringBuffer("收到支付后台回调，参数为：\n");
		Enumeration<String> enu = getParaNames();
		while(enu.hasMoreElements()){
			String name = enu.nextElement();
			log.append(name).append("=").append(getPara(name)).append("\n");
			if("vcode".equals(name))
				continue;
			params.put(name, getPara(name));
		}
		log.append("-----------------------------");
		logger.info(log.toString());

		String checkVcode = ChecksumHelper.getChecksum(params, PropKit.get("busi.secretkey"));
		logger.info("payId=>" + payId + ", vcode=>" + vcode);
		logger.info("payId=>" + payId + ", checkvcode=>" + checkVcode);
		if(!vcode.equalsIgnoreCase(checkVcode)){
			logger.info("payId=>" + payId + "签名失败了！");
			renderJson(buildResp(1, "签名失败"));
			return false;
		}
		return true;
	}

}
