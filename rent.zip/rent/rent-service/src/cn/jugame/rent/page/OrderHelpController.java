package cn.jugame.rent.page;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.page.service.OrderCancelService;
import cn.jugame.rent.page.service.OrderHelpContactMsgService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.jfinal.plugin.redis.Cache;
import com.jfinal.plugin.redis.Redis;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 订单求助处理类
 */
@Before(LoginInterceptor.class)
public class OrderHelpController extends BaseController{

    private Logger logger = Loggers.rentLog();
    
    private OrderHelpContactMsgService msgService = new OrderHelpContactMsgService();

    /**
     * 根据指定的ID获取对应的求助原因说明
     * @param id
     * @return
     */
    private String getHelpReasonDescription(int id){
        if(id == 1){
            return "密码错误，请更换帐密给我";
        }
        if(id == 2){
            return "请帮我解除账号登陆异常";
        }
        if(id == 3){
            return "请提供登陆验证码给我";
        }

        return "";
    }

    /**
     * 玩家发起订单求助
     */
    public void callHelp(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请登录后再进行操作。");
            return;
        }

        final String orderId = getPara("order_id");
        if(StringUtils.isBlank(orderId)){
            errorPage("没有订单号");
            return;
        }

        int helpType = getParaToInt("help_reason", 0);
        final String helpReason = getHelpReasonDescription(helpType);
        if(StringUtils.isBlank(helpReason)){
            errorPage("请先选择求助原因再发起订单求助。");
            return;
        }

        if(StringUtils.isBlank(helpReason)){
            errorPage("请先选择订单求助的原因");
            return;
        }

        String[] pics = getParaValues("pic");
        if(pics == null) pics = new String[0]; //做一层保险
        if(pics.length > 5){
            errorPage("最多上传5张求助截图");
            return;
        }
        final JSONArray json = new JSONArray();
        for(int i=0; i<pics.length; ++i){
            json.add(pics[i]);
        }

        final Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if(order == null){
            errorPage("不存在的订单");
            return;
        }

        //确保订单是出租中的
        if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
            errorPage("您的订单目前不是出租中，无法求助");
            return;
        }

        //确保时间还在可求助时间内
        Date rentStartTime = order.getDate("rent_start_time");
        if(rentStartTime.getTime() + PropKit.getInt("order.order_help.timeout")*1000L < System.currentTimeMillis()){
            errorPage("您的订单已经超出了号主求助时间范围，如有问题请联系客服。");
            return;
        }


        //先将数据字段取出
        final String gameName = order.getStr("game_name");
        final int orderPayAmount = order.getInt("order_pay_amount");
        final String productName = order.getStr("product_name");
        final int buyuserUid = order.getInt("buyuser_uid");
        final int selluserUid = order.getInt("selluser_uid");
        final String selluserPhonenum = order.getStr("selluser_phonenum");
        final int  sellerGuaranteeAmount = order.getInt("seller_guarantee_amount");
        //确保买家一致
        if(buyuserUid != uid.intValue()){
            errorPage("您只能对自己的订单发起求助。");
            return;
        }

        //检查一下是否超过每个订单额定的求助请求
        List<Record> helps = SmartDb.find("select * from `order_help` where `order_id`=?", orderId);
        if(helps.size() >= PropKit.getInt("order.max_help_count")){
            errorPage("您订单的求助次数过多，请直接申请撤单。");
            return;
        }

        //看看有没有还在等待号主处理的求助请求
        for(Record help : helps){
            if(help.getInt("status") == Order.HELP_STATUS_WAITING){
            	String content = "您的求助信息已经通知号主，无需重复提交。请耐心等待5分钟，若号主超时未能响应，平台将自动为您免责撤单。\n"
            			+ "关注微信服务号“jiaoyi8868”并绑定平台账号，及时获取订单变动消息！";
            	msgService.sendMsg(orderId, content, Order.HELP_MESSAGE_SENDER_SYSTEM, Order.HELP_MESSAGE_SENDER_BUYUSER);
            	//重定向到聊天窗口去
                redirect("contact_window?order_id="+orderId);
                return;
            }
        }

        boolean tx = Db.tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                //记录这个求助请求，并对号主发起通知
                Record help = new Record();
                help.set("order_id", orderId);
                help.set("buyuser_uid", buyuserUid);
                help.set("selluser_uid", selluserUid);
                help.set("help_type", helpType);
                help.set("help_reason", helpReason);
                help.set("help_pics", json.toString());
                help.set("c_time", Common.now());
                help.set("status", Order.HELP_STATUS_WAITING);
                if(!SmartDb.save("order_help", help)){
                    logger.error("订单【" + orderId + "】记录求助请求时失败了，sql=>" + SmartDb.lastQuery(), SmartDb.lastQuery());
                    return false;
                }

                //将订单设置为等待帮助状态
                order.keep("order_id");
                order.set("modify_time", Common.now());
                order.set("order_help", Order.ORDER_HELP);
                order.set("order_help_type", helpType);
                if(!SmartDb.update("order", "order_id", order)){
                    logger.error("订单【" + orderId + "】记录求助状态时发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                    return false;
                }

                return true;
            }
        });
        if(!tx){
            errorPage("很抱歉您的求助因为服务器发生了一些小故障而失败了，请联系平台客服撤单。");
            return;
        }

        //消息发送到求助聊天窗口
        //发送消息给买家
        {
        	String content = "您的求助信息已经通知号主，请耐心等待5分钟，若号主超时未响应求助，平台将自动为您免责撤单。\n"
        				+ "关注微信服务号“jiaoyi8868”并绑定平台账号，及时获取订单变动消息！";
        	msgService.sendMsg(orderId, content, Order.HELP_MESSAGE_SENDER_SYSTEM, Order.HELP_MESSAGE_SENDER_BUYUSER);
        }
        //发送消息给卖家
        {
        	String content = "玩家租赁了您的账号并向您发起了求助：\n"
        			+ helpReason + "\n"
        			+ "请您尽快处理，若求助超过5分钟未处理，平台将自动撤单。感谢您的理解和支持。";
        	msgService.sendMsg(orderId, content, Order.HELP_MESSAGE_SENDER_SYSTEM, Order.HELP_MESSAGE_SENDER_SELLUSER);
        }

        //发送通知提醒
        NotifyService.instance.sendHelpMessageToSelluser(orderId, helpReason);

        setAttr("msg", "您成功向号主发起了订单求助，号主将在5分钟内给予协助并回应，若超时未处理系统将自动为您撤单。");
        setAttr("order_id", orderId);
        setAttr("type", "buyuser");
        redirect("contact_window?order_id=" + orderId);
    }

    /**
     * 号主进入订单求助处理页
     */
    public void help(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请登录后再进行操作。");
            return;
        }

        String orderId = getPara("order_id");
        if(StringUtils.isBlank(orderId)){
            errorPage("没有订单号");
            return;
        }

        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if(order == null){
            errorPage("不存在的订单");
            return;
        }

        //确保订单是出租中
        if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
            errorPage("当前订单状态不是出租中，无法进行求助处理");
            return;
        }

        //确保卖家一致
        if(uid.intValue() != order.getInt("selluser_uid").intValue()){
            errorPage("不是您的出租订单，无法进行求助处理。");
            return;
        }

        //获取求助内容
        Record help = SmartDb.findFirst("select * from `order_help` where `order_id`=? and `status`=?", orderId, Order.HELP_STATUS_WAITING);
        if(help == null){
            errorPage("您出租的这笔订单没有需要帮助玩家的地方。");
            return;
        }

        List<String> pics = new ArrayList<>();
        try{
            JSONArray json = JSONArray.fromObject(help.getStr("help_pics"));
            for(int i=0; i<json.size(); ++i){
                pics.add(json.getString(i));
            }
        }catch(Exception e){
            logger.error("订单【" + orderId + "】的求助图片数据包含了非法的json格式，help.id=>" + help.getLong("id"));
        }

        setAttr("pics", pics);
        setAttr("help", toMap(help));
        setAttr("order", order2map(order));
        render("help.html");
    }

    /**
     * 判断字符串是否符合密码格式
     * @param str
     * @return
     */
    private boolean checkPassword(String str){
        return str.length() <= 20;
    }

    /**
     * 判断字符串是否符合验证码格式
     * @param str
     * @return
     */
    private boolean checkAuthcode(String str){
        //只能允许字母和数字
        if(str.length() > 10)
            return false;
        for(int i=0; i<str.length(); ++i){
            char c = str.charAt(i);
            if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
                continue;
            //发现有不符合格式的字符
            return false;
        }
        return true;
    }

    /**
     * 号主进行订单求助
     */
    public void doHelp(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请登录后再进行操作。");
            return;
        }

        final String orderId = getPara("order_id");
        if(StringUtils.isBlank(orderId)){
            errorPage("没有订单号");
            return;
        }
        final String selluserGamePwd = getPara("selluser_game_pwd");
        if(StringUtils.isBlank(selluserGamePwd)){
            errorPage("没有提交更新的密码或者验证码");
            return;
        }

        //与求助超时定时任务进行同步
        DistLocker locker = new DistLocker("order-help-" + orderId);
        try{
            locker.lock();

            //干正事
            final Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
            if(order == null){
                errorPage("不存在的订单");
                return;
            }
            String gameName =order.getStr("game_name");
            //如果订单刚好被取消了，特意提醒改密
            if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
                errorPage("当前订单已经取消交易。若是玩家提前取消订单，请您尽快修改账号密码以保护您的账号财产。");
                return;
            }
            //其他状态只要不是出租中的，都一般提醒就够了。
            if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
                errorPage("当前订单并不是‘出租中’，无法进行求助处理");
                return;
            }

            //确保订单号主是本人
            if(order.getInt("selluser_uid").intValue() != uid.intValue()){
                errorPage("您无法处理不是您出租的订单");
                return;
            }

            int helpTypePara = 0;
            //订单求助
            final Record orderHelp = SmartDb.findFirst("select * from `order_help` where `order_id`=? and `status`=? limit 1", orderId, Order.HELP_STATUS_WAITING);
            if(orderHelp != null){
                helpTypePara = orderHelp.getInt("help_type");
            }else{
                helpTypePara = getParaToInt("help_type");
            }
            final int helpType = helpTypePara;
            final int orderPayAmount = order.getInt("order_pay_amount");
            final String productName = order.getStr("product_name");
            final String buyuserPhonenum = order.getStr("buyuser_phonenum");
            final int buyuserUid = order.getInt("buyuser_uid");
            final String originalPassword = order.getStr("selluser_game_pwd");
            //对输入的密码、验证码进行值判断
            if(helpType == Order.HELP_TYPE_PASSWORD ){
                if(!checkPassword(selluserGamePwd)){
                    errorPage("您的新密码长度过长，请不要超过20个字。");
                    return;
                }
            }
            if(helpType == Order.HELP_TYPE_AUTHCODE || helpType == Order.HELP_TYPE_ACCOUNT_FROZEN){
                if(!checkAuthcode(selluserGamePwd)){
                    errorPage("平台只支持不超过10个字长度的字母数字验证码，您的验证码格式不正确。若无法填写请同意撤单。");
                    return;
                }
            }

            boolean succ = Db.tx(new IAtom() {
                @Override
                public boolean run() throws SQLException {
					// 更新订单求助的状态，同时也更新订单里的信息
					if (orderHelp != null) {
						orderHelp.keep("id");
						orderHelp.set("h_time", Common.now());

						orderHelp.set("h_result", selluserGamePwd);
						orderHelp.set("status", Order.HELP_STATUS_OK);
						if (!SmartDb.update("order_help", "id", orderHelp)) {
							logger.error("订单【" + orderId + "】提交求助结果失败了，sql=>" + SmartDb.lastQuery(),
									SmartDb.getException());
							return false;
						}
					}

                    //也更新订单的数据
                    order.keep("order_id");
                    order.set("modify_time", Common.now());
                    order.set("order_help", Order.ORDER_HELP_FINISH);
                    order.set("order_help_type",helpType);
                    order.set("order_help_result", selluserGamePwd);
                    //如果密码错误或者账号冻结的，需要回填新密码到订单
                    if(helpType == Order.HELP_TYPE_PASSWORD){
                        order.set("selluser_game_pwd", selluserGamePwd);
                    }
                    if(!SmartDb.update("order", "order_id", order)){
                        logger.error("订单【" + orderId + "】在求助时更新数据失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                        return false;
                    }

                    return true;
                }
            });
            if(!succ){
                errorPage("平台因为系统错误没有记录到您上传的求助结果，您可以选择‘同意撤单’结束订单。");
                return;
            }

            //发送求助信息到玩家
            String content = "";
            if(helpType == Order.HELP_TYPE_PASSWORD || helpType == Order.HELP_TYPE_ACCOUNT_FROZEN){
            	content = "原密码：" + originalPassword + "；号主回复内容：" + selluserGamePwd;
            }
            if(helpType == Order.HELP_TYPE_AUTHCODE){
            	content = "验证码：" + selluserGamePwd;
            }
            if(StringUtils.isNotBlank(content)){
            	msgService.sendMsg(orderId, content, Order.HELP_MESSAGE_SENDER_SELLUSER, Order.HELP_MESSAGE_SENDER_BUYUSER);

	            //发送求助反馈信息到号主
            	content = "已成功将您的更新信息通知玩家。\n为了提高订单成功率，建议您在未来5分钟继续关注玩家是否有继续求助。";
            	msgService.sendMsg(orderId, content, Order.HELP_MESSAGE_SENDER_SYSTEM, Order.HELP_MESSAGE_SENDER_SELLUSER);
            }
            
            //发送通知消息
            NotifyService.instance.sendHelpFinishMessageToBuyuser(orderId);

            setAttr("type", "selluser");
            setAttr("msg", "您已成功协助玩家处理了订单账号问题");
            redirect("contact_window?order_id="+orderId);
        }finally{
            locker.unlock();
        }
    }

    /**
     * 同意撤单<br>
     *     1. 撤单逻辑<br>
     *     2. 归还号主信誉分
     *     3. 订单必须设置为不允许发起仲裁
     */
    public void cancel(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请登录后再进行操作。");
            return;
        }

        final String orderId = getPara("order_id");
        if(StringUtils.isBlank(orderId)){
            errorPage("没有订单号");
            return;
        }

        //与求助超时定时任务进行同步
        DistLocker locker = new DistLocker("order-help-" + orderId);
        try{
            locker.lock();

            //干正事
            final Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
            if(order == null){
                errorPage("不存在的订单");
                return;
            }

            //若订单当前是已取消的，要给予改密提醒
            if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
                errorPage("您的订单已经取消交易。若是玩家提前取消订单，请您尽快修改账号密码以保护您的账号财产。");
                return;
            }
            //其他状态，反正不是出租中，就简单提示就好了
            if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
                errorPage("当前订单不是‘出租中’状态，无法撤销订单。");
                return;
            }

            //确保订单是这个人的
            if(uid.intValue() != order.getInt("selluser_uid").intValue()){
                errorPage("您只能对您租出的订单取消交易");
                return;
            }

            //一些有用的数据
            int orderPayAmount = order.getInt("order_pay_amount");
            String productName = order.getStr("product_name");
            int selluserUid = order.getInt("selluser_uid");
            int buyuserUid = order.getInt("buyuser_uid");

            //取消订单，号主同意撤单的当然是直接退款啦，当然就是免责撤单啦
            String cancelReason = "号主无法解决订单问题，同意撤单。";
            OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
            cancelInfo.setBuyuserArbitrate(Order.BUYUSER_NO_ARBITRATE);
            cancelInfo.setCancelReason(cancelReason);
            cancelInfo.setCancelReasonEx("");
            cancelInfo.setDeductSelluserGuarantee(false);
            cancelInfo.setDelayRefund(false);
            cancelInfo.setFreeCancel(true);
            cancelInfo.setProductOffsale(true);
            cancelInfo.setProductOffsaleReason(cancelReason);
            JSONObject result = new OrderCancelService(false).cancel(orderId, cancelInfo);
            if(result == null || result.getInt("code") != 0){
                logger.error("卖家同意撤单失败了，orderId=>" + orderId + "原因：" + (result == null ? "null" : result.getString("msg")));
                errorPage("您的撤单因发生了一些系统错误导致失败了，请您稍后再试。");
                return;
            }

            //微信通知玩家
            NotifyService.instance.sendHelpFailMessageToBuyuser(orderId);

            //再修改订单状态，设置为“号主同意撤单”，这样则可以不再支持“仲裁”
            order.keep("order_id");
            order.set("order_help", Order.ORDER_HELP_FINISH);
            order.set("modify_time", Common.now());
            order.set("is_selluser_arbitrate", Order.SELLUSER_CONFIRM_CANCEL); //标记为同意撤单
            if(!SmartDb.update("order", "order_id", order)){
                logger.error("订单【" + orderId + "】设置为‘同意撤单’失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                errorPage("您撤单时系统在更新订单数据时发生了一些错误。");
                return;
            }

            setAttr("msg", "您成功撤销了这笔订单交易并下架了商品，请更新好商品数据后再重新上架。");
            setAttr("type", "selluser");
            render("succ.html");

        }finally{
            locker.unlock();
        }

    }
    
    /**
     * 求助号主窗口
     */
    public void contact_window(){
    	final Integer uid = getSessionAttr("uid");
    	if(uid == null){
    		errorPage("请先登录");
    		return;
    	}
    	
        String orderId = getPara("order_id", "");
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=? ", orderId);
        if(order == null){
            errorPage("不存在的订单");
            return;
        }

        //校验用户是否为订单关联方
        if(order.getInt("buyuser_uid") != uid.intValue() && order.getInt("selluser_uid") != uid.intValue()){
            errorPage("您不是该订单买卖双方中的一方，无法查看求助内容。");
            return;
        }
        
        //订单
        setAttr("order", order2map(order));

        //是否为买家
        if(order.getInt("buyuser_uid") == uid.intValue()){
            setAttr("is_buyuser", true);
        }
        
        setOrderHelpAttr(order, order.getInt("buyuser_uid") == uid.intValue());
        
  		//获取当前消息列表
        StringBuilder messageKey = new StringBuilder().append(orderId).append("-").append(uid);
        Cache cache = Redis.use("rent_redis");
        List<String> messageList = cache.lrange(messageKey.toString(), 0, -1);
        setAttr("messages", json2map(messageList));
        
        render("index.html");
    }

    /**返回号主求助窗口内容**/
    public void getHelpMessages(){
        String orderId = getPara("order_id", "");
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=? ", orderId);
        if(order == null){
            errorPage("不存在的订单");
            return;
        }

        //校验用户是否为订单关联方
        final Integer uid = getSessionAttr("uid");
        if(!(order.getInt("buyuser_uid") == uid.intValue() || order.getInt("selluser_uid") == uid.intValue())){
            logger.info("用户id:"+uid.intValue()+"-"+order.getInt("buyuser_uid")+"-"+ (order.getInt("buyuser_uid") == uid.intValue()));
            errorPage("非法的求助请求");
            return;
        }

        if(order.getInt("buyuser_uid") == uid.intValue()){
            setAttr("is_buyuser",true);
        }
        StringBuilder messageKey = new StringBuilder().append(orderId).append("-").append(uid);

        Cache cache = Redis.use("rent_redis");
        List messageList = cache.lrange(messageKey.toString(),0,-1);
        JSONObject messageInfo = new JSONObject();
        messageInfo.put("data", JSONArray.fromObject(messageList));
        Record helpTime = SmartDb.findFirst("select c_time  from `order_help` where `order_id`=? ORDER BY h_time DESC LIMIT 1 ", orderId);
        if(helpTime != null && helpTime.getDate("c_time") != null){
            Date now = new Date();
            long helpTimebetween =300 - (now.getTime() - helpTime.getDate("c_time").getTime())/1000;
            messageInfo.put("help_time",helpTimebetween);
        }else{
            messageInfo.put("help_time",-1);
        }
        renderText(messageInfo.toString());
    }
    
}
