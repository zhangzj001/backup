package cn.jugame.rent.page;

import cn.j8.json.Json;
import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.rent.api.utils.ResponseDataFormatUtil;
import cn.jugame.rent.bean.GameConf;
import cn.jugame.rent.bean.HotSetting;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.data.IndexData;
import cn.jugame.rent.data.IndexParam;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.PCForwardInterceptor;
import cn.jugame.rent.interceptor.VisitLogInterceptor;
import cn.jugame.rent.page.service.Platforms;
import cn.jugame.rent.utils.*;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.*;

public class IndexController extends BaseController {

    private Logger logger = Loggers.rentLog();

    private Logger event = Loggers.eventLog();

    /**
     * 获取配置
     */
    public void config(){
        String ver = getPara("ver");

        String domainConf = HotSetting.get("DOMAIN_CONFIG", null);
        String domain = "z.8868.cn";
        if(StringUtils.isNotBlank(ver) && StringUtils.isNotBlank(domainConf)){
            Json json = Json.parse(domainConf);
            String _d = json.asObj().strVal(ver);
            if(StringUtils.isNotBlank(_d))
                domain = _d;
        }

        Json conf = Json.object("domain", domain, "date", Common.now());
        renderJson(conf.toString());
    }

    public void test(){
        String payId = "RELET-190924-114308320-51551C";
        Record row = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);
        String rent_end_time = Common.show_time(row.getDate("rent_end_time"));

        Json result = Json.object("rent_end_time", rent_end_time);
        renderJson(result.toString());
    }


    /**
     * Wap版首页
     */
    @Before(PCForwardInterceptor.class)
    public void index() {
        //如果有登录就带上uid
        Integer uid = getSessionAttr("uid");
        //XXX vivo应用市场不允许外链下载登号器
        String jugameFr = getCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME, "");

        IndexParam param = new IndexParam();
        param.setClientFrom(jugameFr);
        if (uid != null && uid > 0) {
            param.setUid(uid);
        }
        Map<String, Object> indexDto = IndexData.getInstance().get(param);

        //新人礼包
        List<Record> newcomerGift = (List<Record>) (indexDto.get("newcomerGift"));
        setAttr("main_boards", ResponseDataFormatUtil.getHomeBoards((List<Record>) (indexDto.get("mainBoards"))));
        setAttr("vip_boards", ResponseDataFormatUtil.getHomeBoards((List<Record>) (indexDto.get("vipBoards"))));
        setAttr("games", toMap((List<Record>) (indexDto.get("hotGames"))));
        setAttr("vips", toMap((List<Record>) (indexDto.get("hotVips"))));
        setAttr("pc_games", toMap((List<Record>) (indexDto.get("hotPcGames"))));

        setAttr("game_products", product2map((List<Record>) (indexDto.get("gameProducts"))));
        setAttr("vip_products", product2map((List<Record>) (indexDto.get("vipProducts"))));
        setAttr("announs", ResponseDataFormatUtil.getHomeAnnouncements((List<Record>) (indexDto.get("announcements"))));
        List<Record> actvityAnnouncements = (List<Record>) (indexDto.get("actvityAnnouncements"));
        if (actvityAnnouncements != null && actvityAnnouncements.size() > 0) {
            setAttr("actvityAnnouncements", ResponseDataFormatUtil.getHomeAnnouncements(actvityAnnouncements));
        } else {
            setAttr("news", ResponseDataFormatUtil.getHomeRecentSuccessOrderNews((List<Record>) (indexDto.get("recentOrder"))));
        }
        if (uid == null) {
            uid = 0;
        } else {
            //通过查询cookies解决跨域登录导致的点击领取新人礼包后的跳转问题
            hasGetNewcomerGift(uid);
        }
        setAttr("uid", uid);
        //获取用户有多少未使用的优惠券
        List<Record> userCoupons = indexDto.get("userCoupons") != null ? (List<Record>) (indexDto.get("userCoupons")) : null;
        setAttr("userCoupons", userCoupons != null ? userCoupons.size() : 0);
		/*//获取未提醒用户的优惠券
		List<Record> userNotifyCoupons =indexDto.get("userNotifyCoupons") != null ?(List<Record>)(indexDto.get("userNotifyCoupons")) :null;
		setAttr("userNewCoupons",userNotifyCoupons != null && userNotifyCoupons.size()>0);*/
        //是否为新用户（未下单用户，用户未登录默认为新用户）
        boolean isNewcomerGiftUser = uid == 0 || User.isNewcomerGiftUser(uid);
        setAttr("is_newcomer", isNewcomerGiftUser && newcomerGift != null && newcomerGift.size() > 0);
        setAttr("newcomer_gift", giftList2Map(newcomerGift));
        //获取首页模块信息
        setAttr("activities", toMap((List<Record>) (indexDto.get("activities"))));
        //新人礼包入口是否开启
        setAttr("newcomer_gift_valid", (isNewcomerGiftUser && newcomerGift != null && newcomerGift.size() > 0) || User.isNewcomerReceiveGiftUser(uid) /*|| (uid != 0 && User.hadNewcomerGift(uid) && User.hadNewcomerGiftLeft(uid))*/);
        setAttr("is_receive_newcomer", User.isNewcomerReceiveGiftUser(uid));
        //是否第一次打开页面
        String isFirstOpenRent = getCookie("first_open_rent");
        boolean isNewcomer = uid == 0 || User.isNewcomer(uid);
        if (StringUtils.isBlank(isFirstOpenRent) && isNewcomer) {
            setAttr("is_first_open_rent", true);
            setCookie("first_open_rent", "rent", 10 * 365 * 24 * 60 * 60);
        }


        render("index.html");
    }


    @Before(PCForwardInterceptor.class)
    public void allGames() {
        String letter = getPara("letter", "");
        int type = getParaToInt("type", GameConf.TYPE_GAME);
        setAttr("type", type);
        setAttr("letter", letter);

        List<Object> games = new ArrayList<>();
        List<Record> rows = null;
        //如果没有指明什么首字母的游戏，则默认加载热门游戏
        //只加载出有商品的游戏
        if (StringUtils.isBlank(letter)) {
            rows = SmartDb.find("select * from `game_conf` where `status`=? and `is_hot`=? and `type`=? and `product_count`>0 order by `weight` desc", GameConf.STATUS_ENABLE, GameConf.TAG_HOT, type);
        } else {
            rows = SmartDb.find("select * from `game_conf` where `status`=? and `game_initial`=? and `type`=? and `product_count`>0 order by `weight` desc", GameConf.STATUS_ENABLE, letter, type);
        }
        if (rows == null) rows = new ArrayList<>();

        for (Record row : rows) {
            Map<String, Object> obj = new HashMap<>();
            obj.put("game_id", row.getStr("game_id"));
            obj.put("game_name", row.getStr("game_name"));
            obj.put("icon", row.getStr("icon_url"));
            obj.put("game_short_name", row.getStr("game_short_name"));
            games.add(obj);
        }
        setAttr("games", games);

        List<Object> gameLetters = new ArrayList<>();
        List<Record> gameInitials = SmartDb.find("select distinct `game_initial` from `game_conf` where `status`=? and `type`=? and `product_count`>0 order by `game_initial`", GameConf.STATUS_ENABLE, type);
        for (Record r : gameInitials) {
            Map<String, Object> map = new TreeMap<>();
            map.put("letter", r.getStr("game_initial"));
            gameLetters.add(map);
        }
        setAttr("game_letters", gameLetters);

        render("all_games.html");
    }

    public void announcement() {
        int id = getParaToInt("id", 0);
        Record row = SmartDb.findFirst("select * from `announcement` where `id`=?", id);
        if (row == null) {
            errorPage("不存在的公告");
            return;
        }

        //记录用户点开公告页的情况
        event.info("type=announcement`id=" + id);

        setAttr("content", row.getStr("content"));
        render("announ.html");
    }

    /**
     * 专门用于302跳转的接口
     */
    @Before(LoginInterceptor.class)
    public void redirect() {
        String url = getPara("url");
        if (StringUtils.isBlank(url)) {
            errorPage("这里什么也没有，空荡荡的...");
            return;
        }
        try {
            getResponse().sendRedirect(url);
            renderNull();
        } catch (Exception e) {
            logger.error("redirect error", e);
            errorPage("好像有只鸟飞过去了...");
        }
    }


    public void faq() {
        String type = getPara("type", "buyuser");

        List<String> pics = new ArrayList<>();
        for (int i = 1; i <= 8; ++i) {
            pics.add("/icons/" + i + ".jpg");
        }
        setAttr("pics", pics);

        setAttr("type", type);
        setAttr("title", "buyuser".equalsIgnoreCase(type) ? "玩家攻略" : "号主攻略");
        render("faq.html");
    }

    /**
     * 心游推荐
     */
    public void recommendation() {
        List<Record> list = SmartDb.find("select * from `game_recommendation` where `status`=1 order by c_time");

        setAttr("games", toMap(list));
        render("recommendation.html");
    }

    /**
     * 心游推荐的游戏下载
     */
    public void gameDownload() {
        int id = getParaToInt("id", 0);
        if (id <= 0) {
            errorPage("请选择需要下载的游戏。");
            return;
        }

        Record row = SmartDb.findFirst("select * from `game_recommendation` where `status`=1 and `id`=?", id);
        if (row == null) {
            errorPage("当前游戏不在心游推荐。");
            return;
        }

        event.info("type=gameDownload`id=" + id + "`game_name=" + row.getStr("game_name"));

        try {
            getResponse().sendRedirect(row.getStr("download_url"));
            renderNull();
        } catch (Exception e) {
            logger.error("gameDownload error", e);
            errorPage("好像有只鸟飞过去了...");
        }
    }

    /**
     * 获取列表
     */
    public void pcgames() {
        redirect("/games?type=" + GameConf.TYPE_PC_GAME);
    }

    /**
     * 获取频道列表
     */
    public void games() {
        int type = getParaToInt("type", Product.PRODUCT_TYPE_GAME);
        setAttr("type", type);

        //如果是游戏账号，则获取热门游戏列表，其余种类获取全部
        List<Record> rows = null;
        if (type == GameConf.TYPE_GAME || type == GameConf.TYPE_PC_GAME) {
            rows = SmartDb.find("select * from `game_conf` where `type`=? and `status`=? and `is_hot`=? order by weight desc", type, GameConf.STATUS_ENABLE, GameConf.TAG_HOT);
        } else {
            rows = SmartDb.find("select * from `game_conf` where `type`=? and `status`=? order by weight desc", type, GameConf.STATUS_ENABLE);
        }

        setAttr("games", toMap(rows));

        render("games.html");
    }

    public void discover() {
        //FIXME 这里获取对应的数据
        String sql = "SELECT * FROM app_activities WHERE `status`=1 AND `tag`=? AND `start_time`<NOW() AND `end_time`>NOW() ORDER BY weight ASC";
        List<Record> rows = SmartDb.get("app_recharge_base", false).find(sql, "rent_wap_discover");
        setAttr("activity_list", toMap(rows));
        List<cn.jugame.service.gameproduct.bean.Product> product_list = Platforms.singleton.getPlatformHotProduct(8);
        setAttr("product_list", product_list);
        render("discover.html");

    }

    /**
     * 新手指引
     **/
    public void newcommerGuide() {
        render("guide/newcommer_guide.html");
    }

    /***
     * 玩家指引
     */
    public void buyerGuide() {
        render("guide/buyer_guide.html");
    }

    /***
     * 号主指引
     */
    public void sellerGuide() {
        render("guide/seller_guide.html");
    }

    /**
     * 常见问题指引
     */
    public void commonProblemGuide() {
        render("guide/common_problem_guide.html");
    }

    public void recommendedProducts() {
        int type = getParaToInt("productType", Product.PRODUCT_TYPE_PCGAME);
        int pageSize = getParaToInt("pageSize", 4);
        List<Record> products = Platforms.singleton.getRecommendedProducts(pageSize, type);
        renderJson("products", product2map(products));
    }

    /***
     * 跳转omr
     */
    @Before(LoginInterceptor.class)
    public void redirectOmr() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请先登录");
            return;
        }
        String chn = PropKit.get("omr_chn");
        String appKey = PropKit.get("omr_app_key");
        String imei = getPara("imei");
        long time = System.currentTimeMillis();
        String sign = null;
        String ormUrl = PropKit.get("omr_url");
        if (StringUtils.isNotBlank(imei)) {
            sign = Common.md5(chn + imei + uid + time + appKey);
        } else {
            sign = Common.md5(chn + uid + time + appKey);
        }
        ormUrl += "?code=" + uid + "&dev=" + imei + "&time=" + time + "&chn=" + chn + "&sign=" + sign;
        redirect(ormUrl);
    }

    /***
     * omr调用接口，用来获取用户信息
     */
    public void getUserInfo() {
        int code = getParaToInt("code", 0);
        if (code == 0) {
            renderJson(buildResp(200, "参数code为空"));
            return;
        }
        String sign = getPara("sign");
        if (StringUtils.isBlank(sign)) {
            renderJson(buildResp(200, "参数sign签名信息为空"));
            return;
        }
        String time = getPara("time");
        if (StringUtils.isBlank(time)) {
            renderJson(buildResp(200, "参数签名时间为空"));
            return;
        }
        String chn = PropKit.get("omr_chn");
        String appKey = PropKit.get("omr_app_key");
        String verifySign = Common.md5(chn + code + time + appKey);
        if (!verifySign.equals(sign)) {
            renderJson(buildResp(401, "签名不正确"));
            return;
        }
        Record row = SmartDb.findFirst("select *  from `member` where uid = ? limit 1", code);
        if (row == null) {
            renderJson(buildResp(501, "code无效"));
            return;
        }
        // 获取用户头像和昵称
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
            bean = accountCenterService.findMemberByUid(code);
        } catch (Exception e) {
            logger.error("error", e);
        }
        String headimg = "";
        if (bean != null && bean.getData() != null) {
            Member member = (Member) bean.getData();
            headimg = member.getHeadimgurl();
        }
        if (StringUtils.isEmpty(headimg)) {
            headimg = PropKit.get("promote.headimg.default");
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("uid", code);
        jsonObject.put("uname", UsernameUtil.getUserName(bean, code));
        jsonObject.put("uhead", headimg);
        renderJson(buildResp(500, "成功返回数据", new KeyValue<>("data", jsonObject.toString())));
        return;
    }
}
