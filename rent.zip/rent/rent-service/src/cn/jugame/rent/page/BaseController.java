package cn.jugame.rent.page;

import cn.jugame.rent.bean.*;
import cn.jugame.rent.utils.*;
import cn.jugame.service.common.util.bean.DataBean;
import cn.jugame.service.common.util.idbuilder.IDBuilder;
import cn.jugame.service.gameproduct.api.IGameService;
import cn.jugame.service.gameproduct.bean.Channel;
import cn.jugame.service.gameproduct.bean.GameProductType;
import cn.jugame.service.gameproduct.constant.ProductTypeGroupConstant;
import com.jfinal.core.Controller;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.*;

public class BaseController extends Controller{
	private static Logger logger = Loggers.rentLog();
	
	private IGameService gameService = ServiceFactory.get(IGameService.class);

    protected byte[] getPostData(){
		int max = getRequest().getContentLength();
		if(max > 8*1024*1024){
			throw new RuntimeException("请求参数体超过了8M");
		}
		
		//非post请求content-length可能为0
		if(max <= 0)
			return new byte[0];
		
		byte[] bytes = new byte[max];
		try{
			int n = Common.readStream(getRequest().getInputStream(), bytes);
			if(n > 0)
				return bytes;
			return new byte[0];
		}catch(Exception e){
			logger.error("request error", e);
			return new byte[0];
		}
    }
    
	protected JSONObject buildResp(int code, String msg, KeyValue... params){
		return Common.buildResp(code, msg, params);
	}
	
	protected JSONObject toJson(Record row){
		JSONObject json = new JSONObject();
		String[] cols = row.getColumnNames();
		for(String col : cols){
			Object val = row.get(col);
			if(val instanceof Date){
				json.put(col, Common.show_time((Date)val));
			}else{
				json.put(col, val);
			}
		}
		return json;
	}
	
	protected JSONArray toJson(List<Record> rows){
		JSONArray arr = new JSONArray();
		for(Record row : rows){
			arr.add(toJson(row));
		}
		return arr;
	}
	
	protected JSONObject parseJson(String content){
		try{
			return JSONObject.fromObject(content);
		}catch(JSONException e){
			logger.error("error", e);
			return null;
		}
	}
	
	protected List<Map<String, Object>> json2map(List<String> jsonStrs){
		List<Map<String, Object>> list = new ArrayList<>();
		for(String json : jsonStrs){
			list.add(json2map(json));
		}
		return list;
	}

	protected Map<String,Object> json2map(String jsonStr){
		Map<String, Object> map = new HashMap<>();
		try{
			JSONObject infos = parseJson(jsonStr);
			if(infos != null) {
				Iterable keys = infos.keySet();
				for (Object key : keys) {
					Object val = infos.get(key);
					map.put(key.toString(), val);
				}
			}
		}catch(Exception e){
			return null;
		}
		return map;
	}

	
	protected Map<String, Object> toMap(Record row, Map<String, String> dateFormat){
		Map<String, Object> map = new HashMap<>();
		String[] cols = row.getColumnNames();
		for(String col : cols){
			Object val = row.get(col);
			if(val instanceof Date){
				//如果有指定日期格式，就套用指定的格式
				String format = "yyyy-MM-dd HH:mm:ss";
				if(dateFormat != null && dateFormat.containsKey(col)){
					format = dateFormat.get(col);
				}
				
				map.put(col, Common.show_time((Date)val, format));
			}else{
				map.put(col, val);
			}
		}
		return map;
	}
	
	protected Map<String, Object> toMap(Record row){
		return toMap(row, null);
	}
	
	protected List<Map<String, Object>> toMap(List<Record> rows, Map<String, String> dateFormat){
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record row : rows){
			list.add(toMap(row, dateFormat));
		}
		return list;
	}
	
	protected List<Map<String, Object>> toMap(List<Record> rows){
		return toMap(rows, null);
	}

	protected  List<Map<String,Object>> blackList2Map(List<Record> infos){
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record entity : infos){
			list.add(blackList2map(entity));
		}
		return list;
	}

	/**
	 * 将黑名单数据数据转成适配view层的map
	 * @param blackItem
	 * @return
	 */
	protected Map<String, Object> blackList2map(Record blackItem){
		Map<String, Object> data = toMap(blackItem, null);
		data.put("c_time",Common.show_time(blackItem.getDate("c_time")) );
		return data;
	}
	/**
	 * 将新人礼包转成适配view层的map
	 * @param useCoupon
	 * @return
	 */
	protected Map<String, Object> gift2map(Record useCoupon){
		Map<String, Object> data = toMap(useCoupon, null);
		data.put("coupon_id",useCoupon.getStr("coupon_id") );
		data.put("name",useCoupon.getStr("name") );
		data.put("pic",useCoupon.getStr("pic") );
		return data;
	}
	protected  List<Map<String,Object>> giftList2Map(List<Record> useCoupons){
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record entity : useCoupons){
			list.add(gift2map(entity));
		}
		return list;
	}
	/**
	 * 将product数据转成适配view层的map
	 * @param product
	 * @return
	 */
	protected Map<String, Object> product2map(Record product) {
		Map<String, Object> data = toMap(product, null);
		// 将金额字段转成元
		data.put("price_hour", Common.round(product.getInt("price_hour") / 100.0, 2));
		data.put("price_day", Common.round(product.getInt("price_day") / 100.0, 2));
		data.put("price_night", Common.round(product.getInt("price_night") / 100.0, 2));
		data.put("guarantee_deposit", Common.round(product.getInt("guarantee_deposit") / 100.0, 2));
		data.put("longterm_first_price", Common.round(product.getInt("longterm_first_price") / 100.0, 2));
		data.put("longterm_relet_price", Common.round(product.getInt("longterm_relet_price") / 100.0, 2));
			
		//VIP视频登录方式转换成中文
		if(product.getInt("vip_login_type")==Product.VIP_LOGIN_TYPE_QQ)
			data.put("vip_login_type", Product.VIP_LOGIN_TYPE_QQ_CN);
		else if(product.getInt("vip_login_type")==Product.VIP_LOGIN_TYPE_WECHAT)
			data.put("vip_login_type", Product.VIP_LOGIN_TYPE_WEBCHAT_CN);
		else if(product.getInt("vip_login_type")==Product.VIP_LOGIN_TYPE_MOBILE)
			data.put("vip_login_type", Product.VIP_LOGIN_TYPE_MOBILE_CN);
		else if(product.getInt("vip_login_type")==Product.VIP_LOGIN_TYPE_BLOG)
			data.put("vip_login_type", Product.VIP_LOGIN_TYPE_BLOG_CN);
		else
			data.put("vip_login_type", "");

		// 扩展属性字段
		try {
			if (StringUtils.isNotBlank(product.getStr("extern_properties"))) {
				JSONArray json = JSONArray.fromObject(product.getStr("extern_properties"));
				List<Map<String, Object>> props = new ArrayList<>();
				for (int i = 0; i < json.size(); ++i) {
					JSONObject p = json.getJSONObject(i);
					Map<String, Object> obj = new HashMap<>();
					obj.put("prop_key", p.getString("prop_key"));
					obj.put("prop_name", p.getString("prop_name"));
					String propValues = "";
					if (!p.has("prop_type") || "0".equals(p.getString("prop_type"))) {
						propValues = p.getString("prop_value");
					} else {
						JSONArray textArray = JSONArray.fromObject(p.getString("prop_value"));
						if (textArray != null && textArray.size() > 0) {
							for (int k = 0; k < textArray.size(); k++) {
								propValues += (textArray.getString(k) + " ");
							}
						}
					}
					obj.put("prop_value", propValues);
					props.add(obj);
				}
				data.put("extern_properties", props);
			}
			if (product.get("promotion_properties") != null) {
				JSONObject promotionProperties = JSONObject.fromObject(product.get("promotion_properties"));
				JSONArray promotionDayProperties = promotionProperties.optJSONArray("promotion_day_title");
				JSONArray promotionHourProperties = promotionProperties.optJSONArray("promotion_hour_title");
				if (promotionDayProperties != null && promotionDayProperties.size() > 0) {
					String promotionDayPropertiesInfo = "";
					for (Object content : promotionDayProperties) {
						promotionDayPropertiesInfo += content.toString() + "，";

					}
					data.put("promotion_day_properties",
							promotionDayPropertiesInfo.substring(0, promotionDayPropertiesInfo.length() - 1));
				} else {
					data.put("promotion_day_properties", promotionDayProperties);
				}
				if (promotionHourProperties != null && promotionHourProperties.size() > 0) {
					String promotionHourPropertiesInfo = "";
					for (Object content : promotionHourProperties) {
						promotionHourPropertiesInfo += content.toString() + "，";
					}
					data.put("promotion_hour_properties",
							promotionHourPropertiesInfo.substring(0, promotionHourPropertiesInfo.length() - 1));
				} else {
					data.put("promotion_hour_properties", promotionHourProperties);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("解析商品的扩展属性失败了:" + product.getStr("product_id") + ", extern_properties=>"
					+ product.getStr("extern_properties"));
		}

		return data;
	}
	
	/**
	 * 将product数组转成适配view层的list
	 * @param rows
	 * @return
	 */
	protected List<Map<String, Object>> product2map(List<Record> rows){
		List<Map<String, Object>> list = new ArrayList<>();
		if(rows == null || rows.size() == 0){
			return list;
		}
		for(Record row : rows){
			list.add(product2map(row));
		}
		return list;
	}
	
	/**
	 * 将order数据转成适配view层的map
	 * @param order
	 * @return
	 */
	protected Map<String, Object> order2map(Record order){
		Map<String, Object> data = toMap(order, null);
		
		//对金额数据转成元
		data.put("order_amount", Common.round(order.getInt("order_amount")/100.0, 2));
		data.put("order_pay_amount", Common.round(order.getInt("order_pay_amount")/100.0, 2));
		data.put("order_guarantee_deposit", Common.round(order.getInt("order_guarantee_deposit")/100.0, 2));
		data.put("product_price", Common.round(order.getInt("product_price")/100.0, 2));
		data.put("amount_off", Common.round(order.getInt("amount_off")/100.0, 2));
		data.put("refund_buyuser_amount", Common.round(order.getInt("refund_buyuser_amount")/100.0, 2));
		data.put("refund_selluser_amount", Common.round(order.getInt("refund_selluser_amount")/100.0, 2));
		data.put("order_origin_price", Common.round(order.getInt("order_origin_price")/100.0, 2));
		
		return data;
	}
	
	/**
	 * 将order数组转成适配view层的list
	 * @param rows
	 * @return
	 */
	protected List<Map<String, Object>> order2map(List<Record> rows){
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record row : rows){
			list.add(order2map(row));
		}
		return list;
	}

	/**
	 * 将orderRelet数据转成适配view层的map
	 * @param orderRelet
	 * @return
	 */
	protected Map<String, Object> relets2map(Record orderRelet){
		Map<String, Object> data = toMap(orderRelet, null);

		//对金额数据转成元
		data.put("order_pay_amount", Common.round(orderRelet.getInt("order_pay_amount")/100.0, 2));
		if(orderRelet.get("promote_gift_money") != null && orderRelet.getInt("promote_gift_money")>0) {
			data.put("promote_gift_money", Common.round(orderRelet.getInt("promote_gift_money") / 100.0, 2));
		}else{
			data.put("promote_gift_money", 0);
		}
		if(orderRelet.get("amount_off") != null && orderRelet.getInt("amount_off")>0) {
			data.put("amount_off", Common.round(orderRelet.getInt("amount_off") / 100.0, 2));
		}else{
			data.put("amount_off", 0);
		}
		if(orderRelet.get("order_origin_price") != null && orderRelet.getInt("order_origin_price")>0) {
			data.put("order_origin_price", Common.round(orderRelet.getInt("order_origin_price") / 100.0, 2));
		}else{
			data.put("order_origin_price", 0);
		}
		return data;

	}

	/**
	 * 将orderRelet数组转成适配view层的list
	 * @param rows
	 * @return
	 */
	protected List<Map<String, Object>> relets2map(List<Record> rows) {
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record row : rows){
			list.add(relets2map(row));
		}
		return list;

	}




	/**
	 * 将coupons数据转成适配view层的map
	 * @param rows
	 * @return
	 */
	protected List<Map<String, Object>> coupons2map(List<Record> rows,Map<String, String> dateFormat){
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record row : rows){
			list.add(coupon2Map(row,dateFormat));
		}
		return list;
	}

	/**
	 * 将coupons数据转成适配view层的map
	 * @param coupon
	 * @return
	 */
	protected Map<String, Object> coupon2Map(Record coupon,Map<String, String> dateFormat){
		Map<String, Object> data = toMap(coupon, dateFormat);
		StringBuilder validTypeContent= new StringBuilder();
		JSONArray validProductType = null;
		try{
			validProductType = JSONArray.fromObject(coupon.get("valid_product_type"));
		}catch(Exception e){
			validProductType = new JSONArray();
		}
		if(validProductType.size() == 0 ){
			validTypeContent.append("通用,");
		}else {
			for (Object type : validProductType) {
				if(! (type instanceof Integer)){
					continue;
				}
				if (Product.PRODUCT_TYPE_GAME == (int) (type)) {
					validTypeContent.append("手游类,");
				} else if (Product.PRODUCT_TYPE_VIP == (int) (type)) {
					validTypeContent.append("影视VIP,");
				} else if (Product.PRODUCT_TYPE_PCGAME == (int) (type)) {
					validTypeContent.append("端游类,");
				} else if (Product.PRODUCT_TYPE_CDK == (int) (type)) {
					validTypeContent.append("CDK,");
				}
			}


		}
		data.put("product_type_filter",validTypeContent.substring(0,validTypeContent.length() > 0 ? validTypeContent.length()-1:validTypeContent.length()));
		data.put("is_available", Common.compareStringDate(data.get("beg_date").toString(), Common.now("yyyy-MM-dd"))? 1 : 0);
		return data;

	}




	protected void errorPage(String err){
		logger.info("请求页面发生了错误：" + err);
		
		setAttr("error", err);
		
//		String clientType = getAttr("client_type");
//		if("pc".equalsIgnoreCase(clientType)){
//			render("/pcview/error.html");
//		}else{
			render("/view/error.html");
//		}
	}
	
	protected String htmlEncode(String str){
		if(str == null)
			return null;
		str = str.replaceAll("<", "&lt;");
		str = str.replaceAll(">", "&gt;");

		//替换掉一些utf8的四字节内容！
		str = str.replaceAll("[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]", "");

		return str;
	}

	
	/** 手续费类型：普通 */
	public static final int FEE_TYPE_NORMAL = 0;
	
	/** 手续费类型：号主自推广 */
	public static final int FEE_TYPE_PROMOTE = 1;
	
	/** 手续费类型：扶持商品 */
	public static final int FEE_TYPE_SUPPORT = 3;
	
	protected double getOrderFee(int uid, String productId){
		return getOrderFee(null, uid, productId, FEE_TYPE_NORMAL);
	}
	
	/**
	 * 获取订单手续费
	 * @param gameId  游戏id
	 * @param uid     号主用户id
	 * @param productId 商品id
	 * @param feeType 手续费类型，见BaseController.FEE_TYPE_* 常量
	 * @return 手续费
	 */
	protected double getOrderFee(String gameId, int uid, String productId, int feeType){
		double feeRateDiscount = 1;
		double feeRate = 0;

		if(feeType == FEE_TYPE_SUPPORT) {
			feeRate  = Common.round(Double.parseDouble(PropKit.get("support_default_rate")),2);
			return feeRate;
		}
		
		Record member = User.getMember(uid);

		//获取商品的手续费折扣
		Record product = Product.getProduct(productId);
		if(PropKit.getBoolean("fee_rate_discount_valid") && product != null && product.getDouble("fee_rate_discount") > 0){
			feeRateDiscount = product.getDouble("fee_rate_discount");
		}
		
		//如果针对个人有配置手续费，就直接用这个
		if(member.getBigDecimal("fee_rate").doubleValue() >= 0){
			feeRate = Common.round(member.getBigDecimal("fee_rate").doubleValue() * feeRateDiscount,2);
			return feeRate;
		}
		
		//如果游戏有单独配置费率则使用游戏配置的费率，若无则使用默认费率
		if(StringUtils.isNotBlank(gameId)){
			Record conf = SmartDb.findFirst("select * from game_conf where game_id=?", gameId);
			if(conf != null){
				double fee = (feeType==FEE_TYPE_PROMOTE) ? conf.getBigDecimal("promote_fee_rate").doubleValue():conf.getBigDecimal("fee_rate").doubleValue();
				if(fee >= 0) {
					feeRate = Common.round(fee * feeRateDiscount,2);
					return feeRate;
				}
			}
		}
		
		//没配置，则使用默认的手续费率
		String defaultFee = PropKit.get("order.fee_rate");
		if(StringUtils.isBlank(defaultFee)){
			feeRate = Common.round(0.15d * feeRateDiscount,2);
			return feeRate;
		}else{
			feeRate = Common.round(Double.parseDouble(defaultFee) * feeRateDiscount,2);
		}
		return feeRate;
	}
	
	/** 将字符串金额（单位元）转成整型分 */
	protected int toFen(String money){
		if(StringUtils.isBlank(money))
			return 0;
		try{
			double yuan = Double.parseDouble(money);
			return (int)(yuan * 100);
		}catch(Exception e){
			return 0;
		}
	}

	protected String generateSellPid(){
		return IDBuilder.productIdBuilder("SELL-PID");
	}

	//通过查询cookies解决跨域登录导致的点击领取新人礼包后的跳转问题
	public void hasGetNewcomerGift(Integer uid){

		String hasGetNewcomerGift = getCookie("user_get_newcomer_gift");

		String getNewcomerGiftInPara = getPara("user_get_newcomer_gift");
		logger.info("弹出领取新人礼包的标识："+hasGetNewcomerGift+"----"+getNewcomerGiftInPara);
		if((StringUtils.isNotEmpty(hasGetNewcomerGift) && "1".equals(hasGetNewcomerGift)) || (StringUtils.isNotEmpty(getNewcomerGiftInPara) && "1".equals(getNewcomerGiftInPara))){
			setCookie("user_get_newcomer_gift","0",60*10,"/coupon");
			setCookie("user_get_newcomer_gift","0",60*10,"/");
			//1.//发放优惠券
			if(!User.isNewcomerGiftUser(uid)){
				setAttr("get_newcomer_gift_success",Common.RESPONSE_FAIL);
			}else {
				DistLocker locker = new DistLocker("newcomergift_" + uid);
				boolean succ = false;
				try {
					succ = locker.lock();
					if (!succ) {
						logger.error("newcomergift_加锁失败，uid=>" + uid);
						setAttr("get_newcomer_gift_success",Common.RESPONSE_EXCEPTION);
						return;
					}
					Coupon.newComerGift(uid,0);
					setAttr("get_newcomer_gift_success",Common.RESPONSE_SUCCESS);
				} finally {
					if (succ) locker.unlock();
				}
			}
		}
	}
	
	/**
	 * 根据游戏ID获取对应的可用渠道列表
	 * @param gameId
	 * @return
	 */
	public JSONObject getChannels(String gameId){
		DataBean<List<Channel>> chBean = gameService.getChannelByGameId(gameId);
		if(chBean == null || chBean.getData() == null){
			return buildResp(1, "获取渠道列表失败");
		}
		
		//因为需要从这里获取渠道图片
		Map<String, Channel> chMap = new TreeMap<>();
		for(Channel ch : chBean.getData()){
			chMap.put(ch.getChannelId(), ch);
		}

		//使用账号相关的渠道配置
		JSONArray channels = new JSONArray();
		DataBean<List<GameProductType>> bean = gameService.getGameProductTypeListByProductType(gameId, ProductTypeGroupConstant.ACCOUNT);
		if(bean == null || bean.getData() == null){
			return buildResp(2, "获取账号类渠道列表失败了");
		}
		
		Integer uid = getSessionAttr("uid");
		List<GameProductType> gptList = bean.getData();
		String[] unsupportedChannels = PropKit.get("unsupported_channels").split(",");
		for(GameProductType gpt : gptList){
		    //昵称中包含‘租号’两个字的一定选中，否则就看看能不能发布出来
            if(StringUtils.isBlank(gpt.getNickName()) || gpt.getNickName().indexOf("租号") == -1) {
                int isPublish = gpt.getIsPublish();
                //不支持发布的渠道仅针对普通用户需要隐藏，如果是自营UID就不需要隐藏了!
                if (isPublish != 1 && !User.isSelfUid(uid)) {
                    continue;
                }
            }
			
			JSONObject obj = new JSONObject();
			Channel ch = chMap.get(gpt.getChannelId());
			if(ch == null)
				continue;
			
			//如果渠道是走账号API交易的，也过滤掉，这些类型的账号很危险！
			if(Common.in(ch.getChannelId(), unsupportedChannels))
				continue;
			
			obj.put("channel_id", ch.getChannelId());
			obj.put("channel_name", ch.getChannelName());
			obj.put("icon", ch.getChannelIconUrl());
			channels.add(obj);
		}
		
		return buildResp(0, "ok", new KeyValue<>("channels", channels));
	}
	
	/**
	 * 将propertie数据转成适配view层的map
	 * @param row
	 * @return
	 */
	protected Map<String, Object> properties2map(Record row, String propertieValues) {
		Map<String, Object> data = toMap(row, null);
		if (row.getInt("prop_type") == 0) {
			data.put("prop_text", propertieValues);
			return data;
		}
		
		//配置错误，扔掉
		if(StringUtils.isBlank(row.getStr("prop_text")))
			return data;
		
		JSONArray confPropertiesArray = null;
		try {
			confPropertiesArray = JSONArray.fromObject(row.getStr("prop_text"));
		} catch (Exception e) {
			logger.error("properties2map: parse error, row.id=>" + row.getInt("id"), e);
			return data;
		}
		
		JSONArray currentPropertiesArray = new JSONArray();
		if(StringUtils.isNotBlank(propertieValues)){
			try{
				currentPropertiesArray = JSONArray.fromObject(propertieValues);
			}catch(Exception e){
				logger.error("error parsing propertieValues: " + propertieValues, e);
			}
		}
		
		List<Map<String, Object>> props = new ArrayList<>();
		for (int i = 0; i < confPropertiesArray.size(); ++i) {
			Map<String, Object> obj = new HashMap<>();
			obj.put("name", confPropertiesArray.getString(i));
			obj.put("value", confPropertiesArray.getString(i));
			
			boolean checked = isCheckedProperty(confPropertiesArray.getString(i), currentPropertiesArray);
			obj.put("checked", checked ? "1" : "0");
			
			props.add(obj);
		}
		data.put("prop_text", props);
		
		return data;
	}
	
	private boolean isCheckedProperty(String val, JSONArray confs){
		for(int i=0; i<confs.size(); ++i){
			if(val.equalsIgnoreCase(confs.getString(i)))
				return true;
		}
		return false;
	}
	
	/**
	 * 将propertie数组转成适配view层的list
	 * @param rows product_properties的record对象列表
	 * @return
	 */
	protected  List<Map<String,Object>> properties2map(List<Record> rows, String externProperties){
		JSONArray json = new JSONArray();
		try{
			if(StringUtils.isNotBlank(externProperties))
				json = JSONArray.fromObject(externProperties);
		}catch(Exception e){
			logger.error("error parsing jsonarray: " + externProperties, e);
		}
		
		List<Map<String, Object>> list = new ArrayList<>();
		for(Record row : rows){
			String propertieValues = "";
			if(StringUtils.isBlank(externProperties)){
				list.add(properties2map(row, propertieValues));
				continue;
			}
			
			for(int i=0; i<json.size(); ++i){
				JSONObject p = json.optJSONObject(i);
				if(p != null && row.getStr("prop_key").equals(p.getString("prop_key"))){
					propertieValues = p.getString("prop_value");
					break;
				}
			}
			list.add(properties2map(row, propertieValues));
		}
		return list;
	}

	protected Record getOrder(String orderId){
		return SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
	}
	
	protected Record getFirstRelet(String orderId){
		return SmartDb.findFirst("select * from `order_relet` where `order_id`=? and `type`=? limit 1", orderId, Order.ORDER_RELET_FIRST);
	}

	/**
	 * 当前是否支持仲裁
	 * 1. 必须在订单结束后n小时内
	 * 2. 有保证金的一定支持仲裁
	 * 3. 没保证金的，但是如果is_free_cancel=false，也支持
	 * @param order
	 * @return
	 */
	protected boolean orderCanArbitrate(Record order){
		int orderStatus = order.getInt("order_status");
		//订单还没结束
		if(orderStatus != Order.ORDER_STATUS_FINISH && orderStatus != Order.ORDER_STATUS_CANCEL)
			return false;

		//当前是否正在申请仲裁
		if(order.getInt("is_selluser_arbitrate") != Order.SELLUSER_NO_ARBITRATE)
			return false;

		//如果订单是强制立即退款的，也不允许仲裁
        if(order.getInt("quick_refund") == 1)
            return false;

		//已经超过仲裁时限
        long finishTime = order.getDate("order_finish_time").getTime();
        if(System.currentTimeMillis() - finishTime > PropKit.getInt("order.show_arbitrate_timeout")*1000L){
            return false;
        }

		//没有保证金，同时is_free_cancel=true，也不支持
		if(order.getInt("seller_guarantee_amount") <= 0 && order.getInt("is_free_cancel") == Order.FREE_CANCEL){
			return false;
		}

		//有保证金的一定支持仲裁
		//没保证金的，is_free_cancel=false 也需要支持仲裁
		return true;
	}
	
	/**
     * 判断当前订单是否支持求助<br>
     * 会调用setAttr设置三个变量：<br>
     * 	support_help: 表示当前游戏是否支持号主求助<br>
     * 	can_help: 表示订单当前是否能求助号主<br>
     * 	left_help_time: 表示当前求助还剩下多少时间（毫秒数），若当前无求助则值为0<br>
     * @param order 订单数据
     * @return
     */
    protected void setOrderHelpAttr(Record order, boolean isBuyuser){
    	//是否支持号主求助
		boolean supportHelp = order.getInt("support_help") == GameConf.SUPPORT_HELP_YES;
		//如果超过了可求助时间，那么也不允许求助
        if(order.getDate("rent_start_time").getTime() + PropKit.getInt("order.order_help.timeout")*1000L < System.currentTimeMillis()) {
            supportHelp = false;
        }
        setAttr("support_help", supportHelp);
		
		//如果支持号主求助，那么现在是否超过了求助次数或者超过了可求助时间，亦或者是号主已经不在线了
		setAttr("can_help", supportHelp);
		
		//-1表示当前没有求助，或者上一次求助已经结束了
		setAttr("left_help_time", -1);
		
		if(supportHelp){
			Record currHelp = SmartDb.findFirst("select * from `order_help` where `order_id`=? and `status`=? order by `id` desc limit 1", order.getStr("order_id"), Order.HELP_STATUS_WAITING);
			Record apply = SmartDb.findFirst("select * from `order_cancel_apply` where `order_id`=? order by `id` desc limit 1", order.getStr("order_id"));

			//当前是否能够求助
			setAttr("can_help", orderCanHelp(order, currHelp, apply, isBuyuser));
			
			if(currHelp != null){
				//求助剩余时间，从支付时间开始计算
				long passTime = System.currentTimeMillis() - currHelp.getDate("c_time").getTime();
				long leftTime = PropKit.getInt("order.order_help_dealine")*1000L - passTime;
				if(leftTime < 0)
					leftTime = 0;
				setAttr("left_help_time", leftTime/1000); //秒为单位
			}
		}
    }
    
    private boolean orderCanHelp(Record order, Record currHelp, Record cancelApply, boolean isBuyuser){
    	//看看第一次支付时间是否已经过了
		if(order.getDate("rent_start_time").getTime() + PropKit.getInt("order.order_help.timeout")*1000L < System.currentTimeMillis()) {
            return false;
        }

		//如果当前正在申请撤单，不给求助
		if(cancelApply != null && cancelApply.getInt("status") == Order.ORDER_CANCEL_APPLY_NEW) {
            return false;
        }
		
		//看看当前是不是在等待号主响应中
		if(currHelp != null){
			//当前正在等待响应，如果是玩家则不允许再发起求助，如果是号主则可以响应求助
			return isBuyuser ? false : true;
		}else{
            //看看是否超过了求助次数
            Record helpCount = SmartDb.findFirst("select count(id) as _count from `order_help` where `order_id`=? and `status` iN (?, ?)", order.getStr("order_id"), Order.HELP_STATUS_OK, Order.HELP_STATUS_FAIL);
            if(helpCount.getInt("_count") >= PropKit.getInt("order.max_help_count")) {
                return false;
            }
		}
		
		//看看支付时间是否在号主在线时间内
		if(!Common.inHour(order.getInt("seller_online_begin_time"), order.getInt("seller_online_end_time"))) {
            return false;
        }

        //最后交给订单决定
		return order.getInt("support_help") == GameConf.SUPPORT_HELP_YES;
    }

    /**
     * 解析当前订单的退款状态，返回一个描述信息
     * @param order
     * @return
     */
    public String parseRefundStatusDesc(Record order, boolean refundDetail){
        String refundStatusDesc = null;

        int orderStatus = order.getInt("order_status");
        int isRefund = order.getInt("order_isrefund_guarantee");
        int guaranteeAmount = order.getInt("order_guarantee_deposit");
        int isTerminate = order.getInt("order_isterminate");
        int refundBuyuserAmount = order.getInt("refund_buyuser_amount");

        //交易成功的情况，有押金才有退款一说
        if(orderStatus == Order.ORDER_STATUS_FINISH && guaranteeAmount > 0){
            //退了，且有押金
            if(isRefund == Order.ORDER_REFUNDED){
                refundStatusDesc = "已退押金";
                if (refundDetail) refundStatusDesc += Common.round(guaranteeAmount / 100.0, 2) + "元";
            }
            //还没退
            else{
                //看看是否被仲裁了
                if(isTerminate == Order.ORDER_TERMINATED){
                    refundStatusDesc = "扣除押金";
                    if(refundDetail) refundStatusDesc += Common.round(guaranteeAmount / 100.0, 2) + "元";
                }else{
                    refundStatusDesc = "等待退款";
                }
            }
        }
        if(orderStatus == Order.ORDER_STATUS_CANCEL && order.getInt("order_ispay") == Order.ORDER_PAID){
            //退了钱
            if(isRefund == Order.ORDER_REFUNDED && refundBuyuserAmount > 0){
                refundStatusDesc = "已退款";
                if(refundDetail) refundStatusDesc += Common.round(refundBuyuserAmount / 100.0, 2) + "元";
            }
            //没退钱
            if(isRefund == Order.ORDER_NOT_REFUND){
                //看看是否被仲裁
                if(isTerminate == Order.ORDER_TERMINATED && guaranteeAmount > 0){
                    refundStatusDesc = "扣除押金";
                    if(refundDetail) refundStatusDesc += Common.round(guaranteeAmount / 100.0, 2) + "元";
                }
                if(isTerminate == Order.ORDER_NOT_TERMINATED){
                    refundStatusDesc = "等待退款";
                }
            }
        }

        return refundStatusDesc;
    }
}
