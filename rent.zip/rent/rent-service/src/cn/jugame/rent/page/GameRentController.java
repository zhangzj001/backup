package cn.jugame.rent.page;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.account_center.service.vo.UserAuthInfo;
import cn.jugame.rent.bean.*;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.PCForwardInterceptor;
import cn.jugame.rent.page.service.ProductPromotionService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.*;
import cn.jugame.service.common.util.bean.DataBean;
import cn.jugame.service.common.util.idbuilder.IDBuilder;
import cn.jugame.service.gameproduct.api.IGameService;
import cn.jugame.service.gameproduct.bean.Channel;
import cn.jugame.service.gameproduct.bean.GamePartition;
import cn.jugame.service.gameproduct.bean.GamePartitionCategory;
import cn.jugame.service.gameproduct.bean.GamePartitionSearch;
import com.google.common.collect.Lists;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.jfinal.render.Render;
import com.jfinal.render.RenderManager;
import com.jfinal.upload.UploadFile;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.io.File;
import java.util.*;

/**
 * 游戏租赁
 * @author zimT_T
 *
 */
public class GameRentController extends BaseController{
	
	private Logger logger = Loggers.rentLog();
	
	private IGameService gameService = ServiceFactory.get(IGameService.class);
	
	//租号支付模块
	private IPayment payment = PaymentFactory.get();

    private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);

	/**
	 * 出租类型的选择页
	 */
	@Before(LoginInterceptor.class)
	public void choose(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请先登录");
            return;
        }

        //当前实名情况
        boolean isAuth = true;
        MemberBean<UserAuthInfo> memberBean = accountCenterService.getUserAuthInfo(uid);
        if (memberBean == null || memberBean.getData() == null ||
                StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())){
            isAuth = false;
        }
        setAttr("is_realname_auth", isAuth);

		render("choose.html");
	}

	/**
	 * 获取游戏列表
	 */
	public void games(){
		String letter = getPara("letter");
		String keywords = getPara("keywords");
		//增加端游手游字段
		int type = getParaToInt("type", 0);
		JSONArray games = new JSONArray();
		List<Record> rows = null;
		
		String sql = "select * from `game_conf` where `status`=?";
		List<Object> params = Lists.newArrayList(GameConf.STATUS_ENABLE);
		if(StringUtils.isNotBlank(letter)){
			sql += " and `game_initial`=?";
			params.add(letter);
		}else{
			//说明是拿游戏展示首页的数据，这时候只出热门游戏
			sql += " and `is_hot`=?";
			params.add(GameConf.TAG_HOT);
		}
		if(type > 0){
			sql += " and `type`=?";
			params.add(type);
		}
		if(StringUtils.isNotBlank(keywords)){
			sql += " and `game_name` like ?";
			params.add("%" + keywords + "%");
		}
		rows = SmartDb.find(sql, params.toArray());
		Integer uid = getSessionAttr("uid");
		if(uid != null) {
			Product.hiddenVipProduct(PropKit.get("vip_privilege_uids").split(","), PropKit.get("vip_privilege_game_id").split(","), rows, uid.toString());
		}

		for(Record row : rows){
			JSONObject obj = new JSONObject();
			obj.put("game_id", row.getStr("game_id"));
			obj.put("game_name", row.getStr("game_name"));
			obj.put("game_short_name", row.getStr("game_short_name"));
			obj.put("icon", row.getStr("icon_url"));
			games.add(obj);
		}
		
		renderJson(buildResp(0, "ok", new KeyValue<>("games", games)));
	}
	
	/**
	 * 根据游戏选定情况获取渠道列表
	 */
	public void channels(){
		String gameId = getPara("game_id", "");
		
		JSONObject rtn = getChannels(gameId);
		if(rtn.getInt("code") != 0){
			renderJson(rtn);
			return;
		}

		renderJson(buildResp(0, "ok", new KeyValue<>("channels", rtn.getJSONArray("channels"))));
	}
	
	/**
	 * 获取区服分组
	 */
	public void partitionCategories(){
		String gameId = getPara("game_id", "");
		String channelId = getPara("channel_id", "");
		
		GamePartitionSearch partitionArg = new GamePartitionSearch();
		partitionArg.setGameId(gameId);
		partitionArg.setChannelId(channelId);
		partitionArg.setType(2);
		DataBean<List<GamePartitionCategory>> bean = gameService.getGamePartitionCategoryListByModel(partitionArg);
		
		JSONArray categories = new JSONArray();
		if(bean == null || bean.getData() == null){
			renderJson(buildResp(1, "获取区服分组列表失败了: " + (bean != null ? bean.getMsg() : "连接失败")));
			return;
		}
		
		List<GamePartitionCategory> ctgs = bean.getData();
		for(GamePartitionCategory ctg : ctgs){
			
			//XXX 因为运营的不作为！导致这里要硬编码：王者荣耀不要“全区全服”这种区服！
			if("2130".equalsIgnoreCase(gameId)){
				if(ctg.getCategoryName().contains("全区") || ctg.getCategoryName().contains("全服"))
					continue;
			}
			
			
			JSONObject obj = new JSONObject();
			obj.put("category_id", ctg.getcategoryId());
			obj.put("category_name", ctg.getCategoryName());
			categories.add(obj);
		}
		
		renderJson(buildResp(0, "ok", new KeyValue<>("categories", categories)));
	}
	
	/**
	 * 根据游戏和渠道选定情况获取区服列表
	 */
	public void partitions(){
		String gameId = getPara("game_id", "");
		String categoryId = getPara("category_id", "");
		
		DataBean<List<GamePartition>> bean = gameService.getGamePartitionListByCategoryId(categoryId, gameId);
		if(bean == null || bean.getData() == null){
			renderJson(buildResp(1, "获取区服列表失败了"));
			return;
		}
		List<GamePartition> list = bean.getData();
	
		JSONArray partitions = new JSONArray();
		for(GamePartition gp : list){
			//XXX 因为运营的不作为！导致这里要硬编码：王者荣耀不要“全区全服”这种区服！
			if("2130".equalsIgnoreCase(gameId)){
				if(gp.getPartitionName().contains("全区") || gp.getPartitionName().contains("全服"))
					continue;
			}

			JSONObject obj = new JSONObject();
			obj.put("partition_id", gp.getPartitionId());
			obj.put("partition_name", gp.getPartitionName());
			partitions.add(obj);
		}
		
		renderJson(buildResp(0, "ok", new KeyValue<>("partitions", partitions)));
	}

	/**
	 * 出租页面
	 */
	@Before({LoginInterceptor.class, PCForwardInterceptor.class})
	public void index(){
		List<Object> gameLetters = new ArrayList<>();
		for(char i='A'; i<='Z'; ++i){
			Map<String, Object> map = new TreeMap<>();
			map.put("letter", String.valueOf(i));
			gameLetters.add(map);
		}
		setAttr("game_letters", gameLetters);
		setAttr("type",getPara("type"));
		render("index.html");
	}
	
	/**
	 * 出租商品详细信息填写页
	 */
	@Before({LoginInterceptor.class, PCForwardInterceptor.class})
	public void rentdetail(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请先登录");
			return;
		}

        boolean isAuth = true;
        MemberBean<UserAuthInfo> memberBean = accountCenterService.getUserAuthInfo(uid);
        if (memberBean == null || memberBean.getData() == null ||
                StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())){
            isAuth = false;
        }
        setAttr("is_realname_auth", isAuth);

//        int needRealname = HotSetting.getInt("REALNAME_AUTHORIZED", 0);
        int needRealname = PropKit.getInt("realname.force", 0);
		if(needRealname == 1 && !isAuth) {
            render("../user/realname.html");
            return;
        }
		
		String productId = getPara("product_id");
		String gameId = getPara("game_id");
		String channelId = getPara("channel_id");
		String partitionId = getPara("game_partition_id");
		
		//新建商品时没有值，修改商品时回填
		String gameName = "";
		String channelName = "";
		String partitionName = "";

		//如果productId有值，则通过商品信息来获取gameId, channelId, partitionId
		Record product = null;
		if(StringUtils.isNotBlank(productId)){
			product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
			if(product == null){
				errorPage("不存在的商品，无法修改");
				return;
			}
			
			//如果商品不是本人的，不允许修改
			if(product.getInt("seller_uid").intValue() != uid){
				errorPage("该商品不是您发布的，无法进行修改。");
				return;
			}
			
			//如果这个商品还在限制上架时间内，不允许编辑上架
			Date limitOnsaleTime = product.getDate("limit_onsale_time");
			if(limitOnsaleTime != null && limitOnsaleTime.getTime() > System.currentTimeMillis()){
				errorPage("您当前的商品由管理员限制上架，限制时间至" + Common.show_time(limitOnsaleTime));
				return;
			}
			
			gameId = product.getStr("game_id");
			channelId = product.getStr("channel_id");
			partitionId = product.getStr("game_partition_id");
			gameName = product.getStr("game_name");
			channelName = product.getStr("channel_name");
			partitionName = product.getStr("game_partition_name");
			JSONObject rtn = getChannels(gameId);
			setAttr("channels",rtn);
			
			GamePartitionSearch partitionArg = new GamePartitionSearch();
			partitionArg.setGameId(gameId);
			partitionArg.setChannelId(channelId);
			partitionArg.setType(2);
			DataBean<List<GamePartitionCategory>> bean = gameService.getGamePartitionCategoryListByModel(partitionArg);
			
			JSONArray categories = new JSONArray();
			
			List<GamePartitionCategory> ctgs = bean.getData();
			for(GamePartitionCategory ctg : ctgs){
				JSONObject obj = new JSONObject();
				obj.put("category_id", ctg.getcategoryId());
				obj.put("category_name", ctg.getCategoryName());
				categories.add(obj);
			}
			setAttr("categories",categories);
		}

		//XXX 如果是QQ客户端，只支持数字输入
        if("10".equalsIgnoreCase(channelId) //安卓QQ客户端
                || "437".equalsIgnoreCase(channelId)  //安卓QQ客户端体验服
                || "394".equalsIgnoreCase(channelId) //苹果QQ客户端
        ){
		    setAttr("account_number_only", true);
        }
		
		List<Record> properties = SmartDb.find("select * from `product_properties` where `game_id`=? and `status`=1", gameId);
		setAttr("game_id", gameId);
		setAttr("channel_id", channelId);
		setAttr("partition_id", partitionId);
		setAttr("game_name", gameName);
		setAttr("channel_name", channelName);
		setAttr("partition_name", partitionName);
		List<Map<String, Object>> propertie_list = properties2map(properties, product != null ? product.getStr("extern_properties") : "");
		setAttr("properties", propertie_list);

		Record gameConf = SmartDb.findFirst("select * from `game_conf` where `game_id`=? and `status`=?", gameId, GameConf.STATUS_ENABLE);
		if(gameConf == null){
		    errorPage("不存在的游戏/会员类型。");
		    return;
        }

        setAttr("min_price",Common.round(gameConf.getInt("min_price")/100,2));
        //标记为游戏账号出租
        setAttr("product_type",gameConf.getInt("type"));

        //游戏是否支持让号主自助选择能否响应求助
        setAttr("choose_help_option", false);
        if(gameConf.getInt("support_help") == GameConf.SUPPORT_HELP_YES && gameConf.getInt("force_seller_help") == GameConf.SUPPORT_HELP_NO){
            setAttr("choose_help_option", true);
        }

		//其它一些限制属性
		setAttr("max_price_hour", PropKit.getInt("product.max_price_hour"));
		setAttr("max_price_day", PropKit.getInt("product.max_price_day"));
		setAttr("max_guarantee_deposit", PropKit.getInt("product.max_guarantee_deposit"));
		
		//看看支不支持押金
		boolean noGuaranteeDeposit = noGuaranteeDeposit(gameId);
		setAttr("no_guarantee_deposit", noGuaranteeDeposit);
		
		//获取当前这个游戏的手续费率
		double feeRate = getOrderFee(gameId, uid,productId, BaseController.FEE_TYPE_NORMAL);
		setAttr("fee_rate", (int)(feeRate*100));
		
		//包夜价展示时间段
		setAttr("in_night_begin", PropKit.getInt("product.in_night_begin"));
		setAttr("in_night_end", PropKit.getInt("product.in_night_end"));
		setAttr("in_night_showprice_end", PropKit.getInt("product.in_night_showprice_end"));

		//如果是修改商品，此时将商品的旧值带上返回
		if(StringUtils.isNotBlank(productId)){
			//获取旧数据
			Map<String, Object> orig = product2map(product);
			
			//图片
			List<String> pics = new ArrayList<>();
			List<Record> picRows = SmartDb.find("select * from `product_picture` where `product_id`=? order by `type` asc", productId);
			for(Record row : picRows){
				pics.add(row.getStr("pic_url"));
			}
			orig.put("pics", pics);
			//设置优惠活动信息
			List<Record> promotions = SmartDb.find("select * from `product_promotions` where `product_id`=?",productId);
			Map<String, Object> promotionInfo = new HashMap<>();
			List promotionHourDataBeans = new ArrayList();
			List promotionDayDataBeans = new ArrayList();
			Map<String, Object> promotionDayInfo =new HashMap<>();
			Map<String, Object> promotionHourInfo = new HashMap<>();
			int promotionHourStatus=0;
			int promotionDayStatus=0;
			for(Record promotion:promotions){
				Map<String, Object> promotionHour =new HashMap<>();
				Map<String, Object> promotionDay = new HashMap<>();
				if(promotion.getInt("type") == ProductPromotionService.PROMOTION_TYPE_HOUR){
					promotionHour.put("promote_unit",promotion.getInt("promote_unit"));
					promotionHour.put("promote_gift",promotion.getInt("promote_gift_time"));
					promotionHour.put("promotion_id","\""+promotion.getStr("promotion_id")+"\"");
					promotionHourStatus = promotion.getInt("status");
					promotionHourDataBeans.add(promotionHour);
				}

				if(promotion.getInt("type") == ProductPromotionService.PROMOTION_TYPE_DAY){
					promotionHour.put("promotion_id","\""+promotion.getStr("promotion_id")+"\"");
					promotionDay.put("promote_unit",promotion.getInt("promote_unit"));
					promotionDay.put("promote_gift", (int)Common.round(promotion.getInt("promote_gift_money")/100.0, 0));
					promotionDayDataBeans.add(promotionDay);
					promotionDayStatus = promotion.getInt("status");
				}
			}
			promotionDayInfo.put("data",promotionDayDataBeans);
			promotionDayInfo.put("status",promotionDayStatus);
			promotionHourInfo.put("data",promotionHourDataBeans);
			promotionHourInfo.put("status",promotionHourStatus);
			promotionInfo.put("promotion_hour",promotionHourInfo);
			promotionInfo.put("promotion_day",promotionDayInfo);
			orig.put("promotion",promotionInfo);
			setAttr("promotionJson",JSONObject.fromObject(promotionInfo));
			setAttr("orig", orig);
		}
		//判断游戏是否支持登号器登录
	    int loginType = Loginkey.getLoginType(gameId,channelId);
		setAttr("game_login_type",loginType);

		//是否开启实名认证
		setAttr("seller_validation", HotSetting.getInt("SELLER_REAL_NAME_VALIDATION", 0));
		//是否已绑定手机
		setAttr("bind_mobile",User.getBindMobile(uid)!=null?1:0);
		//是否已实名认证
		setAttr("bind_real_name",User.checkBindRealName(uid)?1:0);
		
		//号主交流群
		setAttr("seller_qq_group",HotSetting.get("SELLER_QQ_GROUP_URL", ""));
		
		//是否已经修改过账号，旧商品支持修改一次，新商品不支持
		int hasChangeGameLoginId = 1;
		if(StringUtils.isNotBlank(productId)){
			hasChangeGameLoginId = product.getInt("has_change_game_login_id");
		}
		setAttr("has_change_game_login_id", hasChangeGameLoginId);
		
		//如果号主是商铺
		setAttr("is_shop", false);
		Record shopInfo = SmartDb.get(false).findFirst("select * from `shop_info` where `uid`=?", uid);
		if(shopInfo != null){
			setAttr("is_shop", true);
			//获取对应的合租者列表
			List<Record> coops = SmartDb.get(false).find("select * from `shop_cooperation_list` where `shop_id`=?", shopInfo.getInt("id"));
			setAttr("cooperation_list", toMap(coops));
		}
		
		setAttr("coop_fee_rate", 0);
		//旧的合租者分成
		if(shopInfo != null && StringUtils.isNotBlank(productId)){
			Record royalty = SmartDb.get(false).findFirst("select * from `shop_product_royalty` where `product_id`=?", productId);
			if(royalty != null){
				setAttr("coop_fee_rate", royalty.getInt("royalty"));
			}
		}

		render("rentdetail.html");
	}

	/**
	 * 出租会员VIP账号的详情页
	 */
	@Before({LoginInterceptor.class, PCForwardInterceptor.class})
	public void rentVipDetail(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请先登录");
			return;
		}

        //是否实名，未实名则要求实名！
//        int needRealname = HotSetting.getInt("REALNAME_AUTHORIZED", 0);
        int needRealname = PropKit.getInt("realname.force", 0);
		if(needRealname == 1) {
            MemberBean<UserAuthInfo> memberBean = accountCenterService.getUserAuthInfo(uid);
            if (memberBean == null || memberBean.getData() == null ||
                    StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())) {
                render("../user/realname.html");
                return;
            }
        }

        String productId = getPara("product_id");
		String gameId = getPara("game_id");

		//如果productId有值，则通过商品信息来获取gameId, channelId, partitionId
		Record product = null;
		if(StringUtils.isNotBlank(productId)){
			product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
			if(product == null){
				errorPage("不存在的商品，无法修改");
				return;
			}
			gameId = product.getStr("game_id");
		}
		
		//是否已经修改过账号，旧商品支持修改一次，新商品不支持
		int hasChangeGameLoginId = 1;
		if(StringUtils.isNotBlank(productId)){
			hasChangeGameLoginId = product.getInt("has_change_game_login_id");
		}
		setAttr("has_change_game_login_id", hasChangeGameLoginId);
		
		//当前指定了某个游戏
		if(StringUtils.isNotBlank(gameId)){
			Record game = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", gameId);
			setAttr("current_game", toMap(game));
		}

		//支持的会员账号类型
		String vip_privilege_game_id = PropKit.get("vip_privilege_game_id");
		setAttr("vip_privilege_game_id", vip_privilege_game_id);
		List<Record> rows = SmartDb.find("select * from `game_conf` where `status`=? and `type`=?  order by weight desc,id asc ", GameConf.STATUS_ENABLE, GameConf.TYPE_VIP);

		Product.hiddenVipProduct(PropKit.get("vip_privilege_uids").split(","), PropKit.get("vip_privilege_game_id").split(","), rows, uid.toString());
		Product.hiddenVipProduct(PropKit.get("vip_hidden_hour_price_uids").split(","), PropKit.get("vip_hidden_hour_price_ids").split(","), rows, uid.toString());
		
		setAttr("supportChannels", toMap(rows));

		//其它一些限制属性
		setAttr("max_price_hour", PropKit.getInt("product.max_price_hour"));
		setAttr("max_price_day", PropKit.getInt("product.max_price_day"));
		setAttr("max_guarantee_deposit", PropKit.getInt("product.max_guarantee_deposit"));

		//看看支不支持押金
		setAttr("no_guarantee_deposit", false);

		//获取当前这个游戏的手续费率
		double feeRate = getOrderFee(uid,productId);
		setAttr("fee_rate", (int)(feeRate*100));

		//包夜价展示时间段
		setAttr("in_night_begin", PropKit.getInt("product.in_night_begin"));
		setAttr("in_night_end", PropKit.getInt("product.in_night_end"));
		setAttr("in_night_showprice_end", PropKit.getInt("product.in_night_showprice_end"));

        //如果是修改商品，此时将商品的旧值带上返回
        if(StringUtils.isNotBlank(productId)){
            //获取旧数据
            Map<String, Object> orig = product2map(product);
            setAttr("orig", orig);
        }

		setAttr("product_type", Product.PRODUCT_TYPE_VIP);

		//是否开启实名认证
		setAttr("seller_validation", HotSetting.getInt("SELLER_REAL_NAME_VALIDATION", 0));
		//是否已绑定手机
		setAttr("bind_mobile",User.getBindMobile(uid)!=null?1:0);
		//是否已实名认证
		setAttr("bind_real_name",User.checkBindRealName(uid)?1:0);
		
		//号主交流群
		setAttr("seller_qq_group",HotSetting.get("SELLER_QQ_GROUP_URL", ""));
		render("rentvipdetail.html");
	}


	private boolean noGuaranteeDeposit(String gameId){
		Record conf = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", gameId);
		if(conf == null){
			//没配置...默认需要押金
			return false;
		}

		return conf.getInt("has_guarantee_deposit") == 0;
	}

	private String generateProductId(){
		return IDBuilder.productIdBuilder("RENT-PRO");
	}

	private String generateProductPromoteId(){
		return IDBuilder.productIdBuilder("RENT-PROMOTE");
	}


	
	/**
	 * 保存商品
	 * 如果提交的参数有product_id，则执行update，否则执行add
	 */
	@Before(LoginInterceptor.class)
	public void save(){
		String productId = getPara("product_id");
		if(StringUtils.isBlank(productId)){
			add();
		}else{
			update();
		}
	}

	/**
	 * 发布商品
	 */
	private void add(){
		Integer sellerUid = getSessionAttr("uid");
		if(sellerUid == null){
			errorPage("请登录后再进行商品发布");
			return;
		}
		
		int productType = getParaToInt("product_type", 0);
		if(productType <= 0){
			errorPage("没有指定需要发布的商品类型");
			return;
		}

		String gameId = htmlEncode(getPara("game_id"));
		Record game = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", gameId);
		if (game == null) {
			errorPage("不存在的游戏");
			return;
		}
		String gameName = game.getStr("game_name");
		String gameShortName = game.getStr("game_short_name");
		String gamePic = game.getStr("icon_url");

		//商品标题
		String name = htmlEncode(getPara("name", ""));
		//如果是会员VIP则固定加后缀
		if(productType == Product.PRODUCT_TYPE_VIP){
			if(!Common.arrayContainsString(PropKit.get("vip_privilege_uids").split(","), sellerUid.toString())||
					!Common.arrayContainsString(PropKit.get("vip_privilege_game_id").split(","), gameId)) {
				name = gameName + "会员出租";
			}
		}
		if(StringUtils.isBlank(name)){
			errorPage("没有商品标题");
			return;
		}
		if(name.length() > 50){
			errorPage("商品名称最长不能超过50个字");
			return;
		}
		
		String info = htmlEncode(getPara("info", ""));
        //会员VIP的禁忌行为固定如下
        if(productType == Product.PRODUCT_TYPE_VIP){
            info = "若密码错误、账号冻结或者需要验证码，请15分钟内在订单详情中“联系号主求助”。";
        }
		if(info.length() > 200){
			errorPage("商品描述不能超过200个字");
			return;
		}
		String forbidden = htmlEncode(getPara("forbidden", ""));
		//会员VIP的禁忌行为固定如下
        if(productType == Product.PRODUCT_TYPE_VIP){
			//FIXME 有一些说明针对特定的渠道有不一样。
			if(gameId.equalsIgnoreCase("tencent")){
				forbidden = "严禁登陆QQ、改密。";
			}else {
				forbidden = "严禁改密。";
			}
        }
        if (forbidden.length() > 200) {
            errorPage("商品禁忌描述不能超过100个字");
            return;
        }

		int priceHour = toFen(getPara("price_hour"));
		int priceDay = toFen(getPara("price_day"));
		int priceNight = toFen(getPara("price_night"));
		int maxPriceHour = PropKit.getInt("product.max_price_hour")*100; //转单位为分
        int onsaleProtectTime = getParaToInt("onsale_protect_time", 1); //默认1小时
		
		//最低单价,默认为1元
		int minPrice = game.get("min_price",100);

		if(priceHour < minPrice){
			errorPage("商品时租价至少为" + Common.round(minPrice/100.0, 2) + "元。");
			return;
		}
		if(priceHour > maxPriceHour){
			errorPage("商品时租价超过最大限额:" + maxPriceHour + "元");
			return;
		}
		int maxPriceDay = PropKit.getInt("product.max_price_day")*100; //转单位为分
		if(priceDay < minPrice){
			errorPage("商品日租价至少为" + Common.round(minPrice/100.0, 2) + "元。");
			return;
		}
		if(priceDay > maxPriceDay){
			errorPage("商品日租价超过最大限额:" + maxPriceDay + "元");
			return;
		}
		if(priceNight < minPrice){
			errorPage("商品包夜价至少为" + Common.round(minPrice/100.0, 2) + "元。");
			return;
		}
		if(priceNight > maxPriceDay){
			errorPage("商品包夜价超过了最大限额:" + maxPriceDay + "元");
			return;
		}
		int minRentTime = getParaToInt("min_rent_time", PropKit.getInt("product.min_rent_time"));
		if(minRentTime <= 0){
		    errorPage("商品的最低租赁时长不允许低于1小时");
		    return;
        }
		//最大值不要超过24小时
		if (minRentTime >= 24) {
			errorPage("商品的最低租赁时长不允许超过24小时");
			return;
		}

		int maxGuaranteeDeposit = PropKit.getInt("product.max_guarantee_deposit")*100; //转单位为分
		int guaranteeDeposit = toFen(getPara("guarantee_deposit"));
		//押金不能超过时租价的10倍
		if(guaranteeDeposit > priceHour*10){
			errorPage("商品押金不能超过时租价的10倍");
			return;
		}
		if(guaranteeDeposit >= maxGuaranteeDeposit){
			errorPage("商品押金超过最大限额");
			return;
		}
		int validityDay = getParaToInt("validity_day", PropKit.getInt("product.validity_day")); //有效期，单位天

		String channelId = htmlEncode(getPara("channel_id"));
		String gamePartitionId = htmlEncode(getPara("game_partition_id"));
		String gameRoleName = htmlEncode(getPara("game_role_name", ""));
		String gameUserLevel = htmlEncode(getPara("game_user_level", ""));

        String partitionName = null;
        String channelName = null;

        //如果是会员VIP，不会有游戏信息，其余的账号类型才需要获取！
        if (productType != Product.PRODUCT_TYPE_VIP) {
            //游戏区服
            DataBean<GamePartition> partitionBean = gameService.getGamePartitionById(gameId, gamePartitionId);
            if(partitionBean == null || partitionBean.getData() == null){
                errorPage("不存在的游戏区服");
                return;
            }
            GamePartition partition = partitionBean.getData();
            partitionName = partition.getPartitionName();

            //游戏渠道
            DataBean<Channel> channelBean = gameService.getChannel(channelId);
            if (channelBean == null || channelBean.getData() == null) {
                errorPage("不存在的游戏渠道");
                return;
            }
            Channel channel = channelBean.getData();
            channelName = channel.getChannelName();
        }

		String gameLoginId = getPara("game_login_id", "").trim();
		if(StringUtils.isBlank(gameLoginId)){
			errorPage("没有设置游戏登录账号");
			return;
		}
		String gameLoginPwd = getPara("game_login_password");
		if(StringUtils.isBlank(gameLoginPwd)){
			errorPage("没有设置游戏登录密码");
			return;
		}
		int minPlayScore = getParaToInt("min_play_score", 0);
		if(minPlayScore < 0)
			minPlayScore = 0;
		if(minPlayScore > 100)
			minPlayScore = 100;
		
		//在线时间
		int sellerOnlineBeginTime = getParaToInt("seller_online_begin_time", 7);
		int sellerOnlineEndTime = getParaToInt("seller_online_end_time", 24);
		//保证在合理范围
		if(sellerOnlineBeginTime < 0 || sellerOnlineBeginTime > 24 || sellerOnlineEndTime < 0 || sellerOnlineEndTime > 24){
			errorPage("您的号主在线时间必须在0时~24时的范围内。");
			return;
		}
		
		//进行排重，要求 游戏+渠道+账号 当前唯一上架
		if(Product.isDuplicateProduct(productType, sellerUid, gameId, channelId, gameLoginId, null)){
			errorPage("该客户端的游戏账号您当前已经发布成功一件租赁商品，无需重新发布。");
			return;
		}
		
		//图片地址
		String[] pics = getParaValues("pic");
		if(pics == null) pics = new String[0]; //做一层保险
		if(productType != Product.PRODUCT_TYPE_VIP) {
            if (pics.length == 0) {
                errorPage("请至少上传1张游戏截图");
                return;
            }
            if (pics.length > 10) {
                errorPage("最多上传10张游戏截图");
                return;
            }
        }
		
		//优惠信息
		String promotions = getPara("promotion","");
		if(ProductPromotionService.instance.validPromotionActivity(promotions)) {
			errorPage("时租满送优惠，不能送超过"+ProductPromotionService.PROMOTION_TYPE_HOUR_MAX+"个小时");
            return;
		}
		
		//匹配扩展属性字段
		JSONArray extProps = new JSONArray();
		List<Record> propRows = SmartDb.find("select * from `product_properties` where `game_id`=?", gameId);
		for(Record prop : propRows){
			JSONObject obj = new JSONObject();
			obj.put("prop_key", prop.getStr("prop_key"));
			obj.put("prop_name", prop.getStr("prop_name"));
			obj.put("prop_type", prop.getInt("prop_type"));
			if(prop.getInt("prop_type")==0) {
				obj.put("prop_value", getPara(prop.getStr("prop_key"), ""));
			}else {
				String [] values = getParaValues(prop.getStr("prop_key"));
				JSONArray valuesArray = new JSONArray();
				for(String value:values) {
					valuesArray.add(value);
				}
				obj.put("prop_value", valuesArray);
			}
			
			extProps.add(obj);
		}
		
		//获取当前卖家的信誉分
		Record member = User.getMember(sellerUid);
		int score = member.getInt("reputation_score");
		//端游商品用号主端游等级，其他用手游等级
		int sellLevel = member.getInt("sell_level");
		if(productType==Product.PRODUCT_TYPE_PCGAME)
			sellLevel = member.getInt("pc_sell_level");
		
		//VIP登录方式
		int vipLoginType = getParaToInt("vip_login_type",0);
		//生成商品ID
		String productId = this.generateProductId();
		//生成商品推广id
		String productPromoteId = this.generateProductPromoteId();
		logger.info("发布新商品：" + productId);
		long nowTime = System.currentTimeMillis();
		String now = Common.show_time(nowTime);
        
        Record productDecorate =	SmartDb.findFirst("select * from product_decorate_payment  where uid = ? and status = ? and pay_time <= ? and invalid_time >=?",
        		sellerUid,Product.DECORATE_PAYMENT_STATUS_PAYED,Common.now(),Common.now());
		
        
        //合租者UID
        int cooperationUid = getParaToInt("cooperation_uid", 0);
        int coopFeeRate = getParaToInt("coop_fee_rate", 0);
        
        Record shopInfo = null;
        if(cooperationUid > 0 && coopFeeRate > 0){
        	shopInfo = SmartDb.findFirst("select * from `shop_info` where `uid`=?", sellerUid);
        	if(shopInfo == null){
        		errorPage("您还没有开通商铺功能，无法关联合租者，若希望开通商铺请联系客服处理。");
        		return;
        	}
        }

        //是否支持求助
        int supportHelp = game.getInt("support_help");
        //支持求助，同时又支持号主自选，那么由参数决定
        if(game.getInt("support_help") == GameConf.SUPPORT_HELP_YES
                && game.getInt("force_seller_help") == GameConf.SUPPORT_HELP_NO){
            supportHelp = getParaToInt("support_help", GameConf.SUPPORT_HELP_NO); //界面没勾选，会不传这个参数过来
        }
		
		//VIP视频登录方式
		int gameLoginType = getParaToInt("game_login_type",1);
		Record row = new Record();
		if(productDecorate != null) {
			row.set("is_decorate", Product.PRODUCT_DECORATE);
		}
		row.set("product_id", productId);
		row.set("game_login_type",gameLoginType);
		row.set("product_promote_id",productPromoteId);
		row.set("name", name);
		row.set("info", info);
		row.set("forbidden", forbidden);
		row.set("price_hour", priceHour);
		row.set("price_day", priceDay);
		row.set("price_night", priceNight);
		row.set("min_rent_time", minRentTime);
		row.set("guarantee_deposit", guaranteeDeposit);
		row.set("validity", validityDay);
		row.set("create_time", now);
		row.set("modify_time", now);
		row.set("onsale_time", now);
		row.set("seller_uid", sellerUid);
		row.set("product_type", productType);
		row.set("game_id", gameId);
		row.set("game_name", gameName);
		row.set("game_short_name", gameShortName);
		row.set("game_pic", gamePic);
		row.set("vip_login_type", vipLoginType);
		if(StringUtils.isNotBlank(channelId)) {
            row.set("channel_id", channelId);
        }
        if(StringUtils.isNotBlank(channelName)) {
            row.set("channel_name", channelName);
            //如果channelName中带有‘苹果’二字，则认为是IOS渠道的
            if(channelName.contains("苹果")){
            	row.set("channel_platform", Product.CHANNEL_PLATFORM_IOS);
            }
            else if(channelName.contains("端游")){
                row.set("channel_platform", Product.CHANNEL_PLATFORM_PC);
            }
            else{
            	row.set("channel_platform", Product.CHANNEL_PLATFORM_ANDROID);
            }
        }
		row.set("status", Product.STATUS_VERIFY); //待审核状态
        //如果商品超过指定数量，直接处于下架状态，不允许审核了
        if(Product.tooManyProducts(sellerUid, null)){
            row.set("status", Product.STATUS_OFFSALE);
        }

		row.set("game_partition_id", gamePartitionId);
		row.set("game_partition_name", partitionName);
		row.set("game_role_name", gameRoleName);
		row.set("game_user_level", gameUserLevel);
		row.set("game_login_id", gameLoginId);
		row.set("game_login_password", gameLoginPwd);
		row.set("sell_pid", this.generateSellPid());
		row.set("extern_properties", extProps.toString());
		row.set("reputation_score", score);
		row.set("min_play_score", minPlayScore);
		row.set("sell_level", sellLevel);
		row.set("seller_online_begin_time", sellerOnlineBeginTime);
		row.set("seller_online_end_time", sellerOnlineEndTime);
		row.set("has_change_game_login_id", 1);
		row.set("cooperation_uid", cooperationUid);
        row.set("support_help", supportHelp);
        row.set("onsale_protect_time", onsaleProtectTime);
		logger.info("发布商品【" + productId + "】信息: " + row.toJson());
		//保存新商品
		if(!SmartDb.save("product", row)){
			logger.error("保存商品信息失败，productId=>" + productId + ", sql => " + SmartDb.lastQuery(), SmartDb.getException());
			errorPage("保存商品信息失败了");
			return;
		}
		
		//保存商品图片
		for(String pic : pics){
			Record picRow = new Record();
			picRow.set("product_id", productId);
			picRow.set("pic_url", pic);
			picRow.set("type", Product.PIC_TYPE_USER);
			picRow.set("c_time", Common.now());
			if(!SmartDb.save("product_picture", picRow)){
				logger.error("保存商品截图失败，productId=>" + productId + "， pic_url=>" + pic);
			}
		}


		//保存商品的优惠信息
		JSONObject promotionValidTitle = ProductPromotionService.instance.savePromotionActivity(promotions,productId);
		if(promotionValidTitle != null){

			String promoteTitle =  promotionValidTitle.size()>0 ? promotionValidTitle.toString():null;
			row.keep("product_id");
			row.set("promotion_properties",promoteTitle);
			if(!SmartDb.update("product","product_id",row)){
				logger.error("保存商品优惠信息失败，productId=>" + productId + ", sql => " + SmartDb.lastQuery(), SmartDb.getException());
			}
		}


		logger.info("新商品【" + productId + "】发布成功！");
		//计算减少的手续费率
		int feeReduce = (int)(Common.round((1.0-Double.parseDouble(PropKit.get("product.guarantee_amount_discount"))),2) *100);
		setAttr("fee_reduce",feeReduce);
		setAttr("msg", "商品发布成功，审核成功后将自动上架！");
		setAttr("product_id", productId);
		setAttr("is_seller_normal ",sellLevel==0?true:false);
		
		
		//如果有合租者的话
		//保存商品之后，同时将合租分成信息存储到 shop_product_royalty
		if(shopInfo != null){
			Record royalty = new Record();
			royalty.set("shop_id", shopInfo.getInt("id"));
			royalty.set("shop_uid", sellerUid);
			royalty.set("product_id", productId);
			royalty.set("cooperation_uid", cooperationUid);
			royalty.set("royalty", coopFeeRate);
			royalty.set("update_time", Common.now());
			royalty.set("create_time", Common.now());
			if(!SmartDb.save("shop_product_royalty", royalty)){
				logger.error("商品【" + productId + "】在关联合租者时发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
			}
		}
		
		render("succ.html");
	}
	
	/**
	 * 修改商品信息
	 */
	private void update(){
		String productId = getPara("product_id");
		if(StringUtils.isBlank(productId)){
			errorPage("没有指定需要修改的商品");
			return;
		}
		
		Integer sellerUid = getSessionAttr("uid");
		if(sellerUid == null){
			errorPage("请登录后再进行商品发布");
			return;
		}
		
		//确保商品处于下架状态/审核状态
		Record product = SmartDb.findFirst("select * from product where product_id=?", productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}
		if(product.getInt("status") == Product.STATUS_ONSALE){
			errorPage("商品当前是上架状态，无法修改信息");
			return;
		}
		if(product.getInt("status") == Product.STATUS_RENT){
			errorPage("商品当前正在出租中，无法修改信息");
			return;
		}
		if(product.getInt("status") == Product.STATUS_VERIFY){
			errorPage("商品当前还在审核中，无法修改信息");
			return;
		}

		String name = getPara("name");
        //会员VIP不修改标题
		if(product.getInt("product_type") == Product.PRODUCT_TYPE_VIP){
			if(!Common.arrayContainsString(PropKit.get("vip_privilege_uids").split(","), sellerUid.toString())
					||!Common.arrayContainsString(PropKit.get("vip_privilege_game_id").split(","), product.getStr("game_id"))) {
				name = product.getStr("name");
			}
		    
        }
        if(StringUtils.isBlank(name)){
            errorPage("没有商品标题");
            return;
        }

		int priceHour = toFen(getPara("price_hour"));
		int priceDay = toFen(getPara("price_day"));
		int priceNight = toFen(getPara("price_night"));
        String info = htmlEncode(getPara("info", ""));
        String forbidden = htmlEncode(getPara("forbidden", ""));
        //会员VIP不修改描述和禁忌
        if(product.getInt("product_type") == Product.PRODUCT_TYPE_VIP) {
            info = product.getStr("info");
            forbidden = product.getStr("forbidden");
        }
        if (info.length() > 200) {
            errorPage("商品描述不能超过200个字");
            return;
        }
        if (forbidden.length() > 200) {
            errorPage("商品禁忌描述不能超过100个字");
            return;
        }
        int onsaleProtectTime = getParaToInt("onsale_protect_time", 1);

		Record game = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", product.getStr("game_id"));
		if (game == null) {
			errorPage("不存在的游戏");
			return;
		}
		int minPrice = game.get("min_price",100);

		int maxPriceHour = PropKit.getInt("product.max_price_hour")*100; //转单位为分
		if(priceHour < minPrice){
			errorPage("商品时租价至少" + Common.round(minPrice/100.0, 2) + "元。");
			return;
		}
		if(priceHour > maxPriceHour){
			errorPage("商品时租价超过最大限额");
			return;
		}
		int maxPriceDay = PropKit.getInt("product.max_price_day")*100; //转单位为分
		if(priceDay < minPrice){
			errorPage("商品日租价至少" + Common.round(minPrice/100.0, 2) + "元。");
			return;
		}
		if(priceDay > maxPriceDay){
			errorPage("商品日租价超过最大限额:" + maxPriceDay + "元");
			return;
		}
		if(priceNight < minPrice){
			errorPage("商品包夜价至少" + Common.round(minPrice/100.0, 2) + "元。");
			return;
		}
		if(priceNight > maxPriceDay){
			errorPage("商品包夜价超过最大限额:" + maxPriceDay + "元");
			return;
		}
		int minRentTime = getParaToInt("min_rent_time", PropKit.getInt("product.min_rent_time"));
		//最大值不要超过24小时
		if (minRentTime >= 24) {
			errorPage("商品的最低租赁时长不允许超过24小时");
			return;
		}

		int maxGuaranteeDeposit = PropKit.getInt("product.max_guarantee_deposit")*100; //转单位为分
		int guaranteeDeposit = toFen(getPara("guarantee_deposit")); //单位为分
		if(guaranteeDeposit > priceHour*10){
			errorPage("商品押金不能超过时租价的10倍");
			return;
		}
		if(guaranteeDeposit >= maxGuaranteeDeposit){
			errorPage("商品押金超过最大限额");
			return;
		}
		
		String gameRoleName = getPara("game_role_name", "");
		String gameUserLevel = getPara("game_user_level", "");
		String gameLoginId = getPara("game_login_id", "").trim();
		
		String orginGameLoginId = product.getStr("game_login_id"); //旧的游戏帐号
		int hasChangeGameLoginId = 1;
		//这是一个旧商品，支持修改一次商品账号
		if(product.getInt("has_change_game_login_id") == 0) {
			//支持修改，那么使用getPara的 game_login_id 值
			//但是用户这次又没有修改游戏账号，那么这个机会继续保留
			if(orginGameLoginId.equals(gameLoginId)) {
				hasChangeGameLoginId = 0;
			}
			//账号为空，则使用旧值
			else if(StringUtils.isBlank(gameLoginId)){
				hasChangeGameLoginId = 0;
				gameLoginId = orginGameLoginId;
			}
		}
		//不支持修改账号，重置回旧的值
		else{
			gameLoginId = orginGameLoginId;
		}
		 
		if(StringUtils.isBlank(gameLoginId)){
			errorPage("没有设置游戏登录账号");
			return;
		}
		String gameLoginPwd = getPara("game_login_password"); //允许留空，保留之前的设置
        int productType = getParaToInt("product_type", 0);
        if(productType <= 0){
            errorPage("没有指定需要发布的商品类型");
            return;
        }

		int minPlayScore = getParaToInt("min_play_score", 0);
		if(minPlayScore < 0)
			minPlayScore = 0;
		if(minPlayScore > 100)
			minPlayScore = 100;

		//在线时间
		int sellerOnlineBeginTime = getParaToInt("seller_online_begin_time", 7);
		int sellerOnlineEndTime = getParaToInt("seller_online_end_time", 24);
		//保证在合理范围
		if(sellerOnlineBeginTime < 0 || sellerOnlineBeginTime > 24 || sellerOnlineEndTime < 0 || sellerOnlineEndTime > 24){
			errorPage("您的号主在线时间必须在0时~24时的范围内。");
			return;
		}
		
		//进行排重，要求 游戏+渠道+账号 当前唯一上架
		if(Product.isDuplicateProduct(productType, sellerUid, product.getStr("game_id"), product.getStr("channel_id"), gameLoginId, productId)){
			errorPage("该客户端的游戏账号您当前已经发布成功一件租赁商品，无需重新发布。");
			return;
		}
		
		//图片
		String[] pics = getParaValues("pic");
		if(pics == null) pics = new String[0];
		if(productType != Product.PRODUCT_TYPE_VIP) {
            if (pics.length == 0) {
                errorPage("请至少上传1张游戏截图");
                return;
            }
            if (pics.length > 10) {
                errorPage("最多上传10张游戏截图");
                return;
            }
        }
		
		//优惠信息
		String promotions = getPara("promotion", "");
		if (ProductPromotionService.instance.validPromotionActivity(promotions)) {
			errorPage("时租满送优惠，不能送超过" + ProductPromotionService.PROMOTION_TYPE_HOUR_MAX + "个小时");
			return;
		}
		
		//扩展属性字段
		JSONArray extProps = new JSONArray();
		List<Record> propRows = SmartDb.find("select * from `product_properties` where `game_id`=?", product.getStr("game_id"));
		for(Record prop : propRows){
			JSONObject obj = new JSONObject();
			obj.put("prop_key", prop.getStr("prop_key"));
			obj.put("prop_name", prop.getStr("prop_name"));
			obj.put("prop_type", prop.getInt("prop_type"));
			if(prop.getInt("prop_type")==0) {
				obj.put("prop_value", getPara(prop.getStr("prop_key"), ""));
			}else {
				String [] values = getParaValues(prop.getStr("prop_key"));
				JSONArray valuesArray = new JSONArray();
				for(String value:values) {
					valuesArray.add(value);
				}
				obj.put("prop_value", valuesArray);
			}
			extProps.add(obj);
		}
		//视频VIP登录方式
		int vipLoginType = getParaToInt("vip_login_type",0);
		
		//获取渠道区服信息
		String channelId = getPara("channel_id");
		String gamePartitionId = getPara("game_partition_id");
        String partitionName = null;
        String channelName = null;

        //如果是会员VIP，不会有游戏信息，其余的账号类型才需要获取！
        if (productType != Product.PRODUCT_TYPE_VIP) {
            //游戏区服
            DataBean<GamePartition> partitionBean = gameService.getGamePartitionById(product.getStr("game_id"), gamePartitionId);
            if(partitionBean == null || partitionBean.getData() == null){
                errorPage("不存在的游戏区服");
                return;
            }
            GamePartition partition = partitionBean.getData();
            partitionName = partition.getPartitionName();

            //游戏渠道
            DataBean<Channel> channelBean = gameService.getChannel(channelId);
            if (channelBean == null || channelBean.getData() == null) {
                errorPage("不存在的游戏渠道");
                return;
            }
            Channel channel = channelBean.getData();
            channelName = channel.getChannelName();
        }
		
		//获取当前卖家的信誉分
		Record member = User.getMember(sellerUid);
		int score = member.getInt("reputation_score");
		//如果是端游，则用端游的号主等级，其他一律用手游的号主等级
		int sellLevel = member.getInt("sell_level");
		if(product.getInt("product_type")==Product.PRODUCT_TYPE_PCGAME)
			product.set("sell_level", member.getInt("pc_sell_level"));
		int gameLoginType = getParaToInt("game_login_type",1);
		

        //合租者UID
        int cooperationUid = getParaToInt("cooperation_uid", 0);
        int coopFeeRate = getParaToInt("coop_fee_rate", 0);
        
        Record shopInfo = null;
        if(cooperationUid > 0 && coopFeeRate > 0){
        	shopInfo = SmartDb.findFirst("select * from `shop_info` where `uid`=?", sellerUid);
        	if(shopInfo == null){
        		errorPage("您还没有开通商铺功能，无法关联合租者，若希望开通商铺请联系客服处理。");
        		return;
        	}
        }

        //是否支持求助
        int supportHelp = game.getInt("support_help");
        //支持求助，同时又支持号主自选，那么由参数决定
        if(game.getInt("support_help") == GameConf.SUPPORT_HELP_YES
                && game.getInt("force_seller_help") == GameConf.SUPPORT_HELP_NO){
            supportHelp = getParaToInt("support_help", GameConf.SUPPORT_HELP_NO); //界面不勾选的时候会不带这个参数，默认认为不支持求助吧
        }

		Record row = new Record();
		if(StringUtils.isNotBlank(channelId))
			row.set("channel_id", channelId);
		if(StringUtils.isNotBlank(channelName))
			row.set("channel_name", channelName);
		if(StringUtils.isNotBlank(gamePartitionId))
			row.set("game_partition_id", gamePartitionId);
		if(StringUtils.isNotBlank(partitionName))
			row.set("game_partition_name", partitionName);
		row.set("product_id", productId);
		row.set("game_login_type",gameLoginType);
		row.set("name", name);
		row.set("info", info);
		row.set("forbidden", forbidden);
		row.set("price_hour", priceHour);
		row.set("price_day", priceDay);
		row.set("price_night", priceNight);
		row.set("min_rent_time", minRentTime);
		row.set("guarantee_deposit", guaranteeDeposit);
		row.set("game_role_name", gameRoleName);
		row.set("game_user_level", gameUserLevel);
		row.set("game_login_id", gameLoginId);
		row.set("reputation_score", score);
		row.set("min_play_score", minPlayScore);
		row.set("extern_properties", extProps.toString());
		row.set("sell_level", sellLevel);
		row.set("seller_online_begin_time", sellerOnlineBeginTime);
		row.set("seller_online_end_time", sellerOnlineEndTime);
		row.set("vip_login_type", vipLoginType);
		row.set("has_change_game_login_id", hasChangeGameLoginId);
		row.set("support_help", supportHelp);
		row.set("onsale_protect_time", onsaleProtectTime);
		//有修改登录密码
		if(StringUtils.isNotBlank(gameLoginPwd)){
			row.set("game_login_password", gameLoginPwd);
		}
		String sellPid = null;
		//商品名称和时租价如果有变化，则重新生成上架号
		if (product.getInt("price_hour") != priceHour || !product.getStr("name").equals(name)) {
			sellPid = Common.md5(product.getStr("name") + product.getInt("price_hour"));
			row.set("sell_pid", sellPid);
		}
		
		//首先判断是否为扶持商品
		if(product.getInt("support_type")==Product.SUPPORT_TYPE_SUPPORTED) {
			//判断保证金、卖家等级、信誉分是否满足条件
			if(product.getInt("seller_guarantee_amount")<=0||score<Product.SUPPORT_REPUTATION_SCORE_MIN||sellLevel!=User.SELL_LEVEL_NORMAL) {
				row.set("support_type", Product.SUPPORT_TYPE_DISSATISFY);
				//SmartDb.update("delete from product_support_apply where product_id=? ", productId);
			}else {
				if(StringUtils.isNotBlank(sellPid)) {
					row.set("support_type", Product.SUPPORT_TYPE_NO_SUPPORT);
				    SmartDb.update("update `product_support_apply` set `sell_pid`=?, `status`=0 where product_id=? and `sell_pid`!=?", sellPid, productId, sellPid);
				}
			}
		}else if(product.getInt("support_type")==Product.SUPPORT_TYPE_DISSATISFY) {
			if(StringUtils.isBlank(sellPid)&&product.getInt("seller_guarantee_amount")>0&&score>=100&&sellLevel==User.SELL_LEVEL_NORMAL) {
				row.set("support_type", Product.SUPPORT_TYPE_SUPPORTED);
			}
		}
		row.set("status", Product.STATUS_VERIFY); //修改商品之后，进入待审核状态
		
		if(shopInfo != null){
			row.set("cooperation_uid", cooperationUid);
		}else{
			row.set("cooperation_uid", 0);
		}
		
		if(!SmartDb.update("product", "product_id", row)){
			logger.error("修改商品失败，product_id=>" + productId + ", sql=>" + SmartDb.lastQuery());
			errorPage("修改商品信息失败了");
			return;
		}
		
		//重新绑定用户自己上传的图片
		SmartDb.update("delete from product_picture where product_id=? and `type`=?", productId, Product.PIC_TYPE_USER);
		for(String pic : pics){	
			Record picRow = new Record();
			picRow.set("product_id", productId);
			picRow.set("pic_url", pic);
			picRow.set("type", Product.PIC_TYPE_USER);
			picRow.set("c_time", Common.now());
			if(!SmartDb.save("product_picture", picRow)){
				logger.error("保存商品截图失败，productId=>" + productId + "， pic_url=>" + pic + ", sql=>" + SmartDb.lastQuery());
			}
		}
		//保存商品的优惠信息
		JSONObject promotionValidTitle = ProductPromotionService.instance.savePromotionActivity(promotions,productId);
		String promoteTitle = promotionValidTitle!=null && promotionValidTitle.size()>0 ? promotionValidTitle.toString():null;
		row.keep("product_id");
		row.set("promotion_properties",promoteTitle);
		if(!SmartDb.update("product","product_id",row)){
			logger.error("保存商品优惠信息失败，productId=>" + productId + ", sql => " + SmartDb.lastQuery(), SmartDb.getException());
		}

		boolean isSetSellerGuaranteeAmounSuccess = product.getInt("seller_guarantee_amount") > 0 ? true:false;
		setAttr("isSetSellerGuaranteeAmounSuccess",isSetSellerGuaranteeAmounSuccess);
		setAttr("msg", "商品更新成功，审核成功后将自动上架！");
		setAttr("product_id", productId);
		setAttr("is_seller_normal ",sellLevel==0?true:false);
		
		//如果有合租者的话
		//保存商品之后，同时将合租分成信息存储到 shop_product_royalty
		if(shopInfo != null){
			Record royalty = SmartDb.findFirst("select * from `shop_product_royalty` where `product_id`=?", productId);
			//编辑商品时，若没有合租者则新建
			if(royalty == null){
				royalty = new Record();
				royalty.set("shop_id", shopInfo.getInt("id"));
				royalty.set("shop_uid", sellerUid);
				royalty.set("product_id", productId);
				royalty.set("cooperation_uid", cooperationUid);
				royalty.set("royalty", coopFeeRate);
				royalty.set("update_time", Common.now());
				royalty.set("create_time", Common.now());
				if(!SmartDb.save("shop_product_royalty", royalty)){
					logger.error("商品【" + productId + "】在关联合租者时发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				}
			}else{
				royalty.keep("product_id");
				royalty.set("cooperation_uid", cooperationUid);
				royalty.set("royalty", coopFeeRate);
				royalty.set("update_time", Common.now());
				if(!SmartDb.update("shop_product_royalty", "product_id", royalty)){
					logger.error("商品【" + productId + "】在修改时关联合租者时发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				}
			}
		}else{
			SmartDb.update("delete from `shop_product_royalty` where `product_id`=? limit 1", productId);
		}
		
		render("succ.html");
	}
	
	/**
	 * 上传图片
	 */
	@Before(LoginInterceptor.class)
	public void uploadImg(){
		Integer sellerUid = getSessionAttr("uid");
		if(sellerUid == null){
			renderJson(buildResp(1, "尚未登录"));
			return;
		}
		UploadFile imgFile = getFile("file");
		if(imgFile == null){
			renderJson(buildResp(1, "没有上传文件"));
			return;
		}
		
		File file = imgFile.getFile();
		//确保图片数据不超过规定大小
		int maxImageSize = PropKit.getInt("product.max_image_size") * 1024;
		if(file.length() > maxImageSize){
			renderJson(buildResp(2, "图片大小超过最大限制:" + PropKit.getInt("product.max_image_size") + "Kb"));
		}
		
		//上传阿里云
		String key = "RENT_" + sellerUid + "/" + System.currentTimeMillis();
		logger.info("生成阿里云key=>" + key);
		if(!AliyunImageUtils.uploadFile(key, file)){
			renderJson(buildResp(2, "图片上传阿里云服务失败"));
			return;
		}
		//拼出这个图片URL
		String url = AliyunImageUtils.getUploadedImgUrl(key);
		logger.info("阿里云图片URL=>" + url);
		
		if(!file.delete()){
			logger.error("删除临时上传文件失败了。");
		}
		renderJson(buildResp(0, "ok", new KeyValue<>("url", url)));
	}
	

	/**
	 * 商品下架
	 */
	@Before(LoginInterceptor.class)
	public void offsale(){
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录之后再执行上架操作");
			return;
		}
		
		String productId = getPara("product_id");
		if(StringUtils.isBlank(productId)){
			errorPage("没有指定需要下架商品");
			return;
		}
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}
		
		//商品必须是上架状态或者被保护状态
		if(product.getInt("status") != Product.STATUS_ONSALE && product.getInt("status") != Product.STATUS_PROTECTED){
			errorPage("当前商品暂时不是上架状态，无法执行下架操作");
			return;
		}
		
		//确保商品是这个人的
		logger.info("offsale : 当前用户UID=" + uid + ", 商品卖家UID=" + product.getInt("seller_uid"));
		if(uid.intValue() != product.getInt("seller_uid").intValue()){
			errorPage("不允许对其他用户发布的商品进行操作");
			return;
		}
		
		if(!Product.offsale(productId, "用户下架", false)){
			logger.error("商品下架失败了，product_id=>" + productId + ", sql=>" + SmartDb.lastQuery());
			errorPage("商品下架时发生了错误");
			return;
		}

		redirect("../product/detail?product_id=" + productId);
	}
	
	@Before(LoginInterceptor.class)
	public void checkOnsale() {
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录之后再执行上架操作");
			return;
		}
		String productId = getPara("product_id", "");
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
		    renderJson(buildResp(Common.RESPONSE_EXCEPTION, "不存在的商品"));
			return ;
		}
		
		//检查当前商品是否被限制上架了
		Date limitOnsaleTime = product.getDate("limit_onsale_time");
		if(limitOnsaleTime == null || limitOnsaleTime.getTime() <= System.currentTimeMillis()){
			renderJson(buildResp(Common.RESPONSE_SUCCESS, "没有被封禁"));
			return;
		}

		//处于限制上架期间
		renderJson(buildResp(Common.RESPONSE_FAIL, 
				"商品由管理员限制上架",
				new KeyValue<>("offsale_reason",product.getStr("offsale_reason")),
				new KeyValue<>("limit_onsale_time", Common.show_time(limitOnsaleTime))));
	}
	
	/**
	 * 商品直接上架
	 */
	@Before(LoginInterceptor.class)
	public void onsale(){
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录之后再执行上架操作");
			return;
		}
		String productId = getPara("product_id", "");
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}
		boolean isSetSellerGuaranteeAmounSuccess = product.getInt("seller_guarantee_amount") > 0 ? true:false;
		String gameLoginPwd = getPara("game_login_password", "");

		logger.info("onsale : 当前用户UID=" + uid + ", 商品卖家UID=" + product.getInt("seller_uid"));
		//确保商品是这个人的
		if(uid.intValue() != product.getInt("seller_uid").intValue()){
			errorPage("不允许对其他用户发布的商品进行操作");
			return;
		}

		//判断一下商品当前状态
		if(product.getInt("status") == Product.STATUS_RENT){
			errorPage("您的商品当前正在出租中！");
			return;
		}
		if(product.getInt("status") == Product.STATUS_VERIFY){
			errorPage("您的商品当前正在审核当中，通过后将自动上架！");
			return;
		}
		if(product.getInt("status") == Product.STATUS_ONSALE){
			errorPage("您的商品当前已上架，无需重复操作！");
			return;
		}

		//是否已经超过了数量限制
        if(Product.tooManyProducts(uid, Lists.newArrayList(productId))){
		    errorPage("您当前商品已经超过了数量限制【" + PropKit.getInt("product.max_product_count") + "件】，无法上架。");
		    return;
        }

		//进行排重，要求 游戏+渠道+账号 当前唯一上架
		if(Product.isDuplicateProduct(product.getInt("product_type"), uid, product.getStr("game_id"), product.getStr("channel_id"), product.getStr("game_login_id"), productId)){
			errorPage("该客户端的游戏账号您当前已经发布成功一件租赁商品，无需重新发布。");
			return;
		}

		//如果当前商品处于保护中的状态，允许直接上架不需审核！
		if(product.getInt("status") == Product.STATUS_PROTECTED){
			if(!Product.onsale(productId, product.getInt("seller_uid"), false)){
				logger.error("商品【" + productId + "】上架失败了！");
				errorPage("您的商品在上架时发生了错误。");
				return;
			}

			setAttr("msg", "您的商品已成功上架！");
			setAttr("product_id", productId);
			render("succ.html");
			return;
		}

		int supportType = product.getInt("support_type");
		int sellerGuaranteeAmount = product.getInt("seller_guarantee_amount");
		//执行上架操作
		product.keep("product_id");
		product.set("status", Product.STATUS_VERIFY);
		product.set("modify_time", Common.now());
		if(StringUtils.isNotBlank(gameLoginPwd)){
			product.set("game_login_password", gameLoginPwd);
		}
		//如果用户的扶持商品已经不符合条件，直接从申请表中删除
		Record user = User.getMember(uid);
		
		//如果是扶持商品，不满足扶持条件则踢出
        if(supportType == Product.SUPPORT_TYPE_SUPPORTED) {
			//判断保证金、卖家等级、信誉分是否满足条件
			if(sellerGuaranteeAmount<=0 || user.getInt("reputation_score")<Product.SUPPORT_REPUTATION_SCORE_MIN || user.getInt("sell_level")!=User.SELL_LEVEL_NORMAL) {
				product.set("support_type", Product.SUPPORT_TYPE_DISSATISFY);
				//SmartDb.update("delete from product_support_apply where product_id=?", productId);
			}
		}else if(supportType == Product.SUPPORT_TYPE_DISSATISFY) {
			if(sellerGuaranteeAmount> 0 && user.getInt("reputation_score")>=100&& user.getInt("sell_level")==User.SELL_LEVEL_NORMAL) {
				product.set("support_type", Product.SUPPORT_TYPE_SUPPORTED);
			}
		}
        Record productDecorate =	SmartDb.findFirst("select * from product_decorate_payment  where uid = ? and status = ? and pay_time <= ? and invalid_time >=?",
				uid,Product.DECORATE_PAYMENT_STATUS_PAYED,Common.now(),Common.now());
		if(productDecorate != null) {
			product.set("is_decorate", Product.PRODUCT_DECORATE);
		}

		//重新上架时更新一下卖家信誉分和等级
		product.set("reputation_score", user.getInt("reputation_score"));
		product.set("sell_level", user.getInt("sell_level"));
		
		if(!SmartDb.update("product", "product_id", product)){
			logger.error("重新上架商品失败了, product_id=>" + productId + ", sql=>" + SmartDb.lastQuery());
			errorPage("执行上架操作发生了错误");
			return;
		}
		
		setAttr("isSetSellerGuaranteeAmounSuccess", isSetSellerGuaranteeAmounSuccess);
		setAttr("msg", "发布成功,商品审核后将自动上架");
		setAttr("product_id", productId);
		setAttr("is_seller_normal ",user.getInt("sell_level")==0?true:false);
		render("succ.html");
	}

	/**
	 * 删除商品
	 * 如果商品设置保证金删除商品时返还号主保证金
	 * */
	@Before(LoginInterceptor.class)
	public void deleteProduct(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登陆后再执行商品删除操作");
			return;
		}
		
		//验证商品是否存在并且已经下架
		String productId = getPara("product_id");
		DistLocker locker = new DistLocker("guarantee-refundAmount-"+productId);
		boolean succ = false;
		try {
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if (!succ) {
				logger.error("下单加锁失败，productId=>" + productId);
				errorPage("服务器发生了一些错误，下单失败了");
				return;
			}
			Record product = SmartDb.findFirst("select * from product where product_id=? and `status` = ?", productId, Product.STATUS_OFFSALE);
			if (product == null) {
				errorPage("不存在的商品");
				return;
			}
			//判断是否为发布商品用户
			if (!uid.equals(product.getInt("seller_uid"))) {
				errorPage("无权限删除该商品");
				return;
			}
			
			int sellerGuaranteeAmount = product.getInt("seller_guarantee_amount");
			
			//更新商品状态
			Boolean isDeleted = Product.deleteProduct(productId);
			if (!isDeleted) {
				errorPage("删除商品失败");
				return;
			}

			String payId = null;
			//判断是否设置保证金
			if (sellerGuaranteeAmount > 0) {
				//插入交易记录
				Record guaranteeAmountOrder = SmartDb.findFirst("select * from guarantee_amount_order where product_id = ? and status = ? order by create_time desc", productId, Product.GUNRANTEE_AMOUNT_STATUS_PAYED);
				if (guaranteeAmountOrder == null) {
					logger.error("该商品没有支付保证金记录:" + productId);
					errorPage("该商品没有支付保证金记录");
					return;
				}
				logger.info("返还保证金转账成功：" + uid + "商品：" + productId + "保证金");
				payId = guaranteeAmountOrder.getStr("pay_id");
				guaranteeAmountOrder.keep("id");
				guaranteeAmountOrder.set("status", Product.GUNRANTEE_AMOUNT_STATUS_REFUNDED);
				guaranteeAmountOrder.set("refund_time", Common.now());
				if (!SmartDb.update("guarantee_amount_order", "id", guaranteeAmountOrder)) {
					logger.error("返还保证金更新订单列表失败，用户：" + uid + "商品：" + productId);
					errorPage("返还保证金更新订单列表失败");
					return;
				}
				logger.info("返还保证金更新订单列表成功，用户：" + uid + "商品：" + productId);
			}

			//返还保证金
			if(sellerGuaranteeAmount > 0 && StringUtils.isNotBlank(payId)){
				if (!payment.refundGuarantee(product, payId, sellerGuaranteeAmount)) {
					logger.error("返还保证金失败：" + uid + "商品：" + productId + "保证金");
					errorPage("返还保证金失败");
					return;
				}
			}
			
		}finally {
			if(succ) locker.unlock();
		}
		setAttr("product_id", productId);
		redirect("/user/myproducts");
	}

	/**
	 * 设置保证金
	 * 商品设置保证金
	 * */
	public void setSellerGuaranteeAmount(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登陆后再执行匿名举报");
			return;
		}
		
		//验证商品是否存在并且已经下架
		String productId = getPara("product_id");
		DistLocker locker = new DistLocker("guarantee-setAmount-"+productId);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("下单加锁失败，productId=>" + productId);
				errorPage("服务器发生了一些错误，下单失败了");
				return;
			}
			Record product = SmartDb.findFirst("select * from product where product_id=? and `status` not in (?,?) ", productId,Product.STATUS_DELETE,Product.STATUS_RENT);
			if(product == null){
				errorPage("不存在的商品");
				return;
			}
			//判断是否为发布商品用户
			if(!uid.equals(product.getInt("seller_uid"))){
				errorPage("无权限设置该商品");
				return;
			}

			if(product.getInt("seller_guarantee_amount")>0){
				errorPage("该商品已设置保证金");
				return;
			}

			Record guaranteeAmoutOrder = new Record();
			String payId = generateGuaranteeOrderId();
			Integer amount = PropKit.getInt("product.guarantee_amount");
			guaranteeAmoutOrder.set("pay_id",payId);
			guaranteeAmoutOrder.set("create_time",Common.now());
			guaranteeAmoutOrder.set("amount",amount);
			guaranteeAmoutOrder.set("product_id",productId);
			guaranteeAmoutOrder.set("uid",uid);
			guaranteeAmoutOrder.set("status",Product.GUNRANTEE_AMOUNT_STATUS_NEW);
			if(!SmartDb.save("guarantee_amount_order", guaranteeAmoutOrder)){
				logger.error("保存保证金支付记录失败："+productId);
				return;
			}
			
			int isNewVersion = getParaToInt("is_new_version", 0);
			String clientType = getAttr("client_type");
			//FIXME 因为app微信支付有问题，让页面跳转到wap界面操作。
			if(!"pc".equalsIgnoreCase(clientType)/* && isNewVersion==0*/){
				String html = payment.payGuarantee(product, payId, amount, Common.getIp(getRequest()));
				if(StringUtils.isBlank(html)){
					errorPage("支付时发生了一些意外，请稍后重试。");
					return;
				}
				renderHtml(html);
				return;
			}

			redirect("/pc/pay/guanIndex?pay_id=" + payId);
			return;
			
			//生成支付页面并跳转到支付页
/*			String html = payment.payGuarantee(product, payId, amount, Common.getIp(getRequest()));
			if(StringUtils.isBlank(html)){
				errorPage("支付时发生了一些意外，请稍后重试。");
				return;
			}
			renderHtml(html);*/
		}finally{
			if(succ) locker.unlock();
		}
	}

	/**
	 * 设置保证金成功回调页面
	 * */
	public void setSellerGuaranteeAmountSuccess(){
		String msg = getPara("msg","");
		String productId = getPara("product_id","");
		setAttr("msg",msg);
		setAttr("product_id",productId);
		setAttr("isSetSellerGuaranteeAmounSuccess",true);
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		boolean isSupportProduct = false;
		//满足条件，可以申请扶持
		if(product.getInt("sell_level")==User.SELL_LEVEL_NORMAL && product.getInt("reputation_score")>=100
				&& product.getInt("seller_guarantee_amount") > 0&&product.getInt("status")==Product.STATUS_ONSALE
				&&product.getInt("product_type")==Product.PRODUCT_TYPE_GAME) {
			if(product.getInt("support_type")==Product.SUPPORT_TYPE_NO_SUPPORT)
			    isSupportProduct = true;
			else if(product.getInt("support_type")==Product.SUPPORT_TYPE_DISSATISFY) {
				SmartDb.update("update `product` set support_type = ? where `product_id`=?", Product.SUPPORT_TYPE_SUPPORTED,productId);
			}
		}
		setAttr("isSupportProduct", isSupportProduct);
		render("succ.html");
	}


	private String generateGuaranteeOrderId(){
		return "GUORD-" + Common.now("yyMMdd-HHmmssSSS") + String.format("%02d", Common.rand(0, 99));
	}
	
	/**
	 * 申请商品扶持
	 */
	@Before(LoginInterceptor.class)
	public void applySupprot() {
		Integer uid = getSessionAttr("uid");
		if (uid == null) {
			renderJson(buildResp(1, "请登录之后再执行扶持操作"));
			return;
		}
		String productId = getPara("product_id", "");
		Record member = SmartDb.findFirst("select * from `member` where `uid` =?",uid);
		try {
			//将用户表中的信誉分、用户等级同步到product表
		    SmartDb.update("update prodcut set sell_level =?,reputation_score=? where `product_id` =? and `seller_uid` =? ", member.getInt("sell_level"),member.getInt("reputation_score"),productId,uid);
		} catch (Exception e) {
			logger.info("将member表中同步信息到product表中失败，product_id="+productId+"，uid="+uid);
		}
		
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if (product == null) {
			renderJson(buildResp(1, "不存在的商品"));
			return;
		}
		// 确保商品是这个人的
		if (uid.intValue() != product.getInt("seller_uid").intValue()) {
			renderJson(buildResp(1, "不允许对其他用户发布的商品进行操作"));
			return;
		}
		// 判断一下商品当前状态，只有上架和出租中的商品能够申请扶持
		if (product.getInt("status") == Product.STATUS_VERIFY || product.getInt("status") == Product.STATUS_OFFSALE
				|| product.getInt("status") == Product.STATUS_PROTECTED) {
			renderJson(buildResp(1, "不允许对未上架的商品进行扶持操作！"));
			return;
		}
		// 判断一下商品是否满足扶持条件
		if (product.getInt("seller_guarantee_amount") <= 0) {
			renderJson(buildResp(1, "您的商品未设置保证金，请先设置保证金后再申请扶持"));
			return;
		}
		if (product.getInt("sell_level") != User.SELL_LEVEL_NORMAL) {
			renderJson(buildResp(1, "您是签约号主，不符合申请扶持条件"));
			return;
		}
		if (product.getInt("support_type") == Product.SUPPORT_TYPE_VERIFY) {
			renderJson(buildResp(1, "您的扶持商品申请正在审核中"));
			return;
		}
		if (product.getInt("support_type") == Product.SUPPORT_TYPE_SUPPORTED) {
			renderJson(buildResp(1, "您的商品当前已申请扶持，无需重复操作"));
			return;
		}
		if (product.getInt("reputation_score") < 100) {
			renderJson(buildResp(1, "您的信誉分不满足申请扶持条件，若您号主信誉分已达100分，请重新上架商品！"));
			return;
		}
		if (product.getInt("product_type") != GameConf.TYPE_GAME) {
			renderJson(buildResp(1, "只有手游类商品才能申请加入扶持"));
			return;
		}
		if(member.getInt("support_status")==User.USER_IS_NOT_SUPPORT) {
			renderJson(buildResp(1, "您暂时不符合申请扶持条件"));
			return;
		}
		
		Record productApply = new Record();
		productApply.set("product_id", productId);
		productApply.set("sell_pid", product.getStr("sell_pid"));
		productApply.set("status", 0);
		productApply.set("create_time", Common.show_time(System.currentTimeMillis()));
		productApply.set("seller_uid", product.getInt("seller_uid"));

		// 根据product_id 申请记录是否存在，不存在则新增，存在则更新
		boolean isSuccess = false;
		Record productApplyHis = SmartDb.findFirst("select * from `product_support_apply` where `product_id`=?",productId);
		if (productApplyHis == null) {
			isSuccess = SmartDb.save("product_support_apply", productApply);
		} else {
			isSuccess = SmartDb.update("product_support_apply", "product_id", productApply);
		}

		// 修改product状态信息
		// 添加申请扶持记录
		product.keep("product_id");
		product.set("modify_time", Common.now());
		product.set("support_type", Product.SUPPORT_TYPE_VERIFY);
		if (!isSuccess || !SmartDb.update("product", "product_id", product)) {
			logger.error("商品申请扶持失败，productId=>" + productId + ", sql => " + SmartDb.lastQuery(), SmartDb.getException());
			logger.error("商品申请扶持失败, product_id=>" + productId + ", sql=>" + SmartDb.lastQuery());
			renderJson(buildResp(1, "商品申请扶持失败"));
			return;
		}
		renderJson(buildResp(0, "您已成功提交加入，我们会尽快审核~"));
	}
	
	/**
	 * 取消商品扶持
	 */
	@Before(LoginInterceptor.class)
	public void abolishSupprot() {
		Integer uid = getSessionAttr("uid");
		if (uid == null) {
			errorPage("请登录之后再执行上架操作");
			return;
		}
		String productId = getPara("product_id", "");
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if (product == null) {
			renderJson(buildResp(1, "不存在的商品"));
			return;
		}
		// 确保商品是这个人的
		if (uid.intValue() != product.getInt("seller_uid").intValue()) {
			renderJson(buildResp(1,"不允许对其他用户发布的商品进行操作"));
			return;
		}
		if(product.getInt("support_type")==Product.SUPPORT_TYPE_VERIFY){
			renderJson(buildResp(1,"您的商品扶持正在审核中"));
			return;
		}
		if(product.getInt("support_type")==Product.SUPPORT_TYPE_NO_SUPPORT){
			renderJson(buildResp(1,"您的商品当前已取消扶持，无需重复操作"));
			return;
		}
		SmartDb.update("delete from product_support_apply where product_id=? ", productId);
		product.keep("product_id");
		product.set("modify_time", Common.now());
		product.set("support_type", Product.SUPPORT_TYPE_NO_SUPPORT);
		product.set("cancel_support_time", Common.now());
		if(!SmartDb.update("product", "product_id", product)){
			logger.error("商品取消扶持失败, product_id=>" + productId + ", sql=>" + SmartDb.lastQuery());
			renderJson(buildResp(1,"取消扶持商品失败"));
			return ;
		}
		renderJson(buildResp(0,"取消扶持商品成功"));
	}

}
