package cn.jugame.rent.page;

import cn.jugame.rent.bean.GameConf;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.UserInfoInterceptor;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.slf4j.Logger;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Before({LoginInterceptor.class, UserInfoInterceptor.class})
public class OrderDetailController extends BaseController{
	
	private Logger logger = Loggers.rentLog();
	
	/**
	 * 玩家侧的订单详情
	 */
	public void index(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再获取订单详情");
			return;
		}
		setAttr("uid",uid);
		String orderId = getPara("order_id", "");
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=? and `buyuser_uid`=?", orderId, uid);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}

		//设置订单
        order.set("refund_status_desc", parseRefundStatusDesc(order, true));
		setAttr("order", order2map(order));
		
		//同时将租赁单全部获取出来
		List<Record> relets = SmartDb.find("select * from `order_relet` where `order_id`=? order by `id` asc", order.getStr("order_id"));
		setAttr("relets", relets2map(relets));
        
        //根据订单详情展示不同的界面
        if(order.getInt("order_status") == Order.ORDER_STATUS_NEW){
        	buyuserOrderDetailNew(order);
        }
        else if(order.getInt("order_status") == Order.ORDER_STATUS_PAID){
        	buyuserOrderDetailPaid(order);
        }
        else if(order.getInt("order_status") == Order.ORDER_STATUS_PAYING){
        	buyuserOrderDetailPaying(order);
        }
        else if(order.getInt("order_status") == Order.ORDER_STATUS_FINISH){
        	buyuserOrderDetailSucc(order);
        }
        else if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
        	buyuserOrderDetailCancel(order);
        }
        else{
        	errorPage("错误的订单状态");
        }
	}
	
	/**
	 * 玩家侧订单详情（新建状态）
	 */
	private void buyuserOrderDetailNew(Record order){
		//提示语
		setAttr("title", "等待支付...");
		setAttr("tips", "已为您锁定商品，请于5分钟内支付完成。");
		
		render("/view/order/order_new.html");
	}
	
	/**
	 * 玩家侧订单详情（租赁中/已支付）
	 */
	private void buyuserOrderDetailPaid(Record order){
		//是否支持号主求助
		//设置了 support_help, can_help, help_left_time 属性
		setOrderHelpAttr(order, true);
		
		boolean canCancel = true;
		//是否超过额定申请次数，超过了就不允许再提交申请撤单了
		Record cancelApplyCount = SmartDb.findFirst("select count(id) as _count from `order_cancel_apply` where `order_id`=?", order.getStr("order_id"));
		if(cancelApplyCount.getInt("_count") >= PropKit.getInt("order.max_cancel_apply_times")){
			canCancel = false;
		}

		//当前订单是否还能续租
		boolean canRelet = true;
		//续租必须超过免责撤单时间(15分钟)
		//如果续租已经不足以支持支付超时时间了，就不让续租了
		if(System.currentTimeMillis() - order.getDate("rent_start_time").getTime() < PropKit.getInt("order.self_cancel_order.timeout")*1000L
				|| order.getDate("rent_end_time").getTime() - System.currentTimeMillis() < PropKit.getInt("order.pay_timeout")*1000L){
			canRelet = false;
		}
		
		//如果正在申请撤单，那么不再允许重复撤单，也不允许续租，setOrderHelpAttr中同样也禁止了求助
		Record apply = SmartDb.findFirst("select * from `order_cancel_apply` where `order_id`=? order by `id` desc limit 1", order.getStr("order_id"));
		if(apply != null){
			Map<String, Object> cancelApply = new HashMap<>();
			cancelApply.put("cancel_apply_status", apply.getInt("status"));
			cancelApply.put("cancel_reason", apply.getStr("cancel_reason"));
			cancelApply.put("check_reason", apply.getStr("check_reason"));
			setAttr("cancel_apply", cancelApply);
			
			//如果正在申请中，设置can_cancel为false，暂时不允许撤单
			if(apply.getInt("status") == Order.ORDER_CANCEL_APPLY_NEW){
				canCancel = false;
				canRelet = false;
			}
		}
		
		setAttr("can_cancel", canCancel);
		setAttr("can_relet", canRelet);
		
		//提示语
		setAttr("title", "已支付");
		setAttr("tips", "请在15分钟内登录账号进行验收，如遇账号密码不对/描述不符等问题且号主无法解决时，可直接申请撤单； 如中途遇到（频繁顶号等）号主违规行为，请记录违规凭证（如截图）并联系平台客服进行撤单维权。"); //默认的提示语
		//如果当前正在提交申请
		if(apply != null && apply.getInt("status") == Order.ORDER_CANCEL_APPLY_NEW){
			setAttr("subtitle", "撤单申请：" + apply.getStr("cancel_reason"));
			setAttr("tips", "您的订单已经成功提交撤单申请，我们将尽快为您处理，请耐心等候。");
		}
		//提交的最后一次申请不允许撤单！
		if(apply != null && apply.getInt("status") == Order.ORDER_CANCEL_APPLY_FAIL){
			String tips = "您的撤单申请【" + apply.getStr("cancel_reason") + "】审核失败，原因【" + apply.getStr("check_reason") + "】，订单将继续有效。";
			if(canCancel){
				tips += "订单有效期内您还有一次撤单申请机会，如有需要可点击下方“申请撤单”重新提交申请，感谢您的支持。";
			}
			setAttr("tips", tips);
		}
		
		//如果有上号码，将上号码带上
		if(order.getInt("selluser_game_login_type") == Product.LOGIN_PC_AUTOKIT
				|| order.getInt("selluser_game_login_type") == Product.LOGIN_MOBILE_AUTOKIT){
			Record loginkey = SmartDb.findFirst("select * from `order_loginkey` where `order_id`=? limit 1", order.getStr("order_id"));
			//还在有效期内
			if(loginkey != null && loginkey.getInt("status") == Order.LOGINKEY_STATUS_VALID){
				setAttr("login_key", loginkey.getStr("loginkey"));
			}
		}
		
		//是否为qq登录的渠道，需要提示特定的信息
		String[] qqLoginConfs = Common.array_filter(PropKit.get("qq_speciallogin_gameconf").split(","));
		setAttr("qq_special_login_remind", Common.in(order.getStr("game_id"), qqLoginConfs));
		
		//当前客服是否下班了
		boolean isKefuRest = Common.inHour(PropKit.getInt("kefu.rest_time.begin"), PropKit.getInt("kefu.rest_time.end"));
		setAttr("is_kefu_rest", isKefuRest);
		
		//订单起租时间开始计算的已过分钟数
		long passTime = System.currentTimeMillis() - order.getDate("rent_start_time").getTime();
		long passTimeMinute = passTime / 60000;
		setAttr("rent_pass_time", passTimeMinute);

		//如果是VIP会员，需要增加显示登录方式
        setAttr("vip_login_type", 0);
        if(order.getInt("product_type") == Product.PRODUCT_TYPE_VIP) {
            Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", order.getStr("product_id"));
            setAttr("vip_login_type", product.getInt("vip_login_type"));
        }

		render("/view/order/order_paid.html");
	}
	
	/**
	 * 玩家侧订单详情（租赁中/已支付）
	 */
	private void buyuserOrderDetailPaying(Record order){
		//提示语
		setAttr("title", "续租等待支付...");
		setAttr("tips", "请于5分钟内支付完成。");
		
		render("/view/order/order_paying.html");
	}
	
	/**
	 * 玩家侧订单详情（交易完成）
	 */
	private void buyuserOrderDetailSucc(Record order){
		//是否有仲裁
		Map<String, Object> arbitrate = new HashMap<>();
		int isSelluserArbitrate = order.getInt("is_selluser_arbitrate");
		int punishmentWay = 0;
		//如果仲裁成功了，则获取仲裁的具体判罚方式
		if(isSelluserArbitrate == Order.SELLUSER_ARBITRATE_SUCC){
			Record arRow = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", order.getStr("order_id"));

			arbitrate.put("is_arbitrate", true);
			arbitrate.put("punishment_way", arRow.getInt("punishment_way"));
			arbitrate.put("arbitrate_reason", arRow.getStr("arbitrate_reason"));
			
			punishmentWay = arRow.getInt("punishment_way");
		}else{
			arbitrate.put("is_arbitrate", false);
		}
		setAttr("arbitrate", arbitrate);
		
		//提示语
		setAttr("title", "交易完成");
		//如果遭遇了号主仲裁
        if(isSelluserArbitrate == Order.SELLUSER_ARBITRATE_SUCC){
            String tips = "<b>您本次租号行为遭遇了号主仲裁，";
            if(punishmentWay == Order.PUNISHMENT_DO_NOTHING){
                tips += "平台将持续关注您是否继续违规，";
            }
            if(punishmentWay == Order.PUNISHMENT_DECREASE_BUYERSCORE){
                tips += "平台判定您违规并扣除您一定的玩家信誉分作为警告，";
            }
            else if(punishmentWay == Order.PUNISHMENT_ALL_BUYER){
                tips += "平台判定您违规并扣除您的押金，";
            }
            tips += "请以后文明租号！</b>";
            setAttr("tips", tips);
        }
        //没有遭遇号主仲裁
        else{
            String tips = "共建文明租号，感谢您的支持。";
            //有押金要退还
            if(order.getInt("order_guarantee_deposit") > 0){
                if(order.getInt("order_isrefund_guarantee") == Order.ORDER_REFUNDED){
                    tips = "您的押金已经退还，请注意查收。共建文明租号，感谢您的支持。";
                }else{
                    tips = "您的押金将在24小时无号主投诉后退还您的账户，请耐心等候，感谢您的支持和理解。";
                }
            }
            setAttr("tips", tips);
        }

        render("/view/order/order_succ.html");
	}
	
	/**
	 * 玩家侧订单详情（交易取消）
	 */
	private void buyuserOrderDetailCancel(Record order){
		//是否有仲裁
		Map<String, Object> arbitrate = new HashMap<>();
		int isSelluserArbitrate = order.getInt("is_selluser_arbitrate");
		int punishmentWay = 0;
		//如果仲裁成功了，则获取仲裁的具体判罚方式
		if(isSelluserArbitrate == Order.SELLUSER_ARBITRATE_SUCC){
			Record arRow = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", order.getStr("order_id"));
			punishmentWay = arRow.getInt("punishment_way");

			arbitrate.put("is_arbitrate", true);
			arbitrate.put("punishment_way", punishmentWay);
			arbitrate.put("arbitrate_reason", arRow.getStr("arbitrate_reason"));
		}else{
			arbitrate.put("is_arbitrate", false);
		}
		setAttr("arbitrate", arbitrate);
		
		//提示语
		setAttr("title", "已取消");
		setAttr("subtitle", order.getStr("cancel_reason"));

		if(order.getInt("order_ispay") == Order.ORDER_PAID) {
            boolean freeCancel = order.getInt("is_free_cancel") == 1;
            boolean delayRefund = Order.isDelayRefund(order, freeCancel);
            //免责情况下
            String tips = "已成功为您撤单，";
            if (freeCancel) {
                if (delayRefund) {
                    tips += "您的租金押金将在24小时无号主投诉后全额返还到您的账户中，请耐心等候。";
                } else {
                    tips += "您的租金押金已经全额返还到您的账户，请注意查收。";
                }
            } else {
                //有责肯定是要延迟到账的
                tips += "您的租金将按30分钟为梯度进行计时收费，并在24小时无号主投诉后将剩余的租金和押金返还到您的账户中，请耐心等候。";
            }
            //如果遭遇了号主仲裁
            if(isSelluserArbitrate == Order.SELLUSER_ARBITRATE_SUCC){
                tips += "<br><b>您本次租号行为遭遇了号主仲裁，";
                if(punishmentWay == Order.PUNISHMENT_DO_NOTHING){
                    tips += "平台将持续关注您是否继续违规，";
                }
                if(punishmentWay == Order.PUNISHMENT_DECREASE_BUYERSCORE){
                    tips += "平台判定您违规并扣除您一定的玩家信誉分作为警告，";
                }
                else if(punishmentWay == Order.PUNISHMENT_ALL_BUYER){
                    tips += "平台判定您违规并扣除您的押金。";
                }
                tips += "请以后文明租号！</b>";
            }
            setAttr("tips", tips);
        }
        //若是未支付的
        else{
		    setAttr("tips", "您的订单因为超时未支付而由系统自动取消了。如果您当天因为未支付而导致过多订单取消，将有可能影响到您的信誉分，文明租号，你我共建！");
        }

		render("/view/order/order_fail.html");
	}
	
	/**
	 * 号主侧的订单详情
	 */
	public void seller(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再获取订单详情");
			return;
		}
		setAttr("uid",uid);
		String orderId = getPara("order_id", "");
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=? and `selluser_uid`=?", orderId, uid);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
        
        setAttr("order", order2map(order));

        //同时将租赁单全部获取出来
        List<Record> relets = SmartDb.find("select * from `order_relet` where `order_id`=? order by `id` asc", order.getStr("order_id"));
        setAttr("relets", relets2map(relets));

        //当前是否支持求助，如果支持求助且 还在求助时间范围内，则可以发起聊天
        setAttr("can_help", false); // 默认不支持号主求助

		//是否支持仲裁
		setAttr("can_arbitrate", orderCanArbitrate(order));

		//是否支持停止订单
        setAttr("can_stop", false);
        
        //提示语
        if(order.getInt("order_status") == Order.ORDER_STATUS_PAID){
        	setAttr("title", "已支付");
        	//如果订单当前正在仲裁
        	setAttr("tips", "订单结束前请勿随意改动密码或者顶号，如接到玩家投诉，您有可能将面临扣除保证金或者信誉分的风险。");
        	
        	//判断是否支持求助
    		boolean supportHelp = order.getInt("support_help") == GameConf.SUPPORT_HELP_YES;
    		if(supportHelp){
    		    //当前是否存在撤单申请
                Record cancelApply = SmartDb.findFirst("select * from `order_cancel_apply` where `order_id`=? order by `id` desc limit 1", orderId);
                boolean isCanceling = (cancelApply != null && cancelApply.getInt("status") == Order.ORDER_CANCEL_APPLY_NEW);

                //当前时间是否还支持求助
    			long supportHelpTime = order.getDate("rent_start_time").getTime() + PropKit.getInt("order.order_help.timeout")*1000L;

    			//号主在线时间
                boolean isOnline = Common.inHour(order.getInt("seller_online_begin_time"), order.getInt("seller_online_end_time"));

                //可求助时间范围内 + 没有撤单申请 + 号主在线时间内
    			if(supportHelpTime > System.currentTimeMillis() && !isCanceling && isOnline){
    				setAttr("can_help", true);
    			}
    		}

    		//已支付状态，同时起租时间15分钟之后，那么支持停止订单
            Date rentStartTime = order.getDate("rent_start_time");
            if(System.currentTimeMillis() - rentStartTime.getTime() >= PropKit.getInt("order.self_cancel_order.timeout")*1000L){
                setAttr("can_stop", true);
            }
        }

        if(order.getInt("order_status") == Order.ORDER_STATUS_FINISH
                || order.getInt("order_status") == Order.ORDER_STATUS_CANCEL) {
            String tips = null;
            String subtitle = null;
            //订单结束的资金说明
            if(order.getInt("order_status") == Order.ORDER_STATUS_FINISH){
                setAttr("title", "交易完成");
                tips = "订单租金已经转到您的账户，请注意查收。";
                if(orderCanArbitrate(order)){
                    tips += "若您怀疑玩家存在毁号行为，您可以在12小时内提交证据并对玩家发起仲裁。感谢您的支持。";
                }
            }
            if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
                setAttr("title", "已取消");
                subtitle = "原因【" + order.getStr("cancel_reason") + "】";

                boolean delay = Order.isDelayRefund(order, order.getInt("is_free_cancel") == Order.FREE_CANCEL);
                if (delay) {
                    tips = "已产生的租金将会在订单结束24小时后到账，请注意查收。";
                } else {
                    tips = "已产生的租金已经到账，请注意查收。";
                }

                if (order.getInt("is_deducted_guarantee_amount") == Order.ORDER_DEDUCTED_GUARANTEE) {
                    tips += "本次撤单需扣除您5元保证金，订单结束前请勿随意更改账号密码或顶号，如接到玩家投诉，您可能将面临扣除保证金和信誉分的风险。";
                } else {
                    tips += "为避免过多玩家撤单而影响您的信誉分，请确保您的商品信息正确，并及时处理玩家求助。";
                }
            }

            //如果有仲裁，追加仲裁说明
            int isArbitrate = order.getInt("is_selluser_arbitrate");
            //正在仲裁中...
            if (isArbitrate == Order.SELLUSER_ARBITRATE) {
                subtitle = "等待仲裁结果...【原因: " + order.getStr("arbitrate_reason") + "】";
                tips += "<br><b>我们已经接收到您的仲裁申请，客服将在仲裁发起后12小时内完成处理，请耐心等候。</b>";
            }
            if (isArbitrate == Order.SELLUSER_ARBITRATE_SUCC) {
                subtitle = "仲裁成功！【" + order.getStr("arbitrate_reason") + "】";

                Map<String, Object> arbitrate = new HashMap<>();
                Record arRow = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", order.getStr("order_id"));
                arbitrate.put("punishment_way", arRow.getInt("punishment_way"));
                arbitrate.put("arbitrate_reason", arRow.getStr("arbitrate_reason"));
                setAttr("arbitrate", arbitrate);

                int punishmentWay = arRow.getInt("punishment_way");
                tips += "<br><b>您已仲裁成功，";
                if (punishmentWay == Order.PUNISHMENT_DO_NOTHING) {
                    tips += "平台已经对玩家进行了警告处理，并会持续对该玩家的后续行为进行跟踪，租金将计时收取并在订单结束24小时内到账，感谢您的支持。";
                }
                if (punishmentWay == Order.PUNISHMENT_DECREASE_BUYERSCORE) {
                    tips += "平台已经对玩家进行警告并且已经做出扣除信誉分的惩罚处理，租金将计时收取并在订单结束24小时内到账，感谢您的支持。";
                }
                if (punishmentWay == Order.PUNISHMENT_ALL_BUYER) {
                    //如果有押金且是用户押金类型
                    if (order.getInt("order_guarantee_deposit") > 0 && order.getInt("guarantee_deposit_type") == Product.GUARANTEE_DEPOSIT_TYPE_USER) {
                        tips += "平台已经对玩家进行警告并作扣除用户押金的处理，租金将计时收取并且和押金一同在订单结束24小时内到账，感谢您的支持。";
                    }
                    //没有押金或者押金是平台押金，使用PUNISHMENT_DO_NOTHING的提示语
                    else {
                        tips += "平台已经对玩家进行了警告处理，并会持续对该玩家的后续行为进行跟踪，租金将计时收取并在订单结束24小时内到账，感谢您的支持。";
                    }
                }
                tips += "</b>";
            }
            if (isArbitrate == Order.SELLUSER_ARBITRATE_FAIL) {
                tips += "<br><b>您提交的仲裁失败！</b>";
            }

            setAttr("tips", tips);
            setAttr("subtitle", subtitle);
        }
        
        //判断是否玩家是否在号主黑名单
        Record bl = SmartDb.findFirst("select * from `seller_blacklist` where `seller_id`=? and `buyuser_uid`=? limit 1", 
        		order.getInt("selluser_uid"), order.getInt("buyuser_uid"));
        setAttr("in_black_list", bl != null);

        render("/view/order/seller_order_detail.html");
	}
}