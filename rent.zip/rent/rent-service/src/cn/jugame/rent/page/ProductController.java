package cn.jugame.rent.page;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.rent.bean.*;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.interceptor.PCForwardInterceptor;
import cn.jugame.rent.interceptor.VisitLogInterceptor;
import cn.jugame.rent.page.service.ProductSearchService;
import cn.jugame.rent.page.service.Platforms;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.search.SearchResult;
import cn.jugame.rent.search.SearchTerm;
import cn.jugame.rent.search.SortTerm;
import cn.jugame.rent.utils.*;
import cn.jugame.service.common.util.bean.DataBean;
import cn.jugame.service.gameproduct.api.IGameService;
import cn.jugame.service.gameproduct.bean.Channel;
import cn.jugame.service.gameproduct.bean.GamePartition;
import com.google.common.collect.Lists;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

public class ProductController extends BaseController{
	
	private Logger logger = Loggers.rentLog();

	private Logger event = Loggers.eventLog();

    private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
    
	private IGameService gameService = ServiceFactory.get(IGameService.class);
	
	/**
	 * 获取商品详情
	 */
	@Before(PCForwardInterceptor.class)
	public void detail(){
		String isSupport = getPara("is_support","0");
		setAttr("is_support",isSupport);
		String productId = getPara("product_id", "");
		//根据商品推广id获取商品
		Record product =  Product.getProduct(productId);

		if(product == null){
			errorPage("该商品不存在");
			return;
		}
		Integer loginUid = getSessionAttr("uid");
		if(loginUid != null && loginUid.intValue() == product.getInt("seller_uid")){
			setAttr("is_my_product",true);
		}
		setAttr("t_uid",getPara("t_uid"));
		//新人礼包入口是否开启
		setAttr("newcomer_gift_valid",User.newcomerGiftValid(loginUid == null ? 0 : loginUid));
		//如果商品已经下架了，不展示内容！
		if(product.getInt("status") == Product.STATUS_OFFSALE){
		    //如果用户已经登陆了，且该商品是他自己的，就给他自己一个人看吧
            Integer uid = getSessionAttr("uid");
            if(uid == null || uid.intValue() != product.getInt("seller_uid").intValue()) {
                errorPage("该商品当前已经下架，无法查看详情！");
                return;
            }
		}
		
		Record gameConf = SmartDb.findFirst("select * from game_conf where game_id=?", product.getStr("game_id"));
		if(gameConf == null){
			errorPage("不存在的游戏或会员VIP");
			return;
		}
		setAttr("game", toMap(gameConf));

        //获取号主信息
        MemberBean<Member> bean = accountCenterService.findMemberByUid(product.getInt("seller_uid"));
		if(bean == null || bean.getData() == null){
		    errorPage("商品的号主信息不存在");
		    return;
        }
        Member seller = bean.getData();
		//用户昵称和头像
		setAttr("seller_nickname", UsernameUtil.getUserName(bean, product.getInt("seller_uid")));
		//设置页面描述数据
		String gameName = product.getStr("game_name");
		if(product.getInt("product_type") == Product.PRODUCT_TYPE_VIP){
			gameName = "会员VIP";
		}
		setAttr("page_title", "【" + gameName + "】账号" + Common.round(product.getInt("price_hour")/100.0, 2) + "元出租");
		setAttr("page_description", "【" + gameName + "】-" + htmlEncode(product.getStr("name")));

		Map<String, Object> data = product2map(product);
		
		//商品图片
		List<Record> pics = SmartDb.find("select * from product_picture where product_id=?", product.getStr("product_id"));
		//如果没有图片，则默认选用游戏大图作为图片，如果游戏没有大图，就用游戏icon图吧，好过没有!
		if(pics.size() == 0){
			String iconUrl = gameConf.getStr("hd_icon_url");
			if(StringUtils.isBlank(iconUrl)){
				iconUrl = gameConf.getStr("icon_url");
			}

			if(StringUtils.isNotBlank(iconUrl)){
				Record tmp = new Record()
						.set("product_id", productId)
						.set("pic_url", iconUrl)
						.set("type", Product.PIC_TYPE_SYSTEM)
						.set("c_time", Common.now());
				pics.add(tmp);
			}
		}
		data.put("pics", toMap(pics));
		
		//如果该商品正在出租，获取租赁时间
		if(product.getInt("status") == Product.STATUS_RENT){
			Record order = SmartDb.findFirst("select * from `order` where `product_id`=? and `order_status` IN (?, ?) order by `order_time` desc limit 1",
					product.getStr("product_id"), Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_PAYING);
			if(order != null){
				setAttr("rent_start_time", Common.show_time(order.getDate("rent_start_time")));
				setAttr("rent_end_time", Common.show_time(order.getDate("rent_end_time")));
			}

			Record notPayOrder = SmartDb.findFirst("select count(*) as _count from `order` where `product_id` = ? and `order_ispay` = ? and `order_status` = ? ",
					product.getStr("product_id"),Order.ORDER_NOT_PAY,Order.ORDER_STATUS_NEW);
			if(notPayOrder != null && notPayOrder.getLong("_count") > 0){
				setAttr("product_lock",true);
			}
		}
		
		String vipHiddenHourPriceIds = PropKit.get("vip_hidden_hour_price_ids","");
		boolean isHideHourPrice = false;
		if(vipHiddenHourPriceIds.contains(product.getStr("game_id"))) {
			isHideHourPrice = true;
		}
		setAttr("isHideHourPrice", isHideHourPrice);
		
		String jugameFr = getCookie(VisitLogInterceptor.CHANNEL_COOKIE_NAME);
		boolean isRentApp = getAttr("isRentApp") != null?getAttr("isRentApp"):false;
		if(StringUtils.isNotEmpty(jugameFr) && jugameFr.startsWith("cw_") && !isRentApp) {
			setAttr("is_promote_app",true);
		}
		setAttr("in_night", Common.inHour(PropKit.getInt("product.in_night_begin"), PropKit.getInt("product.in_night_showprice_end")));
		setAttr("product", data);
		setAttr("product_id",productId);
		setAttr("is_recommend",getAttr("is_recommend"));
		render("detail.html");
	}

	/**
	 * 与detail接口一样的功能，但是不管商品是否下架都能看到详情页！
	 * 供内部客服使用！
	 */
	public void kefuDetail(){
		String productId = getPara("product_id", "");
		Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
		if(product == null){
			errorPage("不存在的商品");
			return;
		}

		Map<String, Object> data = product2map(product);

		//商品图片
		List<Record> pics = SmartDb.find("select * from product_picture where product_id=?", productId);
		data.put("pics", toMap(pics));

		//如果该商品正在出租，获取租赁时间
		if(product.getInt("status") == Product.STATUS_RENT){
			Record order = SmartDb.findFirst("select * from `order` where `product_id`=? and `order_status` IN (?, ?) order by `order_time` desc limit 1",
					productId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_PAYING);
			if(order != null){
				setAttr("rent_start_time", Common.show_time(order.getDate("rent_start_time")));
				setAttr("rent_end_time", Common.show_time(order.getDate("rent_end_time")));
			}
		}

		setAttr("in_night", Common.inHour(PropKit.getInt("product.in_night_begin"), PropKit.getInt("product.in_night_showprice_end")));
		setAttr("product", data);
		render("detail.html");
	}

	/***
	 * 获取推广商品列表
	 */
	public void promoteList(){
		HttpServletRequest request = this.getRequest();
		request.setAttribute("is_promote",Order.ORDER_FROM_USERPROMOTE);

		setAttr("game_name", "游戏");
		list();
	}
	
	/**
	 * 获取推荐的商品明细
	 * **/
	public void recommendDetail(){
		HttpServletRequest request = this.getRequest();
		request.setAttribute("is_recommend",Product.PRODUCT_RECOMMEND);
		detail();
	}
	
	/***
	 * 根据首字母获取游戏列表
	 */
	public void allGames() {
		String letter = getPara("letter", "");
		int type = getParaToInt("type",GameConf.TYPE_GAME);
		
		List<Record> rows = getGamesAndLetters(letter,type).get("games");
		JSONArray games =new JSONArray();
		for(Record row : rows){
			JSONObject obj = new JSONObject();
			obj.put("game_id", row.getStr("game_id"));
			obj.put("game_name", row.getStr("game_name"));
			obj.put("icon", row.getStr("icon_url"));
			obj.put("game_short_name",row.getStr("game_short_name"));
			games.add(obj);
		}

		List<Record> gameInitials = getGamesAndLetters(letter,type).get("gameLetters");
		JSONArray gameLetters =new JSONArray();
		for(Record r : gameInitials){
			JSONObject obj = new JSONObject();
			obj.put("letter", r.getStr("game_initial"));
			gameLetters.add(obj);
		}
		renderJson(buildResp(0, "ok", new KeyValue<>("games", games),new KeyValue<>("gameLetters", gameLetters),new KeyValue<>("letter",letter)));
	}
	
	private  Map<String,List<Record>> getGamesAndLetters(String letter,int type){
		Map<String,List<Record>>  map = new HashMap<String,List<Record>>();
		//获取游戏
		List<Record> rows = null;
		if(StringUtils.isBlank(letter)){
			rows = SmartDb.find("select * from `game_conf` where `status`=? and `is_hot`=? and `type`=? and `support_product_count`>0  order by `weight`  desc", GameConf.STATUS_ENABLE, GameConf.TAG_HOT,type);
		}else{
			rows = SmartDb.find("select * from `game_conf` where `status`=? and `game_initial`=? and `type`=?  and `support_product_count`>0 order by `weight` desc", GameConf.STATUS_ENABLE, letter,type);
		}
		if(rows == null) rows = new ArrayList<>();
		map.put("games", rows);
		//获取首字母
		List<Record> gameInitials = SmartDb.find("select distinct `game_initial` from `game_conf` where `status`=? and `type`=?  and `support_product_count`>0 order by `game_initial`", GameConf.STATUS_ENABLE,type);
		map.put("gameLetters", gameInitials);
		return map;
	}
	
	
	/**
	 * 获取商品列表
	 */
	@Before(PCForwardInterceptor.class)
	public void list(){
		String gameId = getPara("game_id", "");
		String gameShortName = getPara("game_short_name");
		String channelId = getPara("channel_id", "");
		String keyword = getPara("keyword", "");
		String partitionId = getPara("game_partition_id", "");
		int offset = getParaToInt("offset", 0);
		int limit = getParaToInt("limit", 30);
		int gameType = getParaToInt("game_type", 0); //默认全搜索
		int status = getParaToInt("status", 0);
		int orderbyPrice = getParaToInt("orderby_price", 0);
		int orderbyTradeHour = getParaToInt("orderby_trade_hour", 0);
		int sellerUid = getParaToInt("seller_uid", 0);
		int sellLevel = getParaToInt("sell_level", -1);
		int hasSellerGuarantee = getParaToInt("has_seller_guarantee", -1);
		int gameLoginType = getParaToInt("game_login_type",-1);
		int isPromoteProduct = getParaToInt("is_promote_product",0);
		String priceUp = getPara("price_up","");
		String priceDown = getPara("price_down","");
		int priceUpFen = StringUtils.isNotEmpty(priceUp) ? (int)(Double.parseDouble(priceUp)*100) : 0;
		int priceDownFen = StringUtils.isNotEmpty(priceDown) ? (int)(Double.parseDouble(priceDown)*100) : 0;
		if(StringUtils.isNotBlank(gameId)) {
			setAttr("game_id", gameId);
		}
		//判读是否搜索推荐商品
		int isRecommendProductList = getParaToInt("is_recommend_product",0);

		//尝试获取游戏配置信息
		Record gameConf = null;
		//优先使用gameId
		if(StringUtils.isNotBlank(gameId)){
			gameConf = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", gameId);
		}
		//再尝试使用game_short_name
		if(gameConf == null && StringUtils.isNotBlank(gameShortName)){
			gameConf = SmartDb.findFirst("select * from `game_conf` where `game_short_name`=?", gameShortName);
		}
		
		//如果有指定游戏，但是对应的游戏配置又都查不到
		if(gameConf == null && (StringUtils.isNotBlank(gameId) || StringUtils.isNotBlank(gameShortName))){
			errorPage("不存在的游戏账号/会员VIP");
			return;
		}
		//如果有游戏名，加上游戏名作为前缀
		if(gameConf != null){
			//既然已经明确了游戏配置，那就更新掉对应的参数
			gameId = gameConf.getStr("game_id");
			gameShortName = gameConf.getStr("game_short_name");
			gameType = gameConf.getInt("type");
        	setAttr("game_name", gameConf.getStr("game_name"));
		}
		
		//根据当前gameType获取热门游戏列表
		List<Record> hotGames = Platforms.singleton.getGames(gameType, GameConf.TAG_HOT, 9);
		setAttr("hot_games", toMap(hotGames));
		
		//若有channelId，则获取一次channel的信息
		if(StringUtils.isNotBlank(channelId)){
			DataBean<Channel> bean = gameService.getChannel(channelId);
			if(bean.getData() == null){
				errorPage("获取渠道详情失败了，请稍后重试");
				return;
			}
			//补上渠道名称
			setAttr("channel_name", bean.getData().getChannelName());
		}
		
		//若有分区ID，则获取一次分区的信息
		if(StringUtils.isNotBlank(partitionId) && StringUtils.isNotBlank(gameId)){
			DataBean<GamePartition> bean = gameService.getGamePartitionById(gameId, partitionId);
			if(bean.getData() == null){
				errorPage("获取游戏区服失败了，请稍后重试");
				return;
			}
			//补上区服的名称
			setAttr("partition_name", bean.getData().getPartitionName());
		}

		//筛选新春装饰商品
		int isProductDecorate = getParaToInt("is_product_decorate",0);
		setAttr("is_product_decorate", isProductDecorate);
		setAttr("game_id", gameId);
		setAttr("game_type", gameType);
		setAttr("price_up",priceUp);
		setAttr("price_down",priceDown);
		setAttr("is_recommend_product",isRecommendProductList);
		setAttr("channel_id", channelId);
		setAttr("keyword", keyword);
		setAttr("game_partition_id", partitionId);
		setAttr("page_size", limit);
		setAttr("status", status);
		setAttr("orderby_price", orderbyPrice);
		setAttr("orderby_trade_hour", orderbyTradeHour);
		setAttr("seller_uid", sellerUid);
		setAttr("sell_level", sellLevel);
		setAttr("has_seller_guarantee", hasSellerGuarantee);
		setAttr("game_login_type", gameLoginType);
		setAttr("is_promote_product",isPromoteProduct);
		//是否在扶持商品列表区域
		int isSupportArea = getParaToInt("is_support_area", 0);
		setAttr("is_support_area", isSupportArea);
		//如果是扶持区域，需要加载游戏列表，优惠券等信息
		if(isSupportArea==1) {
			String letter = getPara("letter", "");
			int type = getParaToInt("type",GameConf.TYPE_GAME);

			// 根据当前gameType获取热门游戏列表
			List<Object> games = new ArrayList<>();
			List<Record> rows = getGamesAndLetters(letter, type).get("games");

			for(Record row : rows){
				Map<String, Object> obj = new HashMap<>();
				obj.put("game_id", row.getStr("game_id"));
				obj.put("game_name", row.getStr("game_name"));
				obj.put("icon", row.getStr("icon_url"));
				obj.put("game_short_name",row.getStr("game_short_name"));
				games.add(obj);
			}
			setAttr("games", games);

			List<Object> gameLetters = new ArrayList<>();
			List<Record> gameInitials = getGamesAndLetters(letter, type).get("gameLetters");
			for(Record r : gameInitials){
				Map<String, Object> map = new TreeMap<>();
				map.put("letter", r.getStr("game_initial"));
				gameLetters.add(map);
			}
			setAttr("gameLetters", gameLetters);
			
			//获取优惠券展示
			List<Record> coupons= SmartDb.find("select * from `coupon`  where valid_support_type is not null and valid_support_type != '[]' and status =?  order by c_time desc ",Coupon.STATUS_ONSALE);
			//从coupons中筛选出扶持商品优惠券
			coupons = Coupon.getSupportGift(coupons, Product.SUPPORT_TYPE_SUPPORTED);
			if (coupons.size()>0) {
				Record coupon = coupons.get(0);
				coupon.set("c_time", Common.show_time(coupon.getDate("c_time"), "yyyy-MM-dd"));
				coupon.set("e_time", Common.addDay(coupon.getStr("c_time"), coupon.getInt("valid_days"), "yyyy-MM-dd"));
				setAttr("suport_coupon", coupon);
				Integer uid = getSessionAttr("uid");
				
				if(uid !=null) {
					if(PropKit.get("newcomer.gift","newcomer").equals(coupon.getStr("action_type"))) {
						//如果是新用户则可领取
						if(User.isNewcomerGiftUser(uid)) {
							setAttr("is_support_coupon",true);
						}
						//新用户，且之前已经领取过新人礼包未领过扶持区的优惠券的
						Record order = SmartDb.findFirst("select * from `order` where buyuser_uid = ?",uid);
						Record user = SmartDb.findFirst("select * from `member` m  where m.uid = ? and m.has_newcomer_gift = ?  ",uid,User.USER_HAS_NEWCOMER_GIFT);
						if(order==null&&user!=null){
							List<Record> userCoupons =  SmartDb.find("select * from `user_coupon`  where valid_support_type is not null  and valid_support_type != '[]' and uid =?",uid);
							if(!Coupon.isReceiveAllCoupons(coupons, userCoupons)) 
								setAttr("is_support_coupon",true);
						}
					}else {
						List<Record> userCoupons =  SmartDb.find("select * from `user_coupon`  where valid_support_type is not null  and valid_support_type != '[]' and uid =?",uid);
						if(!Coupon.isReceiveAllCoupons(coupons, userCoupons)) 
							setAttr("is_support_coupon",true);
					}
					
				}else {
					setAttr("is_support_coupon",true);
				}
			}
		}
        
		//配置游戏的关键词
		if(StringUtils.isNotBlank(gameId)){
			setAttr("keywords", GameConf.getGameKeywords(gameId));
		}
		
		//如果指定了卖家，需要获取一次卖家信息
        Member seller = null;
        if(sellerUid > 0) {
            MemberBean<Member> bean = accountCenterService.findMemberByUid(sellerUid);
            if(bean == null || bean.getData() == null){
                errorPage("您所查看商品的号主并不存在。");
                return;
            }
            seller = bean.getData();
        }

		//新人礼包入口是否开启
        Integer loginUid = getSessionAttr("uid");
		setAttr("newcomer_gift_valid", User.newcomerGiftValid(loginUid == null ? 0 : loginUid));

        //筛选商品
		List<Record> products = null;
		List<Record> supportProducts = Lists.newArrayList();
		int totalCount = 0;
		
		//没有关键词，在数据库搜索
		if(StringUtils.isBlank(keyword)){
			setCookie("search_key_word", "true", 5 * 60);
			List<Object> params = new ArrayList<>();
			String where = "where ";
			if(status > 0){
				where += "`status`=?";
				params.add(status);
			}else{
				where += "`status` in (?, ?)";
				params.add(Product.STATUS_ONSALE);
				params.add(Product.STATUS_RENT);
			}
			if(StringUtils.isNotBlank(gameId)){
				where += " and game_id=?";
				params.add(gameId);
			}
			if(StringUtils.isNotBlank(channelId)){
				where += " and channel_id=?";
				params.add(channelId);
			}
			if(StringUtils.isNotBlank(partitionId)){
				where += " and game_partition_id=?";
				params.add(partitionId);
			}
			if(sellerUid > 0){
			    where += " and `seller_uid`=?";
			    params.add(sellerUid);
            }

			if(gameLoginType == Product.LOGIN_ACCOUNTPASSWORD){
				where += " and `game_login_type`= ?";
				params.add(gameLoginType);
			}

			if(gameLoginType >= Product.LOGIN_PC_AUTOKIT){
				where += " and `game_login_type` >= ?";
				params.add(gameLoginType);
			}
			if(isProductDecorate > 0) {
				where += " and `is_decorate` = ?";
				params.add(Product.PRODUCT_DECORATE);
			}

			//扶持区域商品，号主总是“普通号主”，保证金总是>0,信誉分满分，且只能是游戏类型的商品
			if(isSupportArea==1){
				where += " and `seller_guarantee_amount`>0 and `reputation_score`>=? and `sell_level`=? and `support_type`=? and product_type =? ";
				params.add(Product.SUPPORT_REPUTATION_SCORE_MIN);
				params.add(User.SELL_LEVEL_NORMAL);
				params.add(Product.SUPPORT_TYPE_SUPPORTED);
				params.add(GameConf.TYPE_GAME);
			}
			//非扶持区域商品，允许筛选
			else{
				if(sellLevel == User.SELL_LEVEL_GOLD || sellLevel == User.SELL_LEVEL_SILVER || sellLevel == User.SELL_LEVEL_NORMAL){
					where += " and `sell_level`=?";
					params.add(sellLevel);
				}
				//金牌银牌号主一块
				if(sellLevel == 100){
					where += " and `sell_level`!=?";
					params.add(User.SELL_LEVEL_NORMAL);
				}
				//已交保证金
				if(hasSellerGuarantee == 1){
					where += " and `seller_guarantee_amount`>0";
				}
				
				//如果是自己推广的链接，不做信誉分限制。
				Integer isPromote = (Integer)getRequest().getAttribute("is_promote");
				if(isPromote == null || isPromote != Order.ORDER_FROM_USERPROMOTE){
					where += " and `reputation_score` > " + PropKit.getInt("product.min_reputation_required");
				}
				
				if(gameType > 0){
					//XXX game_type基本上与product_type的取值一样，但只有CDK不一样
					int productType = gameType;
					if(gameType == GameConf.TYPE_GAME)
						productType = Product.PRODUCT_TYPE_GAME;
					if(gameType == GameConf.TYPE_PC_GAME)
						productType = Product.PRODUCT_TYPE_PCGAME;
					if(gameType == GameConf.TYPE_VIP)
						productType = Product.PRODUCT_TYPE_VIP;
					if(gameType == GameConf.TYPE_CDK)
						productType = Product.PRODUCT_TYPE_CDK;
					
					where += " and `product_type` =?";
					params.add(productType);
				}
			}
			
			//是否优惠活动商品
			if(isPromoteProduct == 1){
				where += " and `promotion_properties` is not null and `promotion_properties` != '' and `promotion_properties` != '{}' ";
			}

			if(isRecommendProductList == Product.PRODUCT_RECOMMEND){
				where += " AND EXISTS ( SELECT 1 FROM product_recommended pr WHERE pr.product_id = p.product_id)";
			}

			if(StringUtils.isNotEmpty(priceDown)){
				where += " AND price_hour >= ?";
				params.add(priceDownFen);
			}
			if(StringUtils.isNotEmpty(priceUp)){
				where += " AND price_hour <= ?";
				params.add(priceUpFen);
			}
			
			//这里真恶心...
			List<Object> p1 = Lists.newArrayList(params);
			p1.add(offset);
			p1.add(limit);
			
			//商品上架中的永远在出租中的前面
			String orderSql = "  order by `status` asc, ";
			
			//如果是ios的，将ios的商品靠前排
			if("ios".equalsIgnoreCase(getSessionAttr("pf"))){
				orderSql += " `channel_platform` desc, ";
			}
			
			//若用户显示指定了排序方式，则优先使用用户指定的排序方式
			//按成交量排序
			if(orderbyTradeHour == 1){
				orderSql += "`trade_hour` desc, ";
			}
			else if(orderbyTradeHour == 2){
				orderSql += "`trade_hour` asc, ";
			}
			//按时租价排序
			if(orderbyPrice == 1){
				orderSql += "`price_hour` desc, ";
			}
			else if(orderbyPrice == 2){
				orderSql += "`price_hour` asc, ";
			}
			
			//筛选过后，默认的排序方式
			orderSql += " `reputation_score` desc, "
					+ "`seller_guarantee_amount` desc, "
					+ "`sell_level` desc, "
					+ "`is_seller_online` desc, ";
			
			//XXX 通过sortId实现每个用户排序方式的不一样！
			Integer sortId = Product.getSortId(this);
			if(sortId == null){
				orderSql += "`id` asc ";
			}else{
				orderSql += "(`id` & " + sortId + ") asc ";
			}
			
			//每个列表页首部展示2个扶持商品
			if(isSupportArea!=1&&offset==0){
				String supportWhere = where + " and p.`sell_level`=" + User.SELL_LEVEL_NORMAL;
				supportWhere += " and p.`seller_guarantee_amount`>0";
				supportWhere += " and p.`reputation_score` >= "+Product.SUPPORT_REPUTATION_SCORE_MIN;
				supportWhere += " and p.`support_type` = " + Product.SUPPORT_TYPE_SUPPORTED;
				supportWhere += " and p.`status` = "+Product.STATUS_ONSALE;
				
				List<Object> supportParams = Lists.newArrayList(params);
				
				String supportSelectSql = "select * from `product` p " + supportWhere;
				supportProducts = SmartDb.get(false).find(supportSelectSql + orderSql + "limit 2", supportParams.toArray());
			}

			//正常的商品列表
			String selectSql = "select * from `product` p " + where;
			orderSql += "limit ?, ?";
			
			SmartDb.TrackableDb db = SmartDb.get(false);
			products = db.find(selectSql + orderSql, p1.toArray());
			logger.info("selectSql => " + db.lastQuery());
			//XXX 这里可以走负载均衡读
			Record row = db.findFirst("select count(id) as _count from `product` p " + where, params.toArray());
			totalCount = row.getLong("_count").intValue();
			logger.info("product.list从数据库总共搜索出" + totalCount + "条匹配商品");
			logger.info("product.list从数据库搜索，sql => " + db.lastQuery());
		}
		//有关键词就去搜索引擎搜索
		else{
			setCookie("search_key_word","false",5*60);
			//如果sell_level==100，则是要金牌+银牌的号主筛选
			int[] sls = new int[]{};
			if(sellLevel == User.SELL_LEVEL_GOLD || sellLevel == User.SELL_LEVEL_SILVER || sellLevel == User.SELL_LEVEL_NORMAL){
				sls = new int[]{sellLevel};
			}
			if(sellLevel == 100){
				sls = new int[]{User.SELL_LEVEL_GOLD, User.SELL_LEVEL_SILVER};
			}
			
			//记录搜索词
			String gameName = gameConf != null ? gameConf.getStr("game_name"):"";
			event.info("keyword=" + keyword + "`game_id=" + gameId + "`game_name=" + gameName);

			SearchTerm term = new SearchTerm().setGameId(gameId)
					.setChannelId(channelId)
					.setPartitionId(partitionId)
					.setKeyword(keyword)
					.setStatus(status)
                    .setSellerUid(sellerUid)
                    .setSellLevel(sls)
                    .setHasSellerGuarantee(hasSellerGuarantee)
                    .setIsPromoteProduct(isPromoteProduct)
                    .setGameLoginType(gameLoginType)
					.setIsRecommendProduct(isRecommendProductList);
			//来自扶持商品列表区域的
			if(isSupportArea==1){
				term.setSupportType(Product.SUPPORT_TYPE_SUPPORTED);
			}
			if(StringUtils.isNotEmpty(priceUp)){
				term.setMaxPriceHour(priceUpFen);
			}
			if(StringUtils.isNotEmpty(priceDown)){
				term.setMinPriceHour(priceDownFen);
			}
			List<SortTerm> fields = new ArrayList<>();
			
			//一定是上架中的在出租中前面
		    fields.add(new SortTerm("status", false));
			
		    //若用户显示指定了排序方式
            //按交易时长排序
            if(orderbyTradeHour == 1){
                fields.add(new SortTerm("trade_hour", true));
            }
            if(orderbyTradeHour == 2){
                fields.add(new SortTerm("trade_hour", false));
            }
			//按价格排序
			if(orderbyPrice == 1){
			    fields.add(new SortTerm("price_hour", true));
            }
            if(orderbyPrice == 2){
			    fields.add(new SortTerm("price_hour", false));
            }

			//筛选过后，按照信誉分和号主等级倒序排列
            fields.add(new SortTerm("reputation_score", true));
            fields.add(new SortTerm("seller_guarantee_amount", true));
            fields.add(new SortTerm("sell_level", true));
            
            //用户没有显示指定排序方式，则使用默认方式并作为最后的排序维度
            if(orderbyPrice == 0){
            	fields.add(new SortTerm("price_hour", false));
            }
            if(orderbyTradeHour == 0){
            	fields.add(new SortTerm("trade_hour", false));
            }

            if(fields.size() > 0){
                term.setSortTerms(fields.toArray(new SortTerm[0]));
            }

            term.setOffset(offset);
            term.setLimit(limit);
			SearchResult result = ProductSearchService.instance.search(term);

			if(result != null && result.getProductIds().size() != 0){
				totalCount = result.getTotalCount();
				logger.info("product.list从搜索引擎总共搜索出" + totalCount + "条匹配商品");

				String selectSql = "select * from `product` p where `product_id`  in ('" + Common.join(result.getProductIds().toArray(new String[0]), "','") + "') order by ";
				selectSql += "`status` asc, ";

				//带上排序
				if(orderbyPrice == 1)
					selectSql += "`price_hour` desc, ";
				if(orderbyPrice == 2)
					selectSql += "`price_hour` asc, ";

				if(orderbyTradeHour == 1)
					selectSql += "`trade_hour` desc, ";
				if(orderbyTradeHour == 2)
					selectSql += "`trade_hour` asc, ";
				
				selectSql += "`reputation_score` desc, `sell_level` desc, ";
				if(orderbyPrice == 0)
					selectSql += "`price_hour` asc, ";
				if(orderbyTradeHour == 0)
					selectSql += "`trade_hour` desc, ";
				selectSql += "`id` asc";

				products = SmartDb.find(selectSql);
				logger.info("product.list从搜索引擎搜索，sql => " + SmartDb.lastQuery());
			}else{
				products = new ArrayList<>();
			}
		}

		setAttr("offset", offset);
		setAttr("start", offset);  //兼容wap版本旧的一些代码
		setAttr("limit", limit);
		setAttr("total_count", totalCount);

		int totalPage = totalCount / limit;
		if(totalCount % limit != 0)
			totalPage ++;
		setAttr("total_page", totalPage);
		int currentPage = offset / limit + 1;
		setAttr("current_page", currentPage);
		//当前页的前后几页
		List<Integer> pages = Lists.newArrayList();
		for(int i=-3; i<=3; ++i){
			int p = currentPage + i;
			if(p < 1 || p > totalPage)
				continue;
			pages.add(p);
		}
		
		Map<String,String> map = this.getGameLoginClient();
		//扶持商品标记用于计算手续费用
		if(isSupportArea==1) {
			for(Record product : products) {
				if(product.getInt("game_login_type")>1)
					product.set("login_client_name", map.get(product.getStr("game_id")+product.getStr("channel_id")));
				product.set("is_support", "2");
			}
		}else {
			for(Record product : products) {
				if(product.getInt("game_login_type")>1)
					product.set("login_client_name", map.get(product.getStr("game_id")+product.getStr("channel_id")));
				product.set("is_support", "0");
			}
		}
		setAttr("show_pages", pages);
		
		//拼接扶持商品到首部
		for(Record sp : supportProducts){
			if(sp.getInt("game_login_type")>1)
				sp.set("login_client_name", map.get(sp.getStr("game_id")+sp.getStr("channel_id")));
			sp.set("is_support", "1");
			products.add(0, sp);
		}
		
		setAttr("in_night", Common.inHour(PropKit.getInt("product.in_night_begin"), PropKit.getInt("product.in_night_showprice_end")));
		List<Map<String, Object>> productList = product2map(products);
		setAttr("product_list", productList);
		//设置推广属性
		setAttr("is_promote", getPara("is_promote"));

		if (offset == 0) {
			render("list.html");
		} else {
			if (productList.size() > 0) {
				render("_list.html");
			} else {
				renderText("");
			}
		}
	}

	/**
	 * 会员VIP列表
	 */
	public void vip(){
		List<Record> rows = SmartDb.find("select * from `game_conf` where `status`=? and `type`=? and `product_count`>0 order by weight desc, id desc", GameConf.STATUS_ENABLE, GameConf.TYPE_VIP);
		setAttr("games", toMap(rows));

		//如果用户已经登录了，尝试获取这个用户当前正在租赁中的订单数量
		setAttr("order_count", 0);
		Integer uid = getSessionAttr("uid");
		if(uid != null){
			Record row = SmartDb.findFirst("select count(`id`) as _count from `order` where `buyuser_uid`=? and `order_status` in (?, ?)", uid, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_PAYING);
			setAttr("order_count", row.getLong("_count").intValue());
		}

		setAttr("page_title", "【会员VIP】账号出租");
		setAttr("page_description", "【会员VIP】商品列表");
		render("vip.html");
	}

    /**
     * CDK商品列表
     */
	public void cdk(){
        List<Record> rows = SmartDb.find("select * from `game_conf` where `status`=? and `type`=? and `product_count`>0 order by weight desc, id desc", GameConf.STATUS_ENABLE, GameConf.TYPE_CDK);
        setAttr("games", toMap(rows));

        //如果用户已经登录了，尝试获取这个用户当前正在租赁中的订单数量
        setAttr("order_count", 0);
        Integer uid = getSessionAttr("uid");
        if(uid != null){
            Record row = SmartDb.findFirst("select count(`id`) as _count from `order` where `buyuser_uid`=? and `order_status` in (?, ?)", uid, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_PAYING);
            setAttr("order_count", row.getLong("_count").intValue());
        }

        setAttr("page_title", "【体验卡】出售");
        setAttr("page_description", "【体验卡】商品列表");
        render("cdk.html");
    }

    /**
     * 商品举报
     */
    @Before(LoginInterceptor.class)
	public void report(){
        final Integer uid = getSessionAttr("uid");
        if(uid == null){
            errorPage("请登陆后再执行匿名举报");
            return;
        }

        String reportReason = getPara("report_reason");
        if(StringUtils.isBlank(reportReason)){
            errorPage("请填写举报理由");
            return;
        }

        String productId = getPara("product_id");
        if(StringUtils.isBlank(productId)){
            errorPage("没有商品ID");
            return;
        }

        Record product = SmartDb.findFirst("select * from product where product_id=?", productId);
        if(product == null){
            errorPage("不存在的商品");
            return;
        }

        //确保商品当前是上架状态 or 出租中 or 保护中
        if(product.getInt("status") != Product.STATUS_ONSALE
                && product.getInt("status") != Product.STATUS_RENT
                && product.getInt("status") != Product.STATUS_PROTECTED){
            errorPage("当前商品并没有上架，不能举报");
            return;
        }

        //用来返回商品列表
        setAttr("game_id", product.getStr("game_id"));

        //XXX 你要不要考虑加个并同步控制？不加不加不加！！
        //看看该商品是否已经存在一条还未处理的举报记录，如果存在就不再需要新加了
        Record report = SmartDb.findFirst("select * from `product_report` where `product_id`=? and `status`=?", productId, Product.REPORT_WAITING);
        if(report != null){
            //已经有了这个举报，将这个uid追加进去
            JSONArray json = new JSONArray();
            try{
                if(StringUtils.isNotBlank(report.getStr("follow_uid")))
                    json = JSONArray.fromObject(report.getStr("follow_uid"));
            }catch(Exception e){
                logger.error("product_report数据有问题，id=>" + report.getLong("id") + ", follow_uid=>" + report.getStr("follow_uid"));
                json = new JSONArray();
            }

            boolean flag = false;
            for(int i=0; i<json.size(); ++i){
                if(uid == json.getInt(i)) {
                    flag = true;
                    break;
                }
            }
            //这个uid还没有记录过
            if(!flag){
                json.add(uid);

                //补充这个uid
                report.keep("id");
                report.set("follow_uid", json.toString());
                if(!SmartDb.update("product_report", "id", report)){
                    logger.error("用户【】发起举报时进行uid追加失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                    errorPage("您的举报我们在记录时发生了一些小问题，但并不影响我们的感激之情！");
                    return;
                }
            }
        }else {
            //尚未有这个商品的举报，则新建一条记录
            report = new Record();
            report.set("product_id", productId);
            report.set("report_reason", reportReason);
            report.set("report_uid", uid);
            report.set("c_time", Common.now());
            report.set("status", Product.REPORT_WAITING);
            report.set("follow_uid", "[" + uid + "]");
            if (!SmartDb.save("product_report", report)) {
                logger.error("用户【" + uid + "】发起举报发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                errorPage("我们在记录您的举报内容时发生了一些意想不到的错误，但并不影响我们的感激之情！");
                return;
            }
        }

        render("report_succ.html");
    }

	/***
	 * 提交游戏反馈
	 */
	public void addFeedback() {
		Integer loginUid = getSessionAttr("uid");
		if(loginUid == null){
			errorPage("请登录后再进行游戏反馈操作");
			return;
		}
		String gameType = getPara("game_type");
		String gameName = getPara("game_name");
		
		
		Record suggestion = new Record();
		suggestion.set("user_id", loginUid);
		suggestion.set("content", gameName+"（"+gameType+"）");
		suggestion.set("createtime", Common.now());
		suggestion.set("category_id", Product.SUGGESTION_CATEGORY_ID);
		suggestion.set("source", Product.SUGGESTION_SOURCE);
		suggestion.set("is_handled", Product.SUGGESTION_IS_HANDLED);
		if(!SmartDb.get("platform").save("suggestion", suggestion)) {
			logger.error("新增游戏反馈失败，sql===》"+SmartDb.get("jiaoyi").lastQuery());
			renderJson(buildResp(1,"游戏反馈提交失败"));
			return ;
		}
		renderJson(buildResp(0,"游戏反馈成功"));
	}
	
	private Map<String,String> getGameLoginClient(){
		Map<String,String> map = new HashMap<String,String>();
		List<Record> loginConfigs = SmartDb.find("select * from login_key_config where status =1");
		for(Record row : loginConfigs) {
			if("battle.net".equals(row.getStr("login_client_name")))
			    map.put(row.getStr("game_id")+row.getStr("channel_id"),"战网上号" );
			else if("steam".equals(row.getStr("login_client_name")))
				map.put(row.getStr("game_id")+row.getStr("channel_id"),"Steam上号" );
			else if("wegame".equals(row.getStr("login_client_name")))
				map.put(row.getStr("game_id")+row.getStr("channel_id"),"Wegame上号" );
			else if("uplay".equals(row.getStr("login_client_name")))
				map.put(row.getStr("game_id")+row.getStr("channel_id"),"Uplay上号" );
			else
				map.put(row.getStr("game_id")+row.getStr("channel_id"),"一键上号" );
		}
		return map;
	}
	
	public void goProductDecorate() {
		final Integer uid = getSessionAttr("uid");
		if (uid == null) {
			errorPage("请登陆后再购买商品装饰");
			return;
		}
		Record row = SmartDb.findFirst(
				"select count(id) _count from product_decorate_payment where uid = ? and status in(?,?)", uid,
				Product.DECORATE_PAYMENT_STATUS_PAYED, Product.DECORATE_PAYMENT_STATUS_INVALID);
		setAttr("buy_count", row == null ? 0 : row.getLong("_count"));
		setAttr("valid_day", PropKit.getInt("product.decorate_invalid_day", 1));
		setAttr("pay_amount", Common.round(PropKit.getInt("product.decorate") / 100.0, 2));
		render("product_decorate.html");
	}
	
	/***
	 * 购买商品装饰
	 */
	public void buyProductDecorate() {
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登陆后再购买商品装饰");
			return;
		}
		//判断是否用户是否已经购买过商品装饰
		DistLocker locker = new DistLocker("Product-Decorate-"+uid);
		boolean succ = false;
		try{
			succ = locker.lock(PropKit.getInt("displock.timeout"));
			if(!succ){
				logger.error("购买商品装饰加锁失败，uid=>" + uid);
				errorPage("服务器发生了一些错误，下单失败了");
				return;
			}
			Record productDecorate =	SmartDb.findFirst("select * from product_decorate_payment  where uid = ? and status = ? and pay_time <= ? and invalid_time >=?",
					uid,Product.DECORATE_PAYMENT_STATUS_PAYED,Common.now(),Common.now());
			if(productDecorate != null) {
				errorPage("您已经购买过商品装饰，无需重复购买");
				return;
			}
			productDecorate = new Record();
			String payId = generateDecorateOrderId();
			Integer amount = PropKit.getInt("product.decorate");
			productDecorate.set("name", "新春活动商品装饰");
			productDecorate.set("pay_id",payId);
			productDecorate.set("create_time",Common.now());
			productDecorate.set("amount",amount);
			productDecorate.set("uid",uid);
			productDecorate.set("status",Product.DECORATE_PAYMENT_STATUS_NEW);
			if(!SmartDb.save("product_decorate_payment", productDecorate)){
				logger.error("保存商品装饰付记录失败："+uid);
				return;
			}
			int isNewVersion = getParaToInt("is_new_version", 0);
			String clientType = getAttr("client_type");
			if(!"pc".equalsIgnoreCase(clientType)&&isNewVersion==0){
				String html = PaymentFactory.get().payProductDecorate(uid, payId, amount, Common.getIp(getRequest()));
				if(StringUtils.isBlank(html)){
					errorPage("支付时发生了一些意外，请稍后重试。");
					return;
				}
				renderHtml(html);
				return;
			}
			redirect("/pc/pay/decorateIndex?pay_id=" + payId);
			return;
			
		}finally{
			if(succ) locker.unlock();
		}
	}
	
	private String generateDecorateOrderId(){
		return "DECO-" + Common.now("yyMMdd-HHmmssSSS") + String.format("%02d", Common.rand(0, 99));
	}
}
