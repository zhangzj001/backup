package cn.jugame.rent.page;

import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.interceptor.IPInterceptor;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.page.service.BuyuserPunishmentService;
import cn.jugame.rent.page.service.GameCenterService;
import cn.jugame.rent.page.service.OrderCancelService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import cn.jugame.service.common.util.bean.DataBean;
import cn.jugame.service.gameproduct.api.IGameService;
import cn.jugame.service.gameproduct.bean.Game;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

@Before(IPInterceptor.class)
public class KefuController extends BaseController {

    private Logger logger = Loggers.kefuLog();

    private IGameService gameService = ServiceFactory.get(IGameService.class);

    /**
     * 订单取消。
     * 在买家发起投诉并经过客服证实之后，由客服调用该接口结束订单，此时将订单租金+押金全额退还
     */
    public void cancel() {
        String orderId = getPara("order_id", "");
        String cancelReason = getPara("cancel_reason", "无条件撤单");
        int freeCancel = getParaToInt("is_free_cancel", 1);
        if (StringUtils.isBlank(orderId)) {
            renderJson(buildResp(1, "没有订单ID"));
            return;
        }
        logger.info("取消订单orderID【" + orderId + "】");


        //订单详情
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if (order == null) {
            renderJson(buildResp(1, "不存在的订单"));
            return;
        }

        //是否下架商品，对于账号密码错误的情况，坚决下架商品！！！
        final int offsale = getParaToInt("offsale", 0);

        //标记为客服处理的
        cancelReason = "客服协助撤单:" + cancelReason;
        //判断是否扣除保证金
        int isDeducted = getParaToInt("is_take_off_seller_guarantee", 0);
        logger.info("客服发起订单取消：订单id----" + orderId + "---是否免责：" + freeCancel + "--是否扣除保证金:" + isDeducted);

        OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
        cancelInfo.setBuyuserArbitrate(Order.BUYUSER_ARBITRATION);
        cancelInfo.setCancelReason(cancelReason);
        cancelInfo.setCancelReasonEx("");
        cancelInfo.setDeductSelluserGuarantee(isDeducted == 1);
        cancelInfo.setDelayRefund(Order.isDelayRefund(order, freeCancel == 1));
        cancelInfo.setFreeCancel(freeCancel == 1);
        cancelInfo.setProductOffsale(offsale == 1);
        cancelInfo.setProductOffsaleReason(cancelReason);
        JSONObject result = new OrderCancelService(true).cancel(orderId, cancelInfo);
        renderJson(result);
    }

    /**
     * 订单撤单申请审核。
     * 在买家发起撤单申请后并经过客服审核，由客服调用该接口审核撤单申请，进行驳回或者进行撤单
     */
    public void cancelCheck() {
        int id = getParaToInt("id", -1);
        int freeCancel = getParaToInt("is_free_cancel", 1);
        //是否强制立即退款，值为1则表示需要立即退款
        int quickRefund = getParaToInt("quick_refund", 0);
        int status = getParaToInt("status", -1);
        //是否下架商品，对于账号密码错误的情况，坚决下架商品！！！
        final int offsale = getParaToInt("offsale", 0);
        //判断是否扣除保证金
        int isDeducted = getParaToInt("is_take_off_seller_guarantee", 0);
        logger.info("客服审核订单撤单结果：apply.id----" + id + "---是否免责：" + freeCancel + "--是否扣除保证金:" + isDeducted + "--强制立即退款:" + quickRefund + "--审核结果---" + status);
        if (id < 0) {
            renderJson(buildResp(1, "没有订单ID"));
            return;
        }
        if (status < 0) {
            renderJson(buildResp(1, "没有审核状态"));
            return;
        }

        Record apply = SmartDb.findFirst("select * from `order_cancel_apply`  where id = ?", id);
        if (apply == null) {
            logger.info("申请记录不存在:" + id);
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "申请记录不存在"));
            return;
        }

        String orderId = apply.getStr("order_id");

        //判断订单是否已经完成
        Record order = SmartDb.findFirst("select * from `order` where order_id = ? and order_status = ?", orderId, Order.ORDER_STATUS_PAID);
        if (order == null) {
            logger.info("订单记录不存在:" + apply.getStr("order_id"));
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "订单记录不存在"));
            return;
        }

        logger.info("取消订单apply.id【" + id + "】, orderId【" + orderId + "】, status【" + status + "】");
        //保存取消证据
        if (status == Order.ORDER_CANCEL_APPLY_SUCCESS) {
            Record row = SmartDb.findFirst("select * from `order_cancel_evidence` where `order_id`=?", order.getStr("order_id"));
            if (row != null) {
                logger.info("取消记录已存在：orderId:" + order.getStr("order_id"));
                renderJson(Common.buildResp(Common.RESPONSE_FAIL, "取消记录已存在"));
                return;
            }

            String cancelReasonEx = apply.get("cancel_reason_ex");
            //取消订单
            OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
            cancelInfo.setBuyuserArbitrate(Order.BUYUSER_ARBITRATION);
            cancelInfo.setCancelReason(apply.getStr("cancel_reason"));
            cancelInfo.setCancelReasonEx(cancelReasonEx);
            cancelInfo.setDeductSelluserGuarantee(isDeducted == 1);
            cancelInfo.setDelayRefund(Order.isDelayRefund(order, freeCancel == 1));
            if (quickRefund == 1) {
                cancelInfo.setDelayRefund(false);
                //FIXME 这里是为了贪快方便，直接更新quick_refunc字段
                SmartDb.update("update `order` set `quick_refund`=1 where `order_id`=?", orderId);
            }
            cancelInfo.setFreeCancel(freeCancel == 1);
            cancelInfo.setProductOffsale(offsale == 1);
            cancelInfo.setProductOffsaleReason(apply.getStr("check_reason"));
            //从apply中解析撤单证据图
            try {
                JSONArray json = JSONArray.fromObject(apply.getStr("pics"));
                for (int i = 0; i < json.size(); ++i) {
                    cancelInfo.addCancelPis(json.getString(i));
                }
            } catch (Exception e) {
                logger.error("订单【" + orderId + "】从apply中解析撤单证据图时发生了错误，非JSONArray格式数据！");
            }
            JSONObject result = new OrderCancelService(true).cancel(orderId, cancelInfo);
            logger.info("订单取消orderId--" + orderId + "--结果--" + result);
        } else if (status == Order.ORDER_CANCEL_APPLY_FAIL) {
            //发送通知消息
            JSONObject message = new JSONObject().accumulate("orderId", apply.getStr("order_id"))
                    .accumulate("userId", order.getInt("buyuser_uid"))
                    .accumulate("gameName", order.getStr("game_name"))
                    .accumulate("checkReason", apply.getStr("check_reason"))
                    .accumulate("orderPayAmount", Common.round(order.getInt("order_pay_amount") / 100.0, 2))
                    .accumulate("productName", order.getStr("product_name"));
            //订单撤单申请数量是否超过两次
            Record cancelApply = SmartDb.findFirst("select count(1) as _sum from order_cancel_apply where order_id = ? ", orderId);
            logger.info("撤单申请次数" + cancelApply.getLong("_sum"));
            if (cancelApply != null && cancelApply.getLong("_sum") >= PropKit.getInt("max_cancel_apply_times", 2)) {
                NotifyService.instance.sendSecondCancelApplyFailMessageToBuyuser(orderId, apply.getStr("check_reason"));
            } else {
                NotifyService.instance.sendFirstCancelApplyFailMessageToBuyuser(orderId, apply.getStr("check_reason"));
            }
        }

        renderJson(Common.buildResp(0, "订单审核成功"));
    }

    /**
     * 订单终止。支持订单在“已支付”，“交易完成”，“交易取消”这三种情况下的仲裁方式！
     * 在卖家发起投诉并经过客服证实之后，由客服系统调用该接口，同时将租金转账给卖家，扣除全部买家押金，同时扣减买家信誉分
     */
    public void terminate() {
        String orderId = getPara("order_id");
        String cancelReason = getPara("cancel_reason", "");
        if (StringUtils.isBlank(orderId)) {
            renderJson(buildResp(1, "没有订单ID"));
            return;
        }
        //扣除的买家信誉分
        int playScore = getParaToInt("play_score", 5);
        if ((playScore >= 0 && playScore < 5) || playScore > 100) {
            renderJson(buildResp(1, "扣除的信誉分的范围应在5分~100分范围。"));
            return;
        }

        //如果订单还在支付中，走终止订单流程
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        JSONObject result = BuyuserPunishmentService.instance.punish(order, cancelReason, playScore);
        renderJson(result);
    }


    /**
     * 导入游戏
     */
    public void importGame() {
        String gameId = getPara("game_id");
        if (StringUtils.isBlank(gameId)) {
            renderJson(buildResp(1, "没有游戏ID"));
            return;
        }

        DataBean<Game> bean = gameService.getGameById(gameId);
        if (bean == null || bean.getData() == null) {
            renderJson(buildResp(2, "不存在的游戏"));
            return;
        }

        Game game = bean.getData();
        Record row = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", gameId);
        if (row != null) {
            renderJson(buildResp(3, "已经存在该游戏的配置"));
            return;
        }

        //扩展数据
        String ext = getPara("ext");
        JSONObject extJson = null;
        try {
            if (StringUtils.isNotBlank(ext)) {
                extJson = JSONObject.fromObject(ext);
            }
        } catch (Exception e) {
            logger.error("error", e);
            renderJson(buildResp(2, "扩展数据格式不是JSON"));
            return;
        }

        //入库
        Record g = new Record();
        g.set("game_id", game.getGameId().trim());
        g.set("game_name", game.getGameName().trim());
        g.set("icon_url", game.getGamePic());
        g.set("has_guarantee_deposit", 1);
        g.set("fee_rate", -1.0);
        g.set("status", 1);
        if (!SmartDb.save("game_conf", g)) {
            logger.error("添加游戏失败，sql=>" + SmartDb.lastQuery());
            renderJson(buildResp(4, "保存游戏配置失败了"));
            return;
        }

        //保存扩展信息
        if (extJson != null) {
            for (Object key : extJson.keySet()) {
                Record e = new Record();
                e.set("game_id", gameId);
                e.set("prop_key", key);
                e.set("prop_name", extJson.get(key));
                e.set("status", 1);
                if (!SmartDb.save("product_properties", e)) {
                    logger.error("保存扩展属性失败，sql=>" + SmartDb.lastQuery());
                }
            }
        }

        renderJson(buildResp(0, "ok"));
    }

    /**
     * 订单自助撤单的复核结果
     */
    public void recheck() {
        int id = getParaToInt("id", 0);
        int punishmentWay = getParaToInt("punishment_way", -1);
        if (id <= 0) {
            renderJson(buildResp(1, "没有自助撤单ID"));
            return;
        }
        int pass = getParaToInt("pass", 1); //默认通过撤单审核
        String remark = getPara("remark", "");
        int score = getParaToInt("score", 0);

        Record evidence = SmartDb.findFirst("select * from `order_cancel_evidence` where `id`=?", id);
        if (evidence == null) {
            renderJson(buildResp(1, "不存在的撤单证据"));
            return;
        }

        //先将一些有用的信息取出来
        String arbitrateReason = evidence.getStr("arbitrate_reason");

        evidence.keep("id");
        evidence.set("pass", pass);
        evidence.set("remark", remark);
        evidence.set("punishment_way", punishmentWay);
        if (!SmartDb.update("order_cancel_evidence", "id", evidence)) {
            logger.error("保存撤单证据时发生了错误，sql=>" + SmartDb.lastQuery());
        }
        Record order = SmartDb.findFirst("select o.* from `order` o, `order_cancel_evidence` oc where oc.order_id=o.order_id and oc.id=?", id);
        if (order == null) {
            logger.error("进行自助撤单复核时发现一个不存在的订单，id=>" + id + ", remark=>" + remark + ", score=>" + score);
            renderJson(buildResp(2, "不存在的订单"));
            return;
        }

        int selluserUid = order.getInt("selluser_uid");
        String orderId = order.getStr("order_id");
        int orderPayAmount = order.getInt("order_pay_amount");
        String productName = order.getStr("product_name");
        int orderStatus = order.getInt("order_status");
        int buyuserUid = order.getInt("buyuser_uid");
        String buyuserPhone = order.getStr("buyuser_phonenum");
        String sellerPhone = order.getStr("selluser_phonenum");
        //仲裁成功！处理起来有点复杂
        if (pass == Order.EVIDENCE_ARBITRATE_SUCC) {
            //通知买家
            NotifyService.instance.sendArbitrateSuccessToBuyuser(orderId);

            //----------------------------------惩罚-----------------------------------------------

            logger.info("惩罚类型：" + punishmentWay);
            JSONObject result = null;
            switch (punishmentWay) {
                case Order.PUNISHMENT_ALL_BUYER:
                    result = BuyuserPunishmentService.instance.punish(order, arbitrateReason, score);
                    break;
                case Order.PUNISHMENT_DO_NOTHING:
                    result = BuyuserPunishmentService.instance.noPunistment(order, arbitrateReason, score);
                    break;
                case Order.PUNISHMENT_DECREASE_BUYERSCORE:
                    result = BuyuserPunishmentService.instance.punishByDecreaseScore(order, arbitrateReason, score);
                    break;
                default:
                    break;
            }
            renderJson(result);
        } else if (pass == Order.EVIDENCE_ARBITRATE_FAIL) {
            order.keep("order_id");
            order.set("is_selluser_arbitrate", Order.SELLUSER_ARBITRATE_FAIL);
            if (!SmartDb.update("order", "order_id", order)) {
                logger.error("完成订单失败了，sql=>" + SmartDb.lastQuery());
                renderJson(buildResp(5, "ok"));
            }
            //微信通知买家
			/*JSONObject message = new JSONObject().accumulate("orderId", orderId)
					.accumulate("gameName", order.getStr("game_name")).accumulate("cancelReason", order.getStr("cancel_reason"))
					.accumulate("orderPayAmount",Common.round(orderPayAmount/100.0, 2))
					.accumulate("productName",productName).accumulate("selluserUid",selluserUid)
					.accumulate("buyuserPhonenum",buyuserPhone).accumulate("selluserPhonenum",sellerPhone)
					.accumulate("buyuserUid",buyuserUid);
			RemindMessagePushService.sendArbitrateFail(message);*/

            //退款给买家暂不支持其它操作方式！以后看情况加逻辑吧！

        }
        renderJson(buildResp(0, "ok"));
    }

    /**
     * 手工发放代金券
     */
    public void giveCoupon() {
        int uid = getParaToInt("uid");
        String couponId = getPara("coupon_id");
        int count = getParaToInt("count", 1);

        Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=? and `status`=?", couponId, Coupon.STATUS_ONSALE);
        if (coupon == null) {
            renderJson(buildResp(1, "不存在的优惠券"));
            return;
        }

        for (int i = 0; i < count; ++i) {
            if (!Coupon.take(uid, coupon)) {
                logger.error("发放代金券【" + couponId + "】给uid【" + uid + "】失败了...");
            }
        }

        renderJson(buildResp(0, "ok"));
    }

    public void giveBean() {
        int uid = getParaToInt("uid", 0);
        if (uid <= 0) {
            renderJson(buildResp(1, "没有UID"));
            return;
        }
        int beanCount = getParaToInt("bean", 0);
        if (beanCount <= 0) {
            renderJson(buildResp(1, "没有指定开心豆"));
            return;
        }

        if (!GameCenterService.instance.giveBean(uid, beanCount)) {
            renderJson(buildResp(1, "派发开心豆失败"));
            return;
        }

        logger.info("手工给用户【" + uid + "】派发开心豆【" + beanCount + "】");

        renderJson(buildResp(0, "ok"));
    }

    public void reportProductOffsale() {
        String productId = getPara("product_id");
        String offsaleReason = getPara("offsale_reason");
        int forbidden = getParaToInt("forbidden", 0);
        String uidStr = getPara("uid");
        int score = getParaToInt("score", 0);

        JSONArray followUid = null;
        try {
            followUid = JSONArray.fromObject(uidStr);
        } catch (Exception e) {
            renderJson(buildResp(1, "举报人UID格式不正确"));
            return;
        }
        if (followUid.size() == 0) {
            renderJson(buildResp(1, "没有举报人UID"));
            return;
        }

        if (StringUtils.isBlank(productId)) {
            renderJson(buildResp(1, "没有商品ID"));
            return;
        }
        if (StringUtils.isBlank(offsaleReason)) {
            renderJson(buildResp(1, "没有下架原因"));
            return;
        }

        Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
        if (product == null) {
            renderJson(buildResp(2, "不存在的商品"));
            return;
        }

        //商品没有下架，则下架！若已经下架了，就不用管了。。。
        if (product.getInt("status") != Product.STATUS_OFFSALE) {
            //下架该商品
            if (!Product.offsale(productId, offsaleReason, false)) {
                renderJson(buildResp(3, "下架商品发生了错误"));
                return;
            }
        }

        //扣分！
        if (score > 0) {
            User.decreaseReputationScore(product.getInt("seller_uid"), score, "商品【" + productId + "】被举报，原因:" + offsaleReason);
        }

        //如果要封禁卖家
        if (forbidden == 1) {
            if (User.userSpecial(product.getInt("seller_uid"), User.TYPE_NO_PRODUCT) == null) {
                User.addUserSpecial(product.getInt("seller_uid"), User.TYPE_NO_PRODUCT, Common.now(), "2099-01-01 00:00:00", "因商品【" + productId + "】被举报而封禁，原因：" + offsaleReason + "；productInfo=>" + product.toJson());
            }
        }

        renderJson(buildResp(0, "ok"));
    }

    /**
     * 处理号主等级签约申请
     */
    public void doSellerLevelAppointment() {
        int id = getParaToInt("id", 0);
        int status = getParaToInt("status", 0);
        String remark = getPara("remark", "");
        if (id <= 0) {
            renderJson(buildResp(Common.RESPONSE_FAIL, "id参数为空"));
            return;
        }
        if (status <= 0) {
            renderJson(buildResp(Common.RESPONSE_FAIL, "审核状态不合法"));
            return;
        }

        Record applyItem = SmartDb.findFirst("select * from seller_apply where id = ? and status = ?", id, User.SELL_UPGRADELEVEL_NEW);
        if (applyItem == null) {
            renderJson(buildResp(Common.RESPONSE_FAIL, "该记录不存在或者已经处理"));
            return;
        }

        int uid = applyItem.getInt("uid");
        int applyingSellLevel = applyItem.getInt("applying_sell_level");
        applyItem.keep("id");
        applyItem.set("status", status);
        applyItem.set("u_time", Common.now());
        if (StringUtils.isNotEmpty(remark)) {
            applyItem.set("remark", remark);
        }
        //更新状态
        if (!SmartDb.update("seller_apply", applyItem)) {
            logger.error("更新申请记录状态错误，id=" + id);
            renderJson(buildResp(Common.RESPONSE_FAIL, "更新申请记录状态错误"));
            return;
        }
        //发送信息
        if (status == User.SELL_UPGRADELEVEL_PASS) {
            if (SmartDb.update("update member set sell_level = ? where uid = ?", applyingSellLevel, uid) <= 0) {
                logger.error("更新申请记录状态错误，uid=" + uid);
                renderJson(buildResp(Common.RESPONSE_FAIL, "更新用户状态错误"));
                return;
            }
            //更新商品的号主等级
            SmartDb.update("update `product` set sell_level = ?,support_type where uid = ? and support_type = ? ", applyingSellLevel, Product.SUPPORT_TYPE_DISSATISFY, uid, Product.SUPPORT_TYPE_SUPPORTED);
            NotifyService.instance.sendSellerLevelChangeMessageToSelluser(uid, User.SELL_LEVEL_NORMAL, applyingSellLevel);
        }

        if (status == User.SELL_UPGRADELEVEL_FAIL) {
            NotifyService.instance.sendSellerLevelChangeMessageToSelluser(uid, User.SELL_LEVEL_NORMAL, User.SELL_LEVEL_NORMAL);
            return;
        }

        renderJson(buildResp(Common.RESPONSE_SUCCESS, "处理成功"));
        return;
    }

//    /**
//     * 推荐商品提醒
//     */
//    public void doProductRecommendedRemind() {
//        int uid = getParaToInt("uid", 0);
//        if (uid <= 0) {
//            renderJson(buildResp(Common.RESPONSE_FAIL, "uid参数为空"));
//            return;
//        }
//        NotifyService.instance.sendProductRecommendedMessageToSelluser(uid);
//        renderJson(buildResp(Common.RESPONSE_SUCCESS, "通知成功"));
//    }

    /**
     * 当扶持申请不通过时，需要发送消息给用户
     */
    public void sendSupportApplyMessage() {
        String productId = getPara("product_id");
        if (StringUtils.isBlank(productId)) {
            renderJson(buildResp(1, "product_id  is null"));
            return;
        }
        Record supportApply = SmartDb.findFirst("select * from product_support_apply  where product_id =?", productId);
        if (supportApply == null) {
            renderJson(buildResp(1, "找不到商品扶持记录"));
            return;
        }
        if (supportApply.getInt("status") != 2) {
            renderJson(buildResp(1, "只有审核不通过的商品才需要发送消息"));
            return;
        }

        //通知扶持失败
        NotifyService.instance.sendProductSupportFailMessageToSelluser(productId);

        renderJson(buildResp(0, "ok"));
    }
}
