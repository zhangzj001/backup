package cn.jugame.rent.page;

import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.Mall;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.page.service.GameCenterService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.helper.misc.ChecksumHelper;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.*;

public class MallController extends BaseController{
	
	private Logger logger = Loggers.rentLog();
	
	private IPayment payment = PaymentFactory.get();

	@Before(LoginInterceptor.class)
	public void index(){
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行操作");
			return;
		}
		
		//从游戏大厅获取开心豆
		int beanCount = GameCenterService.instance.getBeanCount(uid);
		setAttr("beanCount", beanCount);
		
		List<Record> rows = SmartDb.find("select * from `mall` where `status`=1 order by `weight`");
		for(Record row : rows){
			if(row.getInt("external_type") == Mall.TYPE_RMB_COUPON){
				double price = Common.round(row.getInt("price")/100.0, 2);
				row.set("price", price);
			}
		}
		setAttr("mall_items", toMap(rows));
		render("index.html");
	}

	@Before(LoginInterceptor.class)
	public void exchange(){
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行操作");
			return;
		}
		
		String mallId = getPara("mall_id");
		if(StringUtils.isBlank(mallId)){
			errorPage("没有商城商品ID。");
			return;
		}
		Record mallProduct = SmartDb.findFirst("select * from `mall` where `mall_id`=?", mallId);
		if(mallProduct == null){
			errorPage("不存在的商城商品。");
			return;
		}
		
		//根据不同的商品类型，做不同的兑换逻辑
		int externalType = mallProduct.getInt("external_type");
		
		//按用户加分布式锁，保证兑换操作的串行
		DistLocker locker = new DistLocker(uid + "_mall_exchange");
		try{
			locker.lock(PropKit.getInt("displock.timeout"));
			
			//----------------------------------
			//兑换租号优惠券
			if(externalType == Mall.TYPE_BEAN_COUPON){
				if(!exchangeCoupon(uid, mallProduct))
					return;

				setAttr("msg", "兑换成功！");
				render("succ.html");
				return;
			}
			else if(externalType == Mall.TYPE_RMB_COUPON){
				//成不成功都由该函数控制跳转！
				exchangeRmbCoupon(uid, mallProduct);
				return;
			}
			else if(externalType == Mall.TYPE_DATA_TRAFFIC_COUPON){
				if(!exchangeDataTrafficCoupon(uid, mallProduct))
					return;

				setAttr("msg", "<strong>请在<a href='http://app.8868.cn/'>8868交易助手</a>进行流量充值！</strong>租号平台<strong>不会展现</strong>您成功兑换的流量券，请到8868交易助手查阅！");
				render("succ.html");
				return;
			}
			else{
				errorPage("您领取了一个平台无法识别的优惠商品。");
				return;
			}
		}catch(Exception e){
			errorPage("兑换时系统发生了一些小问题。");
			logger.error("exchange.error", e);
		}finally{
			locker.unlock();
		}
	}
	
	private String generateMallOrderId(){
		return "MALLORD-" + Common.now("yyMMdd-HHmmssSSS") + String.format("%02d", Common.rand(0, 99));
	}
	
	/**
	 * 兑换租号优惠券
	 * @param uid
	 * @param mallProduct
	 * @return
	 */
	private boolean exchangeCoupon(int uid, Record mallProduct){
		String couponId = mallProduct.getStr("external_id");
		
		//确保用户有足够的开心豆
		int beanCount = GameCenterService.instance.getBeanCount(uid);
		int price = mallProduct.getInt("price");
		if(beanCount < price){
			errorPage("您的开心豆不足，无法兑换。");
			return false;
		}

		Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=?", couponId);
		if(coupon == null){
			errorPage("不存在的优惠券，无法兑换。");
			return false;
		}

		//若不能领取
		if(!isValid(mallProduct, coupon, uid))
			return false;

		//是否能正常消耗开心豆
		if(!GameCenterService.instance.consume(uid, price)){
			errorPage("消耗开心豆失败，无法兑换优惠券。");
			return false;
		}
		
		//最终将该优惠券绑定给用户
		if(!Coupon.take(uid, coupon)){
			errorPage("领取优惠券时发生了一些错误。");
			return false;
		}
		
		//记录下这次兑换操作
		Record row = new Record();
		row.set("uid", uid);
		row.set("c_time", Common.now());
		row.set("mall_id", mallProduct.getStr("mall_id"));
		row.set("mall_external_id", mallProduct.getStr("external_id"));
		row.set("mall_external_name", mallProduct.getStr("external_name"));
		row.set("mall_external_pic", mallProduct.getStr("external_pic"));
		row.set("mall_external_type", mallProduct.getInt("external_type"));
		row.set("price", price);
		row.set("pay_id", generateMallOrderId());
		row.set("pay_succ_time", Common.now());
		if(!SmartDb.save("mall_exchange_order", row)){
			logger.error("用户【" + uid + "】兑换商城奖品【" + mallProduct.getStr("mall_id") + "】时记录兑换日志发生了错误");
		}
		
		return true;
	}
	
	/**
	 * 兑换RMB类型的优惠券
	 * @param uid
	 * @param mallProduct
	 * @return
	 */
	private boolean exchangeRmbCoupon(int uid, Record mallProduct){
		String couponId = mallProduct.getStr("external_id");
		String mallId = mallProduct.getStr("mall_id");

		Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=?", couponId);
		if(coupon == null){
			errorPage("不存在的优惠券，无法兑换。");
			return false;
		}

		//若不能领取
		if(!isValid(mallProduct, coupon, uid))
			return false;
		
		String productName = mallProduct.getStr("external_name");
		int price = mallProduct.getInt("price");
		String payId = generateMallOrderId();
		
		//先记录兑换日志
		Record row = new Record();
		row.set("uid", uid);
		row.set("c_time", Common.now());
		row.set("mall_id", mallProduct.getStr("mall_id"));
		row.set("mall_external_id", mallProduct.getStr("external_id"));
		row.set("mall_external_name", mallProduct.getStr("external_name"));
		row.set("mall_external_pic", mallProduct.getStr("external_pic"));
		row.set("mall_external_type", mallProduct.getInt("external_type"));
		row.set("price", price);
		row.set("pay_id", payId);
		if(!SmartDb.save("mall_exchange_order", row)){
			logger.error("商城商品【" + mallId + "】进行人民币支付时，入库发生了错误！");
			errorPage("您购买这件商城商品时系统发生了一些错误，暂时无法购买。");
			return false;
		}
		
		//生成支付页面并跳转到支付页
		String html = payment.easyPay(
				uid, 
				payId, 
				productName, 
				Common.round(price/100.0, 2), "购买商城商品【" + mallId + "】", 
				PropKit.get("mall.cb_frontend_url"), 
				PropKit.get("mall.cb_backend_url"),
				Common.getIp(getRequest())
		);
		renderHtml(html);
		return true;
	}

	private boolean exchangeDataTrafficCoupon(int uid, Record mallProduct){
		String couponId = mallProduct.getStr("external_id");

		//确保用户有足够的开心豆
		int beanCount = GameCenterService.instance.getBeanCount(uid);
		int price = mallProduct.getInt("price");
		if(beanCount < price){
			errorPage("您的开心豆不足，无法兑换。");
			return false;
		}

		Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=?", couponId);
		if(coupon == null){
			errorPage("不存在的优惠券，无法兑换。");
			return false;
		}

		//是否能正常消耗开心豆
		if(!GameCenterService.instance.consume(uid, price)){
			errorPage("消耗开心豆失败，无法兑换优惠券。");
			return false;
		}

		//若不能领取
		if(!isValid(mallProduct, coupon, uid))
			return false;

		//当前时间
		String cTime = Common.now();

		Record row = new Record();
		row.set("name", coupon.getStr("name"));
		row.set("uid", uid);
		row.set("type", 2); //2=>满减优惠券
		row.set("amount", Common.round(coupon.getInt("amount_off")/100.0, 2)); //优惠金额
		row.set("min_product_price", 1.0); //满减最低金额
		row.set("status", 5); //5=>未使用
		row.set("remark", "租号商城兑换");
		row.set("create_time", cTime);
		row.set("start_time", cTime);
		row.set("end_time", Common.addDay(cTime, coupon.getInt("valid_days")));
		row.set("description", "租号商城兑换");
		if(!SmartDb.get("base_order").save("flow_coupon", row)){
			logger.error("用户【" + uid + "】兑换流量券商城商品时发生了错误！mall_id=>" + mallProduct.getStr("mall_id"));
			return false;
		}


		//记录下这次兑换操作
		row = new Record();
		row.set("uid", uid);
		row.set("c_time", Common.now());
		row.set("mall_id", mallProduct.getStr("mall_id"));
		row.set("mall_external_id", mallProduct.getStr("external_id"));
		row.set("mall_external_name", mallProduct.getStr("external_name"));
		row.set("mall_external_pic", mallProduct.getStr("external_pic"));
		row.set("mall_external_type", mallProduct.getInt("external_type"));
		row.set("price", price);
		row.set("pay_id", generateMallOrderId());
		row.set("pay_succ_time", Common.now());
		if(!SmartDb.save("mall_exchange_order", row)){
			logger.error("用户【" + uid + "】兑换商城奖品（流量券）【" + mallProduct.getStr("mall_id") + "】时记录兑换日志发生了错误");
		}

		return true;
	}

	private boolean isValid(Record mallProduct, Record coupon, int uid){
		String couponId = coupon.getStr("coupon_id");

		//确保cd时间已经过了
		int cdTime = mallProduct.getInt("cd_time");
		long now = System.currentTimeMillis();
		if(cdTime > 0){
			Record last = SmartDb.findFirst("select * from `mall_exchange_order` where `uid`=? and `mall_external_id`=? and `pay_succ_time` is not null order by `pay_succ_time` desc limit 1", uid, couponId);
			if(last != null && (now < last.getDate("pay_succ_time").getTime() + cdTime*60L*1000)){
				errorPage("连续购买该商城商品的冷却时间还未到，请到期了再来购买。");
				return false;
			}
		}

		//确保优惠券还没过期
		if(coupon.getInt("status") != Coupon.STATUS_ONSALE){
			errorPage("优惠券已下架，无法兑换。");
			return false;
		}
		//确保是系统派发类型的优惠券
		if(coupon.getInt("taken_type") != Coupon.TAKEN_TYPE_SYSTEM){
			errorPage("该优惠券不是可兑换优惠券！");
			return false;
		}

		//是否已经超过领取次数了
		int takenTimesLimit = coupon.getInt("taken_times_limit");
		Record userCouponCount = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=? and `coupon_id`=?", uid, couponId);
		if(takenTimesLimit > 0 && userCouponCount.getLong("_count") >= takenTimesLimit){
			errorPage("您已经领取过这个优惠券!");
			return false;
		}

		return true;
	}



	@Before(LoginInterceptor.class)
	public void frontend(){
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行操作");
			return;
		}
		
		String payId = getPara("orderId");
		if(StringUtils.isBlank(payId)){
			errorPage("没有支付单ID");
			return;
		}
		
		Record exchangeOrder = SmartDb.findFirst("select * from `mall_exchange_order` where `pay_id`=?", payId);
		if(exchangeOrder == null){
			errorPage("不存在的支付交易");
			return;
		}
		
		//看看是否支付了，做不同的提示
		Date paySuccTime = exchangeOrder.getDate("pay_succ_time");
		if(paySuccTime == null){
			setAttr("msg", "您刚刚放弃了购买【" + exchangeOrder.getStr("mall_external_name") + "】。");
			render("succ.html");
			return;
		}
		
		setAttr("msg", "您已成功购买了【" + exchangeOrder.getStr("mall_external_name") + "】！");
		render("succ.html");
	}
	
	public void backend(){
		String payId = getPara("orderId"); //租赁单ID
		if(StringUtils.isBlank(payId)){
			renderJson(buildResp(1, "没有支付单ID"));
			return;
		}
		String recvAmount = getPara("recvAmount");
		long payFinishTime = getParaToLong("completeTime", 0L);
		String strategeId = getPara("strategeId");
		String zhifuPlatformWayId = getPara("zhifuPlatformWayId");
		String zhifuPlatformWayName = getPara("payWay");
		String vcode = getPara("vcode", "");
		
		//验签
		Map<String, String> params = new TreeMap<String, String>();
		StringBuffer log = new StringBuffer("商城收到支付后台回调，参数为：\n");
		Enumeration<String> enu = getParaNames();
		while(enu.hasMoreElements()){
			String name = enu.nextElement();
			log.append(name).append("=").append(getPara(name)).append("\n");
			if("vcode".equals(name))
				continue;
			params.put(name, getPara(name));
		}
		log.append("-----------------------------");
		logger.info(log.toString());
		
		String checkVcode = ChecksumHelper.getChecksum(params, PropKit.get("busi.secretkey"));
		logger.info("payId=>" + payId + ", vcode=>" + vcode);
		logger.info("payId=>" + payId + ", checkvcode=>" + checkVcode);
		if(!vcode.equalsIgnoreCase(checkVcode)){
			logger.info("payId=>" + payId + "签名失败了！");
			renderJson(buildResp(1, "签名失败"));
			return;
		}
		
		//查询这次交易的商城订单
		Record exchangeOrder = SmartDb.findFirst("select * from `mall_exchange_order` where `pay_id`=?", payId);
		if(exchangeOrder == null){
			renderJson(buildResp(2, "不存在的商城交易"));
			return;
		}
		
		//如果已经有了支付时间，则认为已经交易完成了，忽略这次回调
		if(exchangeOrder.getDate("pay_succ_time") != null){
			logger.error("此次商城交易已经完结，忽略这次回调，payId=>" + payId);
			renderJson(buildResp(3, "此次商城交易已经完成"));
			return;
		}
		
		//先取出一些有用的数据
		String couponId = exchangeOrder.getStr("mall_external_id");
		int uid = exchangeOrder.getInt("uid");
		
		Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=?", couponId);
		if(coupon == null){
			logger.error("商城交易数据发生了错误，配置了一个不存在的优惠券，payId=>" + payId + "，exchangeOrder.id=>" + exchangeOrder.getLong("id"));
			renderJson(buildResp(4, "此次商城交易发生了配置数据的错误"));
			return;
		}
		
		//回填支付成功时间，并对用户进行商城商品发放
		exchangeOrder.keep("id");
		exchangeOrder.set("pay_succ_time", Common.show_time(payFinishTime));
		if(!SmartDb.update("mall_exchange_order", "id", exchangeOrder)){
			logger.error("商城交易保存数据失败，payId=>" + payId + "， sql=>" + SmartDb.lastQuery());
			renderJson(buildResp(4, "保存商品交易数据失败"));
			return;
		}
		
		//派发优惠券
		if(!Coupon.take(uid, coupon)){
			logger.error("领取优惠券时发生了一些错误。payId=>" + payId);
			renderJson(buildResp(5, "派发优惠券时发生了一些错误"));
			return;
		}
		
		renderJson(buildResp(0, "ok"));
	}
	
	/**
	 * 查看我的兑换历史
	 */
	@Before(LoginInterceptor.class)
	public void exchangeLog(){
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行操作");
			return;
		}
		
		int pageSize = 20;
		List<Record> rows = SmartDb.find("select * from `mall_exchange_order` where `uid`=? and `pay_succ_time` is not null order by `c_time` desc limit ?", uid, pageSize);
		for(Record row : rows){
			//若类型是人民币的，转换成元
			if(row.getInt("mall_external_type") == Mall.TYPE_RMB_COUPON){
				double price = Common.round(row.getInt("price")/100.0, 2);
				row.set("price", price);
			}
		}
		setAttr("logs", toMap(rows));
		render("exchange_logs.html");
	}
	
}
