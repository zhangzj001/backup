package cn.jugame.rent.page;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.page.service.OrderCancelService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.Date;
import java.util.List;

@Before(LoginInterceptor.class)
public class OrderCancelController extends BaseController{
	
	private Logger logger = Loggers.rentLog();
	
	/**
	 * 玩家侧撤单
	 * 1. 客服不在线：前15分钟+当天头2次撤单+玩家信誉分>=95分，若无押金立即全额退，有押金24小时后全额退
	 * 				15分钟后 or 第3次以后撤单 or 玩家信誉分<95分，统一24小时后计时退
	 * 2. 客服在线：流入客服后台处理
	 */
	public void index(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行撤单操作。");
			return;
		}

		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("您没有选择订单进行撤单操作。");
			return;
		}
		String cancelReason = getPara("cancel_reason");
        String cancelReasonEx = getPara("cancel_reason_ex", "");
        if(StringUtils.isBlank(cancelReason)){
		    errorPage("您没有选择撤单理由");
		    return;
        }

		//自助撤单的证据图片
		String[] pics = getParaValues("pic");
		if(pics == null) pics = new String[0]; //做一层保险
		if(pics.length == 0){
			errorPage("请至少上传1张证据截图");
			return;
		}
		if(pics.length > 5){
			errorPage("最多上传5张证据截图");
			return;
		}
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=? and `buyuser_uid`=?", orderId, uid);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}
		
		//如果订单已经撤销了，不再重复提交
		if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
			errorPage("您当前订单不是出租中的状态，无法进行撤单。");
			return;
		}
		
		List<Record> currentApplies = SmartDb.find("select * from `order_cancel_apply` where `order_id`=? order by `id` asc", orderId);
		//如果撤单申请已经达到了额定次数，则不允许提交撤单
		if(currentApplies.size() >= PropKit.getInt("order.max_cancel_apply_times")){
			errorPage("您已经超过了额定申请撤单次数，该订单不允许再次提交撤单申请。");
			return;
		}
		
		//如果客服在线
		boolean isKefuRest = Common.inHour(PropKit.getInt("kefu.rest_time.begin"), PropKit.getInt("kefu.rest_time.end"));
		if(!isKefuRest){
			JSONArray picsJson = new JSONArray();
			for(String pic : pics){
				picsJson.add(pic);
			}
			
			//创建apply
			Record apply = new Record();
			apply.set("order_id", orderId);
			apply.set("status", Order.ORDER_CANCEL_APPLY_NEW);
            apply.set("cancel_reason", cancelReason);
            apply.set("pics", picsJson.toString());
            apply.set("c_time", Common.now());
            apply.set("cancel_reason_ex", cancelReasonEx);
            apply.set("selluser_uid", order.getInt("selluser_uid"));
            apply.set("buyuser_uid", order.getInt("buyuser_uid"));
			if(!SmartDb.save("order_cancel_apply", apply)){
				logger.error("订单【" + orderId + "】创建撤单申请时发生了错误！sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				errorPage("系统在提交您的撤单申请时发生了一些错误，请联系客服进行撤单处理。");
			}
			
			redirect("/order/detail?order_id=" + orderId);
			return;
		}
		
		//！！！ 客服不在线！！！ 走自动撤单流程！！！
		//1. 判断是否免责（全额退租金）
		boolean freeCancel = Order.isFreeCancel(uid, order);
		//2. 判断是否需要延迟24小时退
		boolean delayRefund = Order.isDelayRefund(order, freeCancel);
		
		OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
		cancelInfo.setBuyuserArbitrate(Order.BUYUSER_ARBITRATION);
		cancelInfo.setCancelReason(cancelReason);
		cancelInfo.setCancelReasonEx(cancelReasonEx);
		cancelInfo.setDelayRefund(delayRefund);
		cancelInfo.setFreeCancel(freeCancel);
		cancelInfo.setProductOffsale(true);
		cancelInfo.setProductOffsaleReason(cancelReason);
		for(String pic : pics){
			cancelInfo.addCancelPis(pic);
		}
		
		//用户申请自助撤单，则直接取消订单
		JSONObject result = new OrderCancelService(true).cancel(orderId, cancelInfo);
		if(result.getInt("code") != 0){
			logger.error("用户【" + uid + "】撤单（客服不在线）失败了，原因为：" + result.getString("msg"));
			errorPage("平台在处理您的撤单时发生了一些错误，请联系客服进行撤单操作。");
			return;
		}
		
		setAttr("free_cancel", freeCancel);
		setAttr("is_delay_refund", delayRefund);
		setAttr("order_id", orderId);
		render("/view/order/cancel.html");
	}
	
	/**
	 * 停止订单
	 */
	public void stop(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再进行撤单操作。");
			return;
		}

		String orderId = getPara("order_id");
		if(StringUtils.isBlank(orderId)){
			errorPage("您没有选择订单进行自助撤单操作。");
			return;
		}
		
		String stopReason = getPara("stop_reason");
        if(StringUtils.isBlank(stopReason)){
            errorPage("请认真填写停止原因！");
            return;
        }

        //自助仲裁的证据图片
        String[] pics = getParaValues("pic");
        if(pics == null) pics = new String[0]; //做一层保险
        if(pics.length == 0){
            errorPage("请至少上传1张截图");
            return;
        }
        if(pics.length > 10){
            errorPage("最多上传10张截图");
            return;
        }

		Record order = SmartDb.findFirst("select * from `order` where `order_id`=? and `selluser_uid`=?", orderId, uid);
		if(order == null){
			errorPage("不存在的订单");
			return;
		}

        //确保订单的卖家是本人
        if(uid.intValue() != order.getInt("selluser_uid").intValue()){
            errorPage("您无法停止他人的订单。");
            return;
        }

        //确保订单还在出租中
        if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
            errorPage("当前订单不在出租中，您无法停止。");
            return;
        }

        //超过免责时间之后，才允许号主停止订单
        Date rentStartTime = order.getDate("rent_start_time");
		if(System.currentTimeMillis() - rentStartTime.getTime() < PropKit.getInt("order.self_cancel_order.timeout")){
		    errorPage("起租15分钟后才支持停止订单。");
		    return;
        }

        //需要修改一些订单信息
        JSONArray json = new JSONArray();
        for(int i=0; i<pics.length; ++i){
            json.add(pics[i]);
        }
        order.keep("order_id");
        order.set("stop_reason", stopReason);
        order.set("stop_pics", json.toString());
        order.set("stop_time", Common.now());
        if(!SmartDb.update("order", "order_id", order)){
            logger.error("停止订单【" + orderId + "】时更新订单信息失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
            errorPage("您在停止订单时发生了系统错误，请您联系客服协助撤单。");
            return;
        }

        //发送通知
		NotifyService.instance.sendOrderStopToBuyuser(orderId);

        //停止订单后，执行撤单操作
		String cancelReason = "号主紧急停止订单";
		OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
		cancelInfo.setBuyuserArbitrate(Order.BUYUSER_ARBITRATION);
		cancelInfo.setCancelReason(cancelReason);
		cancelInfo.setCancelReasonEx("");
		cancelInfo.setDeductSelluserGuarantee(false);
		cancelInfo.setDelayRefund(true);
		cancelInfo.setFreeCancel(false);
		cancelInfo.setProductOffsale(true);
		cancelInfo.setProductOffsaleReason(cancelReason);
		for(String pic : pics){
			cancelInfo.addCancelPis(pic);
		}
        JSONObject result = new OrderCancelService(true).cancel(orderId, cancelInfo);
        if(result == null || result.getInt("code") != 0){
            logger.error("用户【" + uid + "】停止订单时撤单失败了，原因为：" + (result != null ? result.getString("msg") : "null"));
            errorPage("您在停止订单时系统发生了一些错误。");
            return;
        }

        render("/view/order/stop.html");
	}
}
