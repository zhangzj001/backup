package cn.jugame.rent.page;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class CouponController extends BaseController{
	private Logger logger = Loggers.rentLog();
	private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
	public final static  int COUPON_TAKEN_UNLIMIT = -1;
	/**
	 * 领取优惠券
	 */
	@Before(LoginInterceptor.class)
	public void takeCoupon(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再领取优惠券");
			return;
		}
		
		String couponId = getPara("coupon_id");
		if(StringUtils.isBlank(couponId)){
			errorPage("优惠券ID为空");
			return;
		}
		
		Record coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id`=?", couponId);
		if(coupon == null){
			errorPage("不存在的优惠券");
			return;
		}
		if(coupon.getInt("status") == Coupon.STATUS_OFFSALE){
			errorPage("该优惠券已经过期，无法领取");
			return;
		}
		
		//如果该优惠券只能由系统发放，则不允许自主领取，该由后台发放
		if(coupon.getInt("taken_type") != Coupon.TAKEN_TYPE_USER){
			errorPage("该优惠券由系统自动发放，您无法自主领取。");
			return;
		}


		//对于单个人，按顺序调用
		DistLocker locker = new DistLocker(uid + "_takeCoupon");
		try{
			//加锁
			locker.lock(PropKit.getInt("displock.timeout"));
			
			//判断是否符合领取条件
			if(Coupon.ACTION_TYPE_NEWCOMER.equals(coupon.getStr("action_type"))) {
				  if(!User.isNewcomerGiftUser(uid)) {
					  errorPage("该优惠券只能是新用户且未领取过礼包的用户才能领取！");
					  return;
				  }
			}else if(Coupon.ACTION_TYPE_OLDER.equals(coupon.getStr("action_type"))){
				if(User.isNewcomer(uid)) {
					errorPage("该优惠券只支持老用户领取及使用！");
					  return;
				}
			}else if(Coupon.ACTION_TYPE_NEWCOMER_ALONE.equals(coupon.getStr("action_type"))) {
				if(!User.isNewcomer(uid)) {
				 errorPage("该优惠券只支持新用户领取及使用！");
				  return;
				}
			}
			
			//判断是否已到最大领取数
			if(coupon.getInt("taken_type") == Coupon.TAKEN_TYPE_USER && coupon.getInt("max_taken_count") != COUPON_TAKEN_UNLIMIT && coupon.getInt("left_taken_count") <= 0){
				errorPage("该优惠券已领取完毕");
				return;
			}
			
			//是否已经达到最大领取次数
			int takenTimesLimit = coupon.getInt("taken_times_limit");
			Record userCouponCount =null;
			if(Coupon.DATE_RESET_TIMES_YES == coupon.getInt("date_reset_times")) {
				userCouponCount = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=? and `coupon_id`=? and c_time >= ? and c_time <= ?", 
						uid, couponId,Common.now("yyyy-MM-dd 00:00:00"), Common.now("yyyy-MM-dd 23:59:59"));
			}else{
				userCouponCount = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=? and `coupon_id`=?", uid, couponId);
			}
			if(takenTimesLimit > 0 && userCouponCount.getLong("_count") >= takenTimesLimit){
				errorPage("您已经领取过这个优惠券，无需重复领取!");
				return;
			}
			
			//绑定优惠券给这个uid
			if(!Coupon.take(uid, coupon)){
				errorPage("您领取优惠券的时候发生了一些意外...");
				return;
			}
			//更新剩余可领取次数
			String name = coupon.getStr("name");
			int leftTimes = coupon.getInt("left_taken_count");
			coupon.keep("id");
			coupon.set("left_taken_count",leftTimes-1 > 0 ? leftTimes-1 : 0);
			if(!SmartDb.update("coupon",coupon)){
				logger.error("扣除领取次数失败"+couponId);
			}
			setAttr("msg", "恭喜您成功领取【" + name + "】");
			render("take_coupon_succ.html");
		}catch(Exception e){
			logger.error("error", e);
			errorPage("您领取优惠券时系统发生了一些小错误。");
		}finally{
			locker.unlock();
		}
	}
	
	/**
	 * 查看我所有可用的优惠券
	 */
	@Before(LoginInterceptor.class)
	public void coupons(){
		final Integer uid = getSessionAttr("uid");
		if(uid == null){
			errorPage("请登录后再查看优惠券");
			return;
		}
		
		String now = Common.now("yyyy-MM-dd");
		List<Record> coupons = SmartDb.find("select * from `user_coupon` where `uid`=? and `status`=? and `end_date`>=?  and `left_times`>0", uid, Coupon.STATUS_ONSALE, now);
		//List<Record> coupons = SmartDb.find("select * from `user_coupon` where `uid`=? and `status`=? and `end_date`>=? and `beg_date`<=? and `left_times`>0", uid, Coupon.STATUS_ONSALE, now, now);
		
		Map<String, String> dateFormat = new TreeMap<>();
		dateFormat.put("beg_date", "yyyy-MM-dd");
		dateFormat.put("end_date", "yyyy-MM-dd");
		setAttr("coupons", coupons2map(coupons, dateFormat));
		render("coupons.html");
	}
	
	/**
	 * 推广页
	 */
	public void promote(){
		String couponId = getPara();
		if(StringUtils.isBlank(couponId)){
			errorPage("不存在的优惠券");
			return;
		}
		
		Record coupon = SmartDb.findFirst("select * from coupon where `coupon_id`=?", couponId);
		if(StringUtils.isBlank(couponId)){
			errorPage("不存在的优惠券");
			return;
		}
		
		//确保优惠券有效
		if(coupon.getInt("status") != Coupon.STATUS_ONSALE){
			errorPage("该优惠券已经过期，无法领取！");
			return;
		}
		//确保是用户自领类型的
		if(coupon.getInt("taken_type") != Coupon.TAKEN_TYPE_USER){
			errorPage("该优惠券只能由系统发放，无法自助领取！");
			return;
		}
		
		//把适用的游戏名获取出来
		String validGameName = "";
		String validGameId = coupon.getStr("valid_game_id");
		if(StringUtils.isNotBlank(validGameId)){
			try{
				JSONArray json = JSONArray.fromObject(validGameId);
				for(int i=0; i<json.size(); ++i){
					Record game = SmartDb.findFirst("select * from `game_conf` where `game_id`=?", json.getString(i));
					if(game != null)
						validGameName += game.getStr("game_name") + "，";
				}
			}catch(Exception e){
				//ignore
			}
		}
		if(validGameName.length() > 0){
			validGameName = validGameName.substring(0, validGameName.length()-1);
		}else{
			validGameName = "全部";
		}
		
		setAttr("coupon", toMap(coupon));
		setAttr("valid_game_name", validGameName);
		render("promote.html");
	}

	/**
	 * 新人礼包
	 * **/
	public void newcomerGift(){
		Integer uid = getSessionAttr("uid");
		setAttr("uid",uid == null ? 0:uid.intValue());

		//通过查询cookies解决跨域登录导致的点击领取新人礼包后的跳转问题
		if(uid != null) {
			hasGetNewcomerGift(uid);
		}
		List<Record> newcomerGift = Coupon.getNewcomerGift();
		setAttr("newcomer_gift", giftList2Map(newcomerGift));

		//是否领取新人礼包

	   if("1".equals(getPara("isApp")) && getCookie("user_sid") !=null){
		   Object uidObj = getSessionAttr("uid");
		   if(uidObj == null) {
			   StringBuffer currentUrl = getRequest().getRequestURL();
			   if(StringUtils.isNotBlank(getRequest().getQueryString())){
				   currentUrl.append("?").append(getRequest().getQueryString());
			   }
			   String redirectUrl = LoginInterceptor.getLoginUrl(PropKit.get("login_url"),
					   Common.url_encode(currentUrl.toString()),
					   "rent");
			   redirect(redirectUrl);
			   return;
		   }
	   }
	   
		setAttr("is_newcomer",uid == null ||    User.isNewcomerGiftUser(uid));
		setAttr("has_newcomer_gift_left",uid != null && User.hadNewcomerGiftLeft(uid));
		render("newcomer_gift.html");
	}

	/**
	 * 领取新人礼包
	 * **/
	//@Before(LoginInterceptor.class)
	public void getNewcomerGift(){
		//获取用户id
		Integer uid = getSessionAttr("uid");
		if(uid == null){
			renderJson(buildResp(Common.RESPONSE_FAIL,"请登录"));
			return;
		}
		
		//用于区分是否扶持区领取优惠券，现业务是将扶持商品优惠券加入新人礼包中 isSupport    0-非扶持区领新人礼包      1-扶持区领取新人礼包   2-扶持区领取扶持商品优惠券，且该优惠券不在新人礼包中
		int isSupport = getParaToInt("is_support", 0);
		
		String couponId = getPara("coupon_id");

		//发放优惠券
		if(!User.isNewcomerGiftUser(uid)&&isSupport==0){
			renderJson(buildResp(Common.RESPONSE_FAIL,"我们已经是老朋友了,请继续关注平台的后续福利哟"));
			return;
		}
		
		if(isSupport!=0&&StringUtils.isNotBlank(couponId)) {
			Record  coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id` =?", couponId);
			if(coupon!=null&&PropKit.get("default.gift","default").equals(coupon.get("action_type"))) 
				isSupport=2;
		}
		DistLocker locker = new DistLocker("newcomergift_" +uid );
		boolean succ = false;
		try{
			succ = locker.lock();
			if(!succ){
				logger.error("newcomergift_加锁失败，uid=>" + uid);
				renderJson(buildResp(Common.RESPONSE_EXCEPTION,"系统繁忙请稍后再试"));
				return;
			}
			Coupon.newComerGift(uid,isSupport);
		}finally{
			if(succ) locker.unlock();
		}
		renderJson(buildResp(Common.RESPONSE_SUCCESS,"优惠券已放入您的'我的-资产'中可速去下单，优惠体验哟"));

	}
	
	public void getNewCommerGiftPage() {
		//获取用户id
		Integer uid = getSessionAttr("uid")==null?getParaToInt("uid"):getSessionAttr("uid");
		int isPage = getParaToInt("isPage", 0);
		if(uid == null){
			errorPage("请登录后再领取优惠券");
			return;
		}
		
		//用于区分是否扶持区领取优惠券，现业务是将扶持商品优惠券加入新人礼包中 isSupport    0-非扶持区领新人礼包      1-扶持区领取新人礼包   2-扶持区领取扶持商品优惠券，且该优惠券不在新人礼包中
		int isSupport = getParaToInt("is_support", 0);
		
		String couponId = getPara("coupon_id");

		//发放优惠券
		if(!User.isNewcomer(uid)&&isSupport==0){
			errorPage("我们已经是老朋友了,请继续关注平台的后续福利哟");
			return;
		}
		//isReceive 为0表示未领取过
		int isReceive  = getParaToInt("is_receive",0);
		if(!User.hadNewcomerGift(uid)&&isReceive==0) {
			if(isSupport!=0&&StringUtils.isNotBlank(couponId)) {
				Record  coupon = SmartDb.findFirst("select * from `coupon` where `coupon_id` =?", couponId);
				if(coupon!=null&&PropKit.get("default.gift","default").equals(coupon.get("action_type"))) 
					isSupport=2;
			}
			DistLocker locker = new DistLocker("newcomergift_" +uid );
			boolean succ = false;
			try{
				succ = locker.lock();
				if(!succ){
					logger.error("newcomergift_加锁失败，uid=>" + uid);
					errorPage("系统繁忙请稍后再试");
					return;
				}
				Coupon.newComerGift(uid,isSupport);
			}finally{
				if(succ) locker.unlock();
			}
		}
		
		List<Record> newcomerGift = Coupon.getNewcomerGift();
		
		//XXX 通过sortId实现每个用户排序方式的不一样！
		Integer sortId = Product.getSortId(this);
		String orderBy = "";
		if(sortId == null){
			orderBy += "b.`id` asc ";
		}else{
			orderBy += "(b.`id` & " + sortId + ") asc ";
		}
		//获取时租价不大于300的推荐商品
	   List<Record>  products = SmartDb.find("select b.* from `product_recommended` a left join `product` b "
	   		+ "on a.product_id = b.product_id where b.`status` = "+Product.STATUS_ONSALE+" and b.price_hour<=300 order by a.`weight` desc ,"+orderBy +" limit 4");
	   List<Map<String, Object>> productList = product2map(products);
	   setAttr("product_list",productList);
	   setAttr("newcomer_gift", giftList2Map(newcomerGift));
	   
	   render("getNewcomerGift.html");
	}
}
