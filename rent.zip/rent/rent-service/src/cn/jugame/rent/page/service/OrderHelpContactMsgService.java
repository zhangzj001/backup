package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.utils.Common;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.jfinal.plugin.redis.Cache;
import com.jfinal.plugin.redis.Redis;
import net.sf.json.JSONObject;

import java.util.Date;

/**
 * 号主+玩家求助的聊天窗口内容！
 * @author ASUS
 *
 */
public class OrderHelpContactMsgService {
	
	public static class HelpMessage{
		private int receiverUid;
		private int sender; //see Order.HELP_MESSAGE_SENDER_xxx
		private String content;
		private Date time;
		public int getReceiverUid() {
			return receiverUid;
		}
		public void setReceiverUid(int uid) {
			this.receiverUid = uid;
		}
		public int getSender() {
			return sender;
		}
		public void setSender(int sender) {
			this.sender = sender;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public Date getTime() {
			return time;
		}
		public void setTime(Date time) {
			this.time = time;
		}
		
		public JSONObject toJson(){
			JSONObject infoMessage = new JSONObject();
	        infoMessage.accumulate("uid", receiverUid);
	        infoMessage.accumulate("sender", sender);
	        infoMessage.accumulate("content", content);
	        infoMessage.accumulate("time", time != null ? Common.show_time(time) : "~NaN~");
	        return infoMessage;
		}
	}
	
	/**
	 * 发送消息
	 * @param orderId 订单ID
	 * @param content 消息内容
	 * @param sender 发送者类型
	 * @param receiver 接收者类型
	 * @return
	 */
	public boolean sendMsg(String orderId, String content, int sender, int receiver){
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if(order == null){
            return false;
        }
        
        Cache cache = Redis.use("rent_redis");
        
        HelpMessage msg = new HelpMessage();
        msg.setContent(content);
        msg.setSender(sender);
        msg.setTime(new Date());
        msg.setReceiverUid(0);
        if(receiver == Order.HELP_MESSAGE_SENDER_BUYUSER){
        	msg.setReceiverUid(order.getInt("buyuser_uid"));
        }
        if(receiver == Order.HELP_MESSAGE_SENDER_SELLUSER){
        	msg.setReceiverUid(order.getInt("selluser_uid"));
        }
        
        if(msg.getReceiverUid() > 0){
	        //计算一下这个订单的租赁时长多久
	        Date rentStartTime = order.getDate("rent_start_time");
	        Date rentEndTime = order.getDate("rent_end_time");
	        int timeout = 3600; //默认缓存1小时
	        if(rentStartTime != null && rentEndTime != null){
	        	timeout = ((int)(rentEndTime.getTime() - rentStartTime.getTime()))/1000;
	        }
	        
	        StringBuffer messageKey = new StringBuffer().append(orderId).append("-").append(msg.getReceiverUid());
	        long result = cache.rpush(messageKey, msg.toJson().toString());
	        cache.expire(messageKey, timeout);
	        
	        return result > 0;
        }
        
        return true;
	}
	
}
