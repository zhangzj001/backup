package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.service.common.util.idbuilder.IDBuilder;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.List;

/**
 * 功能：商品优惠信息服务
 * 创建日期：2018-04-26
 * @author jiangshishan
 *
 */
public class ProductPromotionService {

    private final static Logger log =  Loggers.rentLog();

    //促销活动生效
    public final static int STATUS_PROMOTION_VALID = 1;
    //促销活动失效
    public final static int STATUS_PROMOTION_INVALID =0;
    //促销活动删除
    public final static int STATUS_PROMOTION_DELETE =-1;

    //促销活动类型:时租满送
    public final static int PROMOTION_TYPE_HOUR =1;
    //促销活动类型:日租满减
    public final static int PROMOTION_TYPE_DAY =2;
    
    //时租满送，最大可送值
    public final static int PROMOTION_TYPE_HOUR_MAX=12;
    private ProductPromotionService(){}

    public static ProductPromotionService instance = new ProductPromotionService();
    //增加优惠活动
    public boolean addOrUpdatePromotionActivity(JSONObject bean,String productId,int status,int type){


        if(bean != null && bean.opt("promote_unit") != null && bean.opt("promote_gift") != null) {
            String title = "租" + bean.optInt("promote_unit") + "减" + bean.optInt("promote_gift");
            Record promotion = new Record();
            promotion.set("product_id", productId);
            promotion.set("type", type);
            promotion.set("status", status);
            promotion.set("promote_unit", bean.opt("promote_unit"));

            if (type == PROMOTION_TYPE_DAY) {
                promotion.set("promote_gift_money", bean.optInt("promote_gift") * 100);
            } else {
                promotion.set("promote_gift_time", bean.optInt("promote_gift"));
            }
            promotion.set("promotion_title", title);

            promotion.set("c_time", Common.now());
            promotion.set("promotion_id", generatePromotionId());
            boolean result = SmartDb.save("product_promotions", promotion);
            if (!result) {
                log.error("增加优惠活动失败" + "-" + promotion.get("product_id"));
            }
            return result;
        }
        return  false;
    }

    /**
     * //增加优惠活动
     *promotionActivity :{"promotion_hour":{"data":[{"promote_unit":3,"promote_gift":1},{"promote_unit":4,"promote_gift":2},{"promote_unit":5,"promote_gift":3}],"status":1},"promotion_day":{"data":[{"promote_unit":1,"promote_gift":1},{"promote_unit":2,"promote_gift":3},{"promote_unit":3,"promote_gift":4}],"status":1}}
     *
     * **/
    public JSONObject savePromotionActivity(String promotionActivity,String productId){

        if(StringUtils.isEmpty(promotionActivity)){
            return null;
        }
        JSONObject promotionTitles = new JSONObject();

        //删除优惠活动
        if(deletePromotionActivity(productId)){
            log.error("删除优惠活动失败：productId-"+productId);
            return  null;
        }

        //提取数据
        JSONObject promotionBean = JSONObject.fromObject(promotionActivity);
        JSONObject promotionDay = promotionBean.optJSONObject("promotion_day");
        JSONObject promotionHour = promotionBean.optJSONObject("promotion_hour");
        if(promotionDay != null){
            JSONArray promotionDayBeans = promotionDay.optJSONArray("data");
            int status = promotionDay.optInt("status");
            JSONArray promotionDayTitle = new JSONArray();
            for(int index = 0 ; index < promotionDayBeans.size();index++){
                JSONObject bean = promotionDayBeans.optJSONObject(index);
                if(addOrUpdatePromotionActivity(bean,productId,status,PROMOTION_TYPE_DAY) && bean.optInt("promote_unit") > 0 ){
                    String title = "租"+bean.optInt("promote_unit")+"天减"+bean.optInt("promote_gift")+"元";
                    promotionDayTitle.add(title);
                }
            }
            if(status ==  STATUS_PROMOTION_VALID ) {
                promotionTitles.accumulate("promotion_day_title",promotionDayTitle);
            }
        }

        if(promotionHour != null){
            JSONArray promotionHourBeans = promotionHour.optJSONArray("data");
            int status = promotionHour.optInt("status");
            JSONArray promotionHourTitle = new JSONArray();
            for(int index = 0 ; index < promotionHourBeans.size();index++){
                JSONObject bean = promotionHourBeans.optJSONObject(index);
                if(addOrUpdatePromotionActivity(bean,productId,status,PROMOTION_TYPE_HOUR)){
                    String title = "租"+bean.optInt("promote_unit")+"送"+bean.optInt("promote_gift");
                    promotionHourTitle.add(title);
                }
            }
            if(status == STATUS_PROMOTION_VALID) {
                promotionTitles.accumulate("promotion_hour_title", promotionHourTitle);
            }
        }

        return  promotionTitles;
    }

    //删除优惠活动
    public boolean deletePromotionActivity(String productId){
        int result =  SmartDb.update("delete from product_promotions  WHERE product_id = ?",productId);
        if(result < 0){
            log.error("删除优惠活动失败"+"-"+productId);
        }
        return result < 0;
    }

    //查询订单关联优惠活动
    public JSONObject findOrderPromotionActivity(String orderId){
        JSONObject promotionInfo = new JSONObject();
        Integer promoteGiftTime = 0;
        Integer promoteGiftMoney = 0;
        List<Record> orderRelets = SmartDb.find("SELECT * FROM `order_relet` where order_id = ? and status != ?",orderId, Order.ORDER_STATUS_CANCEL);
        for(Record relet:orderRelets){
            if(relet.get("promote_gift_time")!=null) {
                promoteGiftTime += relet.getInt("promote_gift_time");
            }
            if(relet.get("promote_gift_money")!=null) {
                promoteGiftMoney += relet.getInt("promote_gift_money");
            }
        }
        promotionInfo.accumulate("promote_gift_time",promoteGiftTime);
        promotionInfo.accumulate("promote_gift_money",(int)Common.round(promoteGiftMoney/100.0, 0));
        return  promotionInfo;

    }

    //查询商品关联优惠活动
    public List<Record> findProductPromotionActivity(String productId){

        return SmartDb.find("SELECT * FROM product_promotions WHERE product_id = ? AND status = ? ",productId,STATUS_PROMOTION_VALID);
    }

    //获取最优惠的活动
    public Record findBestMatchPromotionActivity(int rentType,int rentCount,String productId){

        List<Record> promotionInfos = SmartDb.find("SELECT * FROM product_promotions WHERE product_id = ? AND status = ?",productId,STATUS_PROMOTION_VALID);
        Record basePromotionInfo =  SmartDb.findFirst("SELECT * FROM product_promotions WHERE product_id = ? AND status = ? and type = ?",productId,STATUS_PROMOTION_VALID,rentType);
        Record bestMatchPromotion = null;
        if(promotionInfos != null && promotionInfos.size() >0 && basePromotionInfo != null ) {
            int rentLeastDif = rentCount -basePromotionInfo.getInt("promote_unit");
            for (Record promotion : promotionInfos) {
                if(promotion.getInt("type") != rentType)
                    continue;
                int rentUnitDif = rentCount - promotion.getInt("promote_unit");
                if (rentUnitDif >= 0 && rentLeastDif >= rentUnitDif) {
                        rentLeastDif = rentUnitDif;
                        bestMatchPromotion = promotion;
                }
            }

        }

        return bestMatchPromotion;
    }

    //
    private String generatePromotionId(){
        return IDBuilder.productIdBuilder("RENT-PROMOTION");
    }

    /***
     *    时租最多只能送12个小时
     * @param promotionActivity
     * @return
     */
    public boolean validPromotionActivity(String promotionActivity) {
    	if(StringUtils.isBlank(promotionActivity))
    		return false;
    	//提取数据
        JSONObject promotionBean = JSONObject.fromObject(promotionActivity);
        JSONObject promotionHour = promotionBean.optJSONObject("promotion_hour");
        if(promotionHour==null)
        	return false;
        JSONArray promotionHourBeans = promotionHour.optJSONArray("data");
        for(int index = 0 ; index < promotionHourBeans.size();index++){
            JSONObject bean = promotionHourBeans.optJSONObject(index);
            if(bean.optInt("promote_gift")>PROMOTION_TYPE_HOUR_MAX){
            	return true;
            }
        }
    	return false;
    }
}
