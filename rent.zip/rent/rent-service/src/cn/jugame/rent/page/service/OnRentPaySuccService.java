package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.MD5;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.sql.SQLException;
import java.util.Date;

/**
 * 出租商品支付完成时
 */
public class OnRentPaySuccService {

    private OnRentPaySuccService(){}

    public static OnRentPaySuccService instance = new OnRentPaySuccService();

    private Logger logger = Loggers.rentLog();

    public JSONObject onPaySuccess(Record relet, long payFinishTime, String zhifuPlatformWayId, String zhifuPlatformWayName, String strategeId){
        String payId = relet.getStr("pay_id");

        String orderId = relet.getStr("order_id");
        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", relet.getStr("order_id"));
        if(order == null){
            logger.error("支付服务后台回调时传入了一个不存在订单，其租赁单ID=>" + payId);
            return Common.buildResp(1, "不存在的订单");
        }

        //更新订单状态为已支付
        logger.info("订单"+orderId+"支付回调，更新订单支付状态");
        if(SmartDb.update(String.format("update  `order` set `order_ispay` = %d WHERE order_id = '%s'",Order.ORDER_PAID,orderId)) <= 0){
            logger.error("更新租赁单支付信息失败了, sql=>" + SmartDb.lastQuery());
            return Common.buildResp(3, "更新租赁单支付信息失败了");
        }

        //----------------------------------------------------------------------------
        //有一些信息先拿出来
        String now = Common.now();
        int rentType = relet.getInt("rent_type");
        int buyCount = relet.getInt("buy_count");
        String selluserPhonenum = order.getStr("selluser_phonenum");
        String gameId = order.getStr("game_id");
        String gameName = order.getStr("game_name");
        String selluserGameAccount = order.getStr("selluser_game_account");
        String smsRentTime = buyCount + (rentType == Product.RENT_TYPE_DAY ? "天" : "小时");
        int type = relet.getInt("type");
        int selluserUid = order.getInt("selluser_uid");
        String productName = order.getStr("product_name");
        String channelId = order.getStr("channel_id");

        //如果当前这笔租赁单已经取消，说明触发了“超时未支付”，此时退款已经在 OrderReletFinishTask中触发了，这里无需理会。
        if(relet.getInt("status") == Order.ORDER_STATUS_CANCEL){
            return Common.buildResp(2, "该租赁单已经因超时未支付自动撤单，支付金额已退还至帐户余额。");
        }

        //确保当前租赁单还未支付完成。
        if(relet.getInt("status") != Order.ORDER_STATUS_NEW){
            return Common.buildResp(2, "该租赁单已经完成支付");
        }

        //更新商品状态
        String productId = order.getStr("product_id");
        rentProduct(productId);
        //如果是首租单，更新租赁单状态即可。如果是续租单，还更新order表中的租赁结束时间
        relet.keep("pay_id");
        relet.set("pay_success_time", Common.show_time(payFinishTime));
        relet.set("zhifu_platform_way_id", zhifuPlatformWayId);
        relet.set("zhifu_platform_way_name", zhifuPlatformWayName);
        relet.set("zhifu_strategy_id", strategeId);
        //首租单在支付完成后开始计时
        if(type == Order.ORDER_RELET_FIRST){
            String rentStartTime = now;
            String rentEndTime = ((rentType == Product.RENT_TYPE_HOUR || rentType == Product.RENT_TYPE_FIXED_PRICE) ? Common.addHour(rentStartTime, buyCount) : Common.addDay(rentStartTime, buyCount));
            if(rentType == Product.RENT_TYPE_LONGTERM){
                rentEndTime = Common.addDay(rentStartTime, buyCount*31); //一个月按31天算
            }
            if(rentType == Product.RENT_TYPE_NIGHT){
                //包夜的，直接将日期到指定时间
                int begHour = PropKit.getInt("product.in_night_begin");
                int endHour = PropKit.getInt("product.in_night_end");
                if(endHour > begHour){
                    rentEndTime = Common.now("yyyy-MM-dd " + endHour + ":00:00");
                }
                //结束时间比起始时间小，说明转第二天了。
                else{
                    rentEndTime = Common.addDay(Common.now("yyyy-MM-dd " + endHour + ":00:00"), 1);
                }
            }
            relet.set("rent_start_time", rentStartTime);
            relet.set("rent_end_time", rentEndTime);
        }
        relet.set("status", Order.ORDER_STATUS_PAID);  //租赁单修改为已支付
        if(!SmartDb.update("order_relet", "pay_id", relet)){
            logger.error("更新租赁单失败了, sql=>" + SmartDb.lastQuery());
            return Common.buildResp(3, "更新租赁单信息失败了");
        }

        //重新获取一次租赁单信息
        relet = SmartDb.findFirst("select * from `order_relet` where `pay_id`=?", payId);

        //更新订单的信息
        //重新计算总租金，将已支付+已完成的租赁单的金额进行累加
        Record sum = SmartDb.findFirst(" /*FORCE_MASTER*/ select sum(`order_pay_amount`) as _sum, sum(`amount_off`) as _amountOff_sum from `order_relet` where `order_id`=? and `status` in (?, ?)", orderId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_FINISH);
        int orderPayAmount = sum.getBigDecimal("_sum").intValue();
        //重新计算总金额
        int orderAmount = orderPayAmount + order.getInt("order_guarantee_deposit");
        int selluserGameLoginType = order.getInt("selluser_game_login_type");
        int buyuserUid = order.getInt("buyuser_uid");
        
        //计算优惠金额
        int amountOff =sum.getBigDecimal("_amountOff_sum").intValue();
        order.keep("order_id");
        order.set("order_ispay", Order.ORDER_PAID);
        order.set("modify_time", now);
        order.set("order_amount", orderAmount);
        order.set("order_pay_amount", orderPayAmount);
        order.set("order_origin_price", orderPayAmount);
        order.set("amount_off",amountOff);
        order.set("coupon_use_id",relet.get("coupon_use_id"));
        //如果是首租单，设置rent_start_time，续租单已经有这个值了就不需要设置了。
        if(type == Order.ORDER_RELET_FIRST){
            order.set("rent_start_time", now);
        }
        order.set("rent_end_time", Common.show_time(relet.getDate("rent_end_time")));
        order.set("order_status", Order.ORDER_STATUS_PAID); //订单修改为已支付/已出租 状态
        if(!SmartDb.update("order", "order_id", order)){
            logger.error("更新订单失败了，sql => " + SmartDb.lastQuery());
            return Common.buildResp(3, "更新订单信息失败了");
        }
        
        //如果是登号器登录模式，调用第三方获取登陆码
        logger.info("租赁类型:" + rentType+", 订单id: "+orderId+", 登录类型："+selluserGameLoginType);
        if(selluserGameLoginType == Product.LOGIN_PC_AUTOKIT || selluserGameLoginType == Product.LOGIN_MOBILE_AUTOKIT) {
            //生成登录密钥
			String loginKey = generateLoginKey(orderId, selluserGameAccount, gameId, gameName, channelId, relet.getDate("rent_end_time"));
			if(StringUtils.isBlank(loginKey)){
				//生成登号码失败了，自动退单
				String cancelMsg = "订单生成上号码失败了，支付金额已退还至帐户余额中。";
				OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
				cancelInfo.setBuyuserArbitrate(Order.BUYUSER_ORDERREQUEST_FAIL);
				cancelInfo.setCancelReason(cancelMsg);
				cancelInfo.setCancelReasonEx("");
				cancelInfo.setDeductSelluserGuarantee(false);
				cancelInfo.setDelayRefund(false);
				cancelInfo.setFreeCancel(true);
				cancelInfo.setProductOffsale(false);
                JSONObject result = new OrderCancelService(false).cancel(orderId, cancelInfo);
                if(result == null || result.getInt("code") != 0){
                    logger.error("用户【" + buyuserUid + "】下单生成上号码失败，但是为其自动撤单发生了错误，原因为：" + (result == null ? "null" : result.getString("msg")));
                    return Common.buildResp(2, "订单【" + orderId + "】无法生成上号码撤单失败了");
                }
                return Common.buildResp(2, cancelMsg);
			}
        }
        
        //短信通知卖方此号已租
        NotifyService.instance.sendAddOrderToSelluser(orderId);

        return Common.buildResp(0, "ok");
    }

    private boolean rentProduct(final String productId){
        return Db.tx(new IAtom() {
            @Override
            public boolean run() throws SQLException {
                int n = SmartDb.update("update `product` set `status`=?, `modify_time`=? where `product_id`=? and `status`=?", Product.STATUS_RENT, Common.now(), productId, Product.STATUS_ONSALE);
                if(n == 0){
                    logger.error("商品【" + productId + "】修改为出租中状态失败了, sql => " + SmartDb.lastQuery());
                    return false;
                }
                return true;
            }
        });
    }

    /**
     * 生成登号码，同时存储进本地订单数据
     * @param orderId
     * @param selluserGameAccount
     * @param gameId
     * @param gameName
     * @param channelId
     * @param rentEndTime
     * @return
     */
    private String generateLoginKey(String orderId, String selluserGameAccount, String gameId, String gameName, String channelId, Date rentEndTime){
        //生成登录密钥 md5算法
        String loginKey = MD5.encode(selluserGameAccount+System.currentTimeMillis()+orderId);
        Record loginKeyItem = SmartDb.findFirst("select * from `order_loginkey` where `order_id`=?", orderId);
        if(loginKeyItem == null){
        	//FIXME 找到对应的登录客户端
            Record conf = SmartDb.findFirst("select * from `login_key_config` where `game_id`=? and `channel_id`=?", gameId, channelId);
            if(conf == null){
            	logger.error("登录密钥在创建时无法查询到对应的login_key_config配置，sql => " + SmartDb.lastQuery());
                return null;
            }
            
            Record orderLoginKey = new Record();
            orderLoginKey.set("order_id",orderId);
            orderLoginKey.set("loginkey",loginKey);
            orderLoginKey.set("c_time",Common.now());
            orderLoginKey.set("game_id",gameId);
            orderLoginKey.set("game_name",gameName);
            orderLoginKey.set("valid_time",Common.show_time(rentEndTime));
            orderLoginKey.set("login_client_name", conf.getStr("login_client_name"));
            if(!SmartDb.save("order_loginkey",orderLoginKey)){
                logger.error("新建登录密钥订单失败了，sql => " + SmartDb.lastQuery());
                return null;
            }
        }else{
            loginKeyItem.set("valid_time",Common.show_time(rentEndTime));
            if(!SmartDb.update("order_loginkey",loginKeyItem)){
                logger.error("更新登录密钥订单失败了，sql => " + SmartDb.lastQuery());
                return null;
            }
        }
        return loginKey;
    }
}
