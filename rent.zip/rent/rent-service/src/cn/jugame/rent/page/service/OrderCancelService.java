package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.IAtom;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderCancelService {
	private Logger logger = Loggers.rentLog();
	
	private IPayment payment = PaymentFactory.get();
	
	/** 是否在撤单时通知卖家原因 */
	private boolean notifySelluser;
	public OrderCancelService(boolean notifySelluser){
		this.notifySelluser = notifySelluser;
	}
	
	/**
	 * 撤单操作信息
	 * @author ASUS
	 *
	 */
	public static class CancelInfo{
		private String cancelReason;
		private String cancelReasonEx;
		private boolean productOffsale;
		private String productOffsaleReason;
		private int buyuserArbitrate;
		private boolean freeCancel;
		private boolean delayRefund;
		private List<String> cancelPics = new ArrayList<>();
		private boolean deductSelluserGuarantee;
		public String getCancelReason() {
			return cancelReason;
		}
		public void setCancelReason(String cancelReason) {
			this.cancelReason = cancelReason;
		}
		public String getCancelReasonEx() {
			return cancelReasonEx;
		}
		public void setCancelReasonEx(String cancelReasonEx) {
			this.cancelReasonEx = cancelReasonEx;
		}
		public boolean isProductOffsale() {
			return productOffsale;
		}
		public void setProductOffsale(boolean productOffsale) {
			this.productOffsale = productOffsale;
		}
		public String getProductOffsaleReason() {
			return productOffsaleReason;
		}
		public void setProductOffsaleReason(String productOffsaleReason) {
			this.productOffsaleReason = productOffsaleReason;
		}
		public int getBuyuserArbitrate() {
			return buyuserArbitrate;
		}
		public void setBuyuserArbitrate(int buyuserArbitrate) {
			this.buyuserArbitrate = buyuserArbitrate;
		}
		public boolean isFreeCancel() {
			return freeCancel;
		}
		public void setFreeCancel(boolean freeCancel) {
			this.freeCancel = freeCancel;
		}
		public boolean isDelayRefund() {
			return delayRefund;
		}
		public void setDelayRefund(boolean delayRefund) {
			this.delayRefund = delayRefund;
		}
		public List<String> getCancelPics(){
			return cancelPics;
		}
		public void addCancelPis(String pic){
			cancelPics.add(pic);
		}
		public JSONArray cancelPicsToJson(){
			JSONArray arr = new JSONArray();
			for(String s : cancelPics){
				arr.add(s);
			}
			return arr;
		}
		public boolean isDeductSelluserGuarantee() {
			return deductSelluserGuarantee;
		}
		public void setDeductSelluserGuarantee(boolean deductSelluserGuarantee) {
			this.deductSelluserGuarantee = deductSelluserGuarantee;
		}
	}
	
	/**
	 * 撤单 - 数据库事务操作
	 * @author ASUS
	 *
	 */
	private class OrderCancelAtom implements IAtom{
		private Record order = new Record();
		private CancelInfo cancelInfo;
		
		public OrderCancelAtom(Record order, CancelInfo cancelInfo) {
			//拷贝一份出来，避免用坏order这个实例
			this.order.setColumns(order);
			
			this.cancelInfo = cancelInfo;
		}
		
		//
		private JSONObject rtn = Common.buildResp(0, "ok");
		public JSONObject getResult(){
			return rtn;
		}
		
		@Override
		public boolean run() throws SQLException {
			//先将信息取出
			String productId = order.getStr("product_id");
			String orderId = order.getStr("order_id");
			int selluserUid = order.getInt("selluser_uid");
			int orderLoginType = order.getInt("selluser_game_login_type");
			
			//将订单的所有未完成租赁单都设置为取消
			SmartDb.update("update `order_relet` set `status`=?, `cancel_time`=? where `order_id`=? and `status` in (?, ?)",
					Order.ORDER_STATUS_CANCEL, Common.now(), orderId, Order.ORDER_STATUS_NEW, Order.ORDER_STATUS_PAID);
			
			//取消订单
			String now = Common.now();
			order.keep("order_id");
			order.set("modify_time", now);
			order.set("order_finish_time", now);
			order.set("cancel_time", now);
			order.set("cancel_reason", cancelInfo.getCancelReason());
			order.set("cancel_reason_ex", cancelInfo.getCancelReasonEx());
			order.set("order_status", Order.ORDER_STATUS_CANCEL);
			order.set("is_buyuser_arbitrate", cancelInfo.getBuyuserArbitrate());
			order.set("is_free_cancel", cancelInfo.isFreeCancel() ? Order.FREE_CANCEL : Order.NOT_FREE_CANCEL);
			
			//如果要扣除保证金
			if(cancelInfo.isDeductSelluserGuarantee()){
				order.set("is_deducted_guarantee_amount", Order.ORDER_DEDUCTED_GUARANTEE);
				order.set("deducted_guarantee_amount_time", Common.now());
			}
			
			if(!SmartDb.update("order", "order_id", order)){
				logger.error("cancel -- 撤销订单失败了，orderId=>" + order.getStr("order_id") + ", sql=>" + SmartDb.lastQuery());
				rtn = Common.buildResp(3, "撤销订单时发生了系统错误，无法修改订单信息");
				return false;
			}
			
			//修改登录密钥的有效时间
			if(orderLoginType == Product.LOGIN_MOBILE_AUTOKIT || orderLoginType == Product.LOGIN_PC_AUTOKIT){
				if(SmartDb.update("update `order_loginkey` set `valid_time`=?, status= ? where `order_id`=? ",Common.now(),0,orderId) <= 0){
					logger.info("更新登录密钥有效期失败"+orderId);
				}
			}

			//不需要商品下架的，直接修改商品为上架状态
			if(!cancelInfo.isProductOffsale()){
				if(!Product.onsale(productId, selluserUid, false)){
					logger.error("订单" + orderId + "在撤单后将商品[" + productId + "]设置为上架状态失败了, sql=>" + SmartDb.lastQuery());
					rtn = Common.buildResp(4, "撤销订单时将商品状态设置为‘上架’失败了");
					return false;
				}
			}
			//如果要求下架，就直接下架掉!
			else{
				if(!Product.offsale(productId, "订单撤单【" + cancelInfo.getProductOffsaleReason() + "】而下架", false)){
					logger.error("订单" + orderId + "在撤单后将商品[" + productId + "]设置为下架状态失败了, sql=>" + SmartDb.lastQuery());
					rtn = Common.buildResp(4, "撤销订单时将商品状态设置为‘下架’失败了");
					return false;
				}
			}
			
			//同时添加一条撤单记录，以备仲裁之需
			Record evidence = new Record();
			evidence.set("order_id", orderId);
			evidence.set("type", Order.EVIDENCE_TYPE_BUYUSER);
			evidence.set("pass", 0);
			evidence.set("c_time", Common.now());
			evidence.set("cancel_reason", cancelInfo.getCancelReason());
			evidence.set("cancel_reason_ex", cancelInfo.getCancelReasonEx());
			evidence.set("pics", cancelInfo.cancelPicsToJson().toString());
			evidence.set("cancel_time", Common.now());
			evidence.set("cancel_category", 0); //XXX 线上数据库的这个字段是做啥用？！重构时通篇都没有找到这个字段的用法，这里设置默认值0表示普通撤单！
			if(!SmartDb.save("order_cancel_evidence", evidence)){
				logger.error("订单【" + orderId + "】保存撤单证据/仲裁数据时失败了！sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				return false;
			}
			
			return true;
		}
	}
	
	/**
	 * 撤单操作！
	 * @param orderId
	 * @param cancelInfo
	 */
	public JSONObject cancel(String orderId, CancelInfo cancelInfo){
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			return Common.buildResp(1, "不存在的订单");
		}
		
		//当前订单没有在‘完成’，‘交易取消’的状态，就可以撤单
		if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL){
			return Common.buildResp(2, "当前订单已经交易取消了");
		}
		if(order.getInt("order_status") == Order.ORDER_STATUS_FINISH){
			return Common.buildResp(2, "当前订单已经交易成功，无法撤销。");
		}
		
		//先将数据取出来
		int orderPayAmount = order.getInt("order_pay_amount");
		int buyuserUid = order.getInt("buyuser_uid");
		int selluserUid = order.getInt("selluser_uid");
		String selluserPhonenum = order.getStr("selluser_phonenum");
		String buyuserPhonenum =order.getStr("buyuser_phonenum");
		String gameName = order.getStr("game_name");
		String productName = order.getStr("product_name");
		int helpType = order.getInt("order_help")>0 ? order.getInt("order_help_type") : 0;
		int isDeductedGurantee = order.getInt("is_deducted_guarantee_amount");
		
		//
		OrderCancelAtom atom = new OrderCancelAtom(order, cancelInfo);
		boolean succ = Db.tx(atom);
		//事务失败了..
		if(!succ){
			return atom.getResult();
		}
		
		//如果要扣除保证金
		if(cancelInfo.isDeductSelluserGuarantee()){
			logger.info("订单【" + orderId + "】需要扣除号主保证金！");
			if (!Product.deductedSellerGuaranteeAmount(order.getStr("product_id"))) {
				logger.error("扣除保证金后，更新商品信息失败：" + order.getStr("product_id"));
			}
		}
		
		//重新获取一次订单信息
		order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		Record successApply = SmartDb.findFirst("select * from order_cancel_apply where order_id = ? and  `status` = ? order by c_time desc",
				order.getStr("order_id"), Order.ORDER_CANCEL_APPLY_SUCCESS);
		
		//计算需要转账给玩家的钱
		double amount = Order.getOrderRefundAmountToBuyuser(order, successApply);
		amount += Common.round(order.getInt("order_guarantee_deposit")/100.0, 2);
		amount = Common.round(amount, 2);
		logger.info("订单【" + orderId + "】撤单时计算得到需要转账给玩家的资金是：" + amount + "元");

        //非延时退款的，立即调用支付模块进行退款
        //延时退款的则由定时任务 BuyuserArbitrateRefundTask 触发。
		if(!cancelInfo.isDelayRefund()){
			logger.info("订单【" + orderId + "】不需要延迟退款，立即结算！");
			if(!payment.orderFailForBoth(orderId)){
				logger.error("撤销订单时支付服务退款失败了! orderId=>" + orderId);
				return Common.buildResp(5, "撤单后将租金押金退还给买家发生了错误");
			}
		}
		
		
        //如果是无责取消，优惠券使用次数+1
		//退还未结束的支付单的优惠券id
        if(cancelInfo.isFreeCancel()){
			List<Record> relets = SmartDb.find("SELECT * FROM `order_relet` WHERE order_id = ? AND `status` = ?",orderId,Order.ORDER_STATUS_CANCEL);
			for(Record relet : relets){
				if (StringUtils.isNotBlank(relet.getStr("coupon_use_id"))) {
					Coupon.increaseUserCoupon(buyuserUid, relet.getStr("coupon_use_id"));
				}
			}
        }
        
        //如果是因为求助失败而导致的撤单，需要扣除号主信誉分
  		if(cancelInfo.getBuyuserArbitrate() == Order.BUYUSER_ASKHELP_TIMEOUT){
  			User.decreaseReputationScore(selluserUid, 3, "订单【" + orderId + "】玩家求助失败，扣除号主信誉3分");
  		}
		
		// 通知卖家撤单原因
		if (this.notifySelluser) {
		    //是否延迟退款
            boolean isDelayRefund = Order.isDelayRefund(order, order.getInt("is_free_cancel") == Order.FREE_CANCEL);
            if(order.getInt("quick_refund") == 1)
                isDelayRefund = false;

			JSONObject message = new JSONObject()
					.accumulate("orderId", orderId)
					.accumulate("gameName", gameName)
					.accumulate("cancelReason", cancelInfo.getCancelReason())
					.accumulate("orderPayAmount", Common.round(orderPayAmount / 100.0, 2))
					.accumulate("refundAmount", amount)
					.accumulate("productName", productName)
                    .accumulate("is_delay_refund", isDelayRefund)
                    .accumulate("is_free_cancel", order.getInt("is_free_cancel"));

			if (cancelInfo.getBuyuserArbitrate() == Order.BUYUSER_ARBITRATION) {
			    //通知号主
				NotifyService.instance.sendOrderCancelMessageToSelluser(orderId, cancelInfo.getCancelReason());
				//通知玩家
                NotifyService.instance.sendOrderCancelMessageToBuyuser(orderId, isDelayRefund);
			}

			if (cancelInfo.getBuyuserArbitrate() == Order.BUYUSER_ASKHELP_TIMEOUT) {
				NotifyService.instance.sendHelpTimeOutMessageToBuyuser(orderId);
			}

			if (cancelInfo.getBuyuserArbitrate() == Order.BUYUSER_COMPETITION_FAIL) {
				NotifyService.instance.sendAddOrderFailToBuyuser(orderId);
			}
		} else {
			logger.info("订单【" + orderId + "】无需通知卖家！撤单原因：" + cancelInfo.getCancelReason());
		}
		
		return Common.buildResp(0, "ok");
	}
	
	/**
	 * 单笔支付单取消操作
	 * @param relet
	 * @return
	 */
	public JSONObject reletCancel(Record relet) {
		String now = Common.now();
		String orderId = relet.getStr("order_id");
		JSONObject jsonObject = new JSONObject();
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		
		//如果订单已经过期了，则不进行处理
		if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL 
				|| order.getInt("order_status") == Order.ORDER_STATUS_FINISH){
			jsonObject.put("code", Common.RESPONSE_FAIL);
			return jsonObject;
		}
		
		int type = relet.getInt("type");
		
		//设置租赁单为取消
		relet.keep("pay_id");
		relet.set("status", Order.ORDER_STATUS_CANCEL);
		relet.set("cancel_time", now);
		if(!SmartDb.update("order_relet", "pay_id", relet)){
			logger.error("超时取消租赁单失败了，pay_id=>" + relet.getStr("pay_id") + ", sql=>" + SmartDb.lastQuery());
			jsonObject.put("code", Common.RESPONSE_FAIL);
			return jsonObject;
		}
		
		//如果是续租单，需要将订单状态改回paid
		if(type == Order.ORDER_RELET_CONTINUE){
			logger.info("订单【" + orderId + "】-租赁单【" + relet.getStr("pay_id") + "】是续租单，尝试将订单改回‘已支付/出租中’状态");
			SmartDb.update("update `order` set `order_status`=?, modify_time=? where `order_id`=? and `order_status`=?", Order.ORDER_STATUS_PAID, now, orderId, Order.ORDER_STATUS_PAYING);
			logger.info("reletTimeoutCancel.sql => " + SmartDb.lastQuery());
		}
		
		//总是对超时未支付的执行一次原路退款的动作。
		//如果用户真的没有支付任何金额，refund方法将返回失败，不过这没有什么所谓。
		//如果用户通过混合支付的方式，refund方法会返还用户扣除的平台余额，这样能将扣掉的金额返还用户。
		String remark = "订单【" + orderId + "】-租赁单【" + relet.getStr("pay_id") + "】原路退款";
		if(!payment.refund(order.getInt("buyuser_uid"), orderId, relet.getStr("pay_id"), null, remark)){
			logger.error("超时未支付取消租赁单【" + relet.getStr("pay_id") + "】，在退款时失败了（若用户没有进行过支付，此为正常！）");
		}
		jsonObject.put("code", Common.RESPONSE_SUCCESS);
		return jsonObject;
	}
}
