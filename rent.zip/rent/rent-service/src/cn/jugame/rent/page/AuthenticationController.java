package cn.jugame.rent.page;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.account_center.service.vo.UserAuthInfo;
import cn.jugame.rent.api.utils.SmsUtil;
import cn.jugame.rent.bean.HotSetting;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.ServiceFactory;
import com.jfinal.aop.Before;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.Date;

/***
 * 身份验证
 * @author Administrator
 *
 */
@Before(LoginInterceptor.class)
public class AuthenticationController extends BaseController {

	private Logger logger = Loggers.rentLog();
	private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);
	private SmsUtil smsUtil = new SmsUtil();
	
	/***
	 * 验证是否已经绑定手机
	 */
	public void checkBindMobile() {
		Integer uid = getSessionAttr("uid");
		if(uid == null) {
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "请先登录后再执行操作"));
			return ;
		}
		
		//获取平台用户信息
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        }catch(Exception e){
            logger.error("error", e);
        }
        
        if(bean == null || bean.getCode() != MemberBean.OK || bean.getData() == null) {
        	logger.info("验证是否绑定手机号码失败，从平台获取用户信息失败，uid【"+uid+"】");
        	if(bean != null) {
        		logger.info("平台返回信息【"+bean.getMsg()+"】");
        	}
        	renderJson(buildResp(Common.RESPONSE_EXCEPTION, "从平台获取用户信息失败"));
			return ;
        }
        
        cn.jugame.account_center.service.vo.Member member =  (Member) bean.getData(); 
        if(StringUtils.isNotBlank(member.getMobile())) {
        	renderJson(buildResp(Common.RESPONSE_SUCCESS, "已绑定手机"));
			return ;
        }
        renderJson(buildResp(Common.RESPONSE_FAIL, "未绑定手机"));
		return ;
	}
	
	/***
	 * 发送短信验证码
	 */
	public void sendSmsCode() {
		String mobile = getPara("moblie");
		if(StringUtils.isBlank(mobile)) {
			renderJson(buildResp(Common.RESPONSE_FAIL,"手机号码为空"));
			return;
		}
		try {
			smsUtil.sendSmsCode(mobile);
		} catch (Exception e) {
			renderJson(buildResp(Common.RESPONSE_FAIL,"发送短信验证码失败"));
			logger.info("手机号码【"+mobile+"】发送短信失败，失败信息："+e);
			return;
		}
		renderJson(buildResp(Common.RESPONSE_SUCCESS, "短信发送成功"));
		return ;
	}
	
	/***
	 * 更新绑定手机号
	 */
	public void bindMobile() {
		Integer uid = getSessionAttr("uid");
		if(uid == null) {
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "请先登录后再执行操作"));
			return ;
		}
		String mobile = getPara("mobile");
		if (StringUtils.isBlank(mobile)) {
			renderJson(buildResp(Common.RESPONSE_FAIL,"手机号码为空"));
			return;
		}
		String vcode = getPara("vcode");
		if(StringUtils.isBlank(vcode)) {
			renderJson(buildResp(Common.RESPONSE_FAIL, "验证码为空"));
			return;
		}
		
		if(!smsUtil.validateSmsCode(mobile, vcode)) {
			renderJson(buildResp(Common.RESPONSE_FAIL, "验证码错误"));
			return;
		}
		
		//确保该手机号没被其它uid绑定
		MemberBean otherMemberBean = accountCenterService.findMemberByMobile(mobile);
		if(otherMemberBean == null){
			renderJson(buildResp(Common.RESPONSE_FAIL, "系统在查询当前手机号绑定情况时发生了一些错误，请稍后再试。"));
			return;
		}
		Member user = (Member)otherMemberBean.getData();
		if(user != null && user.getUid() != uid.intValue()){
			renderJson(buildResp(Common.RESPONSE_FAIL, "当前手机号已经绑定其它账号，请更换手机号或者先解绑该手机号"));
			return;
		}
		
		MemberBean memberBean = accountCenterService.bindMobile(uid, mobile);
		if(memberBean != null && memberBean.getCode() == MemberBean.OK && memberBean.getData() != null ) {
			renderJson(buildResp(Common.RESPONSE_SUCCESS,"绑定手机号码成功",new KeyValue("mobile",mobile)));
			return;
		}
		renderJson(buildResp(Common.RESPONSE_FAIL, "绑定手机号码失败"));
		return;
	}
	
	/***
	 * 是否已经实名认证
	 */
	public void checkBindRealName(){
		Integer uid = getSessionAttr("uid");
		if(uid == null || uid ==0) {
			uid = getParaToInt("uid");
		}
		if(uid == null || uid == 0) {
			logger.info("验证是否实名认证失败，原因【uid为空】");
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "uid为空"));
			return ;
		}
		MemberBean<UserAuthInfo> memberBean= accountCenterService.getUserAuthInfo(uid);
		if(memberBean == null || memberBean.getData() == null ||
				StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())) {
			renderJson(buildResp(Common.RESPONSE_FAIL, "未实名认证"));
			return ;
		}
		renderJson(buildResp(Common.RESPONSE_SUCCESS, "已实名认证"));
		return ;
	}
	
	/***
	 * 实名认证
	 */
	public void bindRealName() {
		Integer uid = getSessionAttr("uid");
		if(uid == null) {
			logger.info("绑定实名认证失败，原因【uid为空】");
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "uid为空"));
			return ;
		}
		
		String name = getPara("name");
		if(StringUtils.isBlank(name)) {
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "真实姓名为空"));
			return ;
		}
		
		String idNum = getPara("idNum");
		if(StringUtils.isBlank(idNum)) {
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "身份证号码为空"));
			return ;
		}
		
		if(Common.idnumberToAge(idNum) < 18) {
			renderJson(buildResp(Common.RESPONSE_EXCEPTION, "您身份证格式不正确或未年满16周岁。"));
			return ;
		}
		
		//一个身份证只能绑定一个
		MemberBean<Boolean> member = accountCenterService.checkIdNumInUserAuthInfo(idNum);
		if(member != null ) {
			logger.info("调用身份证是否已经绑定过uid，返回code【"+member.getCode()+"】");
			logger.info("调用身份证是否已经绑定过uid，返回msg【"+member.getMsg()+"】");
			logger.info("调用身份证是否已经绑定过uid，返回data【"+member.getData()+"】");
			if(member.getData()) {
				renderJson(buildResp(Common.RESPONSE_EXCEPTION, "该身份证已绑定过，不能再使用！"));
				return ;
			}
		}
		
		//如果需要验证手机
		int needAuthByMobile = getParaToInt("needAuthByMobile", 0);
		String mobile = "";
		if(needAuthByMobile == 1){
			mobile = getPara("mobile");
			if(StringUtils.isBlank(mobile)) {
				renderJson(buildResp(Common.RESPONSE_FAIL,"手机号码为空"));
				return;
			}
			String vcode = getPara("vcode");
			if(StringUtils.isBlank(vcode)) {
				renderJson(buildResp(Common.RESPONSE_FAIL, "手机验证码不能为空"));
				return;
			}
			
			if(!smsUtil.validateSmsCode(mobile, vcode)){
				renderJson(buildResp(Common.RESPONSE_FAIL, "手机验证码不正确"));
				return;
			}
			
			//如果该手机号已经绑定其它用户，不允许重复绑定！
			MemberBean otherMemberBean = accountCenterService.findMemberByMobile(mobile);
			if(otherMemberBean == null){
				renderJson(buildResp(Common.RESPONSE_FAIL, "系统在查询当前手机号绑定情况时发生了一些错误，请稍后再试。"));
				return;
			}
			Member user = (Member)otherMemberBean.getData();
			if(user != null && user.getUid() != uid.intValue()){
				renderJson(buildResp(Common.RESPONSE_FAIL, "当前手机号已经绑定其它账号，请更换手机号或者先解绑该手机号"));
				return;
			}
			
			//顺便把手机给绑定了
			MemberBean memberBean = accountCenterService.bindMobile(uid, mobile);
			if(memberBean == null || memberBean.getData() == null){
				renderJson(buildResp(Common.RESPONSE_FAIL, "系统在绑定您的手机时发生了一些意想不到的错误，请稍后再试。"));
				return;
			}
		}else{
			//直接从平台获取用户手机号
			MemberBean mb = accountCenterService.findMemberByUid(uid);
			if(mb == null || mb.getData() == null){
				renderJson(buildResp(Common.RESPONSE_FAIL, "系统在获取您的用户信息时发生了一些错误，请稍后再试。"));
				return;
			}
			Member user = (Member)mb.getData();
			mobile = user.getMobile();
		}
		
		UserAuthInfo userAuthInfo = new UserAuthInfo();
		userAuthInfo.setUid(uid);
		userAuthInfo.setPhoneNum(mobile);
		userAuthInfo.setName(name);
		userAuthInfo.setIdNum(idNum);
		userAuthInfo.setCreateTime(new Date());
		MemberBean<UserAuthInfo> UserAuthBean = accountCenterService.saveOrUpdateUserAuthInfo(userAuthInfo, true);
		if(UserAuthBean == null || UserAuthBean.getData() == null || UserAuthBean.code != MemberBean.OK) {
			logger.info("uid【"+uid+"】实名认证失败，返回信息msg => " + (UserAuthBean != null ? UserAuthBean.getMsg() : "UserAuthBean Is NULL!"));
			renderJson(buildResp(Common.RESPONSE_FAIL, "实名认证失败"));
			return;
		}
		logger.info("uid【"+uid+"】实名认证成功，返回信息msg【"+UserAuthBean.getMsg()+"】");
		
		renderJson(buildResp(Common.RESPONSE_SUCCESS, "实名认证成功"));
		return;
		
	}
	
	/***
	 * 检查是否开启号主验证
	 */
	public void checkSellerValidation() {
		 int sellerValidation = HotSetting.getInt("SELLER_REAL_NAME_VALIDATION", 0);
		 if(sellerValidation==1) {
			 renderJson(buildResp(Common.RESPONSE_SUCCESS, "已开启实名认证"));
			 return;
		 }
		 renderJson(buildResp(Common.RESPONSE_FAIL, "未开启实名认证"));
		 return;
	}
}
