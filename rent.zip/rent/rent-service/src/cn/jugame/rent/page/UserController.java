package cn.jugame.rent.page;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.account_center.service.vo.UserAuthInfo;
import cn.jugame.rent.bean.*;
import cn.jugame.rent.interceptor.LoginInterceptor;
import cn.jugame.rent.page.service.GameCenterService;
import cn.jugame.rent.page.service.Platforms;
import cn.jugame.rent.page.service.QrCodeService;
import cn.jugame.rent.page.service.SellerBlackListService;
import cn.jugame.rent.utils.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jfinal.aop.Before;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.*;

public class UserController extends BaseController {

    private Logger logger = Loggers.rentLog();

    private IAccountCenterService accountCenterService = ServiceFactory.get(IAccountCenterService.class);

    /**
     * 登陆链接跳转
     */
    public void login() {
        String currentUrl = getPara("currentUrl");
        setAttr("currentUrl", currentUrl);

        //check cookie
        String userSid = getCookie("user_sid");
        if (StringUtils.isNotEmpty(userSid)) {
            redirect(currentUrl);
            return;
        }

        render("login.html");
    }

    /**
     * 我的订单列表
     */
    @Before(LoginInterceptor.class)
    public void myorders() {
        int offset = getParaToInt("offset", 0);
        int limit = getParaToInt("limit", 15);
        setAttr("page_size", limit);
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            if (offset == 0) {
                errorPage("请登录后再进行操作");
            } else {
                renderText("");
            }
            return;
        }

        int status = getParaToInt("status", -1);
        setAttr("status", status);
        int isSeller = getParaToInt("isSeller", 0);
        setAttr("type", isSeller == 1 ? "selluser" : "buyuser");
        setAttr("isSeller", isSeller);

        //如果是号主
        List<Record> orders = null;
        if(isSeller == 1){
            orders = Order.getSelluserOrders(uid, status, 0, offset, limit);
            logger.info("号主订单：" + SmartDb.lastQuery());
        }
        //如果是玩家
        else{
            orders = Order.getBuyuserOrders(uid, status, 0, offset, limit);
            logger.info("玩家订单：" + SmartDb.lastQuery());
        }

        //标记退款进度 + 标记每笔订单还是否支持仲裁
        for (Record order : orders) {
            order.set("enable_arbitrate", orderCanArbitrate(order));

            //已支付状态，同时起租时间15分钟之后，那么支持停止订单
            order.set("can_stop", false);
            Date rentStartTime = order.getDate("rent_start_time");
            if(order.getInt("order_status") == Order.ORDER_STATUS_PAID
                    && System.currentTimeMillis() - rentStartTime.getTime() >= PropKit.getInt("order.self_cancel_order.timeout")*1000L){
                order.set("can_stop", true);
            }
        }

        //设置订单
        setAttr("bind_mobile", User.getBindMobile(uid) != null ? 1 : 0);
        setAttr("orders", order2map(orders));

        if (offset == 0) {
            render("myorders.html");
        } else {
            if (orders.size() > 0) {
                render("_orders.html");
            } else {
                renderText("");
            }
        }
    }

    /**
     * 我的收入流水
     */
    @Before(LoginInterceptor.class)
    public void myrevenue() {
        int offset = getParaToInt("offset", 0);
        int limit = getParaToInt("limit", 15);
        setAttr("page_size", limit);
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            if (offset == 0) {
                errorPage("请登录后再进行操作");
            } else {
                renderText("");
            }
            return;
        }

        List<Record> orders = SmartDb.find("select *, TIMESTAMPDIFF(HOUR, rent_start_time, rent_end_time) as rent_hour from `order` where `selluser_uid`=? and `order_status` IN (?, ?, ?) and `order_ispay`=? order by `order_time` desc limit ?, ?",
                uid, Order.ORDER_STATUS_FINISH, Order.ORDER_STATUS_CANCEL, Order.ORDER_STATUS_PAID, Order.ORDER_PAID, offset, limit);

        //判断每笔订单是否已经结束超过24小时
        for (Record order : orders) {
            order.set("enable_arbitrate", orderCanArbitrate(order));
        }

        setAttr("type", "selluser");
        setAttr("orders", order2map(orders));

        if (offset == 0) {
            render("myrevenue.html");
        } else {
            if (orders.size() > 0) {
                render("_orders.html");
            } else {
                renderText("");
            }
        }
    }

    /**
     * 我发布的商品列表
     */
    @Before(LoginInterceptor.class)
    public void myproducts() {
        int offset = getParaToInt("offset", 0);
        int limit = getParaToInt("limit", 15);
        setAttr("page_size", limit);
        Integer selluserUid = getSessionAttr("uid");
        if (selluserUid == null) {
            if (offset == 0) {
                errorPage("请登录后再进行操作");
            } else {
                renderText("");
            }
            return;
        }
        Record productDecorate = SmartDb.findFirst("select * from product_decorate_payment  where uid = ? and status = ? and pay_time <= ? and invalid_time >=? limit 1",
                selluserUid, Product.DECORATE_PAYMENT_STATUS_PAYED, Common.now(), Common.now());
        setAttr("is_decorate", productDecorate != null ? 0 : 1);
        //新人礼包入口是否开启
        setAttr("newcomer_gift_valid", User.newcomerGiftValid(selluserUid));
        int status = getParaToInt("status", -1);
        setAttr("status", status);

        String statusCondition = "";
        if (status != -1) {
            statusCondition = " and p.`status`=" + status;
        } else {
            statusCondition = " and p.`status` != '999'";
        }

        String searchName = getPara("search_name");
        if (StringUtils.isNotBlank(searchName)) {
            statusCondition += " and (p.name like '" + searchName + "%' or p.game_login_id like '" + searchName + "%')";
        }
        setAttr("search_name", searchName);
        List<Record> products = SmartDb.find("select p.*,pr.weight,psa.`status` as apply_status from `product` p  left join product_recommended pr on p.product_id = pr.product_id left join product_support_apply psa on p.product_id = psa.product_id where p.`seller_uid`=?" + statusCondition + " order by `onsale_time` desc limit ?, ?", selluserUid, offset, limit);

        Record member = User.getMember(selluserUid);
        //判断单个商品是否可扶持
        if (products != null && products.size() > 0 && member.getInt("support_status") == User.USER_IS_SUPPORT && member.getInt("sell_level") == User.SELL_LEVEL_NORMAL) {
            for (Record row : products) {
                //只有手游商品且满足保证金>0，普通号主，满信誉分，还未扶持等商品是可扶持状态
                if (row.getInt("reputation_score") >= 100                                    //满信誉分
                        && row.getInt("sell_level") == User.SELL_LEVEL_NORMAL                //普通号主
                        && row.getInt("support_type") == Product.SUPPORT_TYPE_NO_SUPPORT     //该商品还未申请扶持
                        && row.getInt("product_type") == GameConf.TYPE_GAME                  //手游商品
                        && row.getInt("seller_guarantee_amount") > 0                         //已交保证金
                        && row.getInt("status") == Product.STATUS_ONSALE                     //已上架
                        ) {

                    if (row.getDate("cancel_support_time") != null) {
                        //apply_status=2则表示已申请未通过，需要7天后再开放该商品“扶持申请”功能，号主自己取消的则需再3天后再开放该商品的“扶持申请”功能
                        if (row.getInt("apply_status") != null && row.getInt("apply_status") == 2) {
                            if (new Date().compareTo(Common.addDay(row.getDate("cancel_support_time"), 7)) == -1) {
                                row.set("is_support", false);
                            } else {
                                row.set("is_support", true);
                                setAttr("product_is_support", true);
                            }
                        } else {
                            if (new Date().compareTo(Common.addDay(row.getDate("cancel_support_time"), 3)) == -1) {
                                row.set("is_support", false);
                            } else {
                                row.set("is_support", true);
                                setAttr("product_is_support", true);
                            }
                        }
                    } else {
                        row.set("is_support", true);
                        setAttr("product_is_support", true);
                    }
                }
            }
        }

        setAttr("products", product2map(products));

        //如果该号主有推荐商品，则不可能有扶持商品
        Record recommendProduct = SmartDb.findFirst("SELECT * FROM `product` WHERE product_id IN ( SELECT product_id FROM `product_recommended` ) AND `seller_uid`= ?", selluserUid);
        if (recommendProduct != null) {
            setAttr("product_is_recommend", true);
            //setAttr("product_is_support", false);
        }
        setAttr("is_seller_normal", member.getInt("sell_level") == User.SELL_LEVEL_NORMAL ? true : false);

        //是否开启实名认证
        setAttr("seller_validation", HotSetting.getInt("SELLER_REAL_NAME_VALIDATION", 0));
        //是否已绑定手机
        setAttr("bind_mobile", User.getBindMobile(selluserUid) != null ? 1 : 0);
        //是否已实名认证
        setAttr("bind_real_name", User.checkBindRealName(selluserUid) ? "1" : "0");

        if (offset == 0) {
            render("myproducts.html");
        } else {
            if (products.size() > 0) {
                render("_products.html");
            } else {
                renderText("");
            }
        }
    }

    public void agreement() {
        render("agreement.html");
    }

    public void playerPlan() {
        render("player_plan.html");
    }

    /**
     * 直接对商品进行改密并上架
     */
    @Before(LoginInterceptor.class)
    public void modifyPassword() {
        Integer selluserUid = getSessionAttr("uid");
        if (selluserUid == null) {
            errorPage("请先登录后再改密");
            return;
        }

        String productId = getPara("product_id");
        Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
        if (product == null) {
            errorPage("不存在的商品");
            return;
        }
        String gameLoginPassword = getPara("game_login_password");

        //保证是这个人的商品
        if (selluserUid.intValue() != product.getInt("seller_uid").intValue()) {
            errorPage("您无法修改不是自己发布的商品");
            return;
        }

        int status = product.getInt("status");
        int sellerUid = product.getInt("seller_uid");
        //确保商品状态是上架/保护期
        if (status != Product.STATUS_ONSALE && status != Product.STATUS_PROTECTED) {
            errorPage("您的商品只有在“上架”/“保护期”状态时才能支持快速改密");
            return;
        }

        //修改密码并上架
        String now = Common.now();
        product.keep("product_id");
        product.set("modify_time", now);
        product.set("game_login_password", gameLoginPassword);
        if (status == Product.STATUS_PROTECTED) {
            product.set("onsale_time", now); //能在保护期内修改密码上架，说明商品会靠谱一些，刷新上架时间使其排序靠前
            product.set("status", Product.STATUS_ONSALE);
            product.set("reputation_score", User.getSellerReputationScore(sellerUid)); //更新信誉分
        }
        if (!SmartDb.update("product", "product_id", product)) {
            errorPage("修改商品信息时发生了错误");
            return;
        }

        setAttr("msg", "密码修改成功，您的商品已直接上架。");
        render("succ.html");
    }

    @Before(LoginInterceptor.class)
    public void scoreLog() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请先登录后再查看信誉分记录");
            return;
        }
        String type = getPara("type", "play_score");

        //最多就展示20条记录
        List<Record> rows = SmartDb.find("select * from `user_score_log` where `uid`=? and `type`=? order by `c_time` desc limit 20", uid, type);
        List<Map<String, Object>> data = toMap(rows);

        setAttr("type", type);
        setAttr("scores", data);
        render("scores.html");
    }

    /**
     * 准备对买家进行评价，跳转至评价页！
     */
    @Before(LoginInterceptor.class)
    public void prepareReview() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请先登录后再查看信誉分记录");
            return;
        }

        String orderId = getPara("order_id");
        if (StringUtils.isBlank(orderId)) {
            errorPage("没有订单号");
            return;
        }

        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if (order == null) {
            errorPage("不存在的订单");
            return;
        }
        if (order.getInt("selluser_uid").intValue() != uid.intValue()) {
            errorPage("您无法评价其他人的出租订单。");
            return;
        }
        if (order.getInt("order_status") != Order.ORDER_STATUS_FINISH && order.getInt("order_status") != Order.ORDER_STATUS_CANCEL) {
            errorPage("等订单完成之后您再进行评价吧。");
            return;
        }

        setAttr("order", toMap(order));
        render("review_buyuser.html");
    }

    @Before(LoginInterceptor.class)
    public void reviewBuyuser() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请先登录后再查看信誉分记录");
            return;
        }

        String orderId = getPara("order_id");
        if (StringUtils.isBlank(orderId)) {
            errorPage("没有订单号");
            return;
        }

        Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
        if (order == null) {
            errorPage("不存在的订单");
            return;
        }
        if (order.getInt("selluser_uid").intValue() != uid.intValue()) {
            errorPage("您无法评价其他人的出租订单。");
            return;
        }

        if (order.getInt("order_status") != Order.ORDER_STATUS_FINISH && order.getInt("order_status") != Order.ORDER_STATUS_CANCEL) {
            errorPage("等订单完成之后您再进行评价吧。");
            return;
        }

        if (order.getInt("review_buyuser_star") > 0) {
            errorPage("您已经对成功评价该玩家，无需重复评价");
            return;
        }

        int star = getParaToInt("review_buyuser_star");
        String comment = getPara("review_buyuser_comment");
        order.keep("order_id");
        order.set("review_buyuser_star", star);
        order.set("review_buyuser_comment", comment);
        order.set("review_buyuser_time", Common.now());
        if (!SmartDb.update("order", "order_id", order)) {
            logger.error("订单【" + orderId + "】评价买家时发生了错误，sql=>" + SmartDb.lastQuery());
            errorPage("系统在保存您提交的评价时发生了一些错误，请稍后再重试吧。");
            return;
        }

        setAttr("msg", "您的评价已经成功提交，感谢您对平台的支持！");
        setAttr("back_btn_name", "查看我的收入");
        setAttr("back_btn_url", "/user/myrevenue");
        render("succ.html");
    }

    /**
     * 我的推广二维码
     */
    @Before(LoginInterceptor.class)
    public void mypromote() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请先登录后再查看我的二维码吧。");
            return;
        }

        //如果还没有生成过二维码，就生成一个
        Record member = User.getMember(uid);
        String qrCode = member.getStr("qr_code");

        if (StringUtils.isBlank(qrCode)) {
            logger.info("还没有uid【" + uid + "】的个人二维码，准备生成一个..");
            String promoteUrl = PropKit.get("promote.url") + uid;
            qrCode = QrCodeService.instance.generate(promoteUrl, uid);
            if (StringUtils.isBlank(qrCode)) {
                logger.error("生成个人二维码失败了！uid=>" + uid);
                errorPage("生成个人专属二维码发生了一些错误。");
                return;
            }

            //先保存起来
            member.keep("uid");
            member.set("qr_code", qrCode);
            if (!SmartDb.update("member", "uid", member)) {
                logger.error("保存个人二维码时发生了错误，uid=>" + uid + ", sql=>" + SmartDb.lastQuery());
                errorPage("生成个人专属二维码时发生了一些错误。");
                return;
            }
        }

        setAttr("qr_code", qrCode);
        setAttr("order_succ_count", PropKit.getInt("promote.order_succ_count"));
        setAttr("order_pay_amount", Common.round(PropKit.getInt("promote.order_pay_amount") / 100.0, 2));
        render("mypromote.html");
    }

    /**
     * 访问好友的拉新 推广链接
     */
    @Before(LoginInterceptor.class)
    public void userPromote() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请先登录后再加入好友的聚会吧。");
            return;
        }

        int promoteUid = getParaToInt("promote_uid");

        //自己扫自己的码
        if (uid.intValue() == promoteUid) {
            errorPage("您果然是一位老司机！(^_^)");
            return;
        }

        //好友必须是老司机！
        if (!isQualifiedUid(promoteUid)) {
            errorPage("您的好友暂时还不具备推荐资格！");
            return;
        }

        //用户也必须是一个新用户！
        if (!isNewUid(uid)) {
            errorPage("您已经是一位老司机了！要去<a href='/mall/index'>“优惠商城”</a>看看么？");
            return;
        }

        //已经有过推荐人，那么说明用户已经领取过新人礼包了
        Record member = User.getMember(uid);
        if (member.getInt("promote_uid") > 0) {
            errorPage("您已经领取过新人礼包了，去租号试试吧！");
            return;
        }

        //每自然日推荐次数是否达到上限了
        String key = Common.now("yyyy-MM-dd") + "-userPromote-" + promoteUid;
        long count = CacheUtil.incr(key, 24 * 3600);
        if (count > PropKit.getInt("promote.daily_max_count")) {
            errorPage("您的好友太积极了，把每日推荐次数都用完了！");
            return;
        }

        //同时将uid的推广人设置为friendUid
        member.keep("uid");
        member.set("promote_uid", promoteUid);
        if (!SmartDb.update("member", "uid", member)) {
            logger.error("设置推荐人时发生了错误，uid=>" + uid + ", friendUid=>" + promoteUid);
            errorPage("初始化您的平台用户信息时发生了一些意外，稍后再试试吧。");
            return;
        }

        logger.info("用户【" + uid + "】准备领取新人礼包！");
        Coupon.gift(PropKit.get("promote.newbie.coupon"), uid);

        setAttr("back_btn_name", "我的优惠券");
        setAttr("back_btn_url", "/coupon/coupons");
        setAttr("title", "新人大礼包");
        setAttr("msg", "平台已经将大礼包送到您的优惠券列表里了，快去看看吧！(^_^)");
        render("succ.html");
    }

    /**
     * 判断用户是否有资格进行推荐
     *
     * @param uid
     * @return
     */
    private boolean isQualifiedUid(int uid) {
        Record row = SmartDb.findFirst("select count(id) as _count, sum(order_pay_amount) as _order_pay_amount from `order` where `buyuser_uid`=? and `order_status`=?", uid, Order.ORDER_STATUS_FINISH);

        //老司机 = 成交1笔订单 且 成交金额在5元以上！
        return row.getLong("_count") >= PropKit.getInt("promote.order_succ_count") && row.getBigDecimal("_order_pay_amount").intValue() >= PropKit.getInt("promote.order_pay_amount");
    }

    /**
     * 判断用户是否为租号平台新用户
     *
     * @param uid
     * @return
     */
    private boolean isNewUid(int uid) {
        Record row = SmartDb.findFirst("select `id` from `order` where `buyuser_uid`=? and `order_ispay`=? limit 1", uid, Order.ORDER_PAID);
        return row == null;
    }


    //---------------------------------------------------------------------------------------------------------------

    /**
     * XXX 高危接口！切勿泄漏！用于线上测试！
     */
    public void systemLoginUid() {
        int uid = getParaToInt("uid", 0);
        if (uid <= 0) {
            errorPage("没有指定UID");
            return;
        }

        String vcode = getPara("vcode");
        if (StringUtils.isBlank(vcode)) {
            errorPage("没有校验码");
            return;
        }

        String md5 = Common.md5(uid + "yiqundashabi!!!");
        if (!vcode.equalsIgnoreCase(md5)) {
            errorPage("验证码不通过");
            return;
        }

        setSessionAttr("uid", uid);
        setAttr("msg", "选择UID【" + uid + "】登录成功");
        render("succ.html");
    }

    @Before(LoginInterceptor.class)
    public void sellerPromote() {
        final Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }

        //如果还没有生成过二维码，就生成一个推广二维码
        Record member = User.getMember(uid);
        //获取用户是否开启推广计划
        String qrCode = member.getStr("product_qrcode");
        String oldQrCode = qrCode;
        //推广链接
        String promoteUrl = PropKit.get("product.promote.url") + uid;
        if (StringUtils.isBlank(qrCode)) {
            logger.info("还没有uid【" + uid + "】的商品推广二维码，准备生成一个..");
            qrCode = QrCodeService.instance.generate(promoteUrl, uid);
            if (StringUtils.isBlank(qrCode)) {
                logger.error("生成商品推广二维码失败了！uid=>" + uid);
                errorPage("生成商品推广二维码发生了一些错误。");
                return;
            }
        }
        //背景图片信息
        String backgroundUrl = getPara("background_url", "");
        String backgroundImg = member.getStr("promote_pic");
        if (StringUtils.isNotEmpty(backgroundUrl)) {
            backgroundImg = backgroundUrl;
        } else if (StringUtils.isEmpty(backgroundImg)) {
            backgroundImg = PropKit.get("promote.background.default");
        }
        //推广文案信息
        String promoteContent = getPara("promote_content", "");
        String memberPromoteContent = member.getStr("promote_title");
        member.keep("uid");
        if (StringUtils.isEmpty(backgroundImg) || StringUtils.isNotEmpty(backgroundUrl)) {
            member.set("promote_pic", backgroundImg);
        }
        if (StringUtils.isBlank(oldQrCode)) {
            member.set("product_qrcode", qrCode);
        }
        if (isParaExists("promote_content")) {
            member.set("promote_title", promoteContent);
        }
        if (isParaExists("promote_content") || StringUtils.isNotEmpty(backgroundUrl)) {

            if (!SmartDb.update("member", "uid", member)) {
                logger.error("更新推广信息出错，uid=>" + uid + ", sql=>" + SmartDb.lastQuery());
                errorPage("更新推广信息信息图发生了一些错误。");
                return;
            }
        }

        //获取平台用户信息
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        } catch (Exception e) {
            logger.error("error", e);
        }

        //用户昵称和头像
        setAttr("nickname", UsernameUtil.getUserName(bean, uid));
        String headimg = "";
        if (bean != null && bean.getData() != null) {
            Member user = (Member) bean.getData();
            headimg = user.getHeadimgurl();
        }
        if (StringUtils.isEmpty(headimg)) {
            headimg = PropKit.get("promote.headimg.default");
        }
        //获取所有的背景图片
        String allBackgroundImg = PropKit.get("promote.background.allimg");
        String[] allImgItem = allBackgroundImg.split(";");
        List<Map<String, Object>> allBackgroundList = new ArrayList<>();
        for (int index = 0; index < allImgItem.length; index++) {
            String[] allImgInfo = allImgItem[index].split(":");
            allImgInfo[1] = PropKit.get("promote.background.host") + allImgInfo[1] + "?x-oss-process=style/watermark.jpg";
            HashMap<String, Object> info = new HashMap<>();
            info.put("url", allImgInfo[1]);
            info.put("title", allImgInfo[0]);
            allBackgroundList.add(info);
        }
        setAttr("promote_content", StringUtils.isNotEmpty(promoteContent) ? promoteContent : memberPromoteContent);
        setAttr("all_background_img", allBackgroundList);
        //获取背景图url
        setAttr("backgroundImgBase64", HttpImageReq.getImgBase64(backgroundImg));
        setAttr("backgroundImg", backgroundImg);
        //获取头像图片base64
        setAttr("headImgBase64", HttpImageReq.getImgBase64(headimg));
        setAttr("qrCodeBase64", HttpImageReq.getImgBase64(qrCode));
        setAttr("qr_code", qrCode);
        setAttr("promote_url", promoteUrl);
        render("product_promote.html");
    }

    //获取图片的base64
    @Before(LoginInterceptor.class)
    public void getImgUrlBase64() {
        final Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }
        Record member = User.getMember(uid);
        member.keep("uid");

        //获取所有的背景图片
        String backgroundUrl = getPara("background_url");
        member.set("promote_pic", backgroundUrl);
        if (!SmartDb.update("member", "uid", member)) {
            logger.error("更新推广信息出错，uid=>" + uid + ", sql=>" + SmartDb.lastQuery());
            errorPage("更新推广信息信息图发生了一些错误。");
            return;
        }
        JSONObject result = new JSONObject();
        if (StringUtils.isNotEmpty(backgroundUrl)) {
            result.accumulate("img_base64", HttpImageReq.getImgBase64(backgroundUrl));
        } else {
            result.accumulate("img_base64", "");
        }
        renderJson(result);
    }

    /**
     * 个人中心
     */
    @Before(LoginInterceptor.class)
    public void ucenter() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }

        setAttr("uid", uid);

        //获取平台用户信息
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        } catch (Exception e) {
            logger.error("error", e);
        }

        //用户昵称和头像
        setAttr("nickname", UsernameUtil.getUserName(bean, uid));

        String headimg = "";
        if (bean != null && bean.getData() != null) {
            Member member = (Member) bean.getData();
            headimg = member.getHeadimgurl();
        }
        setAttr("headimg", headimg);

        //在租号平台获取这个用户的信息
        Record member = User.getMember(uid);

        //通过平台成功交易订单赚的钱
        Record row = SmartDb.findFirst("select sum(order_pay_amount * (1 - order_fee)) as _sum from `order` where selluser_uid=? and order_status=?", uid, Order.ORDER_STATUS_FINISH);
        if (row != null && row.get("_sum") != null) {
            setAttr("revenue", Common.round((row.getBigDecimal("_sum").doubleValue()) / 100.0, 2));
        } else {
            setAttr("revenue", 0);
        }
        //玩家+号主信誉分
        setAttr("reputation_score", member.getInt("reputation_score"));
        setAttr("play_score", member.getInt("play_score"));

        //玩家资产: 余额 + 优惠券数量 + 开心豆
        {
            cn.jugame.account_center.service.vo.MemberBean mb = accountCenterService.queryBalance(uid);
            setAttr("balance", mb.getData());

            Record nRow = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=?  and `end_date`>=? and `left_times`>0  and `status`=? limit 1", uid, Common.now("yyyy-MM-dd"), Coupon.STATUS_ONSALE);
            //Record nRow = SmartDb.findFirst("select count(id) as _count from `user_coupon` where `uid`=? and `beg_date`<=? and `end_date`>=? and `left_times`>0  and `status`=? limit 1", uid, Common.now("yyyy-MM-dd"), Common.now("yyyy-MM-dd"),Coupon.STATUS_ONSALE);
            setAttr("coupon_count", nRow.getLong("_count"));

            int beanCount = GameCenterService.instance.getBeanCount(uid);
            setAttr("bean_count", beanCount);
        }

        //号主等级
        setAttr("sell_level", member.getInt("sell_level"));
        //判断7天内是否提醒用户等级变更
        if (getCookie("preivous_sell_level") == null) {
            setCookie("preivous_sell_level", member.getInt("sell_level") + "", PropKit.getInt("seller.level_change_validTime"));
            setAttr("preivous_sell_level", member.getInt("sell_level"));
            setAttr("seller_level_change_notify", false);
        } else {
            setAttr("preivous_sell_level", getCookieToInt("preivous_sell_level"));
            if (getCookieToInt("preivous_sell_level") != member.getInt("sell_level")) {
                setAttr("seller_level_change_notify", true);
                setCookie("preivous_sell_level", member.getInt("sell_level") + "", PropKit.getInt("seller.level_change_validTime"));
            } else {
                setAttr("seller_level_change_notify", false);
            }
        }

        //判断玩家被多少玩家拉黑，最近三天是否有拉黑记录
        int blackItemCounts = SellerBlackListService.instance.getAmountOfBlackListByUserId(uid);
        int blackItemRecentCounts = SellerBlackListService.instance.getUserBlackListIn3Day(uid);
        if (blackItemCounts >= PropKit.getInt("seller.uncivilized_blackitem_counts") && blackItemRecentCounts > 0) {
            setAttr("uncivilized_rent_user", true);
        }

        //判断号主是否满足签约条件（非签约号主）
        int sellerUpgradeLevel = 0;
        Record userRankInfo = SmartDb.findFirst("select * from seller_score where uid = ?", uid);
        if (userRankInfo != null) {
            Double succOrderRate = userRankInfo.getBigDecimal("succ_order_rate").doubleValue();
            Double score = userRankInfo.getBigDecimal("score").doubleValue();
            sellerUpgradeLevel = User.getSellerUpgradeLevel(uid, succOrderRate, score, member.getInt("sell_level"));
            setAttr("seller_upgrade_level", sellerUpgradeLevel);
        } else {
            setAttr("seller_upgrade_level", sellerUpgradeLevel);
        }

        //判断弹窗提醒用户签约
        Record sellerLevelRankApply = SmartDb.findFirst("select * from seller_apply where  uid = ? and DATE_ADD(c_time, INTERVAL ? DAY) > now()   order by c_time desc", uid, PropKit.getInt("seller.sign_time"));
        setAttr("has_levelUpgrade_apply", sellerLevelRankApply != null ? true : false);
        if (getCookie("seller_sign_notify") == null) {
            if (sellerLevelRankApply == null && sellerUpgradeLevel > 0) {
                setAttr("seller_sign_notify", true);
                setCookie("seller_sign_notify", "true", PropKit.getInt("seller.sign_validTime"));
            } else {
                setAttr("seller_sign_notify", false);
            }
        } else {
            setAttr("seller_sign_notify", false);
        }

        //玩家“退款中”、玩家“仲裁中” 和 号主“待处理” 的订单数量
        {
            //玩家侧数据---------------------------------------------------
            //退款中的订单数量
            List<Record> rows = Order.getBuyuserOrders(uid, Order.ORDER_STATUS_CANCEL, 1, -1, -1);
            setAttr("refunding_order_count", rows.get(0).getInt("_count"));
            logger.info("玩家退款中订单数量: " + SmartDb.lastQuery());

            //售后处理的订单数量，for买家
            rows = Order.getBuyuserOrders(uid, Order.ORDER_IN_ARBITRATE, 1, -1, -1);
            setAttr("buyuser_arbitrating_order_count", rows.get(0).getInt("_count"));
            logger.info("玩家售后处理数量: " + SmartDb.lastQuery());

            //号主侧数据---------------------------------------------------
            //待处理的订单数量
            rows = Order.getSelluserOrders(uid, Order.ORDER_IN_SOLVE, 1, -1, -1);
            setAttr("helping_order_count", rows.get(0).getInt("_count"));
            logger.info("号主待处理订单数量: " + SmartDb.lastQuery());

            //售后处理的订单数量，for卖家
            rows = Order.getSelluserOrders(uid, Order.ORDER_IN_ARBITRATE, 1, -1, -1);
            setAttr("selluser_arbitrating_order_count", rows.get(0).getInt("_count"));
            logger.info("号主售后处理订单数量: " + SmartDb.lastQuery());
        }

        //个人中心banner
        String sql = "SELECT a.* FROM pt_banner_images a INNER JOIN pt_banner b ON a.banner_id = b.id AND b.tag = ? and a.status = 1 and b.status = 1 and (down_time >= NOW() or down_time is null) and (up_time < NOW() OR up_time IS NULL) ORDER BY weight ASC";
        List<Record> mainBoards = SmartDb.get("platform").find(sql, PropKit.get("index.ucenter_boards_tag"));
        {
            List<Object> rows = Lists.newArrayList();
            for (Record board : mainBoards) {
                Map<String, Object> map = Maps.newTreeMap();
                map.put("pic_url", board.getStr("image_url"));
                map.put("target_url", board.getStr("alink"));
                rows.add(map);
            }
            setAttr("boards", rows);
        }

        //如果是签约号主，有锁定的资金
        setAttr("lock_amount", 0);

        Record lockAmountRow = SmartDb.findFirst("select sum(`amount`) as _amount from `order_delay_transfer` where `uid`=? and `status`=?", uid, Order.DELAY_TRANSFER_NOT_FINISH);
        if (lockAmountRow.getBigDecimal("_amount") != null) {
            setAttr("lock_amount", Common.round(lockAmountRow.getBigDecimal("_amount").intValue() / 100.0, 2)); //转成元来展示
        }

        //获取红包数量
        setAttr("coupon_new_count", Platforms.singleton.getUserRedvdlopCount(uid));

        //新用户第一次打开个人中心
        //是否第一次打开页面
        String isFirstOpenRent = getCookie("first_open_rent_ucenter");
        boolean isNewcomer = User.isNewcomer(uid);
        if (StringUtils.isBlank(isFirstOpenRent) && isNewcomer) {
            setAttr("is_first_open_ucenter", true);
            setCookie("first_open_rent_ucenter", "rent", 10 * 365 * 24 * 60 * 60);
        }
        render("ucenter.html");
    }


    /**
     * 显示号主黑名单
     */
    @Before(LoginInterceptor.class)
    public void getBlackListForSeller() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }
        int offset = getParaToInt("offset", 0);
        int limit = getParaToInt("limit", 20);
        int blackListCount = SellerBlackListService.instance.getBlackListCount(uid);
        List<Record> blackList = SellerBlackListService.instance.getBlackListForSeller(uid, offset, limit);
        renderText(Common.buildResp(Common.RESPONSE_SUCCESS, "成功", new KeyValue<>("data", blackList2Map(blackList)),
                new KeyValue<>("count", blackListCount), new KeyValue<>("offset", offset), new KeyValue<>("limit", limit)).toString()
        );
    }


    /**
     * 显示号主黑名单页面，
     */
    @Before(LoginInterceptor.class)
    public void getBlackListForSellerPage() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }
        int offset = getParaToInt("offset", 0);
        int limit = getParaToInt("limit", 20);

        List<Record> blackList = SellerBlackListService.instance.getBlackListForSeller(uid, 0, 20);
        int blackListCount = SellerBlackListService.instance.getBlackListCount(uid);
        setAttr("count", blackListCount);
        setAttr("offset", offset);
        setAttr("limit", limit);
        setAttr("black_list", blackList2Map(blackList));
        render("black_detail.html");
    }


    /**
     * 将用户从黑名单中移除
     */
    @Before(LoginInterceptor.class)
    public void deleteBlackItemForSeller() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "无权限移除黑名单用户"));
            return;
        }
        int buyuserUid = getParaToInt("buyuser_uid");
        boolean result = SellerBlackListService.instance.deleteUserFromBlackList(buyuserUid, uid);
        if (result) {
            renderJson(Common.buildResp(Common.RESPONSE_SUCCESS, "移除黑名单成功"));
        } else {
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "移除黑名单失败"));
        }
    }

    /**
     * 号主等级页面
     */
    @Before(LoginInterceptor.class)
    public void userLevelRankPage() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }

        //2.判断用户可申请的号主等级
        Double succOrderRate = 0.0;
        Double score = 0.0;
        //1.获取用户号主综合评分和成单率
        Record userRankInfo = SmartDb.findFirst("select * from seller_score where uid = ?", uid);
        if (userRankInfo != null) {
            succOrderRate = userRankInfo.getBigDecimal("succ_order_rate").doubleValue();
            score = userRankInfo.getBigDecimal("score").doubleValue();
        }
        Record row = SmartDb.findFirst("select * from `member` where `uid`=?", uid);
        if (row == null) {
            errorPage("无法获取您的用户信息");
            return;

        }

        int sellerUpgradeLevel = User.getSellerUpgradeLevel(uid, succOrderRate, score, row.getInt("sell_level"));
        if (User.getSellerReputationScore(uid) < PropKit.getInt("seller.sign_reputation_score")) {
            setAttr("reputation_score_low", true);
        }
        setAttr("curr_sell_level", row.getInt("sell_level"));
        setAttr("succ_order_rate", succOrderRate * 100);
        setAttr("score", Common.round(score, 2));
        setAttr("seller_upgrade_level", sellerUpgradeLevel);

        //3.获取用户头像和昵称
        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        } catch (Exception e) {
            logger.error("error", e);
        }
        String headimg = "";
        if (bean != null && bean.getData() != null) {
            Member member = (Member) bean.getData();
            headimg = member.getHeadimgurl();

        }
        //在租号平台获取这个用户的信息
        Record member = User.getMember(uid);
        if (member == null) {
            errorPage("无法获取您在租号平台的账号信息");
            return;
        }
        //玩家信誉分
        setAttr("reputation_score", member.getInt("reputation_score"));
        //用户昵称和头像
        setAttr("nickname", UsernameUtil.getUserName(bean, uid));
        setAttr("headimg", headimg);
        if (sellerUpgradeLevel == User.SELL_LEVEL_GOLD) {
            setAttr("upper_bound", PropKit.get("seller.gold_upper_bound"));
            setAttr("upper_order_rate", Double.parseDouble(PropKit.get("seller.gold_upper_order_rate")) * 100);
        } else if (row.getInt("sell_level") == User.SELL_LEVEL_GOLD) {
            setAttr("upper_bound", PropKit.get("seller.gold_upper_bound"));
            setAttr("upper_order_rate", Double.parseDouble(PropKit.get("seller.gold_upper_order_rate")) * 100);
        } else if (row.getInt("sell_level") == User.SELL_LEVEL_SILVER) {
            setAttr("upper_bound", PropKit.get("seller.gold_upper_bound"));
            setAttr("upper_order_rate", Double.parseDouble(PropKit.get("seller.gold_upper_order_rate")) * 100);
        } else {
            setAttr("upper_bound", PropKit.get("seller.silver_upper_bound"));
            setAttr("upper_order_rate", Double.parseDouble(PropKit.get("seller.silver_upper_order_rate")) * 100);
        }


        //4.查询15天内审核申请记录
        Record sellerLevelRankApply = SmartDb.findFirst("select * from seller_apply where  uid = ? and DATE_ADD(c_time, INTERVAL ? DAY) > now()  order by c_time desc", uid, PropKit.getInt("seller.sign_time"));
        if (sellerLevelRankApply != null) {
            setAttr("has_levelUpgrade_apply", true);
            setAttr("apply_status", sellerLevelRankApply.getInt("status"));
            setAttr("remark", sellerLevelRankApply.getStr("remark"));
        } else {
            setAttr("has_levelUpgrade_apply", false);
        }

        render("seller_rank.html");
    }


    /**
     * 号主签约申请
     */
    @Before(LoginInterceptor.class)
    public void sellerSign() {
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }
        //1.获取用户号主综合评分和成单率
        Record userRankInfo = SmartDb.findFirst("select * from seller_score where uid = ?", uid);

        if (userRankInfo == null) {
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "无法获取您的评分信息"));
            return;
        }
        Record row = SmartDb.findFirst("select * from `member` where `uid`=?", uid);
        if (row == null) {
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "无法获取您的用户信息"));
            return;

        }
        //2.判断用户可申请的号主等级
        Double succOrderRate = userRankInfo.getBigDecimal("succ_order_rate").doubleValue();
        Double score = userRankInfo.getBigDecimal("score").doubleValue();
        int currSellerLevel = row.getInt("sell_level");
        int sellerUpgradeLevel = User.getSellerUpgradeLevel(uid, succOrderRate, score, currSellerLevel);

        if (sellerUpgradeLevel <= 0) {
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "对不起，暂时不满足签约条件。"));
            return;
        }

        //查询最近一天是否有未审核的记录
        Record applyItem = SmartDb.findFirst("select * from seller_apply where uid = ? and status = ? and c_time > ?", uid, User.SELL_UPGRADELEVEL_NEW, Common.now("yyyy-MM-dd"));
        if (applyItem != null) {
            renderJson(buildResp(Common.RESPONSE_FAIL, "已申请签约"));
            return;
        }
        //3.新增申请记录
        Record userApplyInfo = new Record();
        userApplyInfo.set("uid", uid);
        userApplyInfo.set("product_count", userRankInfo.getInt("product_count"));
        userApplyInfo.set("product_trade_hour", userRankInfo.getInt("product_trade_hour"));
        userApplyInfo.set("paid_order_count", userRankInfo.getInt("paid_order_count"));
        userApplyInfo.set("succ_order_count", userRankInfo.getInt("succ_order_count"));
        userApplyInfo.set("succ_order_amount", userRankInfo.getInt("succ_order_amount"));
        userApplyInfo.set("succ_order_buyuser_count", userRankInfo.getInt("succ_order_buyuser_count"));
        userApplyInfo.set("succ_order_rate", userRankInfo.getBigDecimal("succ_order_rate"));
        userApplyInfo.set("arbitrate_order_fail_count", userRankInfo.getInt("arbitrate_order_fail_count"));
        userApplyInfo.set("arbitrate_order_fail_rate", userRankInfo.getBigDecimal("arbitrate_order_fail_rate"));
        userApplyInfo.set("arbitrate_order_count", userRankInfo.getInt("arbitrate_order_count"));
        userApplyInfo.set("arbitrate_order_rate", userRankInfo.getBigDecimal("arbitrate_order_rate"));
        userApplyInfo.set("score", userRankInfo.getBigDecimal("score"));
        userApplyInfo.set("c_time", Common.now());
        userApplyInfo.set("applying_sell_level", sellerUpgradeLevel);
        userApplyInfo.set("remark", "号主申请");
        if (!SmartDb.save("seller_apply", userApplyInfo)) {
            logger.error("插入申请记录失败。");
            renderJson(Common.buildResp(Common.RESPONSE_FAIL, "插入申请记录失败。"));
            return;
        }
        renderJson(Common.buildResp(Common.RESPONSE_SUCCESS, "号主签约申请成功"));
    }

    @Before(LoginInterceptor.class)
    public void realnameAuth(){
        Integer uid = getSessionAttr("uid");
        if (uid == null) {
            errorPage("请登录后再进行操作");
            return;
        }

        boolean isAuth = true;
        MemberBean<UserAuthInfo> memberBean = accountCenterService.getUserAuthInfo(uid);
        if (memberBean == null || memberBean.getData() == null ||
                StringUtils.isBlank(memberBean.getData().getName()) || StringUtils.isBlank(memberBean.getData().getIdNum())){
            isAuth = false;
        }

        if(isAuth){
            errorPage("您已经成功实名认证。");
            return;
        }

        String redirect = getPara("redirect");
        if(StringUtils.isBlank(redirect)){
            redirect = "/user/ucenter";
        }

        setAttr("uid", uid);
        setAttr("redirect_url", Common.url_decode(redirect));
        render("realname.html");
    }
}
