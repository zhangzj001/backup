package cn.jugame.rent.page.service;

import cn.j8.consul.ServiceCaller;
import cn.j8.json.Json;
import cn.jugame.rent.search.SearchResult;
import cn.jugame.rent.search.SearchTerm;
import com.jfinal.kit.PropKit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.TreeMap;

public class ProductSearchService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private ProductSearchService(){}
	public final static ProductSearchService instance = new ProductSearchService();

	private ServiceCaller searcherCaller = new ServiceCaller(PropKit.get("consul.host"), "rent-product-searcher");

	public SearchResult search(SearchTerm term){
        logger.info("product search: " + term.toJson().toString());
        Map<String, Object> params = new TreeMap<>();
        params.put("termJson", term.toJson().toString());
        String result = searcherCaller.call("/product/search", params);
        Json rJson = Json.parse(result);
        if(rJson == null){
            logger.error("product search error, result=>" + result);
        }
        return SearchResult.from(rJson);
	}
}
