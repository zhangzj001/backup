package cn.jugame.rent.page.service;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.utils.Common;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;

import java.util.List;

/**
 * 对用户行为进行历史行为检测，判断当前操作是否允许或者是否需要封禁用户
 * 
 * @author ASUS
 *
 */
public class SecurityService {
	private SecurityService(){}
	public static final SecurityService singleton = new SecurityService();
	
	/**
	 * 判断用户是否能够下单<br>
	 * 1. 按下单时间计算，当天用户的出租中+已完成的订单数不能超过 USER_MAX_ORDER_1DAY笔。<br>
	 * 2. 按下单时间计算，当天用户对于某个游戏的出租中+已完成的订单数不能超过USER_MAX_ORDER_1DAY笔。<br>
	 * 3. 按下单时间计算，1小时内用户对于某个游戏的出租中+已完成的订单数不能超过USER_GAME_MAX_ORDER_1HOUR笔。<br>
	 * 当达到上面3条限制中的任意一条时，方法将返回false，此时需要限制用户下单。
	 * @param gameId
	 * @param userId
	 * @return
	 */
	public boolean orderAddGuard(String gameId, int userId) {
		// 当日订单限制
		Record order1Day = SmartDb.get(false).findFirst(
				"select count(id) as _count from `order` where `order_time`>? and `buyuser_uid`=? and `order_status` in (?, ?) limit 1",
				Common.now("yyyy-MM-dd 00:00:00"), userId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_FINISH);
		if (order1Day.getLong("_count") > PropKit.getInt("USER_MAX_ORDER_1DAY", 20)) {
			return false;
		}
		// 当日单游戏限制
		Record gameOrder1Day = SmartDb.get(false).findFirst(
				"select count(id) as _count from `order` where `order_time`>? and `buyuser_uid`=? and `game_id` = ? and `order_status` in (?, ?) limit 1",
				Common.now("yyyy-MM-dd 00:00:00"), userId, gameId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_FINISH);
		if (gameOrder1Day.getLong("_count") > PropKit.getInt("USER_GAME_MAX_ORDER_1DAY", 10)) {
			return false;
		}

		// 每个用户对单款游戏同时“出租中”的订单量要求<=3笔，超过时不允许下单
		String finishTime = Common.show_time(System.currentTimeMillis() - 3600 * 1000);
		Record sameOrder1Hour = SmartDb.get(false).findFirst(
				"select count(id) as _count from `order` where `order_time`>? and `buyuser_uid`=? and `game_id` = ? and `order_status` in (?, ?) limit 1",
				finishTime, userId, gameId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_FINISH);
		if (sameOrder1Hour.getLong("_count") > PropKit.getInt("USER_GAME_MAX_ORDER_1HOUR", 3)) {
			return false;
		}
		return true;
	}

	/**
	 * 当前用户被号主拉黑的总数是否已经达到告警值，告警值见配置MAX_USER_BLACK_1Day
	 * @param userId
	 * @return
	 */
	public boolean userBlackGuard(int userId) {
		Record blackItemCountsRecord = SmartDb.get(false).findFirst(
				"select count(id) as _count from `seller_blacklist` where `buyuser_uid`=? and `status`=? and c_time>?",
				userId, SellerBlackListService.BLACK_USER_STATUS_VALID, Common.now("yyyy-MM-dd 00:00:00"));
		if (blackItemCountsRecord.getLong("_count") > PropKit.getInt("MAX_USER_BLACK_1Day", 5)) {
			return false;
		}
		return true;
	}

	/**
	 * 对用户当天每个小时的 支付中+已完成 的订单数进行排查，只要任何一个小时内出现超过USER_MAX_ORDER_1Hour笔单的，都告警
	 * @param userId
	 * @return
	 */
	public boolean userOrderBlackGuard(int userId) {
		//计算一天每个小时的出租中+完成的下单量
		List<Record> order1Hour = SmartDb.find(
				"SELECT COUNT(id) as _count FROM `order` WHERE order_time > ? AND buyuser_uid = ? AND `order_status` in (?, ?) GROUP BY HOUR(order_time)",
				Common.now("yyyy-MM-dd 00:00:00"), userId, Order.ORDER_STATUS_PAID, Order.ORDER_STATUS_FINISH);
		for (Record orders : order1Hour) {
			if (orders.getLong("_count") >= PropKit.getInt("USER_MAX_ORDER_1Hour", 4)) {
				return false;
			}
		}
		return true;
	}
}
