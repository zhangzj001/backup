package cn.jugame.rent.page.service;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.URLConnectionHttpFetcher;
import com.jfinal.kit.PropKit;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;

import java.util.Map;
import java.util.TreeMap;

/**
 * 游戏大厅API
 * @author zimT_T
 *
 */
public class GameCenterService {
	private static String GetBeanCountUrl = PropKit.get("game_center.url")+"/ucgc/Member.getBeanByUid";
	private static String GiveBeanUrl = PropKit.get("game_center.url") + "/ucgc/Member.presentBean";
	private static String ConsumeUrl = PropKit.get("game_center.url") + "/ucgc/Order.createOrder";
	
	private static String caller = PropKit.get("game_center.caller");
	private static String apiKey = PropKit.get("game_center.apiKey");
	
	public static GameCenterService instance = new GameCenterService();
	
	private URLConnectionHttpFetcher fetcher = new URLConnectionHttpFetcher();
	
	private Logger logger = Loggers.rentLog();

	private GameCenterService(){}
	
	private String sign(Map<String, String> params, String caller, String appkey) {
		StringBuilder sb = new StringBuilder();
		sb.append(caller);
		for (String key : params.keySet()) {
		       String value = params.get(key);
		       if (value == null) {//为null时，替换为空字符
		              value = "";
		       }
		       sb.append(key + "=" + value);
		}
		sb.append(appkey);
		return Common.md5(sb.toString());
	}
	
	private String doPost(String url, Map<String, String> data, String caller, String apiKey){
		JSONObject params = new JSONObject();
		params.put("id", System.currentTimeMillis());
		
		JSONObject client = new JSONObject();
		client.put("caller", caller);
		params.put("client", client);
		
		String sign = sign(data, caller, apiKey);
		params.put("sign", sign);
		params.put("encrypt", "md5");
		params.put("data", data);
		
		return fetcher.posts(url, params.toString());
	}
	
	/**
	 * 获取用户开心豆数量
	 * @param uid
	 * @return
	 */
	public int getBeanCount(int uid){
		Map<String, String> postData = new TreeMap<String, String>();
		postData.put("uid", uid + "");
		String postRtnStr = doPost(GetBeanCountUrl, postData, caller, apiKey);
		int userBeanCount = -1;
		if(StringUtils.isBlank(postRtnStr)){
			logger.error("请求游戏大厅服务失败，无法获知开心豆数量.");
			return userBeanCount;
		}
		
		try{
			logger.info("getBeanCount.请求游戏大厅返回：" + postRtnStr);
			JSONObject rtnObj = JSONObject.fromObject(postRtnStr);
			JSONObject stateObj = rtnObj.optJSONObject("state");
			if(stateObj != null && stateObj.getInt("code") == 200){
				JSONObject dataObj = rtnObj.getJSONObject("data");
				userBeanCount = dataObj.getInt("bean");
			}else{
				logger.error("请求游戏大厅返回数据有错误：" + postRtnStr);
			}
		}catch(Exception e){
			logger.error("getBeanCount.error", e);
		}
		
		return userBeanCount;
	}
	
	/**
	 * 派发开心豆
	 * @param uid
	 * @param beanNum
	 * @return
	 */
	public boolean giveBean(int uid, int beanNum){
		Map<String, String> postData = new TreeMap<String, String>();
		postData.put("uid", String.valueOf(uid));
		postData.put("bean", String.valueOf(beanNum));
		postData.put("caller", caller);
		postData.put("opType", "160");
		postData.put("remark", "租号奖励");
		String postRtnStr = doPost(GiveBeanUrl, postData, caller, apiKey);
		if(StringUtils.isBlank(postRtnStr)){
			logger.error("请求游戏大厅服务失败，无法派发开心豆.");
			return false;
		}
		
		try {
			logger.info("giveBean.请求游戏大厅返回：" + postRtnStr);
			JSONObject postRtnObj = JSONObject.fromObject(postRtnStr);
			JSONObject data = postRtnObj.optJSONObject("data");
			if(data == null){
				logger.error("请求游戏大厅");
				return false;
			}
			return data.getBoolean("success");
		} catch(Exception e) {
			logger.error("presentBean.error", e);
			return false;
		}
	}
	
	/**
	 * 消费开心豆
	 * @param beanCount
	 * @return
	 */
	public boolean consume(int uid, int beanCount){
		Map<String, String> postData = new TreeMap<>();
		postData.put("productName", "租号优惠券");
		postData.put("happyBean", String.valueOf(beanCount));
		postData.put("orderType", "2"); //2=>消费
		postData.put("awardScope", "2");
		postData.put("uid", String.valueOf(uid));
		String postRtnStr = doPost(ConsumeUrl, postData, caller, apiKey);
		if(StringUtils.isBlank(postRtnStr)){
			logger.error("请求游戏大厅服务消费开心豆失败了.");
			return false;
		}
		
		try {
			logger.info("consume.请求游戏大厅返回：" + postRtnStr);
			JSONObject postRtnObj = JSONObject.fromObject(postRtnStr);
			JSONObject state = postRtnObj.getJSONObject("state");
			return state.optInt("code") == 200;
		} catch(Exception e) {
			logger.error("presentBean.error", e);
			return false;
		}
	}
}

