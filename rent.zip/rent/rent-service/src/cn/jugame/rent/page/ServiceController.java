package cn.jugame.rent.page;

import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.util.List;

/**
 * 提供给其它系统调用的接口
 *
 */
public class ServiceController extends BaseController{
	public void myCoupons(){
		String vcode = getPara("vcode");
		int uid = getParaToInt("uid", 0);
		
		//签名
		String checkCode = Common.md5(uid + PropKit.get("service.vkey"));
		if(!checkCode.equalsIgnoreCase(vcode)){
			renderJson(buildResp(1, "签名错误"));
			return;
		}
		
		String now = Common.now("yyyy-MM-dd");
		List<Record> rows = SmartDb.find("select * from `user_coupon` where `uid`=? and `status`=? and `end_date`>=? and `beg_date`<=? and `left_times`>0", uid, Coupon.STATUS_ONSALE, now, now);
		
		JSONArray arr = new JSONArray();
		for(Record row : rows){
			JSONObject obj = new JSONObject();
			obj.put("coupon_id", row.getStr("coupon_id"));
			obj.put("name", row.getStr("name"));
			obj.put("info", row.getStr("info"));
			obj.put("type", row.getInt("type"));
			obj.put("discount", Common.round(row.getBigDecimal("discount").doubleValue(), 2));
			obj.put("max_discount_amount", Common.round(row.getInt("max_discount_amount")/100.0, 2));
			obj.put("amount_off", Common.round(row.getInt("amount_off")/100.0, 2));
			obj.put("beg_date", Common.show_time(row.getDate("beg_date"), "yyyy-MM-dd"));
			obj.put("end_date", Common.show_time(row.getDate("end_date"), "yyyy-MM-dd"));
			obj.put("valid_product_type", row.getStr("valid_product_type"));
			obj.put("day_limit", row.getInt("day_limit"));
			obj.put("times", row.getInt("times"));
			obj.put("left_times", row.getInt("left_times"));
			arr.add(obj);
		}
		
		renderJson(buildResp(0, "ok", new KeyValue<>("data", arr)));
	}
	
}
