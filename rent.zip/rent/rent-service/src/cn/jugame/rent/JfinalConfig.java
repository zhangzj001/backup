package cn.jugame.rent;

import cn.j8.consul.ServiceCaller;
import cn.j8.json.Json;
import cn.jugame.rent.api.ActionSelector;
import cn.jugame.rent.interceptor.AppInterceptor;
import cn.jugame.rent.interceptor.ClientTypeInterceptor;
import cn.jugame.rent.interceptor.ParamInjectInterceptor;
import cn.jugame.rent.interceptor.VisitLogInterceptor;
import cn.jugame.rent.page.*;
import cn.jugame.rent.plugin.QuartzPlugin;
import cn.jugame.rent.utils.*;
import com.alibaba.druid.util.StringUtils;
import com.jfinal.config.*;
import com.jfinal.kit.HttpKit;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.DbInitiator;
import com.jfinal.plugin.redis.RedisPlugin;
import com.jfinal.template.Engine;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.slf4j.Logger;

import java.util.List;

public class JfinalConfig extends JFinalConfig {

	private Logger logger = Loggers.rentLog();

	@Override
	public void configConstant(Constants me) {
		PropKit.use("setting.properties");
		me.setDevMode(PropKit.getBoolean("devMode"));
	}

	@Override
	public void configRoute(Routes me) {
		// 添加路由映射
		me.setBaseViewPath("/view");
		me.add("/", IndexController.class);
		me.add("/product", ProductController.class);
		me.add("/order", SafeOrderController.class);
		me.add("/order_cb", OrderCallbackController.class);
		me.add("/user", UserController.class);
		me.add("/rent", GameRentController.class);
		me.add("/kefu", KefuController.class);
		me.add("/coupon", CouponController.class);
		me.add("/mall", MallController.class);
		me.add("/service", ServiceController.class);
		me.add("/auth", AuthenticationController.class);
		me.add("/question_survey", QuestionSurveyController.class);

		me.add("/order_help", OrderHelpController.class);
		me.add("/order/detail", OrderDetailController.class);
		me.add("/order/cancel", OrderCancelController.class);
		
		// APP使用的api接口
		me.add("/api",  ApiController.class);

		// PC使用的接口
		me.add("/pc", cn.jugame.rent.pcpage.IndexController.class, "/../pcview");
		me.add("/pc/product", cn.jugame.rent.pcpage.ProductController.class, "/../pcview/product");
		me.add("/pc/rent", cn.jugame.rent.pcpage.GameRentController.class, "/../pcview/rent");
		me.add("/pc/order", cn.jugame.rent.pcpage.OrderController.class, "/../pcview/order");
		me.add("/pc/user", cn.jugame.rent.pcpage.UserController.class, "/../pcview/user");
		me.add("/pc/pay", cn.jugame.rent.pcpage.PayController.class, "/../pcview/pay");
	}

	@Override
	public void configPlugin(Plugins me) {
		// 租号玩数据库
		initDb(me, "default");

		// 平台数据库
		initDb(me, "platform");

		// 平台订单数据库
		initDb(me, "base_order");

		// 平台商品数据库
		initDb(me, "base_product");

		// App数据库
		initDb(me, "app_recharge_base");

		// 增加redis插件
		RedisPlugin redisPlugin = null;
		if (PropKit.get("redis.password") != null && !StringUtils.isEmpty(PropKit.get("redis.password"))) {
			redisPlugin = new RedisPlugin("rent_redis", PropKit.get("redis.host"), PropKit.getInt("redis.port"),
					PropKit.getInt("redis.timeout"), PropKit.get("redis.password"), PropKit.getInt("redis.database"));
			redisPlugin.getJedisPoolConfig().setMaxTotal(PropKit.getInt("redis.maxTotal", 500));
		} else {
			redisPlugin = new RedisPlugin("rent_redis", PropKit.get("redis.host"), PropKit.getInt("redis.port"),
					PropKit.getInt("redis.timeout"));
			redisPlugin.getJedisPoolConfig().setMaxTotal(PropKit.getInt("redis.maxTotal", 500));
		}
		me.add(redisPlugin);
	}

	private void initDb(Plugins me, String group) {
        DbInitiator dbInit = new DbInitiator();
        dbInit.initDb(group);
        me.add(dbInit.getDruidPlugin());
        me.add(dbInit.getActiveRecordPlugin());
	}

    @Override
	public void configInterceptor(Interceptors me) {
		// ClientType这个拦截器必须摆在最前面，后面所有逻辑都可能用到ClientType
		me.add(new ClientTypeInterceptor());

		me.add(new ParamInjectInterceptor());
		me.add(new AppInterceptor());
		me.add(new VisitLogInterceptor());
	}

	@Override
	public void configHandler(Handlers me) {
	}

	@Override
	public void configEngine(Engine me) {
		me.addSharedObject("assetsPrefix", PropKit.get("assets_prefix", "/rassets/"));
		me.addSharedObject("pcAssetsPrefix", PropKit.get("pc_assets_prefix", "/pcassets/"));
		me.addSharedObject("kefuUrl", PropKit.get("kefu_url"));
		me.addSharedObject("kefuRentAppUrl", PropKit.get("kefu_rentapp_url"));
		me.addSharedObject("orderUtils", new TemplateOrderUtils());
		me.addSharedObject("productUtils", new TemplateProductUtils());
		me.addSharedObject("templateUtils", new TemplateUtils());
		me.addSharedObject("userFrontUtils", new TemplateUserFrontUtils());
		me.addSharedObject("devMode", PropKit.getBoolean("devUrlMode"));
		me.addSharedObject("platform_login_domain", PropKit.get("platform_login_domain"));
		// 支付服务
		me.addSharedObject("platform_pay_domain", PropKit.get("platform_pay_domain"));
		me.addSharedObject("app_adaptation_version", PropKit.get("app_adaptation_version"));
		
		me.addSharedFunction("/view/_common/widget.html");
	}

    @Override
    public void onStart() {
        super.onStart();

        // 启动定时任务
        if (!new QuartzPlugin().start()) {
            logger.error("quartz启动失败！！！！！");
            throw new RuntimeException("quartz启动失败");
        }

        // 初始化oss
        AliyunImageUtils.AliyunConfig conf = new AliyunImageUtils.AliyunConfig();
        conf.setAccessKeyId(PropKit.get("accessKeyId"));
        conf.setAccessKeySecret(PropKit.get("accessKeySecret"));
        conf.setEndpoint(PropKit.get("endpoint"));
        conf.setBucket(PropKit.get("bucket"));
        conf.setImgEndpoint(PropKit.get("imgEndpoint"));
        AliyunImageUtils.init(conf);

        // 初始化api
        ActionSelector.init();
    }

    public static void main(String[] args) throws Exception {
	}

}
