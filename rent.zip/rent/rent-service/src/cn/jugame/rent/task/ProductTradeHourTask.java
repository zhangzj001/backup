package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 计算每个商品的交易时间
 * @author zimT_T
 *
 */
@DisallowConcurrentExecution
public class ProductTradeHourTask implements Job{

	private Logger logger = Loggers.rentLog();
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		logger.info("准备开始计算上架商品的租赁时长数据...");
		//获取当前上架/保护期的商品，计算成功交易的总时长
		List<Record> rows = Db.find("select product_id, seller_uid from `product` where `status` in (?, ?)", Product.STATUS_ONSALE, Product.STATUS_PROTECTED);
		logger.info("更新的商品数量"+rows.size());
		for(Record row : rows){
			String productId = row.getStr("product_id");
			int sellerUid = row.getInt("seller_uid");
			//计算这个商品的总交易时间
			List<Record> orders = SmartDb.find("select * from `order` where `product_id`=? and `selluser_uid`=? and `order_status`=?", productId, sellerUid, Order.ORDER_STATUS_FINISH);
			
			//汇总总租赁时间
			long t = 0;
			for(Record order : orders){
				if(order.get("rent_end_time")!=null && order.get("rent_start_time")!=null) {
					t += order.getDate("rent_end_time").getTime() - order.getDate("rent_start_time").getTime();
				}
			}
			
			logger.info("商品【" + productId + "】更新交易租赁总时长为: " + t + "！");
			//转变成小时
			t = t/1000/3600;
			SmartDb.update("update `product` set `trade_hour`=? where `product_id`=?", t, productId);
			logger.info("ProductTradeHourTask.sql => " + SmartDb.lastQuery());
		}
	}

}
