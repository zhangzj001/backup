package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.Date;
import java.util.List;

/**
 * 买家自助撤单的租金、押金归还<br>
 * 押金可以全额归还，租金需要通过实际租赁时间计算出给买卖双方各多少钱。
 * @author zimT_T
 *
 */
@DisallowConcurrentExecution
public class BuyuserArbitrateRefundTask implements Job{
	
	private Logger logger = Loggers.rentLog();
	
	private IPayment payment = PaymentFactory.get();

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		String finishTime = Common.show_time(System.currentTimeMillis()-PropKit.getLong("order.keep_guarantee_deposit_time")*3600*1000);
		//24小时前自助撤单的，而且此单已经支付了，并且没有发生卖家投诉，则予以退还租金、押金
		//事实上这里使用order_isrefund_retal或者order_isrefund_guarantee判断都是一样的
		List<Record> orders = SmartDb.find("select * from `order` where "
				+ "`order_status`=? and `order_finish_time`<=? and `order_ispay`=? and `order_isrefund_guarantee`=? and `order_isterminate`=? and `is_buyuser_arbitrate`=?",
				Order.ORDER_STATUS_CANCEL, finishTime, Order.ORDER_PAID, Order.ORDER_NOT_REFUND, Order.ORDER_NOT_TERMINATED, Order.BUYUSER_ARBITRATION);
		
		for(Record order: orders){
			String orderId = order.getStr("order_id");
			int buyuserUid = order.getInt("buyuser_uid");
			String couponUseId = order.getStr("coupon_use_id");
			int isSelluserArbitrate = order.getInt("is_selluser_arbitrate");
			int selluserUid = order.getInt("selluser_uid");
			int freeCancel = order.getInt("is_free_cancel");
            Date stopTime = order.getDate("stop_time"); //用于标记是否卖家停止订单
            
            logger.info("BuyuserArbitrateRefundTask -- 准备为订单【" + orderId + "】执行撤单退款！");
            
            //执行订单退款逻辑
            if(!payment.orderFailForBoth(orderId)){
            	logger.error("订单【" + orderId + "】取消时进行转账发生了错误！");
            	continue;
            }

			String gameName = order.getStr("game_name");
			String cancelReason = order.getStr("cancel_reason");
			String productName =order.getStr("product_name");
			int orderPayAmount = order.getInt("order_pay_amount");
			String selluserPhonenum = order.getStr("selluser_phonenum");
			String buyuserPhonenum = order.getStr("buyuser_phonenum");
			
			//实际撤单时间
	        Record successApply = SmartDb.findFirst("select * from order_cancel_apply where order_id = ? and  `status` = ? order by c_time desc",
	        		order.getStr("order_id"), Order.ORDER_CANCEL_APPLY_SUCCESS);
            
            //计算实际应退还给买家的租金
            double buyuserAmount = Order.getOrderRefundAmountToBuyuser(order, successApply);
            
			//如果是通过买家的撤单，同时号主又不处理的，扣除号主信誉分5分
            if((isSelluserArbitrate == Order.SELLUSER_ARBITRATE_FAIL) || (isSelluserArbitrate == Order.SELLUSER_NO_ARBITRATE && stopTime == null)){
			    String remark = "玩家撤单【" + orderId + "】后无号主处理，扣除号主信誉5分";
			    if(isSelluserArbitrate == Order.SELLUSER_ARBITRATE_FAIL){
			    	remark = "玩家撤单【" + orderId + "】后号主仲裁失败，扣除号主信誉5分";
			    }
            	User.decreaseReputationScore(selluserUid, 5, remark);
            }

            //发送退款短信
			if(freeCancel != Order.FREE_CANCEL) {
				JSONObject message = new JSONObject().accumulate("orderId", orderId)
						.accumulate("gameName", gameName).accumulate("cancelReason", cancelReason)
						.accumulate("orderPayAmount",Common.round(orderPayAmount/100.0, 2))
						.accumulate("refundAmount",buyuserAmount)
						.accumulate("productName",productName);
				message.accumulate("buyuserUid",buyuserUid).accumulate("buyuserPhonenum",buyuserPhonenum);
//				RemindMessagePushService.sendCancelMessage(orderId, cancelReason, );

                //FIXME 退款到账通知!
			}

		}
	}

}
