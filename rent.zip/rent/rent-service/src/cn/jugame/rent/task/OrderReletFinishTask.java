package cn.jugame.rent.task;

import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.page.service.OrderCancelService;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.util.MD5;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * 订单到期自动完成任务
 * @author zimT_T
 *
 */
@DisallowConcurrentExecution
public class OrderReletFinishTask implements Job{
	
	private Logger logger = Loggers.rentLog();
	
	private IPayment payment = PaymentFactory.get();
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		Set<String> orderIds = new TreeSet<>();
		
		//1. 租赁单到期自动交易完成！
		try{reletAutoFinish(orderIds);}catch(Throwable e){logger.error("reletAutoFinish error", e);}
		
		//2. 有没有租赁单超时未支付的！
		try{reletTimeoutCancel(orderIds);}catch(Throwable e){logger.error("reletTimeoutCancel error", e);}
		
		//3. 批量自动结单
		try{finishOrders(orderIds);}catch(Throwable e){logger.error("finishOrders error", e);}
	}

	/**
	 * 租赁单到期自动完成交易
	 */
	private void reletAutoFinish(Set<String> orderIds){
		String now = Common.now();
		
		List<Record> relets = SmartDb.find("select * from `order_relet` where `status`=? and `rent_end_time`<?", Order.ORDER_STATUS_PAID, now);
		for(Record relet : relets){
			String orderId = relet.getStr("order_id");
			DistLocker locker = new DistLocker(orderId);
			boolean succ = false;
			try{
				succ = locker.lock(PropKit.getInt("displock.timeout"));
				if(!succ){
					logger.error("自动完成租赁单时发生了加锁失败的错误，reletId=>" + relet.getStr("pay_id"));
					return;
				}
				
				logger.info("reletAutoFinish -- 自动完成租赁单: " + relet.getStr("pay_id") + ", orderId=>" + orderId);
				
				//设置租赁单为完成
				relet.keep("pay_id");
				relet.set("status", Order.ORDER_STATUS_FINISH);
				relet.set("finish_time", now);
				if(!SmartDb.update("order_relet", "pay_id", relet)){
					logger.error("租赁单自动完成失败了，payId=>" + relet.getStr("pay_id") + ", sql=>" + SmartDb.lastQuery());
					continue;
				}
				
				//先记录下来
				orderIds.add(orderId);
			}finally{
				if(succ) locker.unlock();
			}
		}
	}
	
	private void reletTimeoutCancel(Set<String> orderIds){
		String outTime = Common.show_time(System.currentTimeMillis() - PropKit.getInt("order.pay_timeout")*1000);
		List<Record> relets = SmartDb.find("select * from `order_relet` where `status`=? and `create_time`<?", Order.ORDER_STATUS_NEW, outTime);
		for(Record relet : relets){
			String orderId = relet.getStr("order_id");
			DistLocker locker = new DistLocker(orderId);
			boolean succ = false;
			try{
				succ = locker.lock(PropKit.getInt("displock.timeout"));
				if(!succ){
					logger.error("自动完成租赁单时发生了加锁失败的错误，reletId=>" + relet.getStr("pay_id"));
					return;
				}
				
				logger.info("reletTimeoutCancel -- 自动取消租赁单: " + relet.getStr("pay_id") + ", orderId=>" + orderId);
				
				JSONObject jsonObject = new OrderCancelService(false).reletCancel(relet);
				if(jsonObject.getInt("code")==Common.RESPONSE_FAIL){
					logger.info("reletTimeoutCancel -- 无法取消租赁单，可能订单状态已变！relet_id: " + relet.getStr("pay_id") + ", orderId=>" + orderId);
					continue;
				}
				
				//先记录下来
				orderIds.add(orderId);
			}finally{
				if(succ) locker.unlock();
			}
		}
	}
	
	/**
	 * 结单
	 */
	public void finishOrders(Set<String> orderIds){
		for(String orderId : orderIds){
			DistLocker locker = new DistLocker(orderId);
			boolean succ = false;
			
			try{
				succ = locker.lock(PropKit.getInt("displock.timeout"));
				if(!succ){
					logger.error("自动结单时发生了加锁失败的错误，orderId=>" + orderId);
					return;
				}
				
				logger.info("finishOrders -- 尝试自动结单, orderId=>" + orderId);
				
				tryFinishOrder(orderId);
				
			}finally{
				if(succ) locker.unlock();
			}
		}
	}
	
	/**
	 * 尝试结单：最后一笔租赁单都已经完成/取消，则扫描所有租赁单的状态并同步给订单的最终状态。<br>
	 * 规则如下：<br>
	 * 1. 如果该订单只有一笔首租单，且取消 --> 订单设置为取消状态<br>
	 * 2. 如果该订单存在多笔租赁单，那么必然首租单是成功支付的，否则无法续租 --> 订单设置为交易完成状态<br>
	 * 
	 * @param orderId
	 */
	private void tryFinishOrder(String orderId){
		String now = Common.now();
		
		Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
		if(order == null){
			logger.error("OrderReletFinishTask -- 发生了诡异的一幕，存在租赁单对应的订单[" + orderId + "]不存在");
			return;
		}
		//保障一下订单确实还没完成
		if(order.getInt("order_status") == Order.ORDER_STATUS_CANCEL || order.getInt("order_status") == Order.ORDER_STATUS_FINISH){
			logger.error("OrderReletFinishTask -- 订单已经完成/取消，不再重复设置订单状态，orderId=>" + orderId);
			return;
		}
		
		List<Record> rows = SmartDb.find("select * from `order_relet` where `order_id`=? order by `rent_end_time` desc", orderId);
		//只要有一笔租赁单还未完成，都不需要结单
		for(Record row : rows){
			logger.info("订单【" + orderId + "】-租赁单【" + row.getStr("pay_id") + "】当前状态：" + row.getInt("status"));
			if(row.getInt("status") != Order.ORDER_STATUS_CANCEL && row.getInt("status") != Order.ORDER_STATUS_FINISH){
				logger.info("订单【" + orderId + "】还存在未完成的租赁单，不需要结单..");
				return;
			}
		}
		
		//如果该订单只有一笔首租单，且取消 --> 订单设置为取消状态
		//如果该订单存在多笔租赁单，那么必然首租单是成功支付的，否则无法续租 --> 订单设置为交易完成状态
		int orderStatus = Order.ORDER_STATUS_FINISH;
		if(rows.size() == 1){
			orderStatus = rows.get(0).getInt("status");
		}
		logger.info("订单【" + orderId + "】准备将状态设置为=>" + orderStatus);
		
		int selluserUid = order.getInt("selluser_uid");
		int buyuserUid = order.getInt("buyuser_uid");
		String productId = order.getStr("product_id");
		//完成订单，执行转账
		if(orderStatus == Order.ORDER_STATUS_FINISH){
			//一些有用的信息先拿出来
			String selluserPhonenum = order.getStr("selluser_phonenum");
			String gameName = order.getStr("game_name");
			int orderLoginType = order.getInt("selluser_game_login_type");
			String productName = order.getStr("product_name");
			int orderPayAmount = order.getInt("order_pay_amount");
			int amountOff = order.getInt("amount_off");
			int sellLevel = order.getInt("sell_level");
			
			//修改订单
			order.keep("order_id");
			order.set("order_finish_time", now);
			order.set("modify_time", now);
			order.set("order_status", Order.ORDER_STATUS_FINISH);
			if(!SmartDb.update("order", "order_id", order)){
				logger.error("完成订单失败了，sql=>" + SmartDb.lastQuery());
				return;
			}
			//重新获取订单信息
			order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);

			logger.info("订单【" + orderId + "】准备设置商品状态为'保护中'..");
			//将商品设置为保护状态，前提是这个商品没有被强制下架
			Record product = SmartDb.findFirst("select * from `product` where `product_id`=?", productId);
			if(product != null && product.getInt("status") != Product.STATUS_OFFSALE) {
				//端游商品不需要设置保护期，直接上架
				if(product.getInt("product_type")==Product.PRODUCT_TYPE_PCGAME) {
					if(!Product.onsale(product.getStr("product_id"), product.getInt("seller_uid"), false)){
						logger.error("端游商品过了租期自动上架失败了，productId=>" + product.getStr("product_id"));
					}
				}else {
	                product.set("product_id", productId);
					product.set("status", Product.STATUS_PROTECTED);
	                product.set("last_order_time", now);
	                product.set("modify_time", now);
	                if (!SmartDb.update("product", "product_id", product)) {
	                    logger.error("订单" + orderId + "在交易完成后将商品[" + productId + "]设置为保护状态失败了, sql=>" + SmartDb.lastQuery());
	                }
				}
            }else{
			    if(product == null)
			        logger.error("订单【" + orderId + "】对应的商品【" + productId + "】并不存在，无法设置状态...");
			    else
			        logger.error("订单【" + orderId + "】对应的商品【" + productId + "】已经被强制下架了，无需设置状态！");
            }
			
			if(!payment.orderSuccForRental(orderId)){
				logger.error("订单" + orderId + "转款租金失败了！！！");
				return;
			}

			//修改登录密钥的有效时间
			if(orderLoginType == Product.LOGIN_PC_AUTOKIT || orderLoginType==Product.LOGIN_MOBILE_AUTOKIT){
				if(SmartDb.update("update `order_loginkey` set `valid_time`=?, status= ? where `order_id`=? ",Common.now(),0,orderId) <= 0){
					logger.info("更新登录密钥有效期失败"+orderId);
				}
			}

			//通知卖家租期已结束
			{
			    //通知号主
				NotifyService.instance.sendOrderFinishMessageToSelluser(orderId);

				//通知玩家
                NotifyService.instance.sendOrderFinishMessageToBuyuser(orderId);
            }

			//如果是自营UID，且是水煮渠道的，则改密和清绑
			if(isSelfSupport(order)){
				accountClear(order);
			}
			
			//订单成功交易，给卖家增加信誉分
			User.increaseReputationScore(selluserUid, 2, "成功交易订单【" + orderId + "】，信誉+2分");
			Record m = User.getMember(selluserUid);
			if(m.getInt("reputation_score")>=100 && m.getInt("sell_level")==User.SELL_LEVEL_NORMAL) {
				int num=SmartDb.update("update `product` set support_type = ?,reputation_score=?,sell_level=? where seller_guarantee_amount >0 "
						+ "and seller_guarantee_amount >0 and  seller_uid = ? and support_type = ? and `status` = ?",Product.SUPPORT_TYPE_SUPPORTED,m.getInt("reputation_score"),
						 m.getInt("sell_level"),selluserUid,Product.SUPPORT_TYPE_DISSATISFY,Product.STATUS_ONSALE);
				logger.info("uid："+selluserUid+"，更新自动成为扶持商品数为："+num);
			}
			
			//订单成功交易，也给买家增加信誉分
			User.increasePlayScore(buyuserUid, 2, "成功交易订单【" + orderId + "】，信誉分+2");

			//如果是这个用户的首单！看看有没有推荐人，如果有推荐人，则给推荐人发放礼包
			Record member = User.getMember(buyuserUid);
			//有推荐人且还没有给推荐人发放过奖励！这里发放奖励吧。
			if(member.getInt("promote_uid") > 0 && member.getInt("has_promote_gift") == 0){
				int promoteUid = member.getInt("promote_uid");
				
				//先将写数据库，成功了就发奖励
				member.keep("uid");
				member.set("has_promote_gift", 1);
				if(SmartDb.update("member", "uid", member)){
					logger.info("订单【" + orderId + "】完成时，用户【" + buyuserUid + "】的推荐人【" + promoteUid + "】准备领取大礼包了！");
					sendPromoteGift(promoteUid);
				}else{
					logger.error("订单【" + orderId + "】完成时，用户【" + buyuserUid + "】的推荐人【" + promoteUid + "】领取礼包失败了！");
				}
			}
		}
		//订单取消，啥都不变
		if(orderStatus == Order.ORDER_STATUS_CANCEL){
			String couponUseId = order.getStr("coupon_use_id");
			
			//2.恢复商品的状态为上架中
			logger.info("恢复超时未支付的商品状态为上架中===orderId:"+orderId);
			if(!Product.onsale(productId, order.getInt("selluser_uid"), false)){
				logger.error("商品【" + productId + "】修改为出租中状态失败了，orderId=>" + orderId);
				return;
			}
				
			//修改订单信息
			order.keep("order_id");
			order.set("cancel_time", now);
			order.set("cancel_reason", "超时未支付");
			order.set("order_finish_time", now);
			order.set("modify_time", now);
			order.set("order_status", Order.ORDER_STATUS_CANCEL);
			if(!SmartDb.update("order", "order_id", order)){
				logger.error("完成订单失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
				return;
			}
			
			//商品超时未支付，如果买家已经超过次数上限了，扣2分买家信誉分
			String today = Common.now("yyyy-MM-dd");
			Record row = SmartDb.findFirst("select count(id) as _count from `order` where `buyuser_uid`=? and `order_status`=? and `order_ispay`=? and `order_finish_time`>=? and `order_finish_time`<=?", 
					buyuserUid, Order.ORDER_STATUS_CANCEL, Order.ORDER_NOT_PAY, today + " 00:00:00", today + " 23:59:59");
			if(row.getLong("_count") > PropKit.getInt("order.sufferable_nopay_cancel_count")){
				User.decreasePlayScore(buyuserUid, 2, "超时未支付取消订单【" + orderId + "】，信誉分-2");
			}
			
			//如果有使用优惠券，返还次数
	        if(StringUtils.isNotBlank(couponUseId)){
	            Coupon.increaseUserCoupon(buyuserUid, couponUseId);
	        }
		}
	}
	
	private boolean isSelfSupport(Record order){
		if(!"20".equals(order.getStr("channel_id")))
			return false;
		return User.isSelfUid(order.getInt("selluser_uid"));
	}
	
	private void accountClear(Record order){
		String gameAccount = order.getStr("selluser_game_account");
		String newPassword = String.valueOf(Common.rand(100000, 999999));
		
		SmartDb.TrackableDb db = SmartDb.get("platform");
		
		Record row = db.findFirst("select * from `member` where `sdk_uid`=? limit 1", gameAccount);
		if(row == null){
			logger.info("订单【" + order.getStr("order_id") + "】租赁的账号不存在用户表中，sdk_uid=>" + gameAccount);
			return;
		}
		int uid = row.getInt("uid");
		//先清除member表的数据，邮箱+手机+实名+登录密码
		db.update("update `member` set `login_passwd`=?, `email`='', `email_validate`=0, `mobile`='', `mobile_validate`=0, `real_validate`=0, `last_time`=? WHERE sdk_uid=? limit 1", encodePwd(newPassword), Common.now(), gameAccount);
		//删除实名信息
		db.update("delete from `member_auth` where `uid`=? limit 1", uid);
		
		//更新商品的登录密码
		SmartDb.update("update `product` set `game_login_password`=? where `product_id`=?", newPassword, order.getStr("product_id"));
	}
	
	private String encodePwd(String pwd){
		//XXX 注意！！！注意！！！这个md5不是标准md5！！！
		return MD5.encode(MD5.encode("admin" + pwd));
	}
	
	/**
	 * 发放推荐礼包
	 * @param promoteUid
	 */
	private void sendPromoteGift(int promoteUid){
		//先查看一下这个人已经领过多少次“推荐礼包”
		Record recommendCount = SmartDb.findFirst("select count(id) as _count from `member` where `promote_uid`=? and `has_promote_gift`=1", promoteUid);
		//头3次给推荐大礼包
		if(recommendCount.getLong("_count") <= 3){
			logger.info("用户【" + promoteUid + "】领取推荐大礼包!");
			Coupon.gift(PropKit.get("promote.recommend.coupon"), promoteUid);
		}
		//以后给派对大礼包
		else{
			logger.info("用户【" + promoteUid + "】领取派对大礼包!");
			Coupon.gift(PropKit.get("promote.regular.coupon"), promoteUid);
		}
	}

}
