package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.page.service.OrderCancelService;
import cn.jugame.rent.page.service.OrderHelpContactMsgService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import net.sf.json.JSONObject;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 订单求助超时撤单脚本
 */
public class OrderHelpTimeoutTask implements Job{
    private Logger logger = Loggers.rentLog();
    
    private OrderHelpContactMsgService msgService = new OrderHelpContactMsgService();

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        //5分钟前
        String deadline = Common.show_time(System.currentTimeMillis() - PropKit.getInt("order.order_help_dealine")*1000L);
        List<Record> orderHelps = SmartDb.find("select * from `order_help` where `status`=? and `c_time`<?", Order.HELP_STATUS_WAITING, deadline);
        //对于这些超时未处理的求助，直接做撤单处理
        for(Record help : orderHelps){
            String orderId = help.getStr("order_id");

            //与controller进行同步
            DistLocker locker = new DistLocker("order-help-" + orderId);
            try{
                locker.lock();

                //确认订单还在租赁期，否则就不管了
                Record order = SmartDb.findFirst("select * from `order` where `order_id`=?", orderId);
                if(order == null){
                    logger.error("不存在的订单【" + orderId + "】，无法执行订单求助的超时处理");
                    continue;
                }
                if(order.getInt("order_status") != Order.ORDER_STATUS_PAID){
                    logger.error("当前订单【" + orderId + "】已经不在租赁期，无法处理求助请求，当前订单状态=>" + order.getInt("order_status"));

                    //直接标记为求助失败
                    help.keep("id");
                    help.set("h_time", Common.now());
                    help.set("status", Order.HELP_STATUS_FAIL);
                    if(!SmartDb.update("order_help", "id", help)){
                        logger.error("订单已不在出租中状态，更新订单求助信息失败了，orderId=>" + orderId + ", sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                    }

                    continue;
                }

                //一些有用的数据
                int buyuserUid = order.getInt("buyuser_uid");
                int orderHelpType= order.getInt("order_help_type");
                //标记该求助已经结束了
                help.keep("id");
                help.set("h_time", Common.now());
                help.set("status", Order.HELP_STATUS_FAIL);
                if(!SmartDb.update("order_help", "id", help)){
                    logger.error("更新订单求助信息失败了，orderId=>" + orderId + ", sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                    continue;
                }

                //也更新订单的数据
                order.keep("order_id");
                order.set("modify_time", Common.now());
                order.set("order_help", Order.HELP_STATUS_FAIL);
                if(!SmartDb.update("order", "order_id", order)){
                    logger.error("订单【" + orderId + "】在求助时更新数据失败了，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
                    continue;
                }
                //撤单，因为可能是号主来不及处理而撤单的，依然保证24小时后退还金额
                //这种撤单肯定属于玩家免责撤单！
                //账号密码的求助类型要扣除保证金
                JSONObject result = null;
            	String cancelReason = "号主超时未解决订单求助";
            	OrderCancelService.CancelInfo cancelInfo = new OrderCancelService.CancelInfo();
            	cancelInfo.setBuyuserArbitrate(Order.BUYUSER_ASKHELP_TIMEOUT);
            	cancelInfo.setCancelReason(cancelReason);
            	cancelInfo.setCancelReasonEx("");
            	cancelInfo.setDeductSelluserGuarantee(false);
            	cancelInfo.setDelayRefund(false);
            	cancelInfo.setFreeCancel(true);
            	cancelInfo.setProductOffsale(true);
                result = new OrderCancelService(true).cancel(orderId, cancelInfo);
                if(result == null || result.getInt("code") != 0){
                    logger.error("订单求助超时未处理而撤单发生了错误，orderId=>" + orderId + "原因：" + (result == null ? "null" : result.getString("msg")));
                }

                //发送号主求助信 息回复
                String content = "很抱歉号主无法及时响应您的求助，系统将自动为您免责撤单并退还您的资金，请注意查收。\n"
                		+ "（带有“金牌号主”、“银牌号主”、“保证金”标签的商品质量更优，您可尝试重新挑选下单。）";
                msgService.sendMsg(orderId, content, Order.HELP_MESSAGE_SENDER_SYSTEM, Order.HELP_MESSAGE_SENDER_BUYUSER);

            }finally{
                locker.unlock();
            }
        }
    }
}
