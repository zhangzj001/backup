package cn.jugame.rent.task;

import cn.jugame.rent.bean.Product;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import freemarker.template.SimpleDate;
import org.apache.commons.lang.StringUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@DisallowConcurrentExecution
public class ProductTask implements Job{
	
	private Logger logger = Loggers.rentLog();

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		try{disprotect();}catch(Throwable e){logger.error("disprotect error", e);}
		try{offsale();}catch(Throwable e){logger.error("offsale error", e);}
	}

	/**
	 * 商品在过了保护期之后自动解出保护状态，自动上架
	 */
	private void disprotect(){
		int batchSize = 100;
		
		String now = Common.now();
		List<Record> products = SmartDb.find("select * from `product` where `status`=?", Product.STATUS_PROTECTED);
		for(Record product : products){
			Date lastOrderTime = product.getDate("last_order_time");
			if(lastOrderTime == null)
				continue;

			//看看是否超过了保护期
            int protectTime = product.getInt("onsale_protect_time");
            if(protectTime < 0){
                //直接下架
                Product.offsale(product.getStr("product_id"), "订单交易完成后自动下架", false);
                continue;
            }

			long validTime = lastOrderTime.getTime() + protectTime*3600L*1000;
            logger.info("准备验证商品【" + product.getStr("product_id") + "】是否过了保护期，protecteTime -> " + Common.show_time(validTime));
			if(validTime <= System.currentTimeMillis()){
				int sellerUid = product.getInt("seller_uid");
				if(!Product.onsale(product.getStr("product_id"), sellerUid, false)){
					logger.error("商品过了保护期自动上架失败了，productId=>" + product.getStr("product_id"));
				}
			}
		}
	}
	
	/**
	 * 商品到了有效期之后自动下架
	 */
	private void offsale(){
		int batchSize = 100;
		
		long now = System.currentTimeMillis();
		String nowStr = Common.show_time(now);

		//自营uid
		String selfUid = PropKit.get("self_uid");
		
		//商品的上架时间+有效期天数 < 当前时间，则保持商品上架状态不变，否则下架
		String sql = "select * from `product` where `status`=? and `product_type`=?";
		if(StringUtils.isNotBlank(selfUid)){
			sql += " and `seller_uid` not in (" + selfUid + ")";
		}
		sql += " order by `onsale_time`";
		List<Record> products = SmartDb.find(sql + " limit " + batchSize, Product.STATUS_ONSALE, Product.PRODUCT_TYPE_GAME);
		for(Record product : products){
			Date onsaleTime = product.getDate("onsale_time");
			int validity = product.getInt("validity");
			
			//已过有效期
			if(onsaleTime.getTime() + validity*24L*3600*1000 < now){
				logger.info("商品【" + product.getStr("product_id") + "】超过有效期，自动下架！");
				if(!Product.offsale(product.getStr("product_id"), "已过有效期，自动下架", false)){
					logger.error("自动下架商品失败了，productId=>" + product.getStr("product_id") + ", sql=>" + SmartDb.lastQuery());
				}
			}
		}
	}


    public static void main(String[] args) throws Exception{
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date lastOrderTime = f.parse("2019-08-16 17:50:04");
        if(lastOrderTime == null)
            return;

        //看看是否超过了保护期
        int protectTime = 1;
        if(protectTime < 0){
            //直接下架
            System.out.println("下架");
        }

        long validTime = lastOrderTime.getTime() + protectTime*3600L*1000;
        if(validTime <= System.currentTimeMillis()){
            System.out.println("xxx");
        }
    }
}
