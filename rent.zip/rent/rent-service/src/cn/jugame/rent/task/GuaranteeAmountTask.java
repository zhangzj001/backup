package cn.jugame.rent.task;


import cn.jugame.rent.bean.Product;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 保证金订单超时未支付进行退款
 * @author jiangshishan
 *
 */
@DisallowConcurrentExecution
public class GuaranteeAmountTask implements Job {

    private Logger logger = Loggers.rentLog();

    private IPayment payment = PaymentFactory.get();

    public void execute(JobExecutionContext arg0) throws JobExecutionException {

        String endTime = Common.show_time(System.currentTimeMillis() - PropKit.getInt("guarantee.order_notpay_dealine")*1000L);

        List<Record> notPayGuarnteeOrders = SmartDb.find("select * from guarantee_amount_order where `status` = ? and create_time < ?", Product.GUNRANTEE_AMOUNT_STATUS_NEW,endTime);
        //对超时未支付混合支付的进行余额退款
        for(Record notPayOrder:notPayGuarnteeOrders){
            String payId = notPayOrder.getStr("pay_id");
            String productId = notPayOrder.getStr("product_id");
            int uid = notPayOrder.getInt("uid");
            DistLocker locker = new DistLocker("guarantee-setAmount-" + productId);
            boolean succ = false;
            try{
                succ = locker.lock(PropKit.getInt("displock.timeout"));
                if(!succ){
                    logger.error("保证金超时退款发生了加锁失败的错误，reletId=>" + payId);
                    return;
                }
                //更新状态
                logger.info("保证金超时未支付退款订单号："+payId+"用户id"+uid+"商品id:"+productId);
                if(SmartDb.update("update guarantee_amount_order set `status` = ?,refund_time=? where pay_id = ?",Product.GUNRANTEE_AMOUNT_STATUS_REFUNDED,Common.now(),payId) == 0 ){
                    logger.info("保证金超时未支付退款订单号【" + payId + "】，在更新订单状态时");
                }
                
                
                //执行退款	//尝试对用户进行退款，不一定能成功！
                //如果用户有混合支付的话，会先扣掉余额，在这里总是进行一次退款操作，让资金原路退回
                Record product = SmartDb.findFirst("select * from product where product_id=?", productId);
                String remark = "商品【" + product.getStr("product_id") + "】-支付单【" + payId + "】当次支付原路退款";
                if(!payment.refund(product.getInt("seller_uid"), product.getStr("product_id"), payId, null, remark)){
                	logger.info("用户【" + uid + "】的商品【" + productId + "】超时未支付保证金【" + payId + "】，在退款时失败了（若用户没有进行过支付，此为正常！）");
                }

            }finally {
                if(succ) locker.unlock();
            }
        }


    }


}
