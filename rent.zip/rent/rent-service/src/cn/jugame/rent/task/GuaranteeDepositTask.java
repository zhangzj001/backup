package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.pay.IPayment;
import cn.jugame.rent.pay.PaymentFactory;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 对已完成的订单，如果过了投诉期则退还押金
 * @author zimT_T
 *
 */
@DisallowConcurrentExecution
public class GuaranteeDepositTask implements Job{
	
	private Logger logger = Loggers.rentLog();
	
	private IPayment payment = PaymentFactory.get();

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		
		//符合这些要求的订单，拿出来撸一遍：
		//1. 订单交易完成的
		//2. 已经交易完成24小时了
		//3. 下单是需要给押金的
		//4. 订单是已支付的
		//5. 订单没有被投诉终止
		//6. 订单还没有被退还押金
		String finishTime = Common.show_time(System.currentTimeMillis()-PropKit.getLong("order.keep_guarantee_deposit_time")*3600*1000);
		List<Record> orders = SmartDb.find("select * from `order` where "
				+ "`order_status`=? and `order_finish_time`<=? and `order_guarantee_deposit`>0 and `order_ispay`=? and `order_isterminate`=? and `order_isrefund_guarantee`=? ",
				Order.ORDER_STATUS_FINISH, finishTime, Order.ORDER_PAID, Order.ORDER_NOT_TERMINATED, Order.ORDER_NOT_REFUND);
	
		//一个一个退押金
		for(Record order : orders){
			String orderId = order.getStr("order_id");
			
			if(!payment.orderSuccForGuarantee(orderId)){
				logger.error("订单【" + orderId + "】退还玩家押金时失败了！");
			}
		}
	}
	
}
