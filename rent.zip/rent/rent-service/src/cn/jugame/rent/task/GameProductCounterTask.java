package cn.jugame.rent.task;

import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 计算每个游戏的上架商品数
 */
public class GameProductCounterTask implements Job{

    private Logger logger = Loggers.rentLog();

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        List<Record> games = SmartDb.find("select * from `game_conf` where `status`=1");
        for(Record game : games){
            String gameId = game.getStr("game_id");
            Record row = SmartDb.findFirst("select count(id) as _count from `product` where `status` in (?, ?, ?) and `game_id`=?", Product.STATUS_ONSALE, Product.STATUS_RENT, Product.STATUS_PROTECTED, gameId);
            
            Record row1 = SmartDb.findFirst(
            		"select count(id) as _count from `product` where `seller_guarantee_amount`>0 and `reputation_score` >= 100 and `sell_level`=? and `support_type` = ? and `status` in (?, ?, ?) and `game_id`=?", 
            		User.SELL_LEVEL_NORMAL,Product.SUPPORT_TYPE_SUPPORTED,Product.STATUS_ONSALE, Product.STATUS_RENT, Product.STATUS_PROTECTED, gameId);
            
            //更新这个游戏配置的当前上架数
            game.keep("game_id");
            game.set("product_count", row.getLong("_count"));
            game.set("support_product_count", row1.getLong("_count"));
            if(!SmartDb.update("game_conf", "game_id", game)){
                logger.error("更新游戏【" + gameId + "】的商品上架数时发生了错误，sql=>" + SmartDb.lastQuery(), SmartDb.getException());
            }
        }
    }
}
