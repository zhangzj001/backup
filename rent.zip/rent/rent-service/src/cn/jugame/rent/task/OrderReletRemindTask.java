package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import com.jfinal.plugin.redis.Cache;
import com.jfinal.plugin.redis.Redis;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

public class OrderReletRemindTask implements Job {

    private Logger logger = Loggers.rentLog();

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        reletWillFinish();
    }

    //查找半小时结束的单
    private void reletWillFinish() {
        Cache cache = Redis.use("rent_redis");
        String now30MinAfter = Common.show_time(System.currentTimeMillis() + 30 * 60 * 1000);
        String now25MinAfter = Common.show_time(System.currentTimeMillis() + 25 * 60 * 1000);
        List<Record> orders = SmartDb.find("select * from `order` where `order_status`=? and `rent_end_time`<= ? and `rent_end_time` >= ?", Order.ORDER_STATUS_PAID, now30MinAfter, now25MinAfter);
        for (Record order : orders) {
            String key = "reletRemind" + order.get("order_id");

            if (cache.get(key) == null) {
                cache.setex(key, 10 * 60, 1);
                //发送消息
                NotifyService.instance.sendOrderNearlyEndMessageToBuyuser(order.get("order_id"));
            }
        }

    }
}
