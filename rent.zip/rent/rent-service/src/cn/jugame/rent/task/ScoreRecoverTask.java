package cn.jugame.rent.task;

import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class ScoreRecoverTask implements Job{

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		//XXX 2018-02-28 去掉号主信誉分自动回血的功能！
//		//全员卖家信誉分+1，但是别超过100分
//		SmartDb.update("update `member` set `reputation_score`=`reputation_score`+1 where `reputation_score`<=99");
		
		//全员卖家信誉分，如果超过100的每天-1分回落到100
		SmartDb.update("update `member` set `reputation_score`=`reputation_score`-1 where `reputation_score`>100");
		
		//不低于95分的玩家信誉分+1，但不超过100分
		SmartDb.update("update `member` set `play_score`=`play_score`+1 where `play_score`>=95 and `play_score`<100");
	}

}
