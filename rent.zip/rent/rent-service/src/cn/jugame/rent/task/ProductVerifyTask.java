package cn.jugame.rent.task;

import cn.j8.consul.ServiceCaller;
import cn.j8.json.Json;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * 商品自动审核
 *
 * @author zimT_T
 */
@DisallowConcurrentExecution
public class ProductVerifyTask implements Job {

    private Logger logger = Loggers.rentLog();

    private ExecutorService service = Executors.newFixedThreadPool(10);

    private ServiceCaller serviceCaller = new ServiceCaller(PropKit.get("consul.host"), "rent-product-verify");

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        List<Record> products = SmartDb.find("select * from `product` where `status`=?", Product.STATUS_VERIFY);
        for (final Record product : products) {
            service.execute(new Runnable() {
                @Override
                public void run() {
                    doCheck(product);
                }
            });
            doCheck(product);
        }

        service.shutdown();
        try {
            service.awaitTermination(Integer.MAX_VALUE, TimeUnit.DAYS);
        }catch(Exception e){
            logger.info("error", e);
        }
    }

    private void doCheck(Record product) {
        int sellerUid = product.getInt("seller_uid");
        String productId = product.getStr("product_id");
        int productType = product.getInt("product_type");
        String[] pics = getProductPics(productId);
        String text = product.getStr("name") + "。" + product.getStr("info") + "。" + product.getStr("forbidden");

        //看看缓存中是否已经有了审核结果
        logger.info("准备审核商品: " + productId);
        Integer succ = null;

        //如果该用户被封禁永久不得发布商品
        if (isForbidden(sellerUid)) {
            logger.info("商品【" + productId + "】卖家已经被禁！不予通过");
            succ = 0;
        } else if (isNotVerifyUser(sellerUid)) {
            succ = 1;
        } else {
            //会员VIP的因为用户不能自定义输入，无需审核
            if (productType == Product.PRODUCT_TYPE_VIP) {
                succ = 1;
                logger.info("商品【" + productId + "】属于会员VIP类商品，直接通过！");
            }
        }

        if (succ == null || succ == -1) {
            logger.info("商品【" + productId + "】执行易盾审核！");

            Json param = Json.object("productId", productId,
                        "text", text,
                        "sellerUid", sellerUid,
                        "pics", Json.array(pics));
            Json resp = serviceCaller.call("/product/verify", param);
            if(resp != null) {
                succ = resp.asObj().intVal("pass");
                String msg = resp.asObj().strVal("msg");
                logger.info("商品【" + productId + "】审核结果为：" + succ + "，msg=>" + msg);
            }
        }

        //执行上架操作
        if (succ == 1) {
            logger.info("商品【" + productId + "】执行上架操作！");
            if (!Product.onsale(productId, sellerUid, true)) {
                logger.error("自动审核通过商品【" + productId + "】上架失败！");
            }
        }
        //执行下架操作
        else if (succ == 0) {
            logger.info("商品【" + productId + "】执行下架操作！");
            if (!Product.offsale(productId, "自动审核-商品信息存在违规，不予通过", true)) {
                logger.error("自动审核下架商品【" + productId + "】失败");
            }
        }
        //可能各种原因调用易盾失败了，此时不知道保持商品现状即可
        else {
            logger.info("自动审核调用易盾有问题，商品【" + productId + "】保持现状并等待下一次审核！");
        }
    }

    private String[] getProductPics(String productId) {
        List<Record> pics = SmartDb.find("select * from `product_picture` where `product_id`=?", productId);
        String[] ss = new String[pics.size()];
        for (int i = 0; i < pics.size(); ++i) {
            ss[i] = pics.get(i).getStr("pic_url");
        }
        Arrays.sort(ss);
        return ss;
    }

    private String getCacheKey(String text, String[] pics) {
        StringBuffer sb = new StringBuffer();
        sb.append(text);
        for (String s : pics) {
            sb.append(s);
        }
        return "product_vefiry_" + Common.md5(sb.toString());
    }

    private boolean isForbidden(int uid) {
        Record row = User.userSpecial(uid, User.TYPE_NO_PRODUCT);
        return row != null;
    }

    private boolean isNotVerifyUser(int uid) {
        Record row = User.userSpecial(uid, User.TYPE_NO_VERIFY);
        return row != null;
    }
}