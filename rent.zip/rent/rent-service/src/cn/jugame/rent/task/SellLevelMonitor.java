package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.Date;
import java.util.List;

/**
 * 号主等级的自动升降级程序
 * @author ASUS
 *
 */
public class SellLevelMonitor implements Job{
	
	private Logger logger = Loggers.rentLog();

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		String date = Common.show_time(System.currentTimeMillis() - 31*24*3600*1000L, "yyyy-MM-dd"); //31天前
		
		//金牌号主审查
		List<Record> members = SmartDb.find("select * from `member` where `sell_level` in (?, ?) and sl_flag = ?", User.SELL_LEVEL_GOLD, User.SELL_LEVEL_SILVER,User.SELL_LEVEL_AUTOMANAGE);
		for(Record member : members){
			int uid = member.getInt("uid");
			int sellLevel = member.getInt("sell_level");
			Record ss = SmartDb.findFirst("select * from `seller_score` where `uid`=?", uid);
			
			//没有对应的记录，说明这个人在近31天已经成交不到5笔单了，直接降为普通
			if(ss == null){
				logger.info("号主【" + uid + "】近31天成交不足5笔单，直接降为普通！");
				SmartDb.update("update `member` set `sell_level`=? where `uid`=?", User.SELL_LEVEL_NORMAL, uid);
				continue;
			}
			
			//不足80分的信誉分，降为普通
			if(member.getInt("reputation_score") < PropKit.getInt("seller.sign_reputation_score")){
				logger.info("号主【" + uid + "】信誉分不足而自动从金牌降为普通，当前分数：" + member.getInt("reputation_score"));
				SmartDb.update("update `member` set `sell_level`=? where `uid`=?", User.SELL_LEVEL_NORMAL, uid);
				continue;
			}
			
			//对于金牌号主
			double currScore = ss.getBigDecimal("score").doubleValue();
			
			//31天订单成功率
			List<Record> countRows = SmartDb.find("select order_id, order_status, order_time, selluser_game_login_type from `order` where  order_status in (?, ?) and product_type=? and order_ispay=? and `order_finish_time`>=? and `selluser_uid`=?", 
					Order.ORDER_STATUS_CANCEL, Order.ORDER_STATUS_FINISH,Product.PRODUCT_TYPE_GAME,Order.ORDER_PAID, date + " 00:00:00", uid);
			
			double total = 0;
			double succCount = 0;
			for(Record r : countRows){
				//客服下班时间撤单的，同时又是上号器的，不参与成功率的计算
				Date orderTime = r.getDate("order_time");
				if(Common.inHour(orderTime, PropKit.getInt("kefu.rest_time.begin"), PropKit.getInt("kefu.rest_time.end"))
						&& r.getInt("selluser_game_login_type") != Product.LOGIN_ACCOUNTPASSWORD){
					continue;
				}
				
				total++;
				if(r.getInt("order_status") == Order.ORDER_STATUS_FINISH)
					succCount ++;
			}
			double succRate = 0;
			if(total > 0){
				succRate = Common.round(succCount/total, 2);
			}
			
			
			double silverUpperBound = Double.parseDouble(PropKit.get("seller.silver_upper_bound"));
			double silverUpperOrderRate = Double.parseDouble(PropKit.get("seller.silver_upper_order_rate"));
			
			double silverLowerBound = Double.parseDouble(PropKit.get("seller.silver_lower_bound"));
			double silverLowerOrderRate = Double.parseDouble(PropKit.get("seller.silver_lower_order_rate"));
			
			double goldUpperBound = Double.parseDouble(PropKit.get("seller.gold_upper_bound"));
			double goldUpperOrderRate = Double.parseDouble(PropKit.get("seller.gold_upper_order_rate"));
			
			double goldLowerBound = Double.parseDouble(PropKit.get("seller.gold_lower_bound"));
			double goldLowerOrderRate = Double.parseDouble(PropKit.get("seller.gold_lower_order_rate"));
			if(sellLevel == User.SELL_LEVEL_GOLD){
				//评分低于银牌降级分 或者 成功率低于银牌降级成功率，直接降为普通
				if(currScore < silverLowerBound || succRate < silverLowerOrderRate){
					logger.info("号主【" + uid + "】综合评分低于银牌降级分，直接降为普通号主，当前评分：" + (ss == null ? 0 : currScore)+"-当前成功率："+succRate);
					SmartDb.update("update `member` set `sell_level`=? where `uid`=?", User.SELL_LEVEL_NORMAL, uid);
					NotifyService.instance.sendSellerLevelChangeMessageToSelluser(uid,User.SELL_LEVEL_NORMAL,sellLevel);
				}
				//评分低于金牌降级分 或者 成功率低于金牌降级成功率，自动降维银牌
				else if(currScore < goldLowerBound || succRate < goldLowerOrderRate){
					logger.info("号主【" + uid + "】综合评分低于银牌降级分，直接降为普通号主，当前评分: " + currScore+"-当前成功率："+succRate);
					SmartDb.update("update `member` set `sell_level`=? where `uid`=?", User.SELL_LEVEL_SILVER, uid);
					NotifyService.instance.sendSellerLevelChangeMessageToSelluser(uid,User.SELL_LEVEL_SILVER,sellLevel);
				}
				else{
					//维持不变
				}
			}
			//对于银牌号主
			if(sellLevel == User.SELL_LEVEL_SILVER){
				//如果评分达到金牌晋级分，同时成功率也达到了金牌晋级成功率，自动从银牌升为金牌
				if(currScore >= goldUpperBound && succRate >= goldUpperOrderRate){
					logger.info("号主【" + uid + "】已经达到金牌晋级分，自动晋级为金牌号主，当前评分：" + currScore+"-当前成功率："+succRate);
					SmartDb.update("update `member` set `sell_level`=? where `uid`=?", User.SELL_LEVEL_GOLD, uid);
					NotifyService.instance.sendSellerLevelChangeMessageToSelluser(uid,User.SELL_LEVEL_GOLD,sellLevel);
				}
				//如果评分低于银牌降级分，或者成功率低于银牌降级成功率，自动降为普通号主
				else if(currScore < silverLowerBound || succRate < silverLowerOrderRate){
					logger.info("号主【" + uid + "】低于银牌降级分，自动降级为普通号主，当前评分：" + currScore+"-当前成功率："+succRate);
					SmartDb.update("update `member` set `sell_level`=? where `uid`=?", User.SELL_LEVEL_NORMAL, uid);
					NotifyService.instance.sendSellerLevelChangeMessageToSelluser(uid,User.SELL_LEVEL_NORMAL,sellLevel);
				}
				else{
					//维持不变
				}
			}
		}
	}

}
