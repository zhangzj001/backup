package cn.jugame.rent.task;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

/**
 * 专门负责清数据的玩意
 * @author zimT_T
 *
 */
public class ClearTask implements Job{
	
	private Logger logger = Loggers.rentLog();

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		try{clearScoreLog();}catch(Throwable e){logger.error("clearScoreLog.error", e);}
	}

	/**
	 * 清除用户的信誉分历史记录！
	 */
	private void clearScoreLog(){
		//超过30天的删
		long time = System.currentTimeMillis() - 30L*24*3600*1000;
		SmartDb.update("delete from `user_score_log` where `c_time`<=?", Common.show_time(time));
	}
}
