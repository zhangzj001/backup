package cn.jugame.rent.task;

import cn.jugame.jumq.util.Common;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/***
 * 商品装饰失效定时任务
 * @author Administrator
 *
 */
public class ProductDecorateInvalidTask implements Job {

	private Logger logger = Loggers.rentLog();
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		List<Record> list = SmartDb.find("select * from product_decorate_payment where status = ? and invalid_time <= ?",
				Product.DECORATE_PAYMENT_STATUS_PAYED,Common.now());
		if(list != null && list.size() > 0) {
			for(Record row : list) {
				if(SmartDb.update("update product set is_decorate = ? where seller_uid = ?",Product.PRODUCT_NO_DECORATE,row.getInt("uid")) <= 0) {
					logger.info("uid【"+row.getInt("uid")+"】将商品装饰状态改成失效失败");
				}
				row.keep("id");
				row.set("status", Product.DECORATE_PAYMENT_STATUS_INVALID);
				if(!SmartDb.update("product_decorate_payment", row)) {
					logger.info("payId【"+row.getInt("pay_id")+"】将商品装饰状态改成失效失败");
				}
			}
		}
	}

}
