package cn.jugame.rent.task;

import cn.jugame.rent.bean.Message;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.google.common.collect.Lists;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.apache.commons.lang.StringUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 推送运营消息给用户<br>
 */
@DisallowConcurrentExecution
public class MessagePushTask implements Job {

    private Logger logger = Loggers.rentLog();
    private ExecutorService executorService = Executors.newFixedThreadPool(8);

    @Override
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        String sendBeginTime = Common.show_time(System.currentTimeMillis() - PropKit.getInt("message.appmessage_remind_time") * 3600 * 1000L);
        List<Record> messages = SmartDb.find("SELECT * FROM `message_task` WHERE  `c_time` > ? and `status` = ? and `send_time` < ? and `enabled` = ? ORDER BY id DESC", sendBeginTime, Message.MESSAGETASK_STATUS_NEW, Common.now(), Message.MESSAGETASK_STATUS_ENABLED);
        for (Record message : messages) {
            Integer id = message.getInt("id");
            String title = message.getStr("title");
            String content = message.getStr("content");
            String targetUrl = message.getStr("target_url");
            String uidStr = message.getStr("uid");

            //如果uid字段为空则全量发送
            boolean isSendToAll = StringUtils.isBlank(uidStr) ? true : false;

            message.keep("id");
            message.set("send_time", Common.now());
            message.set("status", Message.MESSAGETASK_STATUS_SEND);
            if (!SmartDb.update("message_task", message)) {
                logger.error("更新消息任务状态为已发送" + id);
                continue;
            }

            executorService.execute(new Runnable() {
                @Override
                public void run() {
                    //全量发送
                    if (isSendToAll) {
                        NotifyService.instance.sendJpushMessage(new Integer[]{-1}, title, content, targetUrl);
                    }
                    //指定uid发送
                    else {
                        List<String> recvUids = Lists.newArrayList(uidStr.split(","));

                        //拆分成n组，逐组发送消息，避免消息发送失败
                        List<List<String>> groups = averageAssign(recvUids, recvUids.size() / 50 + 1);
                        for (List<String> group : groups) {
                            NotifyService.instance.sendJpushMessage(toInt(group), title, content, targetUrl);
                        }
                    }
                }
            });
        }
        executorService.shutdown();
    }

    private Integer[] toInt(List<String> uids){
        Integer[] tmp = new Integer[uids.size()];
        for(int i=0; i<tmp.length; ++i){
            tmp[i] = Integer.parseInt(uids.get(i));
        }
        return tmp;
    }

    /**
     * 将一个list均分成n个list,主要通过偏移量来实现的
     *
     * @param source
     * @return
     */
    private <T> List<List<T>> averageAssign(List<T> source, int n) {
        List<List<T>> result = new ArrayList<List<T>>();
        int remaider = source.size() % n;  //(先计算出余数)
        int number = source.size() / n;  //然后是商
        int offset = 0;//偏移量
        for (int i = 0; i < n; i++) {
            List<T> value = null;
            if (remaider > 0) {
                value = source.subList(i * number + offset, (i + 1) * number + offset + 1);
                remaider--;
                offset++;
            } else {
                value = source.subList(i * number + offset, (i + 1) * number + offset);
            }
            result.add(value);
        }
        return result;
    }

}