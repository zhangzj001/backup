package cn.jugame.rent.task;

import cn.jugame.rent.bean.Order;
import cn.jugame.rent.bean.Product;
import cn.jugame.rent.bean.User;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.DistLocker;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.Date;
import java.util.List;

/***
 * 一天内被三个不同玩家撤单，则将该号主拉入小黑屋三天
 */
@DisallowConcurrentExecution
public class BlackHouseTask implements Job {

    private Logger logger = Loggers.rentLog();

    private static final String _start_time = " 00:00:00";
    private static final String _end_time = " 23:59:59";

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        //获取当前日期
        String currentDate = Common.now("yyyy-MM-dd");

        //查询所有符合拉进小黑屋的号主id
        String sql = "select t.selluser_uid,b.sell_level from (select distinct selluser_uid, buyuser_uid from   order_cancel_apply a   where a.c_time >= ?"
                + " and a.c_time <=? and a.`status` = 1) t left join `member` b on t.selluser_uid = b.uid group by  t.selluser_uid having count(*) >=3";
        List<Record> lists = SmartDb.find(sql, currentDate + _start_time, currentDate + _end_time);

        if (lists != null && lists.size() > 0) {
            //查询符合拉进小黑屋的号主中已在小黑屋中的号主
            String sql1 = "select * from user_special  where uid in(select selluser_uid from (select distinct selluser_uid, buyuser_uid from   order_cancel_apply a "
                    + "  where a.c_time >= ?  and a.c_time <=? and a.`status` = 1) t group by  selluser_uid having count(*) >=3)";
            List<Record> userSpecials = SmartDb.find(sql1, currentDate + _start_time, currentDate + _end_time);
            logger.info("一天内被三个不同玩家撤单,sql查询：" + sql1);
            for (Record record : lists) {
                //只有普通号主才拉入小黑屋
                if (record.getInt("sell_level") != User.SELL_LEVEL_NORMAL)
                    continue;

                //扣除商品保证金
                deductedSellerGuaranteeAmount(record.getInt("selluser_uid"));
                Record userSpecial = new Record();
                //设置拉进小黑屋号主id
                userSpecial.set("uid", record.getInt("selluser_uid"));
                userSpecial.set("type", 3);
                userSpecial.set("c_time", Common.now());
                userSpecial.set("beg_time", Common.now());
                userSpecial.set("end_time", Common.addDay(Common.now(), 3));
                userSpecial.set("remark", "一天内被三个不同玩家撤单，被封禁");

                //判断该号主是否已在小黑屋中有记录
                if (userSpecials != null && userSpecials.size() > 0) {
                    Record oldUserSpecial = null;
                    for (Record special : userSpecials) {
                        if (special.getInt("uid").equals(record.getInt("selluser_uid"))) {
                            oldUserSpecial = special;
                            break;
                        }
                    }
                    //oldUserSpecial不为null 则表示该号主已在小黑屋中有记录
                    if (oldUserSpecial != null) {
                        //如果该用户是永久封禁，则不处理
                        if (oldUserSpecial.getInt("type") == 1)
                            continue;
                        userSpecial.set("id", oldUserSpecial.getInt("id"));
                        //如果不是封禁状态
                        if (oldUserSpecial.getInt("type") == 3) {
                            //判断开始时间是不是今天，如果是则不用更新
                            if (currentDate.equals(Common.show_time(oldUserSpecial.getDate("beg_time"), "yyyy-MM-dd")))
                                continue;
                            //判断如果之前拉黑的有效时间要大于现在的拉黑有效时间，则不更新
                            if (oldUserSpecial.getDate("end_time").compareTo(Common.addDay(new Date(System.currentTimeMillis()), 3)) > -1)
                                continue;
                        }
                    }
                }
                //如果存在记录，则更新
                if (userSpecial.getInt("id") != null && userSpecial.getInt("id") > 0) {
                    if (!SmartDb.update("user_special", "id", userSpecial)) {
                        logger.info("拉进小黑屋失败，号主id:" + record.getInt("selluser_uid"));
                    } else {
                        //拉入小黑屋成功后才记录日志
                        addUserSpecialLog(record);
                        logger.info("用户uid【" + record.getInt("selluser_uid") + "】 " + Common.now() + " 被加入小黑屋，将在 " + Common.addDay(Common.now(), 3) + " 放出小黑屋");
                    }
                } else {
                    if (!SmartDb.save("user_special", userSpecial)) {
                        logger.info("拉进小黑屋失败，号主id:" + record.getInt("selluser_uid"));
                    } else {
                        //拉入小黑屋成功后才记录日志
                        addUserSpecialLog(record);
                        logger.info("用户uid【" + record.getInt("selluser_uid") + "】 " + Common.now() + " 被加入小黑屋，将在 " + Common.addDay(Common.now(), 3) + " 放出小黑屋");
                    }
                }
            }
        }
    }

    /***
     * 记录拉黑日志
     * @param record
     */
    private void addUserSpecialLog(Record record) {
        Record userSpecialLog = new Record();
        userSpecialLog.set("uid", record.getInt("selluser_uid"));
        userSpecialLog.set("c_time", Common.now());
        userSpecialLog.set("content", "用户uid【" + record.getInt("selluser_uid") + "】 " + Common.now() + " 被加入小黑屋，将在 " + Common.addDay(Common.now(), 3) + " 放出小黑屋");
        SmartDb.save("user_special_log", userSpecialLog);
    }

    /****
     * 扣除商品保证金
     * @param uid
     */
    private void deductedSellerGuaranteeAmount(int uid) {
        String sql = "select b.* from order_cancel_apply a  left join `order` b on a.order_id = b.order_id "
                + " where a.c_time >= ? and a.c_time <=? and a.`status` = 1 and a.selluser_uid = ?";
        String currentDate = Common.now("yyyy-MM-dd");
        List<Record> orders = SmartDb.find(sql, currentDate + _start_time, currentDate + _end_time, uid);
        String selluserPhonenum = null;
        //uid  扣除保证金的商品数
        int deductedCount = 0;
        if (orders != null && orders.size() > 0) {
            for (Record order : orders) {
                //号主没交保证金或者已经扣除保证金
                if (order.getInt("is_deducted_guarantee_amount") == Order.ORDER_DEDUCTED_GUARANTEE
                        || order.getInt("seller_guarantee_amount") <= 0)
                    continue;
                selluserPhonenum = order.getStr("selluser_phonenum");
                DistLocker locker = new DistLocker(order.getStr("product_id"));
                boolean succ = false;
                try {
                    succ = locker.lock(PropKit.getInt("displock.timeout"));
                    if (!succ) {
                        logger.error("小黑屋定时任务扣除商品保证金，order_id=>" + order.getStr("order_id"));
                        return;
                    }
                    logger.info("BlackHouseTask---deductedSellerGuaranteeAmount -- 小黑屋扣除商品保证金: " + order.getStr("product_id") + ", orderId=>" + order.getStr("order_id"));
                    //更新商品信息
                    if (Product.deductedSellerGuaranteeAmount(order.getStr("product_id"))) {
                        logger.error("扣除保证金后，更新商品信息失败：" + order.getStr("product_id"));
                    }
                    deductedCount++;
                    if (order != null && order.getInt("seller_guarantee_amount") > 0) {
                        //更新订单信息
                        if (SmartDb.update("update `order` set is_deducted_guarantee_amount = ?, deducted_guarantee_amount_time= ? where order_id = ?", Order.ORDER_DEDUCTED_GUARANTEE, Common.now(), order.getStr("order_id")) == 0) {
                            logger.error("扣除保证金后，更新订单信息失败：" + order.getStr("order_id"));
                        }
                    }
                } catch (Exception ex) {
                    logger.error("保证金扣除后更新商品订单异常异常");
                } finally {
                    if (succ) locker.unlock();
                }
            }
        }

        //消息通知
        if (deductedCount > 0) {
            NotifyService.instance.sendDeductProductGuaranteeMessageToSelluser(uid, selluserPhonenum);
        }
    }

}
