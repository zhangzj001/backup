package cn.jugame.rent.task;

import cn.jugame.rent.bean.Coupon;
import cn.jugame.rent.notify.NotifyService;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.Loggers;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.plugin.activerecord.SmartDb;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;

import java.util.List;

/**
 * 优惠券到期提醒
 * @author jiangshishan
 *
 */
@DisallowConcurrentExecution
public class CouponOutDateRemindTask implements Job {
    private Logger logger = Loggers.rentLog();

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        //1.查询明天就要到期的优惠券
        String nextday = Common.show_time(System.currentTimeMillis() + 24*3600*1000, "yyyy-MM-dd");
        List<Record> outDateCoupons = SmartDb.find("SELECT * FROM `user_coupon` WHERE end_date = ? and `status` = ? and `left_times` > 0", nextday, Coupon.STATUS_ONSALE);
        //2.发送提醒
        for(Record outDateCoupon : outDateCoupons){
            NotifyService.instance.sendCouponOutDateRemindMessageToBuyuser(outDateCoupon.getInt("uid"), outDateCoupon.getStr("name"));
        }
    }
}
