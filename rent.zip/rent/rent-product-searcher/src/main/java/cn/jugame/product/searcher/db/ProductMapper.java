package cn.jugame.product.searcher.db;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface ProductMapper {

    /** 上架 */
    public static final int STATUS_ONSALE = 7;
    /** 出租中 */
    public static final int STATUS_RENT = 201;

    @Select("select * from `product_recommended`")
    List<ProductRecommendedEntity> getRecommendedProducts();

    @Select("SELECT * FROM `product` WHERE `status` IN (" + STATUS_ONSALE + ", " + STATUS_RENT + ") AND `reputation_score` > 50")
    List<ProductEntity> getProducts();
}
