package cn.jugame.product.searcher.db;

import lombok.Data;

@Data
public class ProductRecommendedEntity {
    private String productId;
    private int weight;
}
