package cn.jugame.product.searcher;

import cn.jugame.rent.search.SearchResult;
import cn.jugame.rent.search.SearchTerm;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.solr.SolrAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication(exclude=SolrAutoConfiguration.class) //因为solr版本老旧，必须把这个类剔除，否则启动报错
@EnableDiscoveryClient
@EnableScheduling
public class RentProductSearcherApplication extends SpringBootServletInitializer {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public static void main(String[] args) {
        SpringApplication.run(RentProductSearcherApplication.class, args);
    }

    @Autowired
    private LuceneService luceneService;

    @RequestMapping("/product/search")
    public SearchResult searchProducts(@RequestParam String termJson) {
        if(StringUtils.isBlank(termJson))
            return null;

        SearchTerm term = SearchTerm.fromJson(termJson);
        logger.info("search: " + term.toJson().toString());
        return luceneService.search(term);
    }

    //XXX 为了剔除SolrAutoConfiguration.class，必须继承SpringBootServletInitializer来启动
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(RentProductSearcherApplication.class);
    }
}
