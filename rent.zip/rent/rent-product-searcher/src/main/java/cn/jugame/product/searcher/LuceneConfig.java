package cn.jugame.product.searcher;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Data
@Component
public class LuceneConfig {
    @Value("${lucene.index_directory}")
    private String indexDirectory;

    @Value("${lucene.words_file_path}")
    private String wordsFilePath;
}
