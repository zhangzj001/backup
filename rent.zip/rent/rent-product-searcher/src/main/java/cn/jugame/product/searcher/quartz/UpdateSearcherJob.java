package cn.jugame.product.searcher.quartz;

import cn.jugame.product.searcher.LuceneService;
import cn.jugame.product.searcher.db.ProductEntity;
import cn.jugame.product.searcher.db.ProductMapper;
import cn.jugame.rent.utils.Loggers;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
public class UpdateSearcherJob{
//    private Logger L = Loggers.luceneLog();

    @Autowired
    private LuceneService luceneService;

    @Scheduled(fixedDelay = 60000)
	public void execute() {
	    long start = System.currentTimeMillis();
        boolean rtn = luceneService.updateSearcher(true);
        long end = System.currentTimeMillis();

//        L.info("UpdateSearcherTask, code:" + (rtn? "1" : "0")
//                + ", cost:" + (end-start)
//                +", time:" + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date()));
	}
}
