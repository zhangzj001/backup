package cn.jugame.product.searcher.db;

import lombok.Data;

@Data
public class ProductEntity {
    private String productId;
    private String gameId;
    private String channelId;
    private String gamePartitionId;
    private int productType;
    private int status;
    private int sellerUid;
    private int sellLevel;
    private String name;
    private String info;
    private String externProperties;
    private int priceHour;
    private int tradeHour;
    private int reputationScore;
    private int sellerGuaranteeAmount;
    private int isSellerOnline;
    private String promotionProperties;
    private int gameLoginType;
    private int supportType;
}
