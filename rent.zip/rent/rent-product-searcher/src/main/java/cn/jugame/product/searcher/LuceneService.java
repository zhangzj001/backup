package cn.jugame.product.searcher;

import cn.jugame.product.searcher.db.ProductEntity;
import cn.jugame.product.searcher.db.ProductMapper;
import cn.jugame.product.searcher.db.ProductRecommendedEntity;
import cn.jugame.rent.search.SearchResult;
import cn.jugame.rent.search.SearchTerm;
import cn.jugame.rent.search.SortTerm;
import cn.jugame.rent.utils.Loggers;
import com.chenlb.mmseg4j.analysis.ComplexAnalyzer;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.*;
import org.apache.lucene.store.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Created by Administrator on 2017/6/1.
 */
@Service
public class LuceneService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private ReadWriteLock rwlock = new ReentrantReadWriteLock();

    private ComplexAnalyzer _ANALYZER = null;

    private IndexSearcher _SEARCHER = null;

    //默认的排序
    private Sort DEFAULT_SORT = new Sort(new SortField[]{SortField.FIELD_SCORE});

    //分词搜索的字段
    private String[] SEARCH_FIELDS = {"name", "info", "ext"};

    private ComplexAnalyzer createAnalyzer(String path) {
        return new ComplexAnalyzer(path);
    }

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private LuceneConfig luceneConfig;

    /** 商品分类：会员 */
    private static final int PRODUCT_TYPE_VIP = 2;

    private String field2str(Object obj){
    	if(obj == null)
    		return "";
    	return obj.toString();
    }
    
    private void loadProductDocument(IndexWriter writer){
    	FieldType saveButNoTokenFT = new FieldType();
        saveButNoTokenFT.setStored(true);
        saveButNoTokenFT.setTokenized(false);
        saveButNoTokenFT.setIndexOptions(IndexOptions.NONE);
        
    	//推荐商品ID
        List<ProductRecommendedEntity> recommends = productMapper.getRecommendedProducts();
        Set<String> prs = new HashSet<>();
        for(ProductRecommendedEntity r : recommends){
        	prs.add(r.getProductId());
        }

        List<ProductEntity> listR = productMapper.getProducts();
        for (ProductEntity r : listR) {
            Document doc = new Document();
            //商品ID
            doc.add(new Field("product_id", r.getProductId(), saveButNoTokenFT));

            //game_id
            doc.add(new StringField("game_id", field2str(r.getGameId()), StringField.Store.YES));
            
            //channel_id
            doc.add(new StringField("channel_id", field2str(r.getChannelId()), StringField.Store.YES));

            //game_partion_id
            doc.add(new StringField("game_partition_id", field2str(r.getGamePartitionId()), StringField.Store.YES));
            
            //product_type
            doc.add(new StringField("product_type", field2str(r.getProductType()), StringField.Store.YES));

            //status
            addSortedIntField("status", r.getStatus(), doc);

            //seller_uid
            doc.add(new StringField("seller_uid", field2str(r.getSellerUid()), StringField.Store.YES));

            //号主等级
            addSortedIntField("sell_level", r.getSellLevel(), doc);
            
            //标题
            String name = r.getName();
            doc.add(new TextField("name", name == null ? "" : name, TextField.Store.YES));

            //简介
            String info = r.getInfo();
            //会员VIP的商品，不对info建立索引！
            if(r.getProductType() == PRODUCT_TYPE_VIP){
                info = "";
            }
            doc.add(new TextField("info", info == null ? "" : info, TextField.Store.YES));
            
            //扩展属性
            StringBuffer buf = new StringBuffer();
            String extPropStr = r.getExternProperties();
            if(StringUtils.isNotBlank(extPropStr)){
                try{
                	JSONArray exts = JSONArray.fromObject(extPropStr);
                	for(int i=0; i<exts.size(); ++i){
                		JSONObject obj = exts.optJSONObject(i);
                		String propValue = obj.optString("prop_value");
                		if(StringUtils.isNotBlank(propValue)){
                			buf.append(propValue).append("  ");
                		}
                	}
                }catch(Exception e){
                	//不合法的数据，忽略
                }
            }
            doc.add(new TextField("ext", buf.toString(), TextField.Store.YES));

            //价格
            addSortedIntField("price_hour", r.getPriceHour(), doc);

            //交易时长，排序用
            addSortedIntField("trade_hour", r.getTradeHour(), doc);
            
            //号主信誉分
            addSortedIntField("reputation_score", r.getReputationScore(), doc);
            
            //保证金
            addSortedIntField("seller_guarantee_amount", r.getSellerGuaranteeAmount(), doc);
            
            //当前是否在线
            addSortedIntField("is_seller_online", r.getIsSellerOnline(), doc);

            //商品是否有号主推广信息（是否有租送）
            String promotionProperties = r.getPromotionProperties();
            boolean isProductPromotion = (StringUtils.isNotBlank(promotionProperties) && promotionProperties != "{}");
            doc.add(new StringField("is_promote_product", isProductPromotion ? "1" : "0", StringField.Store.YES));
            
            //商品的登录方式
            String gameLoginType = field2str(r.getGameLoginType());
            //将PC上号和手游上号 归属为同一类，都将值设置为2(端游上号)
            if("3".equalsIgnoreCase(gameLoginType)){
            	gameLoginType = "2";
            }
            doc.add(new StringField("game_login_type", gameLoginType, StringField.Store.YES));
            
            //如果商品是推荐商品，带上这个标记
            int isRecommendProduct = 0;
            if(prs.contains(r.getProductId())){
            	isRecommendProduct = 1;
            }
            addSortedIntField("is_recommend_product", isRecommendProduct, doc);
            
            //扶持类型
            addSortedIntField("support_type", r.getSupportType(), doc);
            
            try{
            	writer.addDocument(doc);
            }catch(Exception e){
            	logger.error("error! 加载商品【" + r.getProductId() + "】发生错误!", e);
            }
        }
    }
    
    private Directory createIndexWriter(ComplexAnalyzer analyzer){
    	if(analyzer == null) {
            logger.error("analyzer is null");
            return null;
        }
        
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        config.setCommitOnClose(true);
        config.setOpenMode(OpenMode.CREATE);
        Directory dir = new RAMDirectory();

        IndexWriter writer = null;
        try{
        	writer = new IndexWriter(dir, config);
	        loadProductDocument(writer);
	        writer.commit();
	        
	        return dir;
        }catch(Exception e){
        	logger.error("error", e);
        	return null;
        }finally{
        	if(writer != null){
        		try{writer.close();}catch(Exception e){
                    logger.error("error", e);}
        	}
        }
    }

    private IndexSearcher createSearcher(ComplexAnalyzer analyzer, Directory dir) {
        try{
            Directory target = new RAFDirectory(Paths.get(luceneConfig.getIndexDirectory()));

            //如果目录不为空，说明是从别的地方拷贝数据过来，先将目录旧数据清掉，再copy过来...
            if(dir != null){
	            for(String file : target.listAll()){
	            	target.deleteFile(file);
	            }
	            //将新建立的索引文件拷贝过来
	            for(String file : dir.listAll()){
	            	target.copyFrom(dir, file, file, IOContext.DEFAULT);
	            }
            }
            
            //建立新的searcher
            IndexReader reader = DirectoryReader.open(target);
            return new IndexSearcher(reader);
        } catch (Exception e) {
            logger.error("createSearcher fail", e);
            return null;
        }
        
    }
    
    private void addSortedIntField(String field, int value, Document doc){
        doc.add(new IntPoint(field, value));
        doc.add(new NumericDocValuesField(field, value)); //排序用
        doc.add(new StoredField(field, value)); //存储用
    }
    
    public boolean updateSearcher(boolean create) {
        logger.info("--begin updateSearcher");
        ComplexAnalyzer analyzer = createAnalyzer(luceneConfig.getWordsFilePath());
        if(analyzer == null) {
            logger.error("get new analyzer is null");
            return false;
        }
        
    	//先加载好数据
    	Directory dir = null;
    	if(create){
    		dir = createIndexWriter(analyzer);
        	logger.info("--data loaded!");
    	}

        //写锁
        rwlock.writeLock().lock();

        //使用新建立好的索引，完整替换掉旧的索引
        IndexSearcher s = createSearcher(analyzer, dir);
        if (s == null) {
            logger.error("get new index is null");
            return false;
        }

        if(_ANALYZER != null){
        	_ANALYZER.close();
        }
        if(_SEARCHER != null){
        	try{_SEARCHER.getIndexReader().close();}catch(Exception e){
                logger.error("_SEARCHER error", e);}
        }
        _ANALYZER = analyzer;
        _SEARCHER = s;
        
        rwlock.writeLock().unlock();

        logger.info("--end createSearcher");

        //记得释放这个内存目录
        if(dir != null){
        	try{ dir.close(); }catch(Exception e){
                logger.error("error", e);}
        }
        
        return true;
    }


    public SearchResult search(SearchTerm filter) {
        rwlock.readLock().lock();

        int offset = filter.getOffset();
        int limit = filter.getLimit();
        //若还没有准备好
        if(_SEARCHER == null){
        	SearchResult result = new SearchResult();
        	result.setCode(0);
        	result.setMsg("not yet ready");
        	result.setTotalCount(0);
        	result.setOffset(offset);
        	result.setLimit(limit);
            return result;
        }

        try {
            StringBuffer sb = new StringBuffer();

            BooleanQuery.Builder QB = new BooleanQuery.Builder();

            //关键词
            if(StringUtils.isNotBlank(filter.getKeyword())){
            	String keyword = filter.getKeyword();
	            String[] queries = {keyword, keyword, keyword};
	            Query queryWord = MultiFieldQueryParser.parse(queries, SEARCH_FIELDS, _ANALYZER);
	            QB.add(new BooleanClause(queryWord, BooleanClause.Occur.MUST));
	            sb.append("keyword=" + filter.getKeyword() + "`");
            }

            //游戏ID
            if(StringUtils.isNotBlank(filter.getGameId())){
                Query _q = new TermQuery(new Term("game_id", String.valueOf(filter.getGameId())));
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("game_id=" + filter.getGameId() + "`");
            }

            //渠道ID
            if(StringUtils.isNotBlank(filter.getChannelId())){
                Query _q = new TermQuery(new Term("channel_id", String.valueOf(filter.getChannelId())));
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("channel_id=" + filter.getChannelId() + "`");

            }

            //区服ID
            if(StringUtils.isNotBlank(filter.getPartitionId())){
                Query _q = new TermQuery(new Term("game_partition_id", String.valueOf(filter.getPartitionId())));
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("game_partition_id=" + filter.getPartitionId() + "`");
            }
            
            //商品分类
            if(filter.getProductType() > 0){
            	Query _q = new TermQuery(new Term("product_type", String.valueOf(filter.getProductType())));
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("product_type=" + filter.getProductType() + "`");
            }
            
            //商品状态
            if(filter.getStatus() > 0){
        		Query _q = new DocValuesNumbersQuery("status", new Long[]{(long)filter.getStatus()});
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("status=" + filter.getStatus() + "`");
            }

            //卖家UID
            if(filter.getSellerUid() > 0){
                Query _q = new TermQuery(new Term("seller_uid", String.valueOf(filter.getSellerUid())));
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("seller_uid=" + filter.getSellerUid() + "`");
            }

            //卖家等级
            if(filter.getSellLevel() != null && filter.getSellLevel().length > 0){
            	//注意号主的等级可能是一个多元素的数组，这将是一个或方式的联合查询
            	int[] sls = filter.getSellLevel();
            	if(sls.length == 1){
            		Query _q = new DocValuesNumbersQuery("sell_level", new Long[]{(long)sls[0]});
	                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
	                sb.append("sell_level=" + sls + "`");
            	}
            	else{
            		BooleanQuery.Builder builder = new BooleanQuery.Builder();
            		for(int i=0; i<sls.length; ++i){
                		Query _q = new DocValuesNumbersQuery("sell_level", new Long[]{(long)sls[i]});
            			builder.add(new BooleanClause(_q, BooleanClause.Occur.SHOULD));
            		}
	                QB.add(new BooleanClause(builder.build(), BooleanClause.Occur.MUST));
	                sb.append("sell_level=" + sls + "`");
            	}
            }
            
            //是否设置了保证金
            if(filter.getHasSellerGuarantee() >= 0){
            	int hasSellerGuarantee = filter.getHasSellerGuarantee();
            	//已交保证金
            	if(hasSellerGuarantee == 1){
	        		Query _q = new DocValuesNumbersQuery("seller_guarantee_amount", new Long[]{0L});
	                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST_NOT));
	                sb.append("seller_guarantee_amount>0`");
            	}
            	//未交保证金
            	else if(hasSellerGuarantee == 0){
	        		Query _q = new DocValuesNumbersQuery("seller_guarantee_amount", new Long[]{0L});
	                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
	                sb.append("seller_guarantee_amount=0`");
            	}
            	else{
            		//全部
            	}
            }

            //是否有号主推广
            if(filter.getIsPromoteProduct() > 0){
            	int value = filter.getIsPromoteProduct();
            	//XXX 目前来说平台设置的参数，是大于0的时候才进行搜索
            	if(value > 0){
                    Query _q = new TermQuery(new Term("is_promote_product", String.valueOf(value)));
                    QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                    sb.append("is_promote_product=" + filter.getIsPromoteProduct() + "`");
            	}
            }
            
            //是否按登录方式筛选
            if(filter.getGameLoginType() > 0){
            	int gameLoginType = filter.getGameLoginType();
            	if(gameLoginType > 0){
            		Query _q = new TermQuery(new Term("game_login_type", String.valueOf(gameLoginType)));
                    QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                    sb.append("game_login_type=" + filter.getGameLoginType() + "`");
            	}
            }
            
            //时租价区间
            {
	            long minPriceHour = filter.getMinPriceHour();
	            if(minPriceHour <= 0)
	            	minPriceHour = 0;
	            long maxPriceHour = filter.getMaxPriceHour();
	            if(maxPriceHour <= 0)
	            	maxPriceHour = 100000; //单位为分，这里是1000元，对租号来说足够大了

	            Query _q = DocValuesRangeQuery.newLongRange("price_hour", minPriceHour, maxPriceHour, true, true);
	            QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
	            sb.append("min_price_hour=" + minPriceHour + "`max_price_hour=" + maxPriceHour + "`");
            }
            
            //是否推荐商品
            if(filter.getIsRecommendProduct() > 0){
            	int isRecommendProduct = filter.getIsRecommendProduct();
            	if(isRecommendProduct > 0){
            		Query _q = new DocValuesNumbersQuery("is_recommend_product", (long)isRecommendProduct);
	                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
	                sb.append("is_recommend_product=" + isRecommendProduct + "`");
            	}
            }
            
            //是否扶持商品
            if(filter.getSupportType() >= 0){
        		Query _q = new DocValuesNumbersQuery("support_type", (long)filter.getSupportType());
                QB.add(new BooleanClause(_q, BooleanClause.Occur.MUST));
                sb.append("support_type=" + filter.getSupportType() + "`");
            }

            logger.info("query string: " + sb.toString());

            Query Q = QB.build();
            int totalCount = _SEARCHER.count(Q);

            if(totalCount == 0) {
                logger.error("find nothing. " + sb.toString());
            }

            //排序
            Sort S = DEFAULT_SORT;
            SortTerm[] sort = filter.getSortTerms();
            if(sort != null && sort.length > 0){
            	SortField[] sortFields = new SortField[sort.length];
            	for(int i=0; i<sortFields.length; ++i){
            		sortFields[i] = new SortField(sort[i].getFieldName(), SortField.Type.INT, sort[i].isReverse());
            	}
                S = new Sort(sortFields);
            }

            TopFieldDocs docs = _SEARCHER.search(Q, offset + limit, S);

            int minCount = Math.min(totalCount, offset + limit);

            //offset已经超过数量，返回空了
            List<String> idList = new ArrayList<String>();
            if(minCount > offset) {
                for(int i=offset; i<minCount; i++) {
                    ScoreDoc sd = docs.scoreDocs[i];
                    String productId = _SEARCHER.doc(sd.doc).getField("product_id").stringValue();
                    System.out.println("--got:"
                            +  _SEARCHER.doc(sd.doc).getField("price_hour").numericValue() + "|||"
                            +  _SEARCHER.doc(sd.doc).getField("name").stringValue() + "|||"
                            +  _SEARCHER.doc(sd.doc).getField("info").stringValue());
                    idList.add(productId);
                }
            }

            SearchResult result = new SearchResult();
            result.setCode(0);
            result.setMsg("ok");
            result.setTotalCount(totalCount);
            result.setOffset(offset);
            result.setLimit(limit);
            result.setProductIds(idList);
            return result;
        } catch (ParseException pe) {
            logger.error("ParseException:" + pe.getMessage(), pe);
        } catch (IOException ioe) {
            logger.error("IOException" + ioe.getMessage(), ioe);
        } catch (Throwable e) {
            logger.error("Exception:" + e.toString(), e);
        } finally {
            rwlock.readLock().unlock();
        }

        SearchResult result = new SearchResult();
        result.setCode(-1);
        result.setMsg("search fail");
        return result;
    }
}
