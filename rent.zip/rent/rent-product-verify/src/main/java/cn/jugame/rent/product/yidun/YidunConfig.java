package cn.jugame.rent.product.yidun;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class YidunConfig {
    @Value("${yd.secretid}")
    private String secretId;

    @Value("${yd.secretkey}")
    private String secretKey;

    @Value("${yd.businessid_text}")
    private String businessidText;

    @Value("${yd.businessid_image}")
    private String businessidImage;

    @Value("${yd.api_url_text}")
    private String apiUrlText;

    @Value("${yd.api_url_image}")
    private String apiUrlImage;

    @Value("${yd.user_account}")
    private String userAccount;

    @Value("${yd.version}")
    private String version;

    public String getSecretId() {
        return secretId;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public String getBusinessidText() {
        return businessidText;
    }

    public String getBusinessidImage() {
        return businessidImage;
    }

    public String getApiUrlText() {
        return apiUrlText;
    }

    public String getApiUrlImage() {
        return apiUrlImage;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public String getVersion() {
        return version;
    }
}
