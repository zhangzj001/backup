package cn.jugame.rent.product;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.Semaphore;

@SpringBootApplication
@EnableDiscoveryClient
@RestController
public class RetnProductVerifyApplication {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private VerifyService verifyService;

    @RequestMapping("/product/verify")
    public VerifyResponse verify(@RequestBody VerifyRequest request){
//        logger.info("商品ID：" + request.getProductId());
//        logger.info("卖家：" + request.getSellerUid());
//        if(request.getPics() != null){
//            for(int i=0; i<request.getPics().length; ++i){
//                logger.info("图片：" + request.getPics()[i]);
//            }
//        }
//        logger.info("文字：" + request.getText());

        return verifyService.verify(request);
    }

    public static void main(String[] args) {
        SpringApplication.run(RentProductVerifyApplication.class, args);
    }
}
