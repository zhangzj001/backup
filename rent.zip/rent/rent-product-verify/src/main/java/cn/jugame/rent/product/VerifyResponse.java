package cn.jugame.rent.product;

public class VerifyResponse {
    private int pass;
    private String msg;

    public VerifyResponse(int pass, String msg){
        this.pass = pass;
        this.msg = msg;
    }

    public int getPass() {
        return pass;
    }

    public String getMsg() {
        return msg;
    }
}
