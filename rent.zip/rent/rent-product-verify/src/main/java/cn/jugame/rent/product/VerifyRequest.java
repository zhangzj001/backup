package cn.jugame.rent.product;

public class VerifyRequest {
    private String productId;
    private String text;
    private String[] pics;
    private int sellerUid;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String[] getPics() {
        return pics;
    }

    public void setPics(String[] pics) {
        this.pics = pics;
    }

    public int getSellerUid() {
        return sellerUid;
    }

    public void setSellerUid(int sellerUid) {
        this.sellerUid = sellerUid;
    }
}
