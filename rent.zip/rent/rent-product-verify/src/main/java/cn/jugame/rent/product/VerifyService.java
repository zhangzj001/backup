package cn.jugame.rent.product;

import cn.jugame.rent.product.yidun.YidunResult;
import cn.jugame.rent.product.yidun.YidunService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VerifyService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private YidunService yidunService;

    /**
     * 审核商品数据
     * @param req
     * @return
     */
	public VerifyResponse verify(VerifyRequest req){
	    String productId = req.getProductId();
	    int sellerUid = req.getSellerUid();
	    String[] pics = req.getPics();
	    String text = req.getText();

        logger.info("商品【" + productId + "】即将执行易盾审核！");
        int succ = checkImg(pics, sellerUid);
        String msg = "ok";
        if(succ == 0){
            logger.info("商品【" + productId + "】审核图片不通过!");
            msg = "商品图片审核不通过";
        }else if(succ == 1){
            logger.info("商品【" + productId + "】审核图片通过，继续审核文字..");
            succ = checkText(text, productId, sellerUid);
            if(succ == 0){
                logger.info("商品【" + productId + "】审核文字不通过！");
                msg = "商品信息文字审核不通过";
            }
        }else if(succ == -1){
            logger.info("商品【" + productId + "】审核失败，暂时没有审核结果！");
            msg = "审核服务错误，暂时没有审核结果";
        }

        logger.info("商品【" + productId + "】审核结果为：" + succ);
        return new VerifyResponse(succ, msg);
    }

	private int checkImg(String[] pics, int uid){
		for(String pic : pics){
			YidunResult result = yidunService.imageCheck(pic, uid);
			if(result == null)
				return -1;
			//易盾返回通过和疑似的，都让商品能通过审核，除非是确定为违规的
			//图片涉嫌广告的先放过，毕竟游戏内太多ID号了，容易混淆
			if(result.getAction() == 2 && result.getLabel() != 200){
				return 0;
			}
		}
		return 1;
	}

	private int checkText(String text, String productId, int uid){
		YidunResult result = yidunService.textCheck(text, productId, uid);
		if(result == null)
			return -1;
        //易盾返回通过和疑似的，都让商品能通过审核，除非是确定为违规的
		if(result.getAction() == 2){
			return 0;
		}
		return 1;
	}
	
}
