package cn.jugame.rent.product.yidun;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import cn.j8.json.Json;
import cn.j8.json.JsonArray;
import cn.j8.json.JsonObj;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;

import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.URLConnectionHttpFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class YidunService {
    @Autowired
    private YidunConfig yidunConfig;

	private URLConnectionHttpFetcher fetcher = new URLConnectionHttpFetcher();
	
	private Logger logger = Loggers.rentLog();
	
	// 易盾图片在线鉴定
	public YidunResult imageCheck(String imgUrl, int uid) {

		List<NameValuePair> param = new ArrayList<NameValuePair>();
		// 1.设置公共参数
		param.add(new BasicNameValuePair("secretId", yidunConfig.getSecretId()));
		param.add(new BasicNameValuePair("businessId", yidunConfig.getBusinessidImage()));
		param.add(new BasicNameValuePair("version", yidunConfig.getVersion()));
		param.add(new BasicNameValuePair("timestamp", String.valueOf(System.currentTimeMillis())));
		param.add(new BasicNameValuePair("nonce", String.valueOf(new Random().nextInt())));

		// 2.设置私有参数
		// 一次可传多张.
		JsonArray jsonArray = Json.array().asArray();

		// 去水印
		if (imgUrl.contains("watermark.jpg")) {
			imgUrl = imgUrl.replaceAll("watermark.jpg", "origin");
		} else if (imgUrl.contains(".png")) {
			imgUrl = imgUrl.replace(".png", "_origin.png");
		} else if (imgUrl.contains(".jpg")) {
			imgUrl = imgUrl.replace(".jpg", "_origin.jpg");
		}

		// 传图片URL type:1 url , type:2 base64
		JsonObj image = Json.object().asObj();
		image.put("name", imgUrl);
		image.put("type", 1);
		image.put("data", imgUrl);
		jsonArray.add(image);

		param.add(new BasicNameValuePair("images", jsonArray.toString()));
		param.add(new BasicNameValuePair("account", yidunConfig.getUserAccount() + "_" + uid));

		// 3.生成签名信息
		String signature = SignatureUtils.genSignature(yidunConfig.getSecretKey(), paramToMap(param));
		param.add(new BasicNameValuePair("signature", signature));

		// 4.发送HTTP请求
		String response = fetcher.posts(yidunConfig.getApiUrlImage(), param);
		if(StringUtils.isBlank(response)){
			logger.error("访问易盾图片审核接口返回为空, imgUrl=>" + imgUrl);
			return null;
		}

		// 5.解析接口返回值
		Json resultJson = Json.parse(response);
		if(resultJson == null){
			logger.error("访问易盾图片审核接口返回值不是JSON，content=>" + response);
			return null;
		}

		int code = resultJson.asObj().intVal("code", 0);

		YidunResult result = new YidunResult();
		if (code == 200) {
			Json resultArray = resultJson.asObj().val("result");
			for (int i = 0; i < resultArray.size(); i++) {
				Json jsonObject = resultArray.asArray().val(i);
				String taskId = jsonObject.asObj().strVal("taskId");
				Json labelArray = jsonObject.asObj().val("labels");
				int maxLevel = -1;
				for (int j = 0; j < labelArray.size(); j++) {
					Json jsonObject2 = labelArray.asArray().val(j);
					int label = jsonObject2.asObj().intVal("label", 0);
					int level = jsonObject2.asObj().intVal("level", 0);
					double rate = jsonObject2.asObj().intVal("rate", 0);

					if (level == 2 || level == 1) {
						result.setLabel(label);
					}

					// 如果是疑似色情和性感,直接改为不通过
					if ((label == 100 || label == 110) && rate > 0.5) {
						maxLevel = 2;
					}

					maxLevel = level > maxLevel ? level : maxLevel;
				}
				result.setTaskId(taskId);
				result.setAction(maxLevel);
			}
		} else {
			result.setAction(-1);
		}

		logger.info("用户【" + uid + "】- 易盾检查图片：" + imgUrl + "，审核结果：" + result);

		return result;
	}
	
	// 易盾文本在线鉴定
	public YidunResult textCheck(String content, String productId, int uid) {
		List<NameValuePair> param = new ArrayList<NameValuePair>();
		/* 设置公共参数 */
		param.add(new BasicNameValuePair("secretId", yidunConfig.getSecretId()));
		param.add(new BasicNameValuePair("businessId", yidunConfig.getBusinessidText()));
		param.add(new BasicNameValuePair("version", yidunConfig.getVersion()));
		param.add(new BasicNameValuePair("timestamp", String.valueOf(System.currentTimeMillis())));
		param.add(new BasicNameValuePair("nonce", String.valueOf(new Random().nextInt())));

		/* 设置私有参数 */
		param.add(new BasicNameValuePair("dataId", productId));
		param.add(new BasicNameValuePair("content", content));
		param.add(new BasicNameValuePair("account", yidunConfig.getUserAccount() + "_" + uid));

		// param.add(new BasicNameValuePair("callback", SECRETID));

		/* 生成签名信息 */
		String signature = SignatureUtils.genSignature(yidunConfig.getSecretKey(), paramToMap(param));

		param.add(new BasicNameValuePair("signature", signature));

		/* 发送请求 */
		String response = fetcher.posts(yidunConfig.getApiUrlText(), param);
		if(StringUtils.isBlank(response)){
			logger.error("请求易盾文本审核接口返回为空，content=>" + content + "， productId=>" + productId);
			return null;
		}

		/* 解析接口返回值 */
		Json jsonObject = Json.parse(response);
		if(jsonObject == null){
			logger.error("请求易盾文本审核接口返回值不是JSON，content=>" + response);
			return null;
		}
		
		int code = jsonObject.asObj().intVal("code", 0);

		YidunResult result = new YidunResult();
		if (code == 200) {
            Json resultObject = jsonObject.asObj().val("result");
			int action = resultObject.asObj().intVal("action", 0);
			String taskId = resultObject.asObj().strVal("taskId");
			Json labelArray = resultObject.asObj().val("labels");
			// 不通过的时候:
			if (action == 2 || action == 1) {
				for (int i = 0; i < labelArray.size(); i++) {
					Json jot = labelArray.asArray().val(i);
					int label = jot.asObj().intVal("label", 0);
					result.setLabel(label);
				}
			}
			result.setTaskId(taskId);
			result.setAction(action);
		} else {
			result.setAction(-1);
		}
		return result;
	}
	
	private Map<String, String> paramToMap(List<NameValuePair> params){
		Map<String, String> map = new TreeMap<>();
		for(NameValuePair p : params){
			map.put(p.getName(), p.getValue());
		}
		return map;
	}

}
