package cn.jugame.rent.product.yidun;

import java.io.Serializable;

public class YidunResult implements Serializable{
	private static final long serialVersionUID = 9066309678200220188L;
	/**检测结果 0-通过，1-疑似，2-不通过*/
	private int action;
	/**分类信息*/
	private int label;
	/**易盾的识别任务ID*/
	private String taskId;
	
	public int getAction() {
		return action;
	}
	public void setAction(int action) {
		this.action = action;
	}
	public int getLabel() {
		return label;
	}
	public void setLabel(int label) {
		this.label = label;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("action=>").append(action)
			.append(", label=>").append(label)
			.append(", taskId=>").append(taskId);
		return sb.toString();
	}
}
