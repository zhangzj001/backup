package cn.jugame.rent.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Loggers {
	public static Logger rentLog(){
	    return LoggerFactory.getLogger("rent");
	}
	
	public static Logger luceneLog(){
	    return LoggerFactory.getLogger("lucene");
	}

	public static Logger kefuLog(){
	    return LoggerFactory.getLogger("kefu");
	}

	public static Logger callbackLog(){
	    return LoggerFactory.getLogger("callback");
	}

	public static Logger eventLog(){
	    return LoggerFactory.getLogger("event");
	}
	
	public static Logger yidunLog(){
		return LoggerFactory.getLogger("yidun");
	}

	public static Logger visitLog(){
		return LoggerFactory.getLogger("visit_log");
	}
}
