package cn.jugame.rent.utils;

import com.jfinal.kit.PropKit;

public class DistLocker {

    private String name;
    public DistLocker(String name){
        this.name = name;
    }

    public boolean lock(int seconds){
        int n = seconds;
        while(n-- > 0 && !CacheUtil.add(name, seconds, name + "__lock")){
            Common.sleep(1);
        }
        return n >= 0;
    }

    /**
     * 这个方法仅针对jfinal有效
     * @return
     */
    public boolean lock(){
        return lock(PropKit.getInt("displock.timeout", 30));
    }

    public void unlock(){
        CacheUtil.del(name);
    }

    public boolean await(int seconds){
        while(seconds-- > 0 && CacheUtil.get(name) != null){
            Common.sleep(1);
        }
        return seconds >= 0;
    }

}
