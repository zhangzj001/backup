package cn.jugame.rent.utils;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.impl.APIAccountcenterServiceImpl;
import cn.jugame.service.coupon.api.ICouponServcie;
import cn.jugame.service.coupon.api.impl.APICouponServiceImpl;
import cn.jugame.service.engine.APIEngineServiceImpl;
import cn.jugame.service.engine.IAPIEngineService;
import cn.jugame.service.gameproduct.api.IGameService;
import cn.jugame.service.gameproduct.api.IProductService;
import cn.jugame.service.gameproduct.api.impl.APIGameServiceImpl;
import cn.jugame.service.gameproduct.api.impl.APIProductServiceImpl;
import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;

import java.util.HashMap;
import java.util.Map;

public class PlatformService {

    private String serviceUrl;
    private String caller;
    private String signKey;
    private int timeout;
	private int statEnable;

	private String registUrl;

	/**
	 * 记录配置
	 * @param conf
	 */
    public PlatformService(PlatformServiceConfig conf){
        serviceUrl = conf.getHttpServiceUrl();
        caller = conf.getHttpServiceCaller();
        signKey = conf.getHttpServiceSignkey();
        timeout = conf.getHttpServiceTimeout();
        statEnable = conf.getHttpServiceStatEnable();
        registUrl = conf.getDubboRegistUrl();
    }
    
    private boolean isStart = false;
    private void start(){
    	if(isStart)
    		return;
    	
		VERSIONMAP.put("cn.jugame.order.api.IOrderReadService", "1.0.0");
		VERSIONMAP.put("cn.jugame.shop.api.IShopReadService", "1.1.0");
		VERSIONMAP.put("cn.jugame.redenvelope.api.IRedEnvelopeService", "1.0.3");
		VERSIONMAP.put("cn.jugame.account_center.api.IAccountCenterService", "1.1.2");
		VERSIONMAP.put("cn.jugame.dic.api.IDictionaryService", "1.0.0");
		VERSIONMAP.put("cn.jugame.service.gameproduct.api.IGameService", "1.0.0");
		VERSIONMAP.put("cn.jugame.service.gameproduct.api.IProductService", "1.0.0");
		VERSIONMAP.put("cn.jugame.gift.api.IAppGiftService", "3.5.0");
		VERSIONMAP.put("cn.jugame.order.api.IOrderOperateService", "1.0.0");
		VERSIONMAP.put("cn.juhaowan.custserver.service.api.ILocalKefuService", "1.0.0");
		
		application.setName("RENT");
		registry.setTimeout(50000);
		//注册中心地址
		registry.setAddress(registUrl);
		
		isStart = true;
    }

	private final Map<String, String> VERSIONMAP = new HashMap<String, String>();
	private ApplicationConfig application = new ApplicationConfig();
	private RegistryConfig registry = new RegistryConfig();
	private Map<String, Object> HttpServiceCache = new HashMap<String, Object>();
	
	public <T> T get(Class<? extends T> clazz){
		//确保运行起来了
		start();
		
		if(clazz.getName().equals("cn.jugame.service.gameproduct.api.IProductService")){
			return (T) getProductService();
		}else if(clazz.getName().equals("cn.jugame.service.gameproduct.api.IGameService")){
			return (T) getGameService();
		}else if(clazz.getName().equals("cn.jugame.account_center.api.IAccountCenterService")){
			return (T) getAccountCenterService();
		}else if(clazz.getName().equals("cn.jugame.service.engine.IAPIEngineService")){
			return (T) getAPIEngineService();
		}else if(clazz.getName().equals("cn.jugame.service.coupon.api.ICouponServcie")){
			return (T) getCouponService();
		}else{
			return createService(clazz, VERSIONMAP.get(clazz.getName()));
		}
	}
	
	private <T> T createService(Class<? extends T> clazz, String version){
		ReferenceConfigCache cache = ReferenceConfigCache.getCache();
    	ReferenceConfig<T> reference = new ReferenceConfig<T>(); // 此实例很重，封装了与注册中心的连接以及与提供者的连接，请自行缓存，否则可能造成内存和连接泄漏
    	reference.setTimeout(50000);
    	reference.setApplication(application);
    	reference.setRegistry(registry); // 多个注册中心可以用setRegistries()
    	reference.setInterface(clazz);
    	reference.setVersion(version);
    	T service = cache.get(reference);
		return service;
	}
	
	private IGameService getGameService(){
		IGameService gameService = (IGameService) HttpServiceCache.get("game_service");
		if(gameService == null){
			gameService = new APIGameServiceImpl(serviceUrl, timeout, statEnable, caller, signKey);
			HttpServiceCache.put("game_service", gameService);
		}
		return gameService;
	}
	
	private IProductService getProductService(){
		IProductService productService = (IProductService) HttpServiceCache.get("product_service");
		if(productService == null){
			productService = new APIProductServiceImpl(serviceUrl, timeout, statEnable, caller, signKey);
			HttpServiceCache.put("product_service", productService);
		}
		return productService;
	}
	
	private IAccountCenterService getAccountCenterService(){
		IAccountCenterService accountCenterService = (IAccountCenterService) HttpServiceCache.get("account_center_service");
		if(accountCenterService == null){
			accountCenterService = new APIAccountcenterServiceImpl(serviceUrl, timeout, statEnable, caller, signKey);
			HttpServiceCache.put("account_center_service", accountCenterService);
		}
		return accountCenterService;
	}
	
	private IAPIEngineService getAPIEngineService(){
		IAPIEngineService apiEngineService = (IAPIEngineService) HttpServiceCache.get("api_engine_service");
		if(apiEngineService == null){
			apiEngineService = new APIEngineServiceImpl(serviceUrl, timeout, statEnable, caller, signKey);
			HttpServiceCache.put("api_engine_service", apiEngineService);
		}
		return apiEngineService;
	}
	
	private ICouponServcie getCouponService(){
		ICouponServcie couponService = (ICouponServcie) HttpServiceCache.get("api_coupon_service");
		if(couponService == null){
			couponService = new APICouponServiceImpl(serviceUrl, timeout, statEnable, caller, signKey);
			HttpServiceCache.put("api_coupon_service", couponService);
		}
		return couponService;
	}
}
