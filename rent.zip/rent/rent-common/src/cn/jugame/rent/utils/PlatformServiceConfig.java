package cn.jugame.rent.utils;

public class PlatformServiceConfig {
    private String httpServiceUrl;
    private String httpServiceCaller;
    private String httpServiceSignkey;
    private int httpServiceTimeout;
    private int httpServiceStatEnable;

    private String dubboRegistUrl;

    public String getHttpServiceUrl() {
        return httpServiceUrl;
    }

    public void setHttpServiceUrl(String httpServiceUrl) {
        this.httpServiceUrl = httpServiceUrl;
    }

    public String getHttpServiceCaller() {
        return httpServiceCaller;
    }

    public void setHttpServiceCaller(String httpServiceCaller) {
        this.httpServiceCaller = httpServiceCaller;
    }

    public String getHttpServiceSignkey() {
        return httpServiceSignkey;
    }

    public void setHttpServiceSignkey(String httpServiceSignkey) {
        this.httpServiceSignkey = httpServiceSignkey;
    }

    public int getHttpServiceTimeout() {
        return httpServiceTimeout;
    }

    public void setHttpServiceTimeout(int httpServiceTimeout) {
        this.httpServiceTimeout = httpServiceTimeout;
    }

    public int getHttpServiceStatEnable() {
        return httpServiceStatEnable;
    }

    public void setHttpServiceStatEnable(int httpServiceStatEnable) {
        this.httpServiceStatEnable = httpServiceStatEnable;
    }

    public String getDubboRegistUrl() {
        return dubboRegistUrl;
    }

    public void setDubboRegistUrl(String dubboRegistUrl) {
        this.dubboRegistUrl = dubboRegistUrl;
    }
}
