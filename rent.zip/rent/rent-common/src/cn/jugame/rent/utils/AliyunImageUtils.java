package cn.jugame.rent.utils;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.ServiceException;
import com.aliyun.oss.common.auth.CredentialsProvider;
import com.aliyun.oss.common.auth.DefaultCredentialProvider;
import com.aliyun.oss.model.PutObjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class AliyunImageUtils {
    private static String endpoint;
    
    private static String accessKeyId;
    
    private static String accessKeySecret;
    
    private static String bucket;
    
    private static String imgEndpoint;
    
    private static OSSClient oss = null;
    
    private static Logger logger = LoggerFactory.getLogger(AliyunImageUtils.class);

    public static class AliyunConfig{
        private String endpoint;
        private String accessKeyId;
        private String accessKeySecret;
        private String bucket;
        private String imgEndpoint;

        public String getEndpoint() {
            return endpoint;
        }

        public void setEndpoint(String endpoint) {
            this.endpoint = endpoint;
        }

        public String getAccessKeyId() {
            return accessKeyId;
        }

        public void setAccessKeyId(String accessKeyId) {
            this.accessKeyId = accessKeyId;
        }

        public String getAccessKeySecret() {
            return accessKeySecret;
        }

        public void setAccessKeySecret(String accessKeySecret) {
            this.accessKeySecret = accessKeySecret;
        }

        public String getBucket() {
            return bucket;
        }

        public void setBucket(String bucket) {
            this.bucket = bucket;
        }

        public String getImgEndpoint() {
            return imgEndpoint;
        }

        public void setImgEndpoint(String imgEndpoint) {
            this.imgEndpoint = imgEndpoint;
        }
    }

    public static void init(AliyunConfig conf) {
        endpoint = conf.getEndpoint();
        accessKeyId = conf.getAccessKeyId();
        accessKeySecret = conf.getAccessKeySecret();
        bucket = conf.getBucket();
        imgEndpoint = conf.getImgEndpoint();

        logger.info("accessKeyId => " + accessKeyId);
        logger.info("accessKeySecret => " + accessKeySecret);
        logger.info("imgEndpoint => " + imgEndpoint);
        
        CredentialsProvider cprodiver = new DefaultCredentialProvider(accessKeyId, accessKeySecret);
        oss = new OSSClient(endpoint, cprodiver);
    }
    
    
    /**
     * @param key，格式为： orderid或者productid + '/' + 时间戳精确到毫秒 + '.jpg'
     * @param data
     * @return
     */
    public static boolean uploadFile(String key, byte[] data) {
        if(oss == null) {
            logger.error("oss is null, uploadFile failed");
            return false;
        }
        
        PutObjectRequest putReq = new PutObjectRequest(bucket, key, new ByteArrayInputStream(data));
        try {
        	oss.putObject(putReq);
            logger.error("key: " + key + ", upload ok");
            return true;
        } catch(ClientException e) {
        	logger.error("uploadFile error", e);
        } catch(ServiceException e) {
        	logger.error("uploadFile error", e);
        }
        
        return false;
    }
    
    public static boolean uploadFile(String key, File file){
    	if(oss == null) {
            logger.error("oss is null, uploadFile failed");
            return false;
        }
        
        try {
        	PutObjectRequest putReq = new PutObjectRequest(bucket, key, new FileInputStream(file));
        	oss.putObject(putReq);
            logger.error("key: " + key + ", upload ok");
            return true;
        }catch(FileNotFoundException e){
        	logger.error("uploadFile error", e);
        }catch(ClientException e) {
        	logger.error("uploadFile error", e);
        } catch(ServiceException e) {
        	logger.error("uploadFile error", e);
        }
        
        return false;
    }
    
    /**
     * @param key, 上传时使用的KEY
     * @param sizeRate 30-100。 100是原图，图片大小缩放比例
     * @param qualityRate 10-100, jpeg图片质量
     * @return
     */
    public static String getUploadedImgUrl(String key, int sizeRate, int qualityRate) {
        return "https://" + imgEndpoint + "/" + key 
        		+ "?x-oss-process=style/watermark.jpg";
    }
    
    public static String getUploadedImgUrl(String key) {
    	return getUploadedImgUrl(key, 100, 70);
    }
    
}
