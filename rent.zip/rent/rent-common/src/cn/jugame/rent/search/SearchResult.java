package cn.jugame.rent.search;

import cn.j8.json.Json;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SearchResult implements Serializable{
	private static final long serialVersionUID = -7602502953255075074L;
	
	private int code;
	private String msg;
	private int totalCount;
	private List<String> productIds = new ArrayList<>();
	private int offset;
	private int limit;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public List<String> getProductIds() {
		return productIds;
	}
	public void addProductId(String productId){
		productIds.add(productId);
	}
	public void setProductIds(List<String> productIds){
		this.productIds = productIds;
	}
	
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}

	public static SearchResult from(Json json){
	    if(json == null)
	        return null;
	    SearchResult s = new SearchResult();
        s.setCode(json.asObj().intVal("code"));
        s.setMsg(json.asObj().strVal("msg"));
        s.setTotalCount(json.asObj().intVal("totalCount"));
        Json pIds = json.asObj().val("productIds");
        if(pIds != null) {
            for (int i = 0; i < pIds.size(); ++i) {
                s.addProductId(pIds.asArray().strVal(i));
            }
        }
        s.setOffset(json.asObj().intVal("offset"));
        s.setLimit(json.asObj().intVal("limit"));
        return s;
    }
}
