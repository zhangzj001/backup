package cn.jugame.rent.search;

import cn.j8.json.Json;
import cn.j8.json.JsonArray;
import cn.j8.json.JsonObj;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**
 * 搜索条件
 *
 * @author zimT_T
 */
public class SearchTerm implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(SearchTerm.class);
    private static final long serialVersionUID = -3455544627245796346L;

    private String keyword;
    private String gameId;
    private String channelId;
    private String partitionId;
    private int productType;
    private int status;
    private int sellerUid;
    private int[] sellLevel;
    private int hasSellerGuarantee = -1;
    private int isPromoteProduct;
    private int gameLoginType;
    private int minPriceHour;
    private int maxPriceHour;
    private int isRecommendProduct;
    private int supportType;

    //排序字段
    private SortTerm[] sortTerms;

    //获取偏移和数量
    private int offset = 0;
    private int limit = 10;

    public String getKeyword() {
        return keyword;
    }

    public SearchTerm setKeyword(String keyword) {
        this.keyword = keyword;
        return this;
    }

    public String getGameId() {
        return gameId;
    }

    public SearchTerm setGameId(String gameId) {
        this.gameId = gameId;
        return this;
    }

    public String getChannelId() {
        return channelId;
    }

    public SearchTerm setChannelId(String channelId) {
        this.channelId = channelId;
        return this;
    }

    public String getPartitionId() {
        return partitionId;
    }

    public SearchTerm setPartitionId(String partitionId) {
        this.partitionId = partitionId;
        return this;
    }

    public int getProductType() {
        return productType;
    }

    public SearchTerm setProductTeyp(int productType) {
        this.productType = productType;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public SearchTerm setStatus(int status) {
        this.status = status;
        return this;
    }

    public int getSellerUid() {
        return sellerUid;
    }

    public SearchTerm setSellerUid(int sellerUid) {
        this.sellerUid = sellerUid;
        return this;
    }

    public SortTerm[] getSortTerms() {
        return sortTerms;
    }

    public SearchTerm setSortTerms(SortTerm[] sortFields) {
        this.sortTerms = sortFields;
        return this;
    }

    public SearchTerm setSellLevel(int[] sellLevel) {
        this.sellLevel = sellLevel;
        return this;
    }

    public int[] getSellLevel() {
        return sellLevel;
    }

    public int getHasSellerGuarantee() {
        return hasSellerGuarantee;
    }

    public SearchTerm setHasSellerGuarantee(int hasSellerGuarantee) {
        this.hasSellerGuarantee = hasSellerGuarantee;
        return this;
    }

    public int getIsPromoteProduct() {
        return isPromoteProduct;
    }

    public SearchTerm setIsPromoteProduct(int isPromoteProduct) {
        this.isPromoteProduct = isPromoteProduct;
        return this;
    }

    public SearchTerm setProductType(int productType) {
        this.productType = productType;
        return this;
    }

    public int getGameLoginType() {
        return gameLoginType;
    }

    public SearchTerm setGameLoginType(int gameLoginType) {
        this.gameLoginType = gameLoginType;
        return this;
    }

    public int getMinPriceHour() {
        return minPriceHour;
    }

    public SearchTerm setMinPriceHour(int minPriceHour) {
        this.minPriceHour = minPriceHour;
        return this;
    }

    public int getMaxPriceHour() {
        return maxPriceHour;
    }

    public SearchTerm setMaxPriceHour(int maxPriceHour) {
        this.maxPriceHour = maxPriceHour;
        return this;
    }

    public int getIsRecommendProduct() {
        return isRecommendProduct;
    }

    public SearchTerm setIsRecommendProduct(int isRecommendProduct) {
        this.isRecommendProduct = isRecommendProduct;
        return this;
    }

    public int getSupportType() {
        return supportType;
    }

    public SearchTerm setSupportType(int supportType) {
        this.supportType = supportType;
        return this;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    /**
     * 是否有搜索条件，如果全部搜索条件都是空则返回true
     *
     * @return
     */
    public boolean isEmpty() {
        return StringUtils.isBlank(keyword);
    }

    public Json toJson() {
        JsonObj filter = Json.object().asObj();
        if(StringUtils.isNotBlank(keyword)){
            filter.put("keyword", keyword);
        }
        if (StringUtils.isNotBlank(gameId)) {
            filter.put("gameId", gameId);
        }
        if (StringUtils.isNotBlank(channelId)) {
            filter.put("channelId", channelId);
        }
        if (StringUtils.isNotBlank(partitionId)) {
            filter.put("partitionId", partitionId);
        }
        if (productType > 0) {
            filter.put("productType", productType);
        }
        if (status > 0) {
            filter.put("status", status);
        }
        if (sellerUid > 0) {
            filter.put("sellerUid", sellerUid);
        }
        if (sellLevel != null) {
            Json ar = Json.array();
            for(int sl : sellLevel){
                ar.asArray().add(sl);
            }
            filter.put("sellLevel", ar);
        }
        if (hasSellerGuarantee >= 0) {
            filter.put("hasSellerGuarantee", hasSellerGuarantee);
        }
        if (isPromoteProduct >= 0) {
            filter.put("isPromoteProduct", isPromoteProduct);
        }
        if (gameLoginType > 0) {
            filter.put("gameLoginType", gameLoginType);
        }
        if (minPriceHour >= 0) {
            filter.put("minPriceHour", minPriceHour);
        }
        if (maxPriceHour >= 0) {
            filter.put("maxPriceHour", maxPriceHour);
        }
        if (isRecommendProduct > 0) {
            filter.put("isRecommendProduct", isRecommendProduct);
        }
        if (supportType >= 0) {
            filter.put("supportType", supportType);
        }
        if(sortTerms != null){
            Json ar = Json.array();
            for(SortTerm st : sortTerms){
                ar.asArray().add(st.toJson());
            }
            filter.put("sortTerms", ar);
        }

        filter.put("offset", offset);
        filter.put("limit", limit);
        return filter;
    }

    public static SearchTerm fromJson(String termJson){
        Json json = Json.parse(termJson);
        if(json == null)
            return null;

        SearchTerm searchTerm = new SearchTerm();
        searchTerm.keyword = json.asObj().val("keyword");
        searchTerm.gameId = json.asObj().val("gameId");
        searchTerm.channelId = json.asObj().val("channelId");
        searchTerm.partitionId = json.asObj().val("partitionId");
        searchTerm.productType = json.asObj().intVal("productType");
        searchTerm.status = json.asObj().intVal("status");
        searchTerm.sellerUid = json.asObj().intVal("sellerUid");

        Json sellLevelArr = json.asObj().val("sellLevel");
        if(sellLevelArr != null){
            searchTerm.sellLevel = new int[sellLevelArr.size()];
            for(int i=0; i<searchTerm.sellLevel.length; ++i){
                searchTerm.sellLevel[i] = sellLevelArr.asArray().val(i);
            }
        }

        searchTerm.hasSellerGuarantee = json.asObj().intVal("hasSellerGuarantee", -1);
        searchTerm.isPromoteProduct = json.asObj().intVal("isPromoteProduct");
        searchTerm.gameLoginType = json.asObj().intVal("gameLoginType");
        searchTerm.minPriceHour = json.asObj().intVal("minPriceHour");
        searchTerm.maxPriceHour = json.asObj().intVal("maxPriceHour");
        searchTerm.isRecommendProduct = json.asObj().intVal("isRecommendProduct");
        searchTerm.supportType = json.asObj().intVal("supportType");
        searchTerm.offset = json.asObj().intVal("offset");
        searchTerm.limit = json.asObj().intVal("limit");

        //排序字段
        Json sortTerms = json.asObj().val("sortTerms");
        if(sortTerms != null){
            searchTerm.sortTerms = new SortTerm[sortTerms.size()];
            for(int i=0; i<searchTerm.sortTerms.length; ++i){
                Json sortTerm = sortTerms.asArray().val(i);
                searchTerm.sortTerms[i] = new SortTerm(sortTerm.asObj().val("fieldName"), sortTerm.asObj().val("reverse"));
            }
        }
        return searchTerm;
    }

}
