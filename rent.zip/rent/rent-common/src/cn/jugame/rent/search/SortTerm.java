package cn.jugame.rent.search;

import cn.j8.json.Json;

import java.io.Serializable;

public class SortTerm implements Serializable{
	private static final long serialVersionUID = 1734829092648414744L;
	
	private String fieldName;
	private boolean reverse;
	
	public SortTerm(String fieldName, boolean reverse){
		this.fieldName = fieldName;
		this.reverse = reverse;
	}
	
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public boolean isReverse() {
		return reverse;
	}
	public void setReverse(boolean reverse) {
		this.reverse = reverse;
	}

	public Json toJson(){
	    return Json.object("fieldName", fieldName, "reverse", reverse);
    }
}
