package cn.jugame;

/**
 * 因为是调用jni的，请勿移动该类到其它包下！
 * @author ASUS
 *
 */
public class M2 {
	static{
		System.loadLibrary("jgm2");
		if(!init()){
			throw new RuntimeException("jgm2初始化失败");
		}
	}
	
	public static native boolean init();
	private static native byte[] encode(byte[] src);
	private static native byte[] decode(byte[] src);

	public static byte[] encodeBytes(byte[] src){
	    synchronized (M2.class){
	        return encode(src);
        }
    }

    public static byte[] decodeBytes(byte[] src){
	    synchronized (M2.class){
	        return decode(src);
        }
    }

	public static void main(String[] args) throws Exception{
		if(!init()){
			System.out.println("fuck!!");
			return;
		}
		
		String s = "abcdefg";
		byte[] src = s.getBytes("UTF-8");
		System.out.println("加密前字节长度：" + src.length);
		byte[] dest = encode(src);
		System.out.println("加密后字节长度：" + dest.length);
		src = decode(dest);
		System.out.println("解密后：" + new String(src, "UTF-8") + ", 字节长度：" + src.length);
	}
}
