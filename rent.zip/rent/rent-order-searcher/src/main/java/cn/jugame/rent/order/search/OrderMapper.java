package cn.jugame.rent.order.search;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface OrderMapper {
    /** 新建状态 */
    public final static int ORDER_STATUS_NEW = 0;

    /** 支付中（续租时使用） */
    public final static int ORDER_STATUS_PAYING = 100;

    /** 已支付/已出租 */
    public final static int ORDER_STATUS_PAID = 2;

    /** 订单完成 */
    public final static int ORDER_STATUS_FINISH = 6;

    /** 订单取消 */
    public final static int ORDER_STATUS_CANCEL = 8;

    /** 订单已支付 */
    public final static int ORDER_PAID = 1;

    @Select("select * from `order` where `order_status` in (" + ORDER_STATUS_FINISH + ", " + ORDER_STATUS_CANCEL + ") and `order_ispay`=" + ORDER_PAID + " and id>=#{startId} order by `id` asc limit #{limit}")
    List<OrderEntity> getOrders(int startId, int limit);

}
