package cn.jugame.rent.order.search;

import cn.j8.consul.KvStore;
import cn.j8.es.MappingBuilder;
import cn.j8.json.Json;
import cn.jugame.rent.order.AppConfig;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.rest.RestStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class Indexer {
    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private AppConfig appConfig;

    @Autowired
    @Qualifier("restHighLevelClient")
    private RestHighLevelClient client;

    /**
     * 创建索引
     * @return
     * @throws IOException
     */
    public boolean createIndice() throws IOException {
        CreateIndexRequest createIndexRequest = new CreateIndexRequest("rent_order");
        Json properties = MappingBuilder.properties(OrderEntity.class);
        Json mappings = Json.object("properties", properties);
        createIndexRequest.mapping(mappings.toString(), XContentType.JSON);
        CreateIndexResponse resp = client.indices().create(createIndexRequest, RequestOptions.DEFAULT);
        return resp.isAcknowledged();
    }

    public void indexAll() throws IOException{
        String key = "rent-searcher/indice_curr_id";
        KvStore kv = new KvStore(appConfig.getConsulHost() + ":" + appConfig.getConsulPort());
        String currId = kv.getOne(key);
        int startId = -1;
        if(StringUtils.isNotBlank(currId))
            startId = Integer.valueOf(currId);

        List<OrderEntity> orders = orderMapper.getOrders(++startId, 1000);

        BulkRequest request = new BulkRequest();
        for(int i=0; i<orders.size(); ++i){
            OrderEntity order = orders.get(i);
            XContentBuilder builder = MappingBuilder.data(order);
            request.add(new IndexRequest("rent_order").id(order.getOrderId()).source(builder));

            if(order.getId() > startId)
                startId = order.getId();
        }

        BulkResponse bulkResp = client.bulk(request, RequestOptions.DEFAULT);
        bulkResp.getItems();

        //更新这个id
        kv.set(key, String.valueOf(startId));
    }

    public String indexOne(OrderEntity order) throws IOException{
        XContentBuilder builder = MappingBuilder.data(order);
        IndexRequest request = new IndexRequest("rent_order")
                .id(order.getOrderId())
                .source(builder);
        IndexResponse resp = client.index(request, RequestOptions.DEFAULT);
        return resp.getId();
    }
}
