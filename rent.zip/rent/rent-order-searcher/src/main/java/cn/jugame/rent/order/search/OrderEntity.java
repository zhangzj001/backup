package cn.jugame.rent.order.search;

import cn.j8.es.MappingField;
import lombok.Data;

import java.util.Date;

@Data
public class OrderEntity {
    private int id;

    @MappingField(type = "keyword")
    private String orderId;
    @MappingField(type = "integer")
    private int orderStatus;
    @MappingField(type = "date", format = "yyyy-MM-dd HH:mm:ss")
    private Date orderFinishTime;
    @MappingField(type = "integer")
    private int buyuserUid;
    @MappingField(type = "integer")
    private int selluserUid;
    @MappingField(type = "keyword")
    private String gameId;
    @MappingField(type = "text", analyzer = "ik_max_word", search_analyzer = "ik_max_word")
    private String gameName;
    @MappingField(type = "integer")
    private int orderAmount;
    @MappingField(type = "integer")
    private int orderPayAmount;
    @MappingField(type = "integer")
    private int amountOff;
    @MappingField(type = "keyword")
    private String productId;
    @MappingField(type = "text", analyzer = "ik_max_word", search_analyzer = "ik_max_word")
    private String productName;
}
