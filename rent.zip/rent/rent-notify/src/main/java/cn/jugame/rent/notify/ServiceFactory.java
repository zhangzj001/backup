package cn.jugame.rent.notify;

import cn.jugame.rent.utils.PlatformService;
import cn.jugame.rent.utils.PlatformServiceConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceFactory {
    @Value("${app.dubbo.regist_url}")
    private String dubboRegistUrl;

    @Value("${app.http_service.caller}")
    private String httpServiceCaller;

    @Value("${app.http_service.signkey}")
    private String httpServiceSignKey;

    @Value("${app.http_service.stat_enable}")
    private int httpServiceStatEnable;

    @Value("${app.http_service.timeout}")
    private int httpServiceTimeout;

    @Value("${app.http_service.url}")
    private String httpServiceUrl;

    @Bean
    public PlatformService platformService(){
        PlatformServiceConfig psConf = new PlatformServiceConfig();
        psConf.setDubboRegistUrl(dubboRegistUrl);
        psConf.setHttpServiceCaller(httpServiceCaller);
        psConf.setHttpServiceSignkey(httpServiceSignKey);
        psConf.setHttpServiceStatEnable(httpServiceStatEnable);
        psConf.setHttpServiceTimeout(httpServiceTimeout);
        psConf.setHttpServiceUrl(httpServiceUrl);

        return new PlatformService(psConf);
    }
}
