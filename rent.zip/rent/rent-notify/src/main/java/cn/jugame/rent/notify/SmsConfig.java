package cn.jugame.rent.notify;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Data
public class SmsConfig {
    @Value("${app.sms.code.SMS_2017061502}")
    private String SMS_2017061502;

    @Value("${app.sms.code.SMS_2017061503}")
    private String SMS_2017061503;

    @Value("${app.sms.code.SMS_20170704}")
    private String SMS_20170704;

    @Value("${app.sms.code.SMS_20170728}")
    private String SMS_20170728;

    @Value("${app.sms.code.SMS_20170809}")
    private String SMS_20170809;

    @Value("${app.sms.code.SMS_20170814}")
    private String SMS_20170814;

    @Value("${app.sms.code.SMS_20171017}")
    private String SMS_20171017;

    @Value("${app.sms.code.SMS_20171018}")
    private String SMS_20171018;

    @Value("${app.sms.code.SMS_2018012302}")
    private String SMS_2018012302;

    @Value("${app.sms.code.SMS_2018012303}")
    private String SMS_2018012303;

    @Value("${app.sms.code.SMS_2018012301}")
    private String SMS_2018012301;

    @Value("${app.sms.code.SMS_2019062701}")
    private String SMS_2019062701;

    @Value("${app.sms.code.SMS_2019062702}")
    private String SMS_2019062702;

    @Value("${app.sms.code.SMS_20181123}")
    private String SMS_20181123;
}
