package cn.jugame.rent.notify;

import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.KeyValue;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.URLConnectionHttpFetcher;
import cn.jugame.service.common.util.cipher.DES;
import cn.jugame.util.helper.misc.ChecksumHelper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 通知工具类
 */
@Service
class Notifier {
    private URLConnectionHttpFetcher fetcher = new URLConnectionHttpFetcher();
    private Logger logger = Loggers.rentLog();

    @Value("${app.wx.message_key}")
    private String wxMessageKey;

    @Value("${app.wx.send_message_url}")
    private String wxUrl;

    @Value("${app.sms.app_key}")
    private String smsAppKey;

    @Value("${app.sms.secret_key}")
    private String smsSecretKey;

    @Value("${app.sms.url}")
    private String smsUrl;

    @Autowired
    private WxOpenId wxOpenId;

    /**
     * 暂时设置为public！！还有一大堆重构的东西。。
     *
     * @param uid
     * @param wxTmplId
     * @param linkUrl
     * @param params
     * @return
     */
    boolean sendWx(int uid, String wxTmplId, String linkUrl, List<WxTmplParam> params) {
        String openId = wxOpenId.get(uid);
        if (StringUtils.isBlank(openId)) {
            return false;
        }

        long nowDate = System.currentTimeMillis();
        String time = Long.toString(nowDate);

        // 接口业务数据
        JSONObject json = new JSONObject();
        json.put("template_id", wxTmplId);
        json.put("open_id", openId);
        json.put("weixin_unique", "ser");
        json.put("url", linkUrl);
        JSONArray myData = new JSONArray();
        for (WxTmplParam param : params) {
            JSONObject paramInfo = new JSONObject();
            paramInfo.put("key", param.getKey());
            paramInfo.put("value", param.getValue());
            paramInfo.put("color", param.getColor());
            myData.add(paramInfo);
        }
        json.put("data", myData);
        try {
            String dataStr = DES.encode(json.toString(), wxMessageKey);
            String sign = Common.md5(json.toString() + time + wxMessageKey).substring(0, 8);
            Map<String, String> m = new HashMap<String, String>();
            m.put("cmd", "send_temp_msg");// 接口标识（由接口方提供）
            m.put("data", dataStr);
            m.put("sign", sign);
            m.put("time", time);// 时间戳
            m.put("pid", "rent_service");// 接口业务系统标识（由接口方提供）
            String param = Common.http_build_query(new KeyValue[]{
                    new KeyValue("cmd", "send_temp_msg"),
                    new KeyValue("data", dataStr),
                    new KeyValue("sign", sign),
                    new KeyValue("time", time),
                    new KeyValue("pid", "rent_service")
            });
            String result = fetcher.gets(wxUrl + "?" + param);
            try {
                JSONObject responseInfo = JSONObject.fromObject(result);
                if (responseInfo.optInt("code", -1) == 0) {
                    return true;
                }
                logger.error("微信通知用户【" + openId + "】失败，result=>" + result + ", openId=>" + openId + ", template_id=>" + wxTmplId + ", template_data=>" + myData.toString());
                return false;
            } catch (Exception e) {
                logger.error("微信通知用户【" + openId + "】发生了异常", e.getMessage());
                return false;
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return true;
    }

    /**
     * 短信通知，走短信服务，需要根据配置的消息模板来设置消息内容
     *
     * @param mobile
     * @param smsId
     * @param smsParams
     * @return
     */
    boolean sendSms(String mobile, String smsId, JSONObject smsParams) {
        String appKey = smsAppKey;
        String signName = "8868交易平台";//还TM就必须是这个signName，大鱼那边就是这么规定的！

        Map<String, String> params = new TreeMap<String, String>();
        params.put("appKey", appKey);
        params.put("signName", signName);
        params.put("smsId", smsId);
        params.put("mobile", mobile);
        //短信内容参数
        params.put("smsParam", smsParams.toString());

        String vcode = ChecksumHelper.getChecksum(params, smsSecretKey);
        String url = smsUrl + "?" + Common.http_build_query(new KeyValue[]{
                new KeyValue<>("appKey", appKey),
                new KeyValue<>("signName", signName),
                new KeyValue<>("smsId", smsId),
                new KeyValue<>("mobile", mobile),
                new KeyValue<>("smsParam", smsParams.toString()),
                new KeyValue<>("vcode", vcode)
        });
        String response = fetcher.gets(url);
        if (StringUtils.isBlank(response)) {
            logger.error("调用短信服务返回空，mobile=>" + mobile + ", smsId=>" + smsId + ", smsParams=>" + smsParams);
            return false;
        }
        try {
            JSONObject res = JSONObject.fromObject(response);
            if (res.getInt("code") != 0) {
                logger.error("调用短信服务返回错误，response=>" + response);
                return false;
            }
            return true;
        } catch (Exception e) {
            logger.error("error", e);
            return false;
        }
    }
}