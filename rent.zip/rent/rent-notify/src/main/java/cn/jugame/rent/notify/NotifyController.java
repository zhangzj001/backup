package cn.jugame.rent.notify;

import cn.j8.json.Json;
import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.Member;
import cn.jugame.rent.notify.db.OrderEntity;
import cn.jugame.rent.notify.db.OrderMapper;
import cn.jugame.rent.notify.db.ProductEntity;
import cn.jugame.rent.notify.db.ProductMapper;
import cn.jugame.rent.utils.Common;
import cn.jugame.rent.utils.PlatformService;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * 消息通知服务
 */
@RestController
@RequestMapping("/notify")
public class NotifyController {
    @Value("${app.remind.seller_url}")
    private String remindSellerUrl;

    @Value("${app.remind.buyer_url}")
    private String remindBuyerUrl;

    @Value("${app.rent_service_host}")
    private String rentServiceHost;

    @Value("${app.wx.recommend_success_tmpl_id}")
    private String wxRecommendSuccessTmplId;

    @Value("${app.wx.user_level_change_tmpl_id}")
    private String wxUserLevelChangeTmplId;

    @Value("${app.remind.seller_level_change_url}")
    private String remindSellerLevelChangeUrl;

    @Value("${app.product.cdk_warning_count}")
    private int productCdkWarningCount;

    @Value("${app.wx.order_tmpl_id}")
    private String wxOrderTmplId;

    private Logger logger = LoggerFactory.getLogger(NotifyController.class);

    @Autowired
    private JPushs jPushs;

    @Autowired
    private PlatformService platformService;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private Notifier notifier;

    @Autowired
    private SmsConfig smsConfig;

    private void _sendWxMessage(int uid, OrderWxMessage wxMessage) {
        List<WxTmplParam> wxParams = new ArrayList<>();
        wxParams.add(new WxTmplParam("keyword1", wxMessage.getOrderId()));
        wxParams.add(new WxTmplParam("keyword2", wxMessage.getOrderPayAmount()));
        wxParams.add(new WxTmplParam("keyword3", wxMessage.getProductName()));
        wxParams.add(new WxTmplParam("first", wxMessage.getBrief()));
        wxParams.add(new WxTmplParam("remark", wxMessage.getContent()));
        if (!notifier.sendWx(uid, wxOrderTmplId, wxMessage.getLinkUrl(), wxParams)) {
            logger.error("订单【" + wxMessage.getOrderId() + "】买家微信通知号主失败了！");
        }
    }

    private void _sendJpushMsg(int uid, OrderJpushMessage jpushMessage) {
        jPushs.pushComMsg(uid, jpushMessage.getTitle(), jpushMessage.getToastBrief(), jpushMessage.getLinkUrl());
    }

//    @RequestMapping("/test")
//    public void test(){
//        List<WxTmplParam> wxParams = new ArrayList<>();
//        wxParams.add(new WxTmplParam("keyword1", "test-order-id"));
//        wxParams.add(new WxTmplParam("keyword2", 1));
//        wxParams.add(new WxTmplParam("keyword3", "test-product-name"));
//        wxParams.add(new WxTmplParam("first", "11111111"));
//        wxParams.add(new WxTmplParam("remark", "22222222"));
//        if (!notifier.sendWx(401, wxOrderTmplId, "http://rent.8868test.lo", wxParams)) {
//            logger.error("订单买家微信通知号主失败了！");
//        }
//    }

    private void notifyOrder(OrderEntity order, String brief, String desc, boolean toSeller){
        String orderId = order.getOrderId();
        int uid = toSeller ? order.getSelluserUid() : order.getBuyuserUid();
        String url = (toSeller ? remindSellerUrl: remindBuyerUrl) + orderId;
        double orderPayAmount = Common.round(order.getOrderPayAmount() / 100.0, 2);
        String productName = order.getProductName();

        OrderWxMessage wxMessage = OrderWxMessage.builder()
                .brief(brief)
                .content(desc)
                .linkUrl(url)
                .orderId(orderId)
                .orderPayAmount(orderPayAmount)
                .productName(productName)
                .build();
        _sendWxMessage(uid, wxMessage);

        OrderJpushMessage jpushMessage = OrderJpushMessage.builder()
                .linkUrl(url)
                .title("【8868租号】订单通知")
                .toastBrief(brief)
                .build();
        _sendJpushMsg(uid, jpushMessage);
    }

    private String succ(){
        return Json.object("code", 0, "msg", "ok").toString();
    }
    private String fail(String msg){
        return Json.object("code", 1, "msg", msg).toString();
    }

    /**
     * 发送求助通知给号主
     * @param orderId
     * @param helpReason
     */
    @RequestMapping("/sendHelpMessageToSelluser")
    public String sendHelpMessageToSelluser(@RequestParam String orderId, @RequestParam String helpReason){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String gameName = order.getGameName();
        String mobile = order.getSelluserPhonenum();

        notifyOrder(order,
                "【8868租号】您出租的<" + gameName + ">账号玩家需要您紧急帮助。",
                "帮助说明：" + helpReason + "（若您无法帮助玩家解决，请选择“同意撤单”并尽快修改您的密码。）",
                true);

        //发送短信给号主
        if (StringUtils.isNotBlank(mobile)) {
            JSONObject smsParam = new JSONObject();
            smsParam.put("order_id", orderId);
            smsParam.put("time", "5分钟");

            if (!notifier.sendSms(mobile, smsConfig.getSMS_20171017(), smsParam)) {
                logger.error("订单【" + orderId + "】发送短信通知卖家进行求助处理失败了。");
            }
        }

        return succ();
    }

    /**
     * 发送求助成功的通知给玩家
     * @param orderId
     */
    @RequestMapping("/sendHelpFinishMessageToBuyuser")
    public String sendHelpFinishMessageToBuyuser(@RequestParam String orderId){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String mobile = order.getBuyuserPhonenum();

        notifyOrder(order,
                "【8868租号】号主已完成协助，请前往查看。",
                "号主已完成订单求助。",
                false);

        //发送短信给买家
        if (StringUtils.isNotBlank(mobile)) {
            JSONObject smsParam = new JSONObject();
            smsParam.put("order_id", orderId);
            if (!notifier.sendSms(mobile, smsConfig.getSMS_20171018(), smsParam)) {
                logger.error("订单【" + orderId + "】通知玩家求助完成失败了...");
            }
        }
        return succ();
    }

    /**
     * 发送号主求助超时未响应短信给买家和号主
     * @param orderId
     */
    @RequestMapping("/sendHelpTimeOutMessageToBuyuser")
    public String sendHelpTimeOutMessageToBuyuser(@RequestParam String orderId) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        notifyOrder(order,
                "【8868租号】号主正忙，未能及时协助，系统已为您撤单并退还租金押金。",
                "给您造成不便，敬请谅解！欢迎继续租用平台的其它账号。",
                false);
        return succ();
    }

    /**
     * 发送号主无法协助而同意撤单的通知给玩家
     */
    @RequestMapping("/sendHelpFailMessageToBuyuser")
    public String sendHelpFailMessageToBuyuser(@RequestParam String orderId){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        notifyOrder(order,
                "【8868租号】您的订单因为号主无法提供协助而撤单了。",
                "号主无法提供协助并主动撤销订单，您的租金押金已成功返还到你的余额账户。",
                false
        );
        return succ();
    }

    /**
     * 发送撤单消息给号主
     * @param orderId
     * @param cancelReason
     */
    @RequestMapping("/sendOrderCancelMessageToSelluser")
    public String sendOrderCancelMessageToSelluser(@RequestParam String orderId, @RequestParam String cancelReason){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String gameName = order.getGameName();
        String mobile = order.getSelluserPhonenum();

        notifyOrder(order,
                "【8868租号】您出租的<" + gameName + ">账号已被撤单。撤单原因：" + cancelReason + "，请及时修改密码并重新上架您的租号商品。",
                "为避免影响信誉分，请确保商品信息正确，并及时处理玩家求助。详情请戳>>",
                true);

        if (StringUtils.isNotBlank(mobile)) {
            JSONObject smsParam = new JSONObject();
            smsParam.put("order_id", orderId);
            smsParam.put("time", "5分钟");

            if (!notifier.sendSms(mobile, smsConfig.getSMS_20170704(), smsParam)) {
                logger.error("订单【" + orderId + "】发送短信通知卖家失败了。");
            }
        }
        return succ();
    }

    /**
     * 发送撤单成功消息给玩家
     * @param orderId
     * @param isDelayRefund
     */
    @RequestMapping("/sendOrderCancelMessageToBuyuser")
    public String sendOrderCancelMessageToBuyuser(@RequestParam String orderId, @RequestParam boolean isDelayRefund){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        double orderPayAmount = Common.round(order.getOrderPayAmount() / 100.0, 2);
        String productName = order.getProductName();

        //延迟到账的才需要通知
        if (isDelayRefund) {
            boolean isFreeCancel = order.getIsFreeCancel() == 1;
            String msg = "【8868租号】您的订单" + orderId + "已成功为您撤单，";
            if (isFreeCancel) {
                msg += "在24小时无号主投诉后将租金和押金返还到您的帐户，请耐心等候。";
            } else {
                msg += "已产生的资金将被扣除，剩余资金将在24小时无投诉将退还您的账户，请耐心等候。";
            }

            String mobile = order.getBuyuserPhonenum();

            notifyOrder(order,
                    "【8868租号】您的订单已经成功撤单。",
                     msg,
                    false);

            if (StringUtils.isNotBlank(mobile)) {
                JSONObject smsParam = new JSONObject();
                smsParam.put("order_id", orderId);
                String smsCode = smsConfig.getSMS_2019062701();
                if (isFreeCancel) {
                    smsCode = smsConfig.getSMS_2019062702();
                }
                if (!notifier.sendSms(mobile, smsCode, smsParam)) {
                    logger.error("订单【" + orderId + "】通知玩家失败了...");
                }
            }
        }

        return succ();
    }

    /**
     * 发送下单成功信息
     *
     * @param orderId
     */
    @RequestMapping("/sendAddOrderToSelluser")
    public String sendAddOrderToSelluser(@RequestParam String orderId) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String mobile = order.getSelluserPhonenum();
        String gameName = order.getGameName();

        logger.info("orderId => " + orderId);
        logger.info("mobile => " + mobile);
        logger.info("gameName => " + gameName);

        notifyOrder(order,
                "【8868租号】您的账号已被租用，租期至" + Common.show_time(order.getRentEndTime()),
                "为保证租金正常到账，租赁期间请勿登录账号，若玩家发起求助，请及时处理。",
                true);

        //发送短信给号主
        if (StringUtils.isNotBlank(mobile)) {
            JSONObject smsParam = new JSONObject();
            smsParam.put("gameName", gameName);
            smsParam.put("rentTime", "至" + Common.show_time(order.getRentEndTime()));
            if (!notifier.sendSms(mobile, smsConfig.getSMS_2017061502(), smsParam)) {
                logger.error("订单【" + orderId + "】发送短信通知卖家进行求助处理失败了。");
            }
        }
        return succ();
    }


    /**
     * 发送下单失败信息
     *
     * @param orderId
     */
    @RequestMapping("/sendAddOrderFailToBuyuser")
    public String sendAddOrderFailToBuyuser(@RequestParam String orderId) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        notifyOrder(order,
                "【8868租号】商品被别人抢先租赁了，您的订单自动取消并已将租金/押金退还到您的平台账户，详情请戳>>",
                "欢迎继续租用平台的其它账号。",
                false);

        return succ();
    }

    /**
     * 发送号主停止订单消息给玩家
     *
     * @param orderId
     */
    @RequestMapping("/sendOrderStopToBuyuser")
    public String sendOrderStopToBuyuser(@RequestParam String orderId) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String mobile = order.getBuyuserPhonenum();

        notifyOrder(order,
                "【8868租号】您的订单已被取消（号主停止订单）,剩余租金/押金将在24小时后退还。",
                "如有疑问，请联系客服。详情请戳>>",
                false);

        //发送短信给买家
        if (StringUtils.isNotBlank(mobile)) {
            JSONObject smsParam = new JSONObject();
            smsParam.put("order_id", orderId);
            smsParam.put("cancel_reason", "号主停止订单");
            if (!notifier.sendSms(mobile, smsConfig.getSMS_2018012303(), smsParam)) {
                logger.error("订单【" + orderId + "】通知玩家求助完成失败了...");
            }
        }
        return succ();
    }

    /**
     * 发送仲裁成功信息给玩家
     *
     * @param orderId
     */
    @RequestMapping("/sendArbitrateSuccessToBuyuser")
    public String sendArbitrateSuccessToBuyuser(@RequestParam String orderId) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        double orderPayAmount = Common.round(order.getOrderPayAmount()/ 100.0, 2);
        String productName = order.getProductName();
        int uid = order.getBuyuserUid();

        notifyOrder(order,
                "【8868租号】您在租号期间受到号主举报。",
                "请前往您的订单查看仲裁详情，请戳>>",
                false);
        return succ();
    }

    /**
     * 发送订单完成消息给号主
     * @param orderId
     */
    @RequestMapping("/sendOrderFinishMessageToSelluser")
    public String sendOrderFinishMessageToSelluser(@RequestParam String orderId){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");
        ProductEntity product = productMapper.getProduct(order.getProductId());
        if(product == null)
            return fail("no product");

        String gameName = order.getGameName();
        String mobile = order.getSelluserPhonenum();

        int onsaleProtectTime = product.getOnsaleProtectTime();
        String desc = "为了您的账号安全，明文账号商品请前往修改密码。若您无操作则" + onsaleProtectTime + "小时后系统将自动为您重新上架商品。端游类商品直接上架！";
        if(onsaleProtectTime == 0){
            desc = "您的商品即将上架，为了您的账号安全，明文账号商品请前往修改密码。";
        }
        if(onsaleProtectTime < 0){
            desc = "为了您的账号安全，明文账号商品请前往修改密码并重新上架商品。";
        }

        notifyOrder(order,
                "【8868租号】您出租的<" + gameName + ">账号订单已经到期。",
                desc,
        true);

        //通知卖家租期已结束
        logger.info("订单【" + orderId + "】准备短信通知卖家交易完成..");
        if(StringUtils.isNotBlank(mobile)){
            JSONObject smsParams = new JSONObject();
            smsParams.put("gameName", gameName);
            smsParams.put("protectionTime", onsaleProtectTime);
            if(!notifier.sendSms(mobile, smsConfig.getSMS_2017061503(), smsParams)){
                logger.error("订单交易完成时发送短信给卖家失败了，orderId=>" + orderId);
            }
        }
        return succ();
    }

    /**
     * 发送订单完成消息给玩家
     * @param orderId
     */
    @RequestMapping("/sendOrderFinishMessageToBuyuser")
    public String sendOrderFinishMessageToBuyuser(@RequestParam String orderId){
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String gameName = order.getGameName();

        notifyOrder(order,
                "【8868租号】您租赁的商品<" + gameName + ">租期已到。",
                "如有押金将24小时后退回您的余额。谢谢您的支持！详情请戳>>",
                false);
        return succ();
    }

    /**
     * 发送订单将近结束给玩家
     * @param orderId
     */
    @RequestMapping("/sendOrderNearlyEndMessageToBuyuser")
    public String sendOrderNearlyEndMessageToBuyuser(@RequestParam String orderId) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String gameName = order.getGameName();

        notifyOrder(order,
                "【8868租号】您租用的<" + gameName + ">商品还有半小时结束，进入详情可“续租”畅玩",
                "为了不影响您的畅玩体验，您可续租延长畅玩时间。谢谢您的支持！详情请戳>>",
                false);
        return succ();
    }

    /***
     * 发送商品被推荐通知给号主
     * @param selluserUid
     */
    @RequestMapping("/sendProductRecommendedMessageToSelluser")
    public String sendProductRecommendedMessageToSelluser(@RequestParam int selluserUid) {
        List<WxTmplParam> wxParams = new ArrayList<>();
        wxParams.add(new WxTmplParam("keyword1", "8868平台"));
        wxParams.add(new WxTmplParam("keyword2", getUserName(selluserUid)));
        wxParams.add(new WxTmplParam("first", "【8868租号】恭喜，您上架的商品已被平台设为推荐商品"));
        wxParams.add(new WxTmplParam("remark", "推荐商品在平台可正常交易外，还可享受被其他号主附带为您联合推广外界的权利，推广成交的商品将收取20%手续费作为奖励犒劳推广者，达到双利双赢！【前去了解>】"));
        if (!notifier.sendWx(selluserUid, wxRecommendSuccessTmplId, rentServiceHost, wxParams)) {
            logger.error("用户【" + selluserUid + "】买家微信通知失败了-" + "推荐商品提醒通知失败");
        }

        jPushs.pushComMsg(selluserUid, "【8868租号】推荐商品成功通知", "恭喜，您上架的商品已被平台设为推荐商品，推荐商品在平台可正常交易外，还可享受被其他号主附带为您联合推广外界的权利，推广成交的商品将收取20%手续费作为奖励犒劳推广者，达到双利双赢！【前去了解>】", rentServiceHost);
        return succ();
    }

    /**
     * 发送优惠券到期通知给玩家
     *
     * @param uid
     * @param couponName
     * @return
     */
    @RequestMapping("/sendCouponOutDateRemindMessageToBuyuser")
    public String sendCouponOutDateRemindMessageToBuyuser(@RequestParam int uid, @RequestParam String couponName) {
        jPushs.pushComMsg(uid, "【8868租号】优惠券到时通知", "8868租号：亲爱的玩家，您领取的<" + couponName + ">即将过期，请尽快使用哦。", rentServiceHost + "/coupon/coupons");
        return succ();
    }


    /***
     * 发送第一次撤单申请失败消息给玩家
     * @param orderId
     * @param checkReason
     */
    @RequestMapping("/sendFirstCancelApplyFailMessageToBuyuser")
    public String sendFirstCancelApplyFailMessageToBuyuser(@RequestParam String orderId, @RequestParam String checkReason) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String gameName = order.getGameName();
        int uid = order.getBuyuserUid();

        notifyOrder(order,
                "【8868租号】您租用的<" + gameName + ">商品的撤单申请审核失败了（" + checkReason + "）！订单将继续有效服务。",
                "在订单有效期内您有两次申请撤单机会，您还有一次申请机会，如有需要可点击【查看详情】进入订单详情重新申请撤单，感谢您的支持。",
                false);
        return succ();
    }

    /***
     * 发送第二次撤单申请失败消息给玩家
     * @param orderId
     * @param checkReason
     */
    @RequestMapping("/sendSecondCancelApplyFailMessageToBuyuser")
    public String sendSecondCancelApplyFailMessageToBuyuser(@RequestParam String orderId, @RequestParam String checkReason) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String gameName = order.getGameName();

        notifyOrder(order,
                "【8868租号】您租用的<" + gameName + ">商品的撤单申请审核失败了（" + checkReason + "）！订单将继续有效服务。",
                "在订单有效期内您的两次申请撤单机会已使用完毕，无法再申请撤单，感谢您的支持。",
                false);
        return succ();
    }

    /**
     * 发送号主等级变动消息给号主
     * @param uid
     * @param currLevel
     * @param previousLevel
     */
    @RequestMapping("/sendSellerLevelChangeMessageToSelluser")
    public String sendSellerLevelChangeMessageToSelluser(@RequestParam int uid, @RequestParam int currLevel, @RequestParam int previousLevel) {
        //等级差
        int levelChange = currLevel - previousLevel;
        String userName = getUserName(uid);

        String currLevelName;
        switch (currLevel) {
            case 0:
                currLevelName = "普通号主";
                break;
            case 1:
                currLevelName = "银牌号主";
                break;
            case 2:
                currLevelName = "金牌号主";
                break;
            default:
                currLevelName = "普通号主";
        }
        //判断是否升级
        List<WxTmplParam> wxParams = new ArrayList<>();
        wxParams.add(new WxTmplParam("keyword1", userName));

        String jpushTitle = null, jpushBrief = null, jpushDesc = null;
        if (levelChange > 0) {
            wxParams.add(new WxTmplParam("keyword2", "等级提升"));
            wxParams.add(new WxTmplParam("first", "恭喜你升级为" + currLevelName + "，点此可查看详情>>"));
            wxParams.add(new WxTmplParam("remark", "请加入8868签约号主群（Q群号：666956436），及时了解平台最新动态，享受签约扶持政策。"));

            jpushTitle = "你的号主等级发生了变化";
            jpushBrief = "恭喜你升级为" + currLevelName + "，点此可查看详情>>";
            jpushDesc = remindSellerLevelChangeUrl;
        } else if (levelChange < 0) {
            wxParams.add(new WxTmplParam("keyword2", "等级下降"));
            wxParams.add(new WxTmplParam("first", "您近期的出租情况不理想，系统已将你的等级调整为" + currLevelName + "，请继续努力！"));
            wxParams.add(new WxTmplParam("remark", "点此可查看详情>>"));

            jpushTitle = "你的号主等级发生了变化";
            jpushBrief = "系统已将你的等级调整为" + currLevelName + "，点此可查看详情>>";
            jpushDesc = remindSellerLevelChangeUrl;
        } else if (levelChange == 0) {
            wxParams.add(new WxTmplParam("keyword2", "等级保持不变"));
            wxParams.add(new WxTmplParam("first", "您的签约申请未通过审核，点此可查看详情>>"));
            wxParams.add(new WxTmplParam("remark", "点此可查看详情>>"));

            jpushTitle = "您的签约申请未通过审核";
            jpushBrief = "您的签约申请未通过审核";
            jpushDesc = remindSellerLevelChangeUrl;
        }

        if (!notifier.sendWx(uid, wxUserLevelChangeTmplId, remindSellerLevelChangeUrl, wxParams)) {
            logger.error("用户【" + uid + "】号主等级微信通知号主失败了-");
        }
        jPushs.pushComMsg(uid, jpushTitle, jpushBrief, jpushDesc);
        return succ();
    }

    /**
     * 发送订单出售成功消息给号主
     *
     * @param orderId
     * @param store  剩余库存
     */
    @RequestMapping("/sendOrderSoldMessageToSelluser")
    public String sendOrderSoldMessageToSelluser(@RequestParam String orderId, @RequestParam int store) {
        OrderEntity order = orderMapper.getOrder(orderId);
        if (order == null)
            return fail("no order");

        String productName = order.getProductName();
        String title = "【8868租号】您的商品<" + productName + ">出售成功，剩余库存：" + store + "件";
        String remark = "";
        //如果库存低于3件，需要附上通知告警号主补货。
        if (store < productCdkWarningCount) {
            remark = "您的商品库存已不足" + productCdkWarningCount + "件，为避免影响您的号主信誉分，请及时补货。";
        }

        notifyOrder(order, title, remark, true);
        return succ();
    }

    /**
     * 发送扣除商品保证金通知给号主
     * @param uid
     * @param selluserPhonenum
     */
    @RequestMapping("/sendDeductProductGuaranteeMessageToSelluser")
    public String sendDeductProductGuaranteeMessageToSelluser(@RequestParam int uid, @RequestParam String selluserPhonenum){
        //发送短信
        if (StringUtils.isNotBlank(selluserPhonenum)) {
            if (!notifier.sendSms(selluserPhonenum, smsConfig.getSMS_20181123(), new JSONObject())) {
                logger.error("因商品被多次撤单扣除保证金，给UID【" + uid + "】发送短信通知失败了。");
            }
        }

        //发送系统消息
        jPushs.pushComMsg(uid, "保证金扣除", "系统检测您可能存在出租虚假商品的违规行为，今日出现撤单问题的商品保证金被扣除。如有异议，请联系客服。", "");
        return succ();
    }

    /**
     * 发送商品扶持审核失败给号主
     * @param productId
     */
    @RequestMapping("/sendProductSupportFailMessageToSelluser")
    public String sendProductSupportFailMessageToSelluser(@RequestParam String productId){
        ProductEntity product = productMapper.getProduct(productId);
        if(product == null)
            return fail("no product");

        int uid = product.getSellerUid();
        String gameName = product.getGameName();

        OrderJpushMessage jpushMessage = OrderJpushMessage.builder()
                .linkUrl(rentServiceHost + "/user/myproducts")
                .title("【8868租号】商品通知")
                .toastBrief("您申请的<" + gameName + ">商品加入扶持福利审核不通过，需7天后且符合资格时才可再次申请加入哦，还有机会等着你。")
                .build();
        _sendJpushMsg(uid, jpushMessage);
        return succ();
    }

    /**
     * 发送JSPUH的运营类消息
     * @param uids
     * @param title
     * @param brief
     * @param content
     */
    @RequestMapping("/sendJpushMessage")
    public String sendJpushMessage(@RequestParam String uids, @RequestParam String title, @RequestParam String brief, @RequestParam String content){
        String[] ss = uids.split("`");
        Integer[] iUids = new Integer[ss.length];
        for(int i=0; i<ss.length; ++i){
            iUids[i] = Integer.valueOf(ss[i]);
        }
        jPushs.pushOpMsg(iUids, title, brief, content);
        return succ();
    }

    /**
     * 根据UID获取用户信息，并组装出一个可用于展示的用户名称
     *
     * @param uid
     * @return
     */
    private String getUserName(int uid) {
        IAccountCenterService accountCenterService = platformService.get(IAccountCenterService.class);

        cn.jugame.account_center.service.vo.MemberBean bean = null;
        try {
            bean = accountCenterService.findMemberByUid(uid);
        } catch (Exception e) {
            logger.error("error", e);
        }

        //获取失败了，则使用UID，保留最后4位即可
        if (bean == null || bean.getData() == null) {
            String s = String.valueOf(uid);
            return "***" + s.substring(s.length() - 4);
        }

        //先用昵称
        Member member = (Member) bean.getData();
        String s = member.getNickName();
        if (StringUtils.isNotBlank(s))
            return s;

        s = member.getMobile();
        if (StringUtils.isNotBlank(s)) {
            return s.substring(0, 4) + "****" + s.substring(s.length() - 3);
        }

        return member.getLoginName();
    }
}
