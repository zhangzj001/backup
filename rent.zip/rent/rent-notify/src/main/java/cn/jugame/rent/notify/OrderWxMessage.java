package cn.jugame.rent.notify;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderWxMessage {
    private String orderId;
    private double orderPayAmount;
    private String productName;
    private String brief;
    private String content;
    private String linkUrl;
}
