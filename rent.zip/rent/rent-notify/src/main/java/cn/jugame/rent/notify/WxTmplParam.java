package cn.jugame.rent.notify;

class WxTmplParam {
    private String key;
    private String value;
    private String color = "#2f54b6";
    public WxTmplParam(String key, Object value, String color){
        this.key = key;
        this.value = String.valueOf(value);
        this.color = color;
    }
    public WxTmplParam(String key, Object value){
        this.key = key;
        this.value = String.valueOf(value);
    }
    public String getKey() {
        return key;
    }
    public String getValue() {
        return value;
    }
    public String getColor() {
        return color;
    }
}
