package cn.jugame.rent.notify;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderJpushMessage {
    private String toastBrief;
    private String title;
    private String linkUrl;
}
