package cn.jugame.rent.notify;

import cn.jiguang.common.ClientConfig;
import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jugame.rent.utils.Loggers;
import net.sf.json.JSONObject;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Service
class JPushs {
    private Logger logger = Loggers.rentLog();

    //租号平台推送
    public final int COMMON_MESSAGE_TYPE = 4;
    //运营消息
    public final int OPERATION_MESSAGE_TYPE = 5;

    @Value("${app.jpush.isdebug}")
    private boolean jpushIsDebug;

    @Value("${app.jpush.master_secret}")
    private String jpushMasterSecret;

    @Value("${app.jpush.appkey}")
    private String jpushAppKey;

    @Value("${app.jpush.rentapp.master_secret}")
    private String jpushRentappMasterSecret;

    @Value("${app.jpush.rentapp.appkey}")
    private String jpushRentappAppKey;

    private JPushClient jpushClient;
    private JPushClient jpushRentClient;

    private boolean isInit = false;

    @PostConstruct
    public void init(){
        if(isInit) return;
        ClientConfig config = ClientConfig.getInstance();
        config.setApnsProduction(!jpushIsDebug);
        config.setReadTimeout(1000);
        this.jpushClient = new JPushClient(jpushMasterSecret, jpushAppKey, null, config);
        this.jpushRentClient = new JPushClient(jpushRentappMasterSecret, jpushRentappAppKey, null, config);
        isInit = true;
    }

    private PushPayload buildPushObject_android_tag_message(List<String> uids, String msg) {
        if (uids == null || uids.size() <= 0) {
            return null;
        }
        if (uids.get(0).equals("-1")) {//uid等于-1的就全推
            return PushPayload.newBuilder().setPlatform(Platform.android()).setAudience(Audience.all()).setMessage(Message.content(msg)).build();
        } else {
            return PushPayload.newBuilder().setPlatform(Platform.android()).setAudience(Audience.alias(uids)).setMessage(Message.content(msg)).build();
        }
    }

    private void sendAndroidMsg(JPushClient client, List<String> uidList, String msg, String appName) {
        try {
            PushPayload payload = buildPushObject_android_tag_message(uidList, msg);
            PushResult rentPr = client.sendPush(payload);
            if (rentPr.isResultOK()) {
                logger.info("JPushClient推送消息到【" + appName + "】成功<|>uidList=" + uidList + "<|>msg=" + msg + "<|>result=" + rentPr.toString());
            } else {
                logger.info("JPushClient推送消息到【" + appName + "】失败<|>uidList=" + uidList + "<|>msg=" + msg + "<|>result=" + rentPr.toString());
            }
        } catch (APIConnectionException | APIRequestException e) {
            logger.error("JPushUtil推送消息到【" + appName + "】失败<|>uidList=" + uidList + "<|>msg=" + msg + "<|>e=" + ExceptionUtils.getMessage(e));
        }
    }

    /**
     * 发送消息，消息示例（格式）:
     * <p>
     *  ：{"type":4,"msg_recv_uid":900151489,
     *  "data":{"brief":"注册30天内绑定有效，过期就领不到了哟~",
     *  "title":"只差1步！绑定手机号即领288元新人红包",
     *  "content":"http://m.8868.cn/help/guide.html"}}
     * </p>
     * @param type
     * @param uidList
     * @param brief
     * @param title
     * @param content
     */
    private void pushMsg(int type, List<String> uidList, String title, String brief, String content){
        JSONObject data = new JSONObject()
                .accumulate("brief", brief)
                .accumulate("title", title)
                .accumulate("content", content);
        JSONObject messageInfo = new JSONObject()
                .accumulate("type", type)
                .accumulate("userId", uidList.size() == 1 ? uidList.get(0) : "-1") //多发的情况下，总是-1
                .accumulate("data", data);

        sendAndroidMsg(jpushClient, uidList, messageInfo.toString(), "8868App");
        sendAndroidMsg(jpushRentClient, uidList, messageInfo.toString(), "8868租号App");
    }

    /**
     * 发送通知消息
     * @param uid
     * @param brief
     * @param title
     * @param content
     */
    public void pushComMsg(Integer uid, String title, String brief, String content){
        List<String> uidList = new ArrayList<String>();
        String sUid = (jpushIsDebug ? "T" : "") + uid + "";
        uidList.add(sUid);
        pushMsg(COMMON_MESSAGE_TYPE, uidList, title, brief, content);
    }

    /**
     * 发送通知消息
     * @param uids
     * @param brief
     * @param title
     * @param content
     */
    public void pushComMsg(Integer[] uids, String title, String brief, String content){
        List<String> uidList = new ArrayList<String>();
        for(int uid : uids){
            String sUid = (jpushIsDebug ? "T" : "") + uid + "";
            uidList.add(sUid);
        }
        pushMsg(COMMON_MESSAGE_TYPE, uidList, title, brief, content);
    }

    /**
     * 发送运营活动消息
     * @param uid
     * @param title
     * @param brief
     * @param content
     */
    public void pushOpMsg(Integer uid, String title, String brief, String content){
        List<String> uidList = new ArrayList<String>();
        String sUid = (jpushIsDebug ? "T" : "") + uid + "";
        uidList.add(sUid);
        pushMsg(OPERATION_MESSAGE_TYPE, uidList, title, brief, content);
    }

    /**
     * 发送运营活动消息
     * @param uids
     * @param title
     * @param brief
     * @param content
     */
    public void pushOpMsg(Integer[] uids, String title, String brief, String content){
        List<String> uidList = new ArrayList<String>();
        for(int uid : uids){
            String sUid = (jpushIsDebug ? "T" : "") + uid + "";
            uidList.add(sUid);
        }
        pushMsg(COMMON_MESSAGE_TYPE, uidList, title, brief, content);
    }
}
