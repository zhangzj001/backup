package cn.jugame.rent.notify.db;

import lombok.Data;

import java.util.Date;

@Data
public class OrderEntity {
    private String orderId;
    private int buyuserUid;
    private int selluserUid;
    private int orderPayAmount;
    private String productId;
    private String productName;
    private String gameId;
    private String gameName;
    private String selluserPhonenum;
    private String buyuserPhonenum;
    private int isFreeCancel;
    private Date rentStartTime;
    private Date rentEndTime;
}
