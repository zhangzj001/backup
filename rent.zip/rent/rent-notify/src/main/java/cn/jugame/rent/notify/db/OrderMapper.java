package cn.jugame.rent.notify.db;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface OrderMapper {
    @Select("select * from `order` where order_id=#{orderId}")
    OrderEntity getOrder(String orderId);
}
