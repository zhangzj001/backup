package cn.jugame.rent.notify;

import cn.jugame.account_center.api.IAccountCenterService;
import cn.jugame.account_center.service.vo.MemberBean;
import cn.jugame.account_center.service.vo.MemberWXBind;
import cn.jugame.rent.utils.Loggers;
import cn.jugame.rent.utils.PlatformService;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
class WxOpenId {
    private Logger logger = Loggers.rentLog();

    @Autowired
    private PlatformService platformService;

    public String get(int uid){
        IAccountCenterService accountCenterService = platformService.get(IAccountCenterService.class);

        String openId = null;
        MemberBean<MemberWXBind> mb = accountCenterService.queryWxInfoByUid(uid, "web");
        if (mb != null && mb.code == 0 && mb.data != null) {
            try{
                JSONObject wxjson = JSONObject.fromObject(mb.data);
                openId = wxjson.getString("openid");
            }catch(Exception e){
                logger.error("WxOpenId.get error", e);
                return null;
            }
        }
        return openId;
    }
}
