package cn.jugame.rent.notify.db;

import lombok.Data;

@Data
public class ProductEntity {
    private String productId;
    private String productName;
    private int sellerUid;
    private String gameName;
    private int onsaleProtectTime;
}
