package cn.jugame.rent;

import java.io.InputStream;

import org.yaml.snakeyaml.Yaml;

import cn.jugame.rent.conf.Service;
import cn.jugame.rent.conf.Upstream;

public class GatewayConfig {
	private Service service;
	private Upstream upstream;
	private String ipServer;
	public Service getService() {
		return service;
	}
	public void setService(Service service) {
		this.service = service;
	}
	public Upstream getUpstream() {
		return upstream;
	}
	public void setUpstream(Upstream upstream) {
		this.upstream = upstream;
	}
	public String getIpServer() {
		return ipServer;
	}
	public void setIpServer(String ipServer) {
		this.ipServer = ipServer;
	}
	
	private GatewayConfig(){}

	private static GatewayConfig read(){
		Yaml yaml = new Yaml();
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("setting.yml");
		GatewayConfig conf = yaml.loadAs(is, GatewayConfig.class);
		try{ is.close(); }catch(Exception e){}
		return conf;
	}
	
	public final static GatewayConfig singleton = read();
	
}
