 package cn.jugame.rent;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.jugame.http.HttpJob;
import cn.jugame.http.HttpRequest;
import cn.jugame.http.HttpResponse;
import cn.jugame.http.HttpService;
import cn.jugame.rent.plugin.QuartzPlugin;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Gateway extends HttpJob{
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private GatewayConfig conf = GatewayConfig.singleton;
	public Gateway(){
		setAutoGzip(false);
	}
	
	private OkHttpClient client = new OkHttpClient.Builder()
											.followRedirects(false)
											.followSslRedirects(false)
											.connectTimeout(conf.getUpstream().getConnTimeout(), TimeUnit.SECONDS)
											.readTimeout(conf.getUpstream().getReadTimeout(), TimeUnit.SECONDS)
											.writeTimeout(conf.getUpstream().getWriteTimeout(), TimeUnit.SECONDS)
											.build();
	
	/**
	 * 对UA进行转码，OKHttp会对UA进行检查，某些国产手机的UA带上了中文就会导致OKHttp进行检查时抛出异常。
	 * @param userAgent
	 * @return
	 */
	private String encodeUserAgent(String userAgent) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0, length = userAgent.length(); i < length; i++) {
			char c = userAgent.charAt(i);
			if (c <= '\u001f' || c >= '\u007f') {
				stringBuffer.append(String.format("\\u%04x", (int) c));
			} else {
				stringBuffer.append(c);
			}
		}
		return stringBuffer.toString();
	}
	
	@Override
	protected boolean handleRequest(HttpRequest req, HttpResponse resp) {
		String host = req.getHeader("Host");
		if(StringUtils.isBlank(host)){
			resp.setStatusCode(400);
			resp.setContent("Invalid Host");
			logger.info("11111111111111111");
			return true;
		}
		logger.info("client host: " + host);
		
		//如果包含端口，将端口去掉
		String[] ss = host.split(":");
		if(ss.length > 1){
			host = ss[0];
		}
		
		ServerRouter router = ServerRouter.get(host);
		if(router == null){
			resp.setStatusCode(403);
			resp.setContent("Forbidden");
			logger.info("2222222222222");
			return true;
		}
		
		while(true){
			//反向代理后端机地址
			String targetServer = router.route(req);
			if(StringUtils.isBlank(targetServer)){
				resp.setStatusCode(503);
				resp.setContent("Server is temporary unavailable");
				logger.info("333333333333333333");
				return true;
			}
			String targetUrl = "http://" + targetServer + req.getUri();
			logger.info("Host:" + host + ", 反向代理: " + targetUrl);
			
 			//要求必须有Content-Type
			if(StringUtils.isBlank(req.getContentType())){
				resp.setStatusCode(400);
				resp.setContent("Invalid Content-Type");
				logger.info("444444444444444444444");
				return true;
			}
	
			Request.Builder proxyReqBuilder = new Request.Builder().url(targetUrl);
			proxyReqBuilder.cacheControl(CacheControl.FORCE_NETWORK);

			//带上反向代理的标识
			proxyReqBuilder.header("X-Jugame", "JugameGateway");
			//判断pc平台还是wap平台
			String clientType = ClientType.parse(req);
			proxyReqBuilder.header("Client-Type", clientType);
			
			//将请求过来的头部全部带上
			for(Entry<String, String> e : req.getHeaders().entrySet()){
				String value = e.getValue();
				if("User-Agent".equalsIgnoreCase(e.getKey())){
					value = encodeUserAgent(value);
				}
				proxyReqBuilder.header(e.getKey(), value);
			}
			
			//修改host为目标的host
			proxyReqBuilder.header("Host", targetServer);
			proxyReqBuilder.header("Referer", targetUrl);

			// 获取归属地
//			String ip = IP.getIp(req);
//			JSONObject localtion = IP.findLocation(ip);
//			if(localtion != null){
//				proxyReqBuilder.header("Client-Location", Common.url_encode(localtion.toString()));
//			}
			
			logger.info("req.getMethod() => " + req.getMethod());
			Request proxyReq = null;
			if("GET".equalsIgnoreCase(req.getMethod())){
				proxyReq = proxyReqBuilder.get().build();
			}
			if("POST".equalsIgnoreCase(req.getMethod())){
				RequestBody body = RequestBody.create(MediaType.parse(req.getContentType()), req.getData());
				proxyReq = proxyReqBuilder.post(body).build();
			}
			if("HEAD".equalsIgnoreCase(req.getMethod())){
				proxyReq = proxyReqBuilder.head().build();
			}
			if("PUT".equalsIgnoreCase(req.getMethod())){
				RequestBody body = RequestBody.create(MediaType.parse(req.getContentType()), req.getData());
				proxyReq = proxyReqBuilder.put(body).build();
			}
			if("DELETE".equalsIgnoreCase(req.getMethod())){
				RequestBody body = RequestBody.create(MediaType.parse(req.getContentType()), req.getData());
				proxyReq = proxyReqBuilder.delete(body).build();
			}
			if("PATCH".equalsIgnoreCase(req.getMethod())){
				RequestBody body = RequestBody.create(MediaType.parse(req.getContentType()), req.getData());
				proxyReq = proxyReqBuilder.patch(body).build();
			}
			
			//XXX 其它类型的头部暂时不支持，以后再说吧！
			if(proxyReq == null){
				resp.setStatusCode(403);
				resp.setContent("Forbidden");
				logger.info("666666666666666666666666");
				return true;
			}
			
			Response proxyResp = null;
			try{
				proxyResp = client.newCall(proxyReq).execute();
				
				//设置响应头部
				Headers hs = proxyResp.headers();
				for(String name : hs.names()){
					if("Transfer-Encoding".equalsIgnoreCase(name))
						continue;
					resp.setHeader(name, hs.get(name));
				}
				//将平台分类写入响应cookie中，以便客户端下次访问时再带上来
				ClientType.setClientType(clientType, req, resp);
				
				byte[] respBytes = proxyResp.body().bytes();
				logger.info("proxy: " + targetUrl + ", fetch bytes: " + respBytes.length);
				
				resp.setStatusCode(proxyResp.code());
				resp.setStatusMsg(proxyResp.message());
				resp.setContent(respBytes);
				logger.info("7777777777777777777");
			}
			catch(ConnectException | UnknownHostException | SocketTimeoutException e){
				logger.info("xxxxxxxxxxxxxxxxxxxxxx");
				//这种情况，踢掉异常节点
				router.down(targetServer);
				continue;
			}
			catch(Exception e){
				e.printStackTrace();
				resp.setStatusCode(502);
				resp.setContent("bad gateway");
				logger.info("8888888888888888888888");
			}
			
			return true;
		}
	}
	
	public static void main(String[] args) {
		//启动定时任务
    	if(!new QuartzPlugin().start()){
    		System.out.println("quartz启动失败！！！！！");
    		return;
		}
		
		HttpService service = new HttpService(new Gateway());
		service.setReactorCount(GatewayConfig.singleton.getService().getReactorCount());
		service.setWorderCount(GatewayConfig.singleton.getService().getWorkerCount());
		service.setPort(GatewayConfig.singleton.getService().getPort());
		if(!service.init()){
			System.err.println("初始化服务失败");
			return;
		}
		service.run();
		System.out.println("impossible here!!");
	}
	
}
