package cn.jugame.rent.conf;

public class Service {
	private int reactorCount;
	private int workerCount;
	private int port;
	public int getReactorCount() {
		return reactorCount;
	}
	public void setReactorCount(int reactorCount) {
		this.reactorCount = reactorCount;
	}
	public int getWorkerCount() {
		return workerCount;
	}
	public void setWorkerCount(int workerCount) {
		this.workerCount = workerCount;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
}
