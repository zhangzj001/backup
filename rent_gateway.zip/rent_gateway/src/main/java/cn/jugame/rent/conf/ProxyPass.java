package cn.jugame.rent.conf;

import java.util.ArrayList;
import java.util.List;

public class ProxyPass {
	private String server;
	private int weight;
	private List<String> force = new ArrayList<String>();
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public List<String> getForce() {
		return force;
	}
	public void setForce(List<String> force) {
		this.force = force;
	}
}
