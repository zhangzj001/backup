package cn.jugame.rent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import cn.jugame.http.HttpRequest;
import cn.jugame.rent.conf.ProxyPass;
import cn.jugame.rent.conf.UpstreamServer;

public class ServerRouter {
	
	/** 保存可用后端服务信息 */
	private LinkedList<ProxyPass> goodServers = new LinkedList<>();
	/** 保存宕机后端服务信息 */
	private LinkedList<ProxyPass> badServers = new LinkedList<>();
	
	private ServerRouter(List<ProxyPass> proxy){
		goodServers.addAll(proxy);
	}
	
	private static Map<String, ServerRouter> servers = new HashMap<>();
	
	/**
	 * 获取Host对应的反向代理配置
	 * @param host
	 * @return
	 */
	public static ServerRouter get(String host){
		if(!servers.containsKey(host)){
			for(UpstreamServer server : GatewayConfig.singleton.getUpstream().getServers()){
				if(host.equalsIgnoreCase(server.getHost())){
					servers.put(host, new ServerRouter(server.getProxy()));
				}
			}
		}
		return servers.get(host);
	}
	
	private int index = 0;
	private String routeRobin(){
		List<String> list = servers();
		if(list.size() == 0)
			return null;
		return list.get(index++%list.size());
	}
	
	private List<String> servers(){
		synchronized(goodServers){
			List<String> list = new ArrayList<>();
			for(ProxyPass sc : goodServers){
				for(int i=0; i<sc.getWeight(); ++i){
					list.add(sc.getServer());
				}
			}
			return list;
		}
	}

	public String route(HttpRequest req){
		if(goodServers.size() == 0)
			return null;
		
		//通过客户端IP进行哈希，若没有IP则使用轮询方式
		String clientIp = IP.getIp(req);
		if(StringUtils.isBlank(clientIp)){
			return routeRobin();
		}
		
		//若该IP需要强制走某个后端机，则返回该后端机
		for(ProxyPass uServer : goodServers){
			if(uServer.getForce().contains(clientIp)){
				return uServer.getServer();
			}
		}

		int hash = 0;
		String[] portions = clientIp.split("\\.");
		//取IP前三段
		for(int i=0; i<portions.length-1; ++i){
			int p = Integer.parseInt(portions[i]);
			//这个hash方法抄自nginx
			hash = (hash * 113 + p) % 6271;
		}
		
		List<String> list = servers();
		return list.get(hash % list.size());
	}
	
	/**
	 * 标记某个后端机已经宕机
	 * @param server
	 */
	public void down(String server){
		synchronized (goodServers) {
			Iterator<ProxyPass> it = goodServers.iterator();
			while(it.hasNext()){
				ProxyPass sc = it.next();
				if(sc.getServer().equalsIgnoreCase(server)){
					it.remove();
					badServers.add(sc);
					break;
				}
			}
		}
	}
	
	public void retryBad(){
		if(badServers.size() == 0)
			return;
		goodServers.add(badServers.removeFirst());
	}
}
