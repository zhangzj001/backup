package cn.jugame.rent;

import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;

import cn.jugame.http.HttpRequest;
import cn.jugame.rent.utils.Common;
import net.sf.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class IP {
	//可用于获取客户端真实IP的头部信息
	private static final String[] IP_HEADER_CANDIDATES = {
			"X-real-ip",
			"X-Forwarded-For",
			"Proxy-Client-IP",
			"WL-Proxy-Client-IP",
			"HTTP_X_FORWARDED_FOR",
			"HTTP_X_FORWARDED",
			"HTTP_X_CLUSTER_CLIENT_IP",
			"HTTP_CLIENT_IP",
			"HTTP_FORWARDED_FOR",
			"HTTP_FORWARDED",
			"HTTP_VIA",
			"REMOTE_ADDR"
	};
	
	/**
	 * 获取请求的ip地址
	 * @param request
	 * @return
	 */
	public static String getIp(HttpRequest request) {
		for (String name : IP_HEADER_CANDIDATES) {
			String h = request.getHeader(name);
			if (StringUtils.isNotBlank(h) && !"unknown".equalsIgnoreCase(h)) {
				//如果有多段IP，则取第一段
				String[] ips = Common.array_filter(h.split(","));
				return ips[0].trim();
			}
		}
		InetSocketAddress sa = request.getRemoteAddress();
		if(sa == null)
			return null;
		return sa.getHostName();
	}
	
	private static OkHttpClient client = new OkHttpClient.Builder().build();
	
	/**
	 * 识别IP的归属地，返回的json可能包含3个字段：country、prov、city，有可能没有prov、city字段。
	 * @param ip
	 * @return
	 */
	public static JSONObject findLocation(String ip){
		String url = GatewayConfig.singleton.getIpServer() + ip;
		
		Request req = new Request.Builder().url(url).get().build();
		
		try{
			Response resp = client.newCall(req).execute();
			String str = resp.body().string();
			
			JSONObject json = JSONObject.fromObject(str);
			return json;
		}catch(Exception e){
			return null;
		}
	}
}
