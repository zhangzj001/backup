package cn.jugame.rent.plugin;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Properties;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QuartzPlugin {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private Scheduler scheduler;
	
	public QuartzPlugin(){
		initQuartz();
	}
	
	private void initQuartz(){
		Properties properties = new Properties();
		try {
			InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("job.properties");
			properties.load(is);
			is.close();
		}catch(Exception e){
			logger.error("error", e);
			return;
		}
		
		try{
			SchedulerFactory sf = new StdSchedulerFactory();
			scheduler = sf.getScheduler();
			
			//遍历所有的任务并启动
			Enumeration<Object> e = properties.keys();
			while(e.hasMoreElements()){
				String cls = String.valueOf(e.nextElement());
				String cron = properties.getProperty(cls);

				//新线程执行守护
				if("daemon".equals(cron)){
					logger.info("开始启动后台任务：" + cls);
					Class c = Class.forName(cls);
					final Object obj = c.newInstance();
					final Method m = c.getDeclaredMethod("execute");
					new Thread(){
						@Override
						public void run() {
							try{m.invoke(obj);}catch(Exception e){e.printStackTrace();}
						};
					}.start();
				}
				//普通的定时任务
				else{
					logger.info("开始启动定时任务：" + cls);
					Class c = Class.forName(cls);
					JobDetail job = JobBuilder.newJob(c).withIdentity(cls, "group").build();
					CronTrigger trigger = TriggerBuilder.newTrigger()  
						    .withIdentity(cls +  "_trigger", "group")
						    .withSchedule(CronScheduleBuilder.cronSchedule(cron))
						    .build();
					scheduler.scheduleJob(job, trigger);
				}
			}
		}catch(Exception e){
			logger.error("error", e);
			scheduler = null;
		}
	}
	
	public boolean start() {
		if(scheduler == null)
			return false;
		try{
			scheduler.start();
			return true;
		}catch(Exception e){
			logger.error("error", e);
			return false;
		}
	}
	
	public boolean stop() {
		if(scheduler != null){
			try{scheduler.shutdown();}catch(Exception e){logger.error("error", e);}
		}
		return true;
	}
	
}
