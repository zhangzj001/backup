package cn.jugame.rent.conf;

import java.util.ArrayList;
import java.util.List;

public class UpstreamServer {
	private String host;
	private List<ProxyPass> proxy = new ArrayList<>();
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public List<ProxyPass> getProxy() {
		return proxy;
	}
	public void setProxy(List<ProxyPass> proxy) {
		this.proxy = proxy;
	}
}
