package cn.jugame.rent.conf;

import java.util.List;

public class Upstream {
	private int connTimeout;
	private int readTimeout;
	private int writeTimeout;
	private List<UpstreamServer> servers;
	public int getConnTimeout() {
		return connTimeout;
	}
	public void setConnTimeout(int connTimeout) {
		this.connTimeout = connTimeout;
	}
	public int getReadTimeout() {
		return readTimeout;
	}
	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}
	public int getWriteTimeout() {
		return writeTimeout;
	}
	public void setWriteTimeout(int writeTimeout) {
		this.writeTimeout = writeTimeout;
	}
	public List<UpstreamServer> getServers() {
		return servers;
	}
	public void setServers(List<UpstreamServer> servers) {
		this.servers = servers;
	}
	
}
