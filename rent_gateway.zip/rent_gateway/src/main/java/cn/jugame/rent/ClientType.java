package cn.jugame.rent;

import java.net.HttpCookie;
import java.util.Map;
import java.util.TreeMap;

import cn.jugame.http.HttpRequest;
import cn.jugame.http.HttpResponse;
import cn.jugame.util.Common;

/**
 * 客户端类型
 */
public class ClientType {
	
	/**
	 * 平台类型：手机版
	 */
	public static final String PLATFORM_WAP = "wap";
	
	/**
	 * 平台类型：PC版
	 */
	public static final String PLATFORM_PC = "pc";
	
	private static Map<String, String> parseParams(String queryString){
		TreeMap<String, String> params = new TreeMap<String, String>();
		String[] ss = queryString.split("&");
		for(int i=0; i<ss.length; ++i){
			String[] kv = ss[i].split("=");
			if(kv.length == 2){
				String k = kv[0].trim();
				String v = Common.url_decode(kv[1].trim());
				params.put(k, v);
			}
		}
		return params;
	}

	/**
	 * 判断用户访问的平台类型<br>
	 * 1. 优先从参数__v判断<br>
	 * 2. 从UA判断
	 * 
	 * @param req
	 * @return
	 */
	public static String parse(HttpRequest req) {
		// queryStrign 带有__v参数，优先判断
		Map<String, String> queryStrParam = parseParams(req.getQueryString());
		String v = queryStrParam.get("__v");
		if (v != null) {
			if ("wap".equalsIgnoreCase(v)) {
				return PLATFORM_WAP;
			} else {
				return PLATFORM_PC;
			}
		}
		
		// 判断UA
		boolean isMobile = false;
		String userAgent = req.getHeader("User-Agent");
		if (userAgent != null) {
			userAgent = userAgent.toLowerCase();

			// 现有 Android UA 都包含有 Mobile Safari 字符串
			boolean isAndroid = userAgent.indexOf("mobile safari") > 0;
			boolean isAndroid2 = userAgent.contains("Android") || userAgent.contains("android");
			// 现有 IOS 都包含 iPhone/iPad/iPod
			boolean isIOS = false;
			if (!isAndroid && !isAndroid2) {
				isIOS = userAgent.indexOf("iphone") > 0 || userAgent.indexOf("ipod") > 0 || userAgent.indexOf("ipad") > 0;
			}
			// Windows Phone UA 中包含 IEMobile
			boolean isIEMobile = userAgent.indexOf("iemobile") > 0;

			if (isAndroid || isIOS || isIEMobile || isAndroid2) {
				isMobile = true;
			}
			return isMobile ? PLATFORM_WAP : PLATFORM_PC;
		}
		
		// 默认走wap
		return PLATFORM_WAP;
	}
	
	/**
	 * 设置客户端client_type到响应cookie中
	 * @param type
	 * @param resp
	 */
	public static void setClientType(String type, HttpRequest req, HttpResponse resp){
		//客户端已经具有这个cookie了，不再重复设置
		if(req.getCookie("client_type") != null)
			return;
		
		resp.setCookie(new HttpCookie("client_type", type));
	}
}
