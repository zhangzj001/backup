package cn.jugame.rent;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import cn.jugame.rent.conf.UpstreamServer;

/**
 * 每隔一小段时间将失效的反向代理地址重新设置为有效来重试服务器是否已经重启
 * @author ASUS
 *
 */
public class ServerRouterTask implements Job{

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		for(UpstreamServer server : GatewayConfig.singleton.getUpstream().getServers()){
			ServerRouter.get(server.getHost()).retryBad();
		}
	}
}
