package cn.jugame.rent.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Loggers {
	public static Logger getLogger(Class<?> cls){
		return LoggerFactory.getLogger(cls);
	}
	
	public static Logger checkaccountLogger(){
		return LoggerFactory.getLogger("checkaccount_task");
	}
	
	public static Logger eventLogger(){
		return LoggerFactory.getLogger("event");
	}
}
